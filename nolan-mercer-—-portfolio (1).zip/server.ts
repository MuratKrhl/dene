import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import type { Request, Response } from 'express';
import { createTechHubRouter } from './server/techHubRouter';
import { startBackendScheduler } from './server/rssCollector';
import { createMediaRouter } from './server/media/mediaRouter';
import { startMediaScheduler } from './server/media/mediaCollector';

import net from 'net';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const FEED_TIMEOUT_MS = 20_000;
const FEED_CACHE_TTL_MS = 10 * 60_000;
const YOUTUBE_API_CACHE_TTL_MS = 60 * 60_000;
const FEED_UPSTREAM_SPACING_MS = 150;
const rssCache = new Map<string, { body: string; contentType: string; cachedAt: number }>();
const youtubeApiCache = new Map<string, { payload: unknown; cachedAt: number }>();
const inFlightUpstreamFetches = new Map<
  string,
  Promise<{
    status: number;
    contentType: string;
    body: string;
    cacheState: 'fresh' | 'stale' | 'miss';
  }>
>();

const ALLOWED_FEED_HOSTS = new Set([
  'medium.com',
  'developers.redhat.com',
  'www.redhat.com',
  'blogs.oracle.com',
  'inside.java',
  'kubernetes.io',
  'aws.amazon.com',
  'blog.cloudflare.com',
  'netflixtechblog.com',
  'github.blog',
  'react.dev',
  'nodejs.org',
  'devblogs.microsoft.com',
  'feeds.feedburner.com',
  'www.bleepingcomputer.com',
  'krebsonsecurity.com',
  'www.securityweek.com',
  'www.cisa.gov',
  'openai.com',
  'deepmind.google',
]);

let upstreamQueueTail: Promise<void> = Promise.resolve();

function scheduleUpstreamSlot<T>(task: () => Promise<T>): Promise<T> {
  const run = upstreamQueueTail.then(async () => {
    const result = await task();
    await new Promise((r) => setTimeout(r, FEED_UPSTREAM_SPACING_MS));
    return result;
  });
  upstreamQueueTail = run.then(
    () => undefined,
    () => undefined
  );
  return run;
}

function isAllowedMediumFeedUrl(rawUrl: string): URL | null {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:') {
      return null;
    }
    const host = parsed.hostname.toLowerCase();
    const isMediumHost = host === 'medium.com' || host.endsWith('.medium.com');
    if (!isMediumHost) {
      return null;
    }
    if (!parsed.pathname.startsWith('/feed')) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function isPrivateOrBlockedHost(hostname: string): boolean {
  const host = hostname.trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (
    host === 'localhost' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host.endsWith('.localhost')
  ) {
    return true;
  }
  const ipVersion = net.isIP(host);
  if (ipVersion === 4) {
    const parts = host.split('.').map(Number);
    if (parts[0] === 10 || parts[0] === 127 || parts[0] === 0) return true;
    if (parts[0] === 169 && parts[1] === 254) return true;
    if (parts[0] === 192 && parts[1] === 168) return true;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  }
  if (ipVersion === 6) {
    if (host === '::1' || host.startsWith('fc') || host.startsWith('fd') || host.startsWith('fe80')) {
      return true;
    }
  }
  return false;
}

function isAllowedTechnologyFeedUrl(rawUrl: string): URL | null {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:') return null;
    if (parsed.username || parsed.password) return null;
    if (isPrivateOrBlockedHost(parsed.hostname)) return null;
    return parsed;
  } catch {
    return null;
  }
}

function isAllowedAggregatedFeedUrl(rawUrl: string): URL | null {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:') {
      return null;
    }
    const host = parsed.hostname.toLowerCase();
    if (host === 'medium.com' || host.endsWith('.medium.com')) {
      return parsed.pathname.startsWith('/feed') ? parsed : null;
    }
    if (!ALLOWED_FEED_HOSTS.has(host)) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

async function fetchUpstreamFeedOnce(feedUrl: string): Promise<{
  status: number;
  contentType: string;
  body: string;
  retryAfterMs: number;
}> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FEED_TIMEOUT_MS);

  try {
    const upstream = await fetch(feedUrl, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; WorkspaceFeedReader/1.0)',
        Accept:
          'application/rss+xml, application/atom+xml, application/feed+json, application/xml, text/xml, application/json;q=0.9, */*;q=0.8',
      },
      redirect: 'follow',
      signal: controller.signal,
    });

    const retryHeader = upstream.headers.get('retry-after');
    const parsedRetrySec = retryHeader ? Number(retryHeader) : NaN;
    const retryAfterMs =
      !Number.isNaN(parsedRetrySec) && parsedRetrySec > 0
        ? Math.min(parsedRetrySec * 1000, 2000)
        : 800;

    const body = await upstream.text();
    return {
      status: upstream.status,
      contentType:
        upstream.headers.get('content-type') || 'application/xml; charset=utf-8',
      body,
      retryAfterMs,
    };
  } finally {
    clearTimeout(timer);
  }
}

async function fetchFeedWithCache(feedUrl: string): Promise<{
  status: number;
  contentType: string;
  body: string;
  cacheState: 'fresh' | 'stale' | 'miss';
}> {
  const cached = rssCache.get(feedUrl);
  if (cached && Date.now() - cached.cachedAt < FEED_CACHE_TTL_MS) {
    return {
      status: 200,
      contentType: cached.contentType,
      body: cached.body,
      cacheState: 'fresh',
    };
  }

  // Prevent duplicate concurrent upstream fetches for the same feed URL
  const existingInFlight = inFlightUpstreamFetches.get(feedUrl);
  if (existingInFlight) {
    return existingInFlight;
  }

  const fetchPromise = (async () => {
    let result: Awaited<ReturnType<typeof fetchUpstreamFeedOnce>>;
    try {
      result = await scheduleUpstreamSlot(() => fetchUpstreamFeedOnce(feedUrl));
      if (result.status === 429 || result.status >= 500) {
        await new Promise((r) => setTimeout(r, result.retryAfterMs));
        result = await scheduleUpstreamSlot(() => fetchUpstreamFeedOnce(feedUrl));
      }
    } catch {
      // Single retry on transient upstream socket/timeout error
      await new Promise((r) => setTimeout(r, 600));
      result = await scheduleUpstreamSlot(() => fetchUpstreamFeedOnce(feedUrl));
    }

    if ((result.status < 200 || result.status >= 300) && cached) {
      return {
        status: 200,
        contentType: cached.contentType,
        body: cached.body,
        cacheState: 'stale' as const,
      };
    }

    return {
      status: result.status,
      contentType: result.contentType,
      body: result.body,
      cacheState: 'miss' as const,
    };
  })();

  inFlightUpstreamFetches.set(feedUrl, fetchPromise);
  try {
    return await fetchPromise;
  } finally {
    inFlightUpstreamFetches.delete(feedUrl);
  }
}

function isValidFeedPayload(body: string, contentType: string): boolean {
  const trimmed = body.trim();
  if (!trimmed) return false;
  const lowerHead = trimmed.slice(0, 200).toLowerCase();
  if (lowerHead.startsWith('<!doctype html') || lowerHead.startsWith('<html')) {
    return false;
  }
  if (
    trimmed.startsWith('<?xml') ||
    trimmed.includes('<rss') ||
    trimmed.includes('<feed')
  ) {
    return true;
  }
  if (
    contentType.toLowerCase().includes('json') ||
    trimmed.startsWith('{') ||
    trimmed.startsWith('[')
  ) {
    try {
      const parsed = JSON.parse(trimmed) as
        | { items?: unknown; vulnerabilities?: unknown; totalResults?: unknown }
        | unknown[];
      if (Array.isArray(parsed)) return true;
      return (
        Array.isArray(parsed.items) ||
        Array.isArray(parsed.vulnerabilities) ||
        typeof parsed.totalResults === 'number'
      );
    } catch {
      return false;
    }
  }
  return false;
}

async function handleFeedProxyRequest(
  validatedUrl: URL,
  res: Response,
  label: string
): Promise<void> {
  try {
    const targetUrl = validatedUrl.toString();
    const result = await fetchFeedWithCache(targetUrl);

    if (result.status < 200 || result.status >= 300) {
      const message =
        result.status === 429
          ? `${label} temporarily rate-limited requests (HTTP 429). Retry shortly; existing articles remain saved.`
          : `Upstream ${label} responded with HTTP ${result.status}.`;
      res.status(result.status).json({
        error: message,
        status: result.status,
      });
      return;
    }

    if (!result.body.trim()) {
      res.status(502).json({
        error: `Upstream ${label} returned an empty response body.`,
      });
      return;
    }

    if (!isValidFeedPayload(result.body, result.contentType)) {
      res.status(502).json({
        error: `Upstream ${label} response is not valid RSS, Atom XML, or JSON Feed.`,
      });
      return;
    }

    const normalizedContentType = result.body.trim().startsWith('{')
      ? 'application/feed+json; charset=utf-8'
      : 'application/xml; charset=utf-8';

    if (result.cacheState === 'miss') {
      rssCache.set(targetUrl, {
        body: result.body,
        contentType: normalizedContentType,
        cachedAt: Date.now(),
      });
    }
    res.setHeader('Content-Type', normalizedContentType);
    res.setHeader('Cache-Control', 'public, max-age=300');
    res.setHeader('X-Feed-Cache', result.cacheState);
    res.status(200).send(result.body);
  } catch (err) {
    const isAbort =
      err instanceof Error &&
      (err.name === 'AbortError' || err.message.toLowerCase().includes('abort'));
    if (isAbort) {
      res.status(504).json({
        error: `${label} request timed out after ${FEED_TIMEOUT_MS}ms.`,
      });
      return;
    }

    const message =
      err instanceof Error ? err.message : 'Unknown upstream fetch error';
    console.error('[feed-proxy] Fetch failure:', validatedUrl.toString(), message);
    res.status(502).json({
      error: `Failed to fetch ${label}: ${message}`,
    });
  }
}

async function createApp() {
  const app = express();

  app.get('/api/medium/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      service: 'medium-rss-proxy',
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/articles/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      service: 'multi-source-article-feed-proxy',
      allowedHosts: Array.from(ALLOWED_FEED_HOSTS),
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/medium/rss', async (req: Request, res: Response) => {
    const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
    if (!rawUrl) {
      res.status(400).json({
        error: 'Missing required "url" query parameter.',
      });
      return;
    }

    const validatedUrl = isAllowedMediumFeedUrl(rawUrl);
    if (!validatedUrl) {
      res.status(400).json({
        error:
          'Only HTTPS Medium RSS feed URLs (https://medium.com/feed/...) are permitted.',
      });
      return;
    }

    await handleFeedProxyRequest(validatedUrl, res, 'Medium RSS');
  });

  app.get('/api/articles/feed', async (req: Request, res: Response) => {
    const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
    if (!rawUrl) {
      res.status(400).json({
        error: 'Missing required "url" query parameter.',
      });
      return;
    }

    const validatedUrl = isAllowedAggregatedFeedUrl(rawUrl);
    if (!validatedUrl) {
      res.status(400).json({
        error: 'Requested feed host is not in the approved article source allowlist.',
      });
      return;
    }

    await handleFeedProxyRequest(validatedUrl, res, 'Article Feed');
  });

  app.get('/api/technology/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      service: 'workspace-technology-center-proxy',
      youtubeApiConfigured: Boolean(process.env.YOUTUBE_API_KEY?.trim()),
      nvdApiConfigured: Boolean(process.env.NVD_API_KEY?.trim()),
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/technology/feed', async (req: Request, res: Response) => {
    const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
    if (!rawUrl) {
      res.status(400).json({ error: 'Missing required "url" query parameter.' });
      return;
    }
    const validatedUrl = isAllowedTechnologyFeedUrl(rawUrl);
    if (!validatedUrl) {
      res.status(400).json({
        error: 'Only public HTTPS feed URLs are permitted (private/local hosts are blocked).',
      });
      return;
    }
    await handleFeedProxyRequest(validatedUrl, res, 'Technology Feed');
  });

  app.get('/api/technology/youtube/videos', async (req: Request, res: Response) => {
    const channelId =
      typeof req.query.channelId === 'string' ? req.query.channelId.trim() : '';
    const maxResultsRaw = Number(req.query.maxResults) || 15;
    const maxResults = Math.max(1, Math.min(25, maxResultsRaw));

    if (!/^UC[a-zA-Z0-9_-]{20,30}$/.test(channelId)) {
      res.status(400).json({ error: 'Invalid YouTube channelId format.' });
      return;
    }

    const apiKey = process.env.YOUTUBE_API_KEY?.trim();
    if (!apiKey) {
      // Official public YouTube Channel Atom feed fallback (no API key required)
      const atomUrl = new URL(
        `https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`
      );
      await handleFeedProxyRequest(atomUrl, res, 'YouTube Channel Atom');
      return;
    }

    const cacheKey = `${channelId}:${maxResults}`;
    const cached = youtubeApiCache.get(cacheKey);
    if (cached && Date.now() - cached.cachedAt < YOUTUBE_API_CACHE_TTL_MS) {
      res.json(cached.payload);
      return;
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FEED_TIMEOUT_MS);
    try {
      const chRes = await fetch(
        `https://www.googleapis.com/youtube/v3/channels?part=contentDetails,snippet&id=${encodeURIComponent(channelId)}&key=${encodeURIComponent(apiKey)}`,
        { signal: controller.signal }
      );
      if (chRes.status === 403 || chRes.status === 429) {
        const errBody = await chRes.text();
        res.status(429).json({
          error: 'YouTube Data API quota exceeded or key rejected.',
          quotaExceeded: errBody.toLowerCase().includes('quota'),
          status: chRes.status,
        });
        return;
      }
      if (!chRes.ok) {
        res.status(chRes.status).json({
          error: `YouTube Data API channels request failed (HTTP ${chRes.status}).`,
        });
        return;
      }
      const chJson = (await chRes.json()) as {
        items?: Array<{
          snippet?: { title?: string };
          contentDetails?: { relatedPlaylists?: { uploads?: string } };
        }>;
      };
      const channelItem = chJson.items?.[0];
      const uploadsPlaylistId =
        channelItem?.contentDetails?.relatedPlaylists?.uploads;
      if (!uploadsPlaylistId) {
        res.status(404).json({ error: 'Channel uploads playlist not found.' });
        return;
      }

      const plRes = await fetch(
        `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&playlistId=${encodeURIComponent(uploadsPlaylistId)}&maxResults=${maxResults}&key=${encodeURIComponent(apiKey)}`,
        { signal: controller.signal }
      );
      if (!plRes.ok) {
        res.status(plRes.status).json({
          error: `YouTube Data API playlistItems request failed (HTTP ${plRes.status}).`,
          quotaExceeded: plRes.status === 403 || plRes.status === 429,
        });
        return;
      }
      const plJson = (await plRes.json()) as {
        items?: Array<{
          snippet?: {
            title?: string;
            description?: string;
            publishedAt?: string;
            channelTitle?: string;
            thumbnails?: {
              maxres?: { url?: string };
              high?: { url?: string };
              medium?: { url?: string };
            };
          };
          contentDetails?: { videoId?: string; videoPublishedAt?: string };
        }>;
      };

      const videoIds = (plJson.items || [])
        .map((i) => i.contentDetails?.videoId)
        .filter((v): v is string => Boolean(v));

      const durationsById = new Map<string, string>();
      if (videoIds.length > 0) {
        const vidRes = await fetch(
          `https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id=${encodeURIComponent(videoIds.join(','))}&key=${encodeURIComponent(apiKey)}`,
          { signal: controller.signal }
        );
        if (vidRes.ok) {
          const vidJson = (await vidRes.json()) as {
            items?: Array<{
              id?: string;
              contentDetails?: { duration?: string };
            }>;
          };
          for (const v of vidJson.items || []) {
            if (v.id && v.contentDetails?.duration) {
              durationsById.set(v.id, v.contentDetails.duration);
            }
          }
        }
      }

      const payload = {
        ok: true,
        mode: 'youtube-data-api',
        channelId,
        channelTitle: channelItem?.snippet?.title || '',
        items: (plJson.items || []).map((entry) => {
          const videoId = entry.contentDetails?.videoId || '';
          const thumbs = entry.snippet?.thumbnails;
          return {
            videoId,
            title: entry.snippet?.title || '',
            description: entry.snippet?.description || '',
            channelName:
              entry.snippet?.channelTitle || channelItem?.snippet?.title || '',
            channelId,
            publishedAt:
              entry.contentDetails?.videoPublishedAt ||
              entry.snippet?.publishedAt ||
              null,
            thumbnailUrl:
              thumbs?.maxres?.url || thumbs?.high?.url || thumbs?.medium?.url || null,
            videoUrl: videoId
              ? `https://www.youtube.com/watch?v=${videoId}`
              : '',
            isoDuration: durationsById.get(videoId) || null,
          };
        }),
      };

      youtubeApiCache.set(cacheKey, { payload, cachedAt: Date.now() });
      res.json(payload);
    } catch (err) {
      res.status(502).json({
        error:
          err instanceof Error ? err.message : 'YouTube Data API request failed.',
      });
    } finally {
      clearTimeout(timer);
    }
  });

  app.use('/api/tech-hub', createTechHubRouter());
  app.use('/api/tech-media', createMediaRouter());

  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  return app;
}

createApp()
  .then((app) => {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`Workspace server listening on http://0.0.0.0:${PORT}`);
      startBackendScheduler();
      startMediaScheduler();
    });
  })
  .catch((err) => {
    console.error('Failed to start Workspace server:', err);
    process.exit(1);
  });
