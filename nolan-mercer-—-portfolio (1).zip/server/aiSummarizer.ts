import { GoogleGenAI, Type } from '@google/genai';
import {
  AiImportanceLevel,
  loadTechHubDb,
  saveTechHubDb,
  TechHubArticle,
} from './techHubDb';

const GEMINI_MODEL = 'gemini-4-hydrogen';

export interface AiAnalysisResult {
  turkishSummary: string;
  technicalConcepts: string[];
  keyPoints: string[];
  domainRelevance: string[];
  importance: AiImportanceLevel;
  suggestedTags: string[];
}

export function isGeminiConfigured(): boolean {
  return Boolean(process.env.GEMINI_API_KEY?.trim());
}

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function normalizeImportance(raw: string | undefined): AiImportanceLevel {
  const val = (raw || '').trim().toLowerCase();
  if (val === 'critical') return 'Critical';
  if (val === 'high') return 'High';
  if (val === 'low') return 'Low';
  return 'Medium';
}

export async function analyzeArticleWithAi(
  article: TechHubArticle,
  sourceName: string,
  categoryNames: string[]
): Promise<{ ok: true; analysis: AiAnalysisResult } | { ok: false; error: string }> {
  const ai = getGeminiClient();
  if (!ai) {
    return {
      ok: false,
      error: 'Server GEMINI_API_KEY is not configured. AI summarization is optional and disabled.',
    };
  }

  const prompt = [
    'Analyze the following technical article metadata and produce structured engineering intelligence in JSON.',
    'Write turkishSummary and keyPoints in clear, concise, accurate Turkish.',
    'Do not invent facts beyond what is supported by the title, source, categories, and description.',
    '',
    `Source: ${sourceName}`,
    `Categories: ${categoryNames.join(', ') || 'General'}`,
    `Published At: ${article.publishedAt || 'Unknown'}`,
    `Original URL: ${article.url}`,
    `Title: ${article.title}`,
    `Description: ${article.description || 'No description provided.'}`,
  ].join('\n');

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        systemInstruction:
          'You are a senior enterprise platform and security architect. Summarize technical articles concisely in Turkish, extract key technical concepts, bullet key takeaways, assess relevance to Middleware, Java, Kubernetes, OpenShift, Security, and Cloud, assign technical importance (Critical, High, Medium, Low), and suggest concise technical tags.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            turkishSummary: {
              type: Type.STRING,
              description: 'Concise 2-4 sentence technical summary in Turkish.',
            },
            technicalConcepts: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 to 6 core technical concepts, protocols, or tools mentioned.',
            },
            keyPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 to 5 bullet key points in Turkish.',
            },
            domainRelevance: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description:
                'Relevant domains chosen from: Middleware, Java, Kubernetes, OpenShift, Security, Cloud.',
            },
            importance: {
              type: Type.STRING,
              description: 'One of: Critical, High, Medium, Low',
            },
            suggestedTags: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 to 5 lowercase kebab-case technical tags.',
            },
          },
          required: [
            'turkishSummary',
            'technicalConcepts',
            'keyPoints',
            'domainRelevance',
            'importance',
            'suggestedTags',
          ],
        },
      },
    });

    const text = response.text?.trim();
    if (!text) {
      return { ok: false, error: 'Gemini returned an empty response.' };
    }

    const parsed = JSON.parse(text) as Partial<AiAnalysisResult>;
    const allowedDomains = new Set([
      'Middleware',
      'Java',
      'Kubernetes',
      'OpenShift',
      'Security',
      'Cloud',
    ]);

    const analysis: AiAnalysisResult = {
      turkishSummary: String(parsed.turkishSummary || '').trim(),
      technicalConcepts: Array.isArray(parsed.technicalConcepts)
        ? parsed.technicalConcepts.map((s) => String(s).trim()).filter(Boolean).slice(0, 8)
        : [],
      keyPoints: Array.isArray(parsed.keyPoints)
        ? parsed.keyPoints.map((s) => String(s).trim()).filter(Boolean).slice(0, 6)
        : [],
      domainRelevance: Array.isArray(parsed.domainRelevance)
        ? parsed.domainRelevance
            .map((s) => String(s).trim())
            .filter((s) => allowedDomains.has(s))
        : [],
      importance: normalizeImportance(parsed.importance),
      suggestedTags: Array.isArray(parsed.suggestedTags)
        ? parsed.suggestedTags
            .map((s) => String(s).trim().toLowerCase().replace(/\s+/g, '-'))
            .filter(Boolean)
            .slice(0, 6)
        : [],
    };

    return { ok: true, analysis };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'AI analysis failed';
    return { ok: false, error: message };
  }
}

export async function summarizeAndPersistArticle(
  articleId: string
): Promise<
  | { ok: true; article: TechHubArticle }
  | { ok: false; status: number; error: string }
> {
  const db = loadTechHubDb();
  const article = db.articles.find((a) => a.id === articleId);
  if (!article) {
    return { ok: false, status: 404, error: 'Article not found.' };
  }

  const source = db.sources.find((s) => s.id === article.sourceId);
  const catIds = new Set(
    db.articleCategories.filter((ac) => ac.articleId === article.id).map((ac) => ac.categoryId)
  );
  const catNames = db.categories.filter((c) => catIds.has(c.id)).map((c) => c.name);

  const result = await analyzeArticleWithAi(
    article,
    source?.name || 'Unknown Source',
    catNames
  );
  if (!result.ok) {
    return { ok: false, status: isGeminiConfigured() ? 502 : 503, error: result.error };
  }

  article.aiSummaryTr = result.analysis.turkishSummary;
  article.aiTechnicalConcepts = result.analysis.technicalConcepts;
  article.aiKeyPoints = result.analysis.keyPoints;
  article.aiDomainRelevance = result.analysis.domainRelevance;
  article.aiImportance = result.analysis.importance;
  article.aiGeneratedAt = new Date().toISOString();
  article.aiModel = GEMINI_MODEL;

  const existingTagSet = new Set(
    db.articleTags
      .filter((t) => t.articleId === article.id)
      .map((t) => t.tag.toLowerCase())
  );
  for (const tag of result.analysis.suggestedTags) {
    if (!existingTagSet.has(tag.toLowerCase())) {
      existingTagSet.add(tag.toLowerCase());
      db.articleTags.push({ articleId: article.id, tag, origin: 'ai' });
    }
  }

  await saveTechHubDb(db);
  return { ok: true, article };
}

export function findSimilarArticles(
  targetId: string,
  limit = 4
): Array<{ id: string; title: string; sourceName: string; url: string; publishedAt: string | null; score: number }> {
  const db = loadTechHubDb();
  const target = db.articles.find((a) => a.id === targetId);
  if (!target) return [];

  const targetCats = new Set(
    db.articleCategories.filter((c) => c.articleId === targetId).map((c) => c.categoryId)
  );
  const targetTags = new Set(
    db.articleTags.filter((t) => t.articleId === targetId).map((t) => t.tag.toLowerCase())
  );
  const targetConcepts = new Set(target.aiTechnicalConcepts.map((c) => c.toLowerCase()));
  const targetWords = new Set(
    target.title
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .filter((w) => w.length >= 4)
  );

  const sourceMap = new Map(db.sources.map((s) => [s.id, s.name]));
  const catsByArticle = new Map<string, string[]>();
  for (const ac of db.articleCategories) {
    const arr = catsByArticle.get(ac.articleId) || [];
    arr.push(ac.categoryId);
    catsByArticle.set(ac.articleId, arr);
  }
  const tagsByArticle = new Map<string, string[]>();
  for (const at of db.articleTags) {
    const arr = tagsByArticle.get(at.articleId) || [];
    arr.push(at.tag.toLowerCase());
    tagsByArticle.set(at.articleId, arr);
  }

  const scored = db.articles
    .filter((a) => a.id !== targetId)
    .map((candidate) => {
      let score = 0;
      for (const c of catsByArticle.get(candidate.id) || []) {
        if (targetCats.has(c)) score += 2;
      }
      for (const t of tagsByArticle.get(candidate.id) || []) {
        if (targetTags.has(t)) score += 3;
      }
      for (const concept of candidate.aiTechnicalConcepts) {
        if (targetConcepts.has(concept.toLowerCase())) score += 4;
      }
      const words = candidate.title
        .toLowerCase()
        .split(/[^a-z0-9]+/)
        .filter((w) => w.length >= 4);
      for (const w of words) {
        if (targetWords.has(w)) score += 1;
      }
      return {
        id: candidate.id,
        title: candidate.title,
        sourceName: sourceMap.get(candidate.sourceId) || 'Source',
        url: candidate.url,
        publishedAt: candidate.publishedAt,
        score,
      };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored.slice(0, limit);
}
