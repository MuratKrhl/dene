import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '..', 'data');
const DB_FILE_PATH = path.join(DATA_DIR, 'tech-knowledge-hub.json');
const DB_TMP_PATH = path.join(DATA_DIR, 'tech-knowledge-hub.json.tmp');

export type FeedValidationStatus = 'verified' | 'unverified' | 'error';
export type TechFeedType = 'rss' | 'atom' | 'unverified';
export type AiImportanceLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export interface TechCategory {
  id: string;
  slug: string;
  name: string;
  sortOrder: number;
}

export interface TechHubSource {
  id: string;
  name: string;
  siteUrl: string;
  feedUrl: string;
  feedType: TechFeedType;
  validationStatus: FeedValidationStatus;
  validationNote: string | null;
  enabled: boolean;
  keywordFilter: string[] | null;
  etag: string | null;
  lastModified: string | null;
  lastScanAt: string | null;
  lastSuccessAt: string | null;
  lastError: string | null;
  lastHttpStatus: number | null;
  totalFetched: number;
  createdAt: string;
  updatedAt: string;
}

export interface SourceCategoryLink {
  sourceId: string;
  categoryId: string;
}

export interface TechHubArticle {
  id: string;
  guid: string;
  canonicalUrl: string;
  contentHash: string;
  sourceId: string;
  title: string;
  url: string;
  author: string | null;
  description: string;
  imageUrl?: string | null;
  contentPreview?: string[];
  publishedAt: string | null;
  fetchedAt: string;
  isArchived: boolean;
  archivedAt: string | null;
  aiSummaryTr: string | null;
  aiTechnicalConcepts: string[];
  aiKeyPoints: string[];
  aiDomainRelevance: string[];
  aiImportance: AiImportanceLevel | null;
  aiGeneratedAt: string | null;
  aiModel: string | null;
}

export interface ArticleCategoryLink {
  articleId: string;
  categoryId: string;
}

export interface ArticleTagRecord {
  articleId: string;
  tag: string;
  origin: 'feed' | 'ai' | 'rule';
}

export interface ArticleNoteRecord {
  articleId: string;
  note: string;
  updatedAt: string;
}

export interface ArticleUserStateRecord {
  articleId: string;
  isRead: boolean;
  isFavorite: boolean;
  readAt: string | null;
  updatedAt: string;
}

export interface ScanHistoryRecord {
  id: string;
  startedAt: string;
  finishedAt: string;
  trigger: 'startup' | 'scheduled' | 'manual' | 'source';
  sourceId: string | null;
  sourceName: string;
  status: 'success' | 'not_modified' | 'partial' | 'error' | 'skipped';
  httpStatus: number | null;
  itemsFound: number;
  newAdded: number;
  duplicatesSkipped: number;
  errorMessage: string | null;
  durationMs: number;
}

export interface TechHubAiConfig {
  enabled: boolean;
  autoSummarizeOnScan: boolean;
  maxAutoPerScan: number;
  focusDomains: string[];
}

export interface TechHubSchedulerState {
  intervalHours: number;
  autoSyncEnabled: boolean;
  lastGlobalScanAt: string | null;
  lastSuccessfulGlobalScanAt: string | null;
}

export interface TechHubDatabase {
  schemaVersion: number;
  categories: TechCategory[];
  sources: TechHubSource[];
  sourceCategories: SourceCategoryLink[];
  articles: TechHubArticle[];
  articleCategories: ArticleCategoryLink[];
  articleTags: ArticleTagRecord[];
  articleNotes: ArticleNoteRecord[];
  articleUserState: ArticleUserStateRecord[];
  scanHistory: ScanHistoryRecord[];
  aiConfig: TechHubAiConfig;
  scheduler: TechHubSchedulerState;
}

export const EXACT_CATEGORIES: Array<{ id: string; slug: string; name: string }> = [
  { id: 'cat-kubernetes', slug: 'kubernetes', name: 'Kubernetes' },
  { id: 'cat-nginx', slug: 'nginx', name: 'Nginx' },
  { id: 'cat-powercurve', slug: 'powercurve', name: 'PowerCurve' },
  { id: 'cat-evam', slug: 'evam', name: 'Evam' },
  { id: 'cat-aws', slug: 'aws', name: 'AWS' },
  { id: 'cat-cloudflare', slug: 'cloudflare', name: 'Cloudflare' },
  { id: 'cat-github', slug: 'github', name: 'GitHub' },
  { id: 'cat-security', slug: 'security', name: 'Security' },
  { id: 'cat-java', slug: 'java', name: 'Java' },
  { id: 'cat-ai', slug: 'ai', name: 'AI' },
  { id: 'cat-istio', slug: 'istio', name: 'Istio' },
  { id: 'cat-openshift', slug: 'openshift', name: 'OpenShift' },
  { id: 'cat-elasticsearch', slug: 'elasticsearch', name: 'Elasticsearch' },
  { id: 'cat-devops', slug: 'devops', name: 'DevOps' },
  { id: 'cat-jenkins', slug: 'jenkins', name: 'Jenkins' },
  { id: 'cat-provenir', slug: 'provenir', name: 'Provenir' },
];

interface SeedSourceDef {
  id: string;
  name: string;
  siteUrl: string;
  feedUrl: string;
  feedType: TechFeedType;
  validationStatus: FeedValidationStatus;
  validationNote: string | null;
  enabled: boolean;
  categoryIds: string[];
  keywordFilter?: string[] | null;
}

const INITIAL_SEED_SOURCES: SeedSourceDef[] = [
  // Kubernetes & OpenShift (shared Red Hat feeds without duplication)
  {
    id: 'src-kubernetes-blog',
    name: 'Kubernetes Blog',
    siteUrl: 'https://kubernetes.io/blog/',
    feedUrl: 'https://kubernetes.io/feed.xml',
    feedType: 'atom',
    validationStatus: 'verified',
    validationNote: 'Verified live XML Atom feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-kubernetes', 'cat-devops'],
  },
  {
    id: 'src-redhat-developer',
    name: 'Red Hat Developer',
    siteUrl: 'https://developers.redhat.com/blog',
    feedUrl: 'https://developers.redhat.com/blog/feed',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Shared verified RSS feed for OpenShift, Kubernetes, Java, and DevOps.',
    enabled: true,
    categoryIds: ['cat-kubernetes', 'cat-openshift', 'cat-java', 'cat-devops'],
  },
  {
    id: 'src-redhat-blog',
    name: 'Red Hat Blog',
    siteUrl: 'https://www.redhat.com/en/blog',
    feedUrl: 'https://www.redhat.com/en/rss/blog',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Shared verified RSS feed classified via title/summary/tags across OpenShift, Kubernetes, Security, and AI.',
    enabled: true,
    categoryIds: ['cat-kubernetes', 'cat-openshift', 'cat-devops', 'cat-security'],
  },

  // Nginx
  {
    id: 'src-nginx-community',
    name: 'NGINX Community Blog',
    siteUrl: 'https://blog.nginx.org/',
    feedUrl: 'https://blog.nginx.org/feed',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live RSS 2.0 feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-nginx', 'cat-devops'],
  },
  {
    id: 'src-f5-nginx-blog',
    name: 'F5 NGINX Blog',
    siteUrl: 'https://www.f5.com/company/blog',
    feedUrl: '',
    feedType: 'unverified',
    validationStatus: 'unverified',
    validationNote: 'HTML page only; no official RSS/Atom feed link discovered. Enter a manual RSS URL or run Auto-Discover to activate.',
    enabled: false,
    categoryIds: ['cat-nginx', 'cat-security'],
  },

  // PowerCurve
  {
    id: 'src-fico-powercurve',
    name: 'FICO Blog (PowerCurve Filter)',
    siteUrl: 'https://www.fico.com/blogs',
    feedUrl: 'https://www.fico.com/blogs/rss.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified RSS feed filtered strictly for PowerCurve-related entries.',
    enabled: true,
    categoryIds: ['cat-powercurve'],
    keywordFilter: ['powercurve', 'power curve'],
  },
  {
    id: 'src-fico-main',
    name: 'FICO Main Portal',
    siteUrl: 'https://www.fico.com/',
    feedUrl: '',
    feedType: 'unverified',
    validationStatus: 'unverified',
    validationNote: 'Corporate HTML homepage without RSS/Atom feed. Kept inactive.',
    enabled: false,
    categoryIds: ['cat-powercurve'],
  },

  // Evam
  {
    id: 'src-evam-blog',
    name: 'Evam Blog',
    siteUrl: 'https://evam.com/blog/',
    feedUrl: '',
    feedType: 'unverified',
    validationStatus: 'unverified',
    validationNote: 'No RSS/Atom feed exposed on /blog/ or /feed/. Sitemap.xml exists for manual inspection; kept inactive.',
    enabled: false,
    categoryIds: ['cat-evam'],
  },
  {
    id: 'src-evam-resources',
    name: 'Evam Resources',
    siteUrl: 'https://evam.com/',
    feedUrl: '',
    feedType: 'unverified',
    validationStatus: 'unverified',
    validationNote: 'Corporate site without RSS/Atom endpoint. Never mislabeled as RSS; kept inactive.',
    enabled: false,
    categoryIds: ['cat-evam'],
  },

  // AWS
  {
    id: 'src-aws-news',
    name: 'AWS News Blog',
    siteUrl: 'https://aws.amazon.com/blogs/aws/',
    feedUrl: 'https://aws.amazon.com/blogs/aws/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official AWS News RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-aws', 'cat-devops'],
  },
  {
    id: 'src-aws-architecture',
    name: 'AWS Architecture Blog',
    siteUrl: 'https://aws.amazon.com/blogs/architecture/',
    feedUrl: 'https://aws.amazon.com/blogs/architecture/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official AWS Architecture RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-aws', 'cat-kubernetes'],
  },
  {
    id: 'src-aws-security',
    name: 'AWS Security Blog',
    siteUrl: 'https://aws.amazon.com/blogs/security/',
    feedUrl: 'https://aws.amazon.com/blogs/security/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official AWS Security RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-aws', 'cat-security'],
  },
  {
    id: 'src-aws-main-legacy',
    name: 'AWS Main Blog Feed',
    siteUrl: 'https://aws.amazon.com/blogs/',
    feedUrl: 'https://aws.amazon.com/blogs/feed/',
    feedType: 'unverified',
    validationStatus: 'unverified',
    validationNote: 'Endpoint returned HTTP 404 during verification. Kept inactive; use specific AWS feeds.',
    enabled: false,
    categoryIds: ['cat-aws'],
  },

  // Cloudflare
  {
    id: 'src-cloudflare-blog',
    name: 'Cloudflare Blog',
    siteUrl: 'https://blog.cloudflare.com/',
    feedUrl: 'https://blog.cloudflare.com/rss/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live RSS 2.0 feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-cloudflare', 'cat-devops'],
  },
  {
    id: 'src-cloudflare-security',
    name: 'Cloudflare Security Blog',
    siteUrl: 'https://blog.cloudflare.com/tag/security/',
    feedUrl: 'https://blog.cloudflare.com/tag/security/rss/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live Cloudflare Security RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-cloudflare', 'cat-security'],
  },

  // GitHub
  {
    id: 'src-github-blog',
    name: 'GitHub Blog',
    siteUrl: 'https://github.blog/',
    feedUrl: 'https://github.blog/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official GitHub Blog RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-github', 'cat-devops', 'cat-ai'],
  },
  {
    id: 'src-github-changelog',
    name: 'GitHub Changelog',
    siteUrl: 'https://github.blog/changelog/',
    feedUrl: 'https://github.blog/changelog/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official GitHub Changelog RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-github', 'cat-devops'],
  },
  {
    id: 'src-github-security',
    name: 'GitHub Security Blog',
    siteUrl: 'https://github.blog/category/security/',
    feedUrl: 'https://github.blog/category/security/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official GitHub Security RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-github', 'cat-security'],
  },

  // Security
  {
    id: 'src-the-hacker-news',
    name: 'The Hacker News',
    siteUrl: 'https://thehackernews.com/',
    feedUrl: 'https://feeds.feedburner.com/TheHackersNews',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live cybersecurity news RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-security'],
  },
  {
    id: 'src-cisa-advisories',
    name: 'CISA Cybersecurity Advisories',
    siteUrl: 'https://www.cisa.gov/news-events/cybersecurity-advisories',
    feedUrl: 'https://www.cisa.gov/cybersecurity-advisories/all.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official CISA advisories XML feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-security'],
  },
  {
    id: 'src-owasp-feed',
    name: 'OWASP RSS Feed',
    siteUrl: 'https://owasp.org/',
    feedUrl: 'https://owasp.org/www/rss_feed.xml',
    feedType: 'unverified',
    validationStatus: 'unverified',
    validationNote: 'Configured feed URL returned HTTP 404 during verification. Kept inactive until valid RSS URL is supplied.',
    enabled: false,
    categoryIds: ['cat-security'],
  },
  {
    id: 'src-nist-nvd-rss',
    name: 'NIST NVD CVE RSS (Legacy)',
    siteUrl: 'https://nvd.nist.gov/',
    feedUrl: 'https://nvd.nist.gov/feeds/xml/cve/misc/nvd-rss.xml',
    feedType: 'unverified',
    validationStatus: 'unverified',
    validationNote: 'NIST retired legacy nvd-rss.xml (HTTP 404). Kept inactive.',
    enabled: false,
    categoryIds: ['cat-security'],
  },
  {
    id: 'src-bleepingcomputer',
    name: 'BleepingComputer',
    siteUrl: 'https://www.bleepingcomputer.com/',
    feedUrl: 'https://www.bleepingcomputer.com/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-security'],
  },
  {
    id: 'src-krebs-security',
    name: 'Krebs on Security',
    siteUrl: 'https://krebsonsecurity.com/',
    feedUrl: 'https://krebsonsecurity.com/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-security'],
  },
  {
    id: 'src-snyk-blog',
    name: 'Snyk Blog',
    siteUrl: 'https://snyk.io/blog/',
    feedUrl: 'https://snyk.io/blog/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live AppSec/DevSecOps RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-security', 'cat-devops', 'cat-java'],
  },
  {
    id: 'src-microsoft-security',
    name: 'Microsoft Security Blog',
    siteUrl: 'https://www.microsoft.com/en-us/security/blog/',
    feedUrl: 'https://www.microsoft.com/en-us/security/blog/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-security', 'cat-ai'],
  },

  // Java
  {
    id: 'src-baeldung',
    name: 'Baeldung',
    siteUrl: 'https://www.baeldung.com/',
    feedUrl: 'https://www.baeldung.com/feed',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live Java/Spring RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-java'],
  },
  {
    id: 'src-infoq-java',
    name: 'InfoQ Java',
    siteUrl: 'https://www.infoq.com/java/',
    feedUrl: 'https://feed.infoq.com/java/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live InfoQ Java RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-java'],
  },
  {
    id: 'src-oracle-java',
    name: 'Oracle Java Blog',
    siteUrl: 'https://blogs.oracle.com/java/',
    feedUrl: 'https://blogs.oracle.com/java/rss',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official Oracle Java RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-java'],
  },
  {
    id: 'src-wildfly-news',
    name: 'WildFly News',
    siteUrl: 'https://www.wildfly.org/news/',
    feedUrl: 'https://www.wildfly.org/feed.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official WildFly RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-java', 'cat-openshift'],
  },

  // AI
  {
    id: 'src-huggingface-blog',
    name: 'Hugging Face Blog',
    siteUrl: 'https://huggingface.co/blog',
    feedUrl: 'https://huggingface.co/blog/feed.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official Hugging Face RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-ai'],
  },
  {
    id: 'src-google-research',
    name: 'Google Research Blog',
    siteUrl: 'https://research.google/blog/',
    feedUrl: 'https://research.google/blog/rss/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official Google Research RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-ai'],
  },
  {
    id: 'src-openai-news',
    name: 'OpenAI News',
    siteUrl: 'https://openai.com/news/',
    feedUrl: 'https://openai.com/news/rss.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official OpenAI RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-ai'],
  },
  {
    id: 'src-deepmind-blog',
    name: 'Google DeepMind Blog',
    siteUrl: 'https://deepmind.google/discover/blog/',
    feedUrl: 'https://deepmind.google/blog/rss.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official Google DeepMind RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-ai'],
  },
  {
    id: 'src-anthropic-news',
    name: 'Anthropic News',
    siteUrl: 'https://www.anthropic.com/news',
    feedUrl: 'https://www.anthropic.com/news/rss.xml',
    feedType: 'unverified',
    validationStatus: 'unverified',
    validationNote: 'Official URL returned HTTP 404 during verification. Kept inactive per source validation rule.',
    enabled: false,
    categoryIds: ['cat-ai'],
  },

  // Istio
  {
    id: 'src-istio-blog',
    name: 'Istio Blog',
    siteUrl: 'https://istio.io/latest/blog/',
    feedUrl: 'https://istio.io/latest/blog/feed.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Auto-discovered and verified Istio Blog RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-istio', 'cat-kubernetes'],
  },
  {
    id: 'src-istio-news',
    name: 'Istio Security & News',
    siteUrl: 'https://istio.io/latest/news/',
    feedUrl: 'https://istio.io/latest/news/feed.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified Istio News RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-istio', 'cat-kubernetes', 'cat-security'],
  },

  // Elasticsearch
  {
    id: 'src-elastic-blog',
    name: 'Elastic Blog',
    siteUrl: 'https://www.elastic.co/blog',
    feedUrl: 'https://www.elastic.co/blog/feed',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Auto-discovered and verified Elastic Blog RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-elasticsearch', 'cat-ai'],
  },
  {
    id: 'src-elastic-security-labs',
    name: 'Elastic Security Labs',
    siteUrl: 'https://www.elastic.co/security-labs/',
    feedUrl: 'https://www.elastic.co/security-labs/rss.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Auto-discovered and verified Elastic Security Labs RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-elasticsearch', 'cat-security'],
  },

  // DevOps
  {
    id: 'src-infoq-devops',
    name: 'InfoQ DevOps',
    siteUrl: 'https://www.infoq.com/devops/',
    feedUrl: 'https://feed.infoq.com/devops/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live InfoQ DevOps RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-devops', 'cat-kubernetes'],
  },
  {
    id: 'src-opentelemetry-blog',
    name: 'OpenTelemetry Blog',
    siteUrl: 'https://opentelemetry.io/blog/',
    feedUrl: 'https://opentelemetry.io/blog/index.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified live OpenTelemetry Blog RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-devops', 'cat-kubernetes'],
  },
  {
    id: 'src-ansible-community',
    name: 'Ansible / Red Hat Open Source',
    siteUrl: 'https://www.ansible.com/blog/',
    feedUrl: 'https://www.redhat.com/en/rss/blog/channel/open-source-communities',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Discovered official Red Hat Open Source Communities RSS link from ansible.com/blog/ (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-devops', 'cat-openshift'],
  },
  {
    id: 'src-martin-fowler',
    name: 'Martin Fowler',
    siteUrl: 'https://martinfowler.com/',
    feedUrl: 'https://martinfowler.com/feed.atom',
    feedType: 'atom',
    validationStatus: 'verified',
    validationNote: 'Verified official Atom feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-devops', 'cat-java'],
  },

  // Jenkins
  {
    id: 'src-jenkins-blog',
    name: 'Jenkins Blog & News',
    siteUrl: 'https://www.jenkins.io/blog/',
    feedUrl: 'https://www.jenkins.io/rss.xml',
    feedType: 'atom',
    validationStatus: 'verified',
    validationNote: 'Verified official Jenkins Atom feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-jenkins', 'cat-devops'],
  },
  {
    id: 'src-jenkins-security',
    name: 'Jenkins Security Advisories',
    siteUrl: 'https://www.jenkins.io/security/advisories/',
    feedUrl: 'https://www.jenkins.io/security/advisories/rss.xml',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Verified official Jenkins Security Advisories RSS feed (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-jenkins', 'cat-security', 'cat-devops'],
  },

  // Provenir
  {
    id: 'src-provenir-blog',
    name: 'Provenir Blog & Resources',
    siteUrl: 'https://www.provenir.com/resources/',
    feedUrl: 'https://www.provenir.com/feed/',
    feedType: 'rss',
    validationStatus: 'verified',
    validationNote: 'Auto-discovered WordPress RSS feed via HTML <link rel="alternate"> (HTTP 200).',
    enabled: true,
    categoryIds: ['cat-provenir', 'cat-ai'],
  },
];

function createDefaultDatabase(): TechHubDatabase {
  const now = new Date().toISOString();
  const categories: TechCategory[] = EXACT_CATEGORIES.map((c, idx) => ({
    id: c.id,
    slug: c.slug,
    name: c.name,
    sortOrder: idx + 1,
  }));

  const sources: TechHubSource[] = INITIAL_SEED_SOURCES.map((s) => ({
    id: s.id,
    name: s.name,
    siteUrl: s.siteUrl,
    feedUrl: s.feedUrl,
    feedType: s.feedType,
    validationStatus: s.validationStatus,
    validationNote: s.validationNote,
    enabled: s.enabled,
    keywordFilter: s.keywordFilter ?? null,
    etag: null,
    lastModified: null,
    lastScanAt: null,
    lastSuccessAt: null,
    lastError: null,
    lastHttpStatus: null,
    totalFetched: 0,
    createdAt: now,
    updatedAt: now,
  }));

  const sourceCategories: SourceCategoryLink[] = [];
  for (const s of INITIAL_SEED_SOURCES) {
    for (const catId of s.categoryIds) {
      sourceCategories.push({ sourceId: s.id, categoryId: catId });
    }
  }

  return {
    schemaVersion: 1,
    categories,
    sources,
    sourceCategories,
    articles: [],
    articleCategories: [],
    articleTags: [],
    articleNotes: [],
    articleUserState: [],
    scanHistory: [],
    aiConfig: {
      enabled: true,
      autoSummarizeOnScan: false,
      maxAutoPerScan: 5,
      focusDomains: ['Middleware', 'Java', 'Kubernetes', 'OpenShift', 'Security', 'Cloud'],
    },
    scheduler: {
      intervalHours: 3,
      autoSyncEnabled: true,
      lastGlobalScanAt: null,
      lastSuccessfulGlobalScanAt: null,
    },
  };
}

let cachedDb: TechHubDatabase | null = null;
let writeTail: Promise<void> = Promise.resolve();

function ensureExactCategories(db: TechHubDatabase): void {
  const existingMap = new Map(db.categories.map((c) => [c.id, c]));
  db.categories = EXACT_CATEGORIES.map((c, idx) => ({
    ...(existingMap.get(c.id) || {}),
    id: c.id,
    slug: c.slug,
    name: c.name,
    sortOrder: idx + 1,
  }));
}

export function loadTechHubDb(): TechHubDatabase {
  if (cachedDb) return cachedDb;

  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_FILE_PATH)) {
      const raw = fs.readFileSync(DB_FILE_PATH, 'utf8');
      const parsed = JSON.parse(raw) as Partial<TechHubDatabase>;
      const defaults = createDefaultDatabase();
      const db: TechHubDatabase = {
        schemaVersion: 1,
        categories: Array.isArray(parsed.categories) ? parsed.categories : defaults.categories,
        sources: Array.isArray(parsed.sources) ? parsed.sources : defaults.sources,
        sourceCategories: Array.isArray(parsed.sourceCategories)
          ? parsed.sourceCategories
          : defaults.sourceCategories,
        articles: Array.isArray(parsed.articles) ? parsed.articles : [],
        articleCategories: Array.isArray(parsed.articleCategories) ? parsed.articleCategories : [],
        articleTags: Array.isArray(parsed.articleTags) ? parsed.articleTags : [],
        articleNotes: Array.isArray(parsed.articleNotes) ? parsed.articleNotes : [],
        articleUserState: Array.isArray(parsed.articleUserState) ? parsed.articleUserState : [],
        scanHistory: Array.isArray(parsed.scanHistory) ? parsed.scanHistory : [],
        aiConfig: parsed.aiConfig ? { ...defaults.aiConfig, ...parsed.aiConfig } : defaults.aiConfig,
        scheduler: parsed.scheduler ? { ...defaults.scheduler, ...parsed.scheduler } : defaults.scheduler,
      };
      ensureExactCategories(db);
      cachedDb = db;
      return cachedDb;
    }
  } catch (err) {
    console.error('[tech-hub-db] Failed to read existing DB, initializing fresh store:', err);
  }

  cachedDb = createDefaultDatabase();
  saveTechHubDbSync(cachedDb);
  return cachedDb;
}

export function saveTechHubDbSync(db: TechHubDatabase): void {
  cachedDb = db;
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const serialized = JSON.stringify(db, null, 2);
  fs.writeFileSync(DB_TMP_PATH, serialized, 'utf8');
  fs.renameSync(DB_TMP_PATH, DB_FILE_PATH);
}

export function saveTechHubDb(db: TechHubDatabase): Promise<void> {
  cachedDb = db;
  writeTail = writeTail.then(async () => {
    if (!fs.existsSync(DATA_DIR)) {
      await fs.promises.mkdir(DATA_DIR, { recursive: true });
    }
    const serialized = JSON.stringify(db, null, 2);
    await fs.promises.writeFile(DB_TMP_PATH, serialized, 'utf8');
    await fs.promises.rename(DB_TMP_PATH, DB_FILE_PATH);
  });
  return writeTail;
}

export function normalizeCanonicalUrl(rawUrl: string): string {
  try {
    const parsed = new URL(rawUrl.trim());
    parsed.hash = '';
    const dropParams = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'ref', 'source'];
    for (const p of dropParams) {
      parsed.searchParams.delete(p);
    }
    const pathname = parsed.pathname.replace(/\/+$/, '') || '/';
    parsed.pathname = pathname;
    return parsed.toString();
  } catch {
    return rawUrl.trim();
  }
}

export function computeContentHash(title: string, url: string, publishedAt: string | null): string {
  const normalizedTitle = title.trim().toLowerCase().replace(/\s+/g, ' ');
  const normalizedUrl = normalizeCanonicalUrl(url).toLowerCase();
  const payload = `${normalizedTitle}|${normalizedUrl}|${publishedAt || ''}`;
  return crypto.createHash('sha256').update(payload).digest('hex');
}

export function makeId(prefix: string): string {
  return `${prefix}-${crypto.randomUUID()}`;
}
