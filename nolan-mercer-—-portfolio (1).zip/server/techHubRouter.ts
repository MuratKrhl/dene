import express, { Router } from 'express';
import type { Request, Response } from 'express';
import {
  findSimilarArticles,
  isGeminiConfigured,
  summarizeAndPersistArticle,
} from './aiSummarizer';
import {
  discoverFeedsForSite,
  getScanStatus,
  runGlobalScan,
  scanSingleSource,
  testFeedConnection,
  validatePublicHttpsUrl,
} from './rssCollector';
import {
  loadTechHubDb,
  makeId,
  saveTechHubDb,
  TechHubSource,
} from './techHubDb';

export function createTechHubRouter(): Router {
  const router = Router();
  router.use(express.json({ limit: '1mb' }));

  // Categories (16 fixed backend-managed categories + live counts)
  router.get('/categories', (_req: Request, res: Response) => {
    const db = loadTechHubDb();
    const articleMap = new Map(db.articles.map((a) => [a.id, a]));
    const activeCount = new Map<string, number>();
    const archivedCount = new Map<string, number>();
    const sourceCount = new Map<string, number>();

    for (const sc of db.sourceCategories) {
      sourceCount.set(sc.categoryId, (sourceCount.get(sc.categoryId) || 0) + 1);
    }
    for (const ac of db.articleCategories) {
      const art = articleMap.get(ac.articleId);
      if (!art) continue;
      if (art.isArchived) {
        archivedCount.set(ac.categoryId, (archivedCount.get(ac.categoryId) || 0) + 1);
      } else {
        activeCount.set(ac.categoryId, (activeCount.get(ac.categoryId) || 0) + 1);
      }
    }

    res.json({
      categories: db.categories
        .slice()
        .sort((a, b) => a.sortOrder - b.sortOrder)
        .map((c) => ({
          ...c,
          activeArticleCount: activeCount.get(c.id) || 0,
          archivedArticleCount: archivedCount.get(c.id) || 0,
          sourceCount: sourceCount.get(c.id) || 0,
        })),
    });
  });

  // Status + AI/Scheduler Config
  router.get('/status', (_req: Request, res: Response) => {
    const db = loadTechHubDb();
    const scanStatus = getScanStatus();
    const activeArticles = db.articles.filter((a) => !a.isArchived).length;
    const archivedArticles = db.articles.filter((a) => a.isArchived).length;
    const favoriteArticleIds = new Set(
      db.articleUserState.filter((st) => st.isFavorite).map((st) => st.articleId)
    );
    const favoriteArticles = db.articles.filter(
      (a) => !a.isArchived && favoriteArticleIds.has(a.id)
    ).length;

    res.json({
      ...scanStatus,
      aiConfig: db.aiConfig,
      geminiConfigured: isGeminiConfigured(),
      totals: {
        categories: db.categories.length,
        sources: db.sources.length,
        verifiedActiveSources: db.sources.filter(
          (s) => s.enabled && s.validationStatus === 'verified'
        ).length,
        unverifiedSources: db.sources.filter(
          (s) => s.validationStatus === 'unverified'
        ).length,
        errorSources: db.sources.filter((s) => s.validationStatus === 'error').length,
        activeArticles,
        archivedArticles,
        favoriteArticles,
        totalArticles: db.articles.length,
      },
    });
  });

  router.patch('/config', async (req: Request, res: Response) => {
    const db = loadTechHubDb();
    const body = req.body as {
      scheduler?: Partial<typeof db.scheduler>;
      aiConfig?: Partial<typeof db.aiConfig>;
    };

    if (body.scheduler) {
      if (typeof body.scheduler.autoSyncEnabled === 'boolean') {
        db.scheduler.autoSyncEnabled = body.scheduler.autoSyncEnabled;
      }
      if (typeof body.scheduler.intervalHours === 'number') {
        const allowed = new Set([1, 3, 6, 12, 24]);
        if (allowed.has(body.scheduler.intervalHours)) {
          db.scheduler.intervalHours = body.scheduler.intervalHours;
        }
      }
    }

    if (body.aiConfig) {
      if (typeof body.aiConfig.enabled === 'boolean') {
        db.aiConfig.enabled = body.aiConfig.enabled;
      }
      if (typeof body.aiConfig.autoSummarizeOnScan === 'boolean') {
        db.aiConfig.autoSummarizeOnScan = body.aiConfig.autoSummarizeOnScan;
      }
      if (typeof body.aiConfig.maxAutoPerScan === 'number') {
        db.aiConfig.maxAutoPerScan = Math.max(1, Math.min(20, body.aiConfig.maxAutoPerScan));
      }
    }

    await saveTechHubDb(db);
    res.json({
      scheduler: db.scheduler,
      aiConfig: db.aiConfig,
      geminiConfigured: isGeminiConfigured(),
    });
  });

  // Sources CRUD + Verification + Auto-Discovery
  router.get('/sources', (_req: Request, res: Response) => {
    const db = loadTechHubDb();
    const catMap = new Map(db.categories.map((c) => [c.id, c.name]));
    const catsBySource = new Map<string, string[]>();
    for (const sc of db.sourceCategories) {
      const arr = catsBySource.get(sc.sourceId) || [];
      arr.push(sc.categoryId);
      catsBySource.set(sc.sourceId, arr);
    }

    res.json({
      sources: db.sources.map((s) => {
        const categoryIds = catsBySource.get(s.id) || [];
        return {
          ...s,
          categoryIds,
          categoryNames: categoryIds.map((id) => catMap.get(id) || id),
        };
      }),
    });
  });

  router.post('/sources/test-url', async (req: Request, res: Response) => {
    const rawUrl = typeof req.body?.feedUrl === 'string' ? req.body.feedUrl.trim() : '';
    if (!rawUrl) {
      res.status(400).json({ error: 'feedUrl is required.' });
      return;
    }
    const result = await testFeedConnection(rawUrl);
    res.json(result);
  });

  router.post('/sources/discover', async (req: Request, res: Response) => {
    const rawUrl = typeof req.body?.siteUrl === 'string' ? req.body.siteUrl.trim() : '';
    if (!rawUrl) {
      res.status(400).json({ error: 'siteUrl is required.' });
      return;
    }
    const result = await discoverFeedsForSite(rawUrl);
    res.json(result);
  });

  router.post('/sources', async (req: Request, res: Response) => {
    const db = loadTechHubDb();
    const body = req.body as {
      name?: string;
      siteUrl?: string;
      feedUrl?: string;
      categoryIds?: string[];
      enabled?: boolean;
      keywordFilter?: string[] | null;
    };

    const name = (body.name || '').trim();
    const siteUrl = (body.siteUrl || '').trim();
    const feedUrl = (body.feedUrl || '').trim();
    if (!name) {
      res.status(400).json({ error: 'Source name is required.' });
      return;
    }

    if (siteUrl && !validatePublicHttpsUrl(siteUrl)) {
      res.status(400).json({ error: 'siteUrl must be a valid public HTTP/HTTPS URL.' });
      return;
    }
    if (feedUrl && !validatePublicHttpsUrl(feedUrl)) {
      res.status(400).json({ error: 'feedUrl must be a valid public HTTP/HTTPS URL.' });
      return;
    }

    const validCatIds = new Set(db.categories.map((c) => c.id));
    const categoryIds = Array.isArray(body.categoryIds)
      ? Array.from(new Set(body.categoryIds.filter((id) => validCatIds.has(id))))
      : [];

    let validationStatus: TechHubSource['validationStatus'] = 'unverified';
    let feedType: TechHubSource['feedType'] = 'unverified';
    let validationNote: string | null = 'No verified RSS/Atom URL supplied yet.';
    let lastHttpStatus: number | null = null;
    let enabled = false;

    if (feedUrl) {
      const test = await testFeedConnection(feedUrl);
      lastHttpStatus = test.httpStatus;
      if (test.ok) {
        validationStatus = 'verified';
        feedType = test.feedType;
        validationNote = `Verified live ${test.feedType.toUpperCase()} feed (${test.itemCount} items).`;
        enabled = body.enabled !== false;
      } else {
        validationStatus = 'unverified';
        feedType = 'unverified';
        validationNote = test.error || 'Feed validation failed; kept inactive.';
        enabled = false;
      }
    }

    const now = new Date().toISOString();
    const newSource: TechHubSource = {
      id: makeId('src'),
      name,
      siteUrl: siteUrl || feedUrl,
      feedUrl,
      feedType,
      validationStatus,
      validationNote,
      enabled,
      keywordFilter: Array.isArray(body.keywordFilter)
        ? body.keywordFilter.map((k) => k.trim()).filter(Boolean)
        : null,
      etag: null,
      lastModified: null,
      lastScanAt: null,
      lastSuccessAt: null,
      lastError: null,
      lastHttpStatus,
      totalFetched: 0,
      createdAt: now,
      updatedAt: now,
    };

    db.sources.push(newSource);
    for (const cid of categoryIds) {
      db.sourceCategories.push({ sourceId: newSource.id, categoryId: cid });
    }
    await saveTechHubDb(db);

    res.status(201).json({
      source: {
        ...newSource,
        categoryIds,
      },
    });
  });

  router.patch('/sources/:id', async (req: Request, res: Response) => {
    const db = loadTechHubDb();
    const source = db.sources.find((s) => s.id === req.params.id);
    if (!source) {
      res.status(404).json({ error: 'Source not found.' });
      return;
    }

    const body = req.body as {
      name?: string;
      siteUrl?: string;
      feedUrl?: string;
      enabled?: boolean;
      categoryIds?: string[];
      keywordFilter?: string[] | null;
    };

    if (typeof body.name === 'string' && body.name.trim()) {
      source.name = body.name.trim();
    }
    if (typeof body.siteUrl === 'string') {
      const cleaned = body.siteUrl.trim();
      if (cleaned && !validatePublicHttpsUrl(cleaned)) {
        res.status(400).json({ error: 'siteUrl must be a valid public HTTP/HTTPS URL.' });
        return;
      }
      source.siteUrl = cleaned;
    }

    if (typeof body.feedUrl === 'string') {
      const cleanedFeed = body.feedUrl.trim();
      if (cleanedFeed !== source.feedUrl) {
        if (cleanedFeed && !validatePublicHttpsUrl(cleanedFeed)) {
          res.status(400).json({ error: 'feedUrl must be a valid public HTTP/HTTPS URL.' });
          return;
        }
        source.feedUrl = cleanedFeed;
        source.etag = null;
        source.lastModified = null;

        if (!cleanedFeed) {
          source.feedType = 'unverified';
          source.validationStatus = 'unverified';
          source.validationNote = 'Feed URL cleared; kept inactive.';
          source.enabled = false;
        } else {
          const test = await testFeedConnection(cleanedFeed);
          source.lastHttpStatus = test.httpStatus;
          if (test.ok) {
            source.feedType = test.feedType;
            source.validationStatus = 'verified';
            source.validationNote = `Verified live ${test.feedType.toUpperCase()} feed (${test.itemCount} items).`;
            source.lastError = null;
          } else {
            source.feedType = 'unverified';
            source.validationStatus = 'unverified';
            source.validationNote = test.error || 'Feed validation failed.';
            source.enabled = false;
          }
        }
      }
    }

    if (typeof body.enabled === 'boolean') {
      if (body.enabled && (!source.feedUrl || source.validationStatus === 'unverified')) {
        res.status(400).json({
          error: 'Cannot activate an unverified source without a valid RSS/Atom feed URL.',
        });
        return;
      }
      source.enabled = body.enabled;
    }

    if (body.keywordFilter !== undefined) {
      source.keywordFilter = Array.isArray(body.keywordFilter)
        ? body.keywordFilter.map((k) => k.trim()).filter(Boolean)
        : null;
    }

    if (Array.isArray(body.categoryIds)) {
      const validCatIds = new Set(db.categories.map((c) => c.id));
      const nextIds = Array.from(new Set(body.categoryIds.filter((id) => validCatIds.has(id))));
      db.sourceCategories = db.sourceCategories.filter((sc) => sc.sourceId !== source.id);
      for (const cid of nextIds) {
        db.sourceCategories.push({ sourceId: source.id, categoryId: cid });
      }
    }

    source.updatedAt = new Date().toISOString();
    await saveTechHubDb(db);

    const updatedCats = db.sourceCategories
      .filter((sc) => sc.sourceId === source.id)
      .map((sc) => sc.categoryId);

    res.json({
      source: {
        ...source,
        categoryIds: updatedCats,
      },
    });
  });

  router.delete('/sources/:id', async (req: Request, res: Response) => {
    const db = loadTechHubDb();
    const exists = db.sources.some((s) => s.id === req.params.id);
    if (!exists) {
      res.status(404).json({ error: 'Source not found.' });
      return;
    }
    db.sources = db.sources.filter((s) => s.id !== req.params.id);
    db.sourceCategories = db.sourceCategories.filter((sc) => sc.sourceId !== req.params.id);
    await saveTechHubDb(db);
    res.json({ ok: true });
  });

  router.post('/sources/:id/test', async (req: Request, res: Response) => {
    const db = loadTechHubDb();
    const source = db.sources.find((s) => s.id === req.params.id);
    if (!source) {
      res.status(404).json({ error: 'Source not found.' });
      return;
    }

    if (!source.feedUrl) {
      const discovery = await discoverFeedsForSite(source.siteUrl);
      res.json({
        ok: false,
        source,
        discovery,
        error: discovery.note,
      });
      return;
    }

    const test = await testFeedConnection(source.feedUrl);
    source.lastHttpStatus = test.httpStatus;
    source.updatedAt = new Date().toISOString();
    if (test.ok) {
      source.feedType = test.feedType;
      source.validationStatus = 'verified';
      source.validationNote = `Verified ${test.feedType.toUpperCase()} (${test.itemCount} items).`;
      source.lastError = null;
    } else {
      source.validationStatus = 'error';
      source.lastError = test.error;
    }
    await saveTechHubDb(db);
    res.json({ ...test, source });
  });

  router.post('/sources/:id/scan', async (req: Request, res: Response) => {
    const result = await scanSingleSource(req.params.id, 'source');
    res.status(result.ok ? 200 : 400).json(result);
  });

  // Global Scan + History
  router.post('/scan', async (_req: Request, res: Response) => {
    const result = await runGlobalScan('manual');
    res.json(result);
  });

  router.get('/scan-history', (req: Request, res: Response) => {
    const db = loadTechHubDb();
    const sourceId = typeof req.query.sourceId === 'string' ? req.query.sourceId.trim() : '';
    const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 100));
    const items = db.scanHistory
      .filter((h) => (!sourceId ? true : h.sourceId === sourceId))
      .slice(0, limit);
    res.json({ history: items });
  });

  // Articles Query + Detail + User State (Read / Favorite / Archive / Restore / Note) + AI Summary
  router.get('/articles', (req: Request, res: Response) => {
    const db = loadTechHubDb();

    const categoryId = typeof req.query.categoryId === 'string' ? req.query.categoryId.trim() : '';
    const sourceId = typeof req.query.sourceId === 'string' ? req.query.sourceId.trim() : '';
    const archivedParam = typeof req.query.archived === 'string' ? req.query.archived : 'false';
    const unreadOnly = req.query.unreadOnly === 'true';
    const favoritesOnly = req.query.favoritesOnly === 'true';
    const aiOnly = req.query.aiOnly === 'true';
    const fromDate = typeof req.query.from === 'string' ? req.query.from.trim() : '';
    const toDate = typeof req.query.to === 'string' ? req.query.to.trim() : '';
    const q = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';
    const sort =
      req.query.sort === 'oldest'
        ? 'oldest'
        : req.query.sort === 'important'
          ? 'important'
          : 'newest';
    const page = Math.max(1, Number(req.query.page) || 1);
    const pageSize = Math.min(100, Math.max(1, Number(req.query.pageSize) || 24));

    const sourceNameMap = new Map(db.sources.map((s) => [s.id, s.name]));
    const catMap = new Map(db.categories.map((c) => [c.id, c]));
    const stateMap = new Map(db.articleUserState.map((st) => [st.articleId, st]));
    const noteMap = new Map(db.articleNotes.map((n) => [n.articleId, n.note]));

    const catsByArticle = new Map<string, string[]>();
    for (const ac of db.articleCategories) {
      const arr = catsByArticle.get(ac.articleId) || [];
      arr.push(ac.categoryId);
      catsByArticle.set(ac.articleId, arr);
    }

    const tagsByArticle = new Map<string, string[]>();
    for (const at of db.articleTags) {
      const arr = tagsByArticle.get(at.articleId) || [];
      if (!arr.includes(at.tag)) arr.push(at.tag);
      tagsByArticle.set(at.articleId, arr);
    }

    const fromMs = fromDate ? Date.parse(`${fromDate}T00:00:00.000Z`) : NaN;
    const toMs = toDate ? Date.parse(`${toDate}T23:59:59.999Z`) : NaN;

    const filtered = db.articles.filter((art) => {
      if (archivedParam === 'false' && art.isArchived) return false;
      if (archivedParam === 'true' && !art.isArchived) return false;
      if (sourceId && art.sourceId !== sourceId) return false;

      const artCats = catsByArticle.get(art.id) || [];
      if (categoryId && !artCats.includes(categoryId)) return false;

      const st = stateMap.get(art.id);
      if (unreadOnly && st?.isRead) return false;
      if (favoritesOnly && !st?.isFavorite) return false;
      if (aiOnly && !art.aiSummaryTr) return false;

      const dateStr = art.publishedAt || art.fetchedAt;
      const ms = Date.parse(dateStr);
      if (!Number.isNaN(fromMs) && ms < fromMs) return false;
      if (!Number.isNaN(toMs) && ms > toMs) return false;

      if (q) {
        const srcName = (sourceNameMap.get(art.sourceId) || '').toLowerCase();
        const catNames = artCats
          .map((cid) => catMap.get(cid)?.name || '')
          .join(' ')
          .toLowerCase();
        const tags = (tagsByArticle.get(art.id) || []).join(' ').toLowerCase();
        const hay = `${art.title} ${art.description} ${art.aiSummaryTr || ''} ${art.author || ''} ${srcName} ${catNames} ${tags}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }

      return true;
    });

    const importanceWeight = (art: (typeof db.articles)[number]): number => {
      if (art.aiImportance === 'Critical') return 400;
      if (art.aiImportance === 'High') return 300;
      if (art.aiImportance === 'Medium') return 200;
      if (art.aiImportance === 'Low') return 100;

      let score = 0;
      const st = stateMap.get(art.id);
      if (st?.isFavorite) score += 80;
      if (art.aiSummaryTr) score += 30;
      const cats = catsByArticle.get(art.id) || [];
      if (cats.includes('cat-security')) score += 45;
      if (cats.includes('cat-kubernetes') || cats.includes('cat-openshift')) score += 25;
      if (cats.includes('cat-java') || cats.includes('cat-ai')) score += 20;
      const titleLower = art.title.toLowerCase();
      if (
        titleLower.includes('cve-') ||
        titleLower.includes('critical') ||
        titleLower.includes('zero-day') ||
        titleLower.includes('vulnerability') ||
        titleLower.includes('advisory') ||
        titleLower.includes('release')
      ) {
        score += 50;
      }
      return score;
    };

    filtered.sort((a, b) => {
      if (sort === 'important') {
        const diff = importanceWeight(b) - importanceWeight(a);
        if (diff !== 0) return diff;
      }
      const aMs = Date.parse(a.publishedAt || a.fetchedAt) || 0;
      const bMs = Date.parse(b.publishedAt || b.fetchedAt) || 0;
      return sort === 'oldest' ? aMs - bMs : bMs - aMs;
    });

    const total = filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const safePage = Math.min(page, totalPages);
    const startIdx = (safePage - 1) * pageSize;

    const items = filtered.slice(startIdx, startIdx + pageSize).map((art) => {
      const st = stateMap.get(art.id);
      const artCatIds = catsByArticle.get(art.id) || [];
      return {
        ...art,
        sourceName: sourceNameMap.get(art.sourceId) || 'Source',
        categoryIds: artCatIds,
        categories: artCatIds
          .map((cid) => catMap.get(cid))
          .filter((c): c is NonNullable<typeof c> => Boolean(c)),
        tags: tagsByArticle.get(art.id) || [],
        isRead: Boolean(st?.isRead),
        isFavorite: Boolean(st?.isFavorite),
        note: noteMap.get(art.id) || '',
      };
    });

    res.json({
      items,
      pagination: {
        total,
        page: safePage,
        pageSize,
        totalPages,
      },
    });
  });

  router.get('/articles/:id', (req: Request, res: Response) => {
    const db = loadTechHubDb();
    const article = db.articles.find((a) => a.id === req.params.id);
    if (!article) {
      res.status(404).json({ error: 'Article not found.' });
      return;
    }

    const source = db.sources.find((s) => s.id === article.sourceId);
    const catMap = new Map(db.categories.map((c) => [c.id, c]));
    const catIds = db.articleCategories
      .filter((ac) => ac.articleId === article.id)
      .map((ac) => ac.categoryId);
    const tags = db.articleTags
      .filter((at) => at.articleId === article.id)
      .map((at) => at.tag);
    const state = db.articleUserState.find((st) => st.articleId === article.id);
    const note = db.articleNotes.find((n) => n.articleId === article.id)?.note || '';
    const similarArticles = findSimilarArticles(article.id, 4);

    res.json({
      article: {
        ...article,
        sourceName: source?.name || 'Source',
        sourceSiteUrl: source?.siteUrl || '',
        categoryIds: catIds,
        categories: catIds
          .map((cid) => catMap.get(cid))
          .filter((c): c is NonNullable<typeof c> => Boolean(c)),
        tags: Array.from(new Set(tags)),
        isRead: Boolean(state?.isRead),
        isFavorite: Boolean(state?.isFavorite),
        note,
      },
      similarArticles,
    });
  });

  router.patch('/articles/:id/state', async (req: Request, res: Response) => {
    const db = loadTechHubDb();
    const article = db.articles.find((a) => a.id === req.params.id);
    if (!article) {
      res.status(404).json({ error: 'Article not found.' });
      return;
    }

    const body = req.body as {
      isRead?: boolean;
      isFavorite?: boolean;
      isArchived?: boolean;
      note?: string;
    };

    const nowIso = new Date().toISOString();
    let state = db.articleUserState.find((st) => st.articleId === article.id);
    if (!state) {
      state = {
        articleId: article.id,
        isRead: false,
        isFavorite: false,
        readAt: null,
        updatedAt: nowIso,
      };
      db.articleUserState.push(state);
    }

    if (typeof body.isRead === 'boolean') {
      state.isRead = body.isRead;
      state.readAt = body.isRead ? nowIso : null;
      state.updatedAt = nowIso;
    }
    if (typeof body.isFavorite === 'boolean') {
      state.isFavorite = body.isFavorite;
      state.updatedAt = nowIso;
    }
    if (typeof body.isArchived === 'boolean') {
      article.isArchived = body.isArchived;
      article.archivedAt = body.isArchived ? nowIso : null;
    }
    if (typeof body.note === 'string') {
      const existingNote = db.articleNotes.find((n) => n.articleId === article.id);
      if (existingNote) {
        existingNote.note = body.note;
        existingNote.updatedAt = nowIso;
      } else {
        db.articleNotes.push({
          articleId: article.id,
          note: body.note,
          updatedAt: nowIso,
        });
      }
    }

    await saveTechHubDb(db);
    res.json({
      ok: true,
      id: article.id,
      isRead: state.isRead,
      isFavorite: state.isFavorite,
      isArchived: article.isArchived,
      archivedAt: article.archivedAt,
    });
  });

  router.post('/articles/:id/summarize', async (req: Request, res: Response) => {
    const result = await summarizeAndPersistArticle(req.params.id);
    if (!result.ok) {
      res.status(result.status).json({ error: result.error });
      return;
    }
    res.json({ ok: true, article: result.article });
  });

  return router;
}
