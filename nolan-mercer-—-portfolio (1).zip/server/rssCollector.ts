import net from 'net';
import {
  analyzeArticleWithAi,
  isGeminiConfigured,
} from './aiSummarizer';
import {
  computeContentHash,
  loadTechHubDb,
  makeId,
  normalizeCanonicalUrl,
  saveTechHubDb,
  ScanHistoryRecord,
  TechFeedType,
  TechHubArticle,
  TechHubDatabase,
  TechHubSource,
} from './techHubDb';

const REQUEST_TIMEOUT_MS = 20_000;
const THREE_HOURS_MS = 3 * 60 * 60 * 1000;
const SCHEDULER_POLL_MS = 60_000;
const MAX_CONCURRENCY = 5;
const MAX_SCAN_HISTORY = 300;

let isGlobalScanRunning = false;
const activeSourceScans = new Set<string>();
let schedulerTimer: NodeJS.Timeout | null = null;

export interface ParsedFeedItem {
  guid: string;
  title: string;
  url: string;
  author: string | null;
  description: string;
  imageUrl: string | null;
  contentPreview: string[];
  publishedAt: string | null;
  tags: string[];
}

export interface ParsedFeedResult {
  feedType: 'rss' | 'atom';
  items: ParsedFeedItem[];
}

export interface DiscoveryCandidate {
  url: string;
  title: string;
  feedType: 'rss' | 'atom';
  verified: boolean;
  httpStatus: number | null;
  itemCount: number;
}

export interface DiscoveryResult {
  siteUrl: string;
  httpStatus: number | null;
  candidates: DiscoveryCandidate[];
  sitemapUrl: string | null;
  note: string;
}

function isPrivateOrBlockedHost(hostname: string): boolean {
  const host = hostname.trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (
    host === 'localhost' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host.endsWith('.localhost')
  ) {
    return true;
  }
  const ipVersion = net.isIP(host);
  if (ipVersion === 4) {
    const parts = host.split('.').map(Number);
    if (parts[0] === 10 || parts[0] === 127 || parts[0] === 0) return true;
    if (parts[0] === 169 && parts[1] === 254) return true;
    if (parts[0] === 192 && parts[1] === 168) return true;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  }
  if (ipVersion === 6) {
    if (
      host === '::1' ||
      host.startsWith('fc') ||
      host.startsWith('fd') ||
      host.startsWith('fe80')
    ) {
      return true;
    }
  }
  return false;
}

export function validatePublicHttpsUrl(rawUrl: string): URL | null {
  try {
    const parsed = new URL(rawUrl.trim());
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return null;
    if (parsed.username || parsed.password) return null;
    if (isPrivateOrBlockedHost(parsed.hostname)) return null;
    return parsed;
  } catch {
    return null;
  }
}

function decodeXmlEntities(input: string): string {
  return input
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_m, dec) => {
      const code = Number(dec);
      return Number.isFinite(code) ? String.fromCodePoint(code) : '';
    })
    .replace(/&#x([0-9a-fA-F]+);/g, (_m, hex) => {
      const code = parseInt(hex, 16);
      return Number.isFinite(code) ? String.fromCodePoint(code) : '';
    });
}

function stripHtml(input: string): string {
  return decodeXmlEntities(input)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractParagraphsFromHtml(rawHtml: string): string[] {
  if (!rawHtml) return [];
  const decoded = decodeXmlEntities(rawHtml)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ');

  const withBreaks = decoded
    .replace(/<\/(p|div|h1|h2|h3|h4|h5|h6|li|blockquote|pre|tr)>/gi, '\n\n')
    .replace(/<(br|hr)\s*\/?>/gi, '\n');

  const plain = withBreaks.replace(/<[^>]+>/g, ' ');
  const chunks = plain
    .split(/\n{2,}/)
    .map((c) => c.replace(/\s+/g, ' ').trim())
    .filter((c) => c.length >= 25);

  const unique: string[] = [];
  for (const chunk of chunks) {
    if (!unique.includes(chunk)) {
      unique.push(chunk.slice(0, 900));
    }
    if (unique.length >= 12) break;
  }
  return unique;
}

function isLikelyValidImageUrl(rawUrl: string, baseUrl: string): string | null {
  try {
    const resolved = new URL(decodeXmlEntities(rawUrl).trim(), baseUrl);
    if (resolved.protocol !== 'https:' && resolved.protocol !== 'http:') return null;
    const lower = resolved.toString().toLowerCase();
    if (
      lower.includes('feedburner.com/~r/') ||
      lower.includes('pixel.') ||
      lower.includes('/1x1') ||
      lower.includes('gravatar.com/avatar') ||
      lower.endsWith('.svg')
    ) {
      return null;
    }
    return resolved.toString();
  } catch {
    return null;
  }
}

function extractFeedImageUrl(block: string, htmlBodies: string[], baseUrl: string): string | null {
  const mediaMatches = [
    ...block.matchAll(/<media:(?:content|thumbnail)\b([^>]*)\/?>/gi),
    ...block.matchAll(/<enclosure\b([^>]*)\/?>/gi),
    ...block.matchAll(/<itunes:image\b([^>]*)\/?>/gi),
  ];

  for (const m of mediaMatches) {
    const attrs = m[1] || '';
    const urlMatch = attrs.match(/(?:url|href)=["']([^"']+)["']/i);
    if (!urlMatch?.[1]) continue;
    const typeMatch = attrs.match(/type=["']([^"']+)["']/i);
    const mediumMatch = attrs.match(/medium=["']([^"']+)["']/i);
    const isEnclosureTag = m[0].toLowerCase().startsWith('<enclosure');
    if (isEnclosureTag && typeMatch?.[1] && !typeMatch[1].toLowerCase().startsWith('image/')) {
      continue;
    }
    if (mediumMatch?.[1] && mediumMatch[1].toLowerCase() !== 'image') {
      continue;
    }
    const valid = isLikelyValidImageUrl(urlMatch[1], baseUrl);
    if (valid) return valid;
  }

  for (const html of htmlBodies) {
    if (!html) continue;
    const decoded = decodeXmlEntities(html);
    const imgMatches = decoded.matchAll(/<img\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi);
    for (const im of imgMatches) {
      if (!im[1]) continue;
      const valid = isLikelyValidImageUrl(im[1], baseUrl);
      if (valid) return valid;
    }
  }

  return null;
}

function extractTagText(block: string, tagNames: string[]): string {
  for (const tag of tagNames) {
    const escaped = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`, 'i');
    const match = block.match(regex);
    if (match && match[1]) {
      const cleaned = stripHtml(match[1]);
      if (cleaned) return cleaned;
    }
  }
  return '';
}

function extractTagRaw(block: string, tagNames: string[]): string {
  for (const tag of tagNames) {
    const escaped = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`, 'i');
    const match = block.match(regex);
    if (match && match[1]) {
      const val = decodeXmlEntities(match[1]).trim();
      if (val) return val;
    }
  }
  return '';
}

function extractCategories(block: string): string[] {
  const tags = new Set<string>();
  const matches = block.matchAll(/<category\b([^>]*)>([\s\S]*?)<\/category>|<category\b([^>]*?)\/>/gi);
  for (const m of matches) {
    const attrs = m[1] || m[3] || '';
    const inner = m[2] ? stripHtml(m[2]) : '';
    const termMatch = attrs.match(/term=["']([^"']+)["']/i);
    const labelMatch = attrs.match(/label=["']([^"']+)["']/i);
    const val = (inner || labelMatch?.[1] || termMatch?.[1] || '').trim();
    if (val && val.length <= 48) {
      tags.add(val.toLowerCase());
    }
  }
  return Array.from(tags).slice(0, 8);
}

function extractAtomLink(block: string, baseUrl: string): string {
  const linkTags = [...block.matchAll(/<link\b([^>]*)\/?>/gi)];
  let fallbackHref = '';
  for (const lt of linkTags) {
    const attrs = lt[1] || '';
    const hrefMatch = attrs.match(/href=["']([^"']+)["']/i);
    if (!hrefMatch?.[1]) continue;
    const href = decodeXmlEntities(hrefMatch[1]).trim();
    const relMatch = attrs.match(/rel=["']([^"']+)["']/i);
    const rel = (relMatch?.[1] || 'alternate').toLowerCase();
    if (rel === 'alternate') {
      try {
        return new URL(href, baseUrl).toString();
      } catch {
        return href;
      }
    }
    if (!fallbackHref && rel !== 'self') {
      fallbackHref = href;
    }
  }
  if (fallbackHref) {
    try {
      return new URL(fallbackHref, baseUrl).toString();
    } catch {
      return fallbackHref;
    }
  }
  return '';
}

function parseDateIso(raw: string): string | null {
  const cleaned = raw.trim();
  if (!cleaned) return null;
  const ms = Date.parse(cleaned);
  if (Number.isNaN(ms)) return null;
  return new Date(ms).toISOString();
}

export function parseRssOrAtomXml(xml: string, feedUrl: string): ParsedFeedResult | null {
  const trimmed = xml.trim();
  if (!trimmed) return null;
  const head = trimmed.slice(0, 400).toLowerCase();
  if (head.startsWith('<!doctype html') || head.startsWith('<html')) {
    return null;
  }

  const isAtom = /<feed[\s>]/i.test(trimmed) && !/<rss[\s>]/i.test(trimmed);
  const isRss = /<rss[\s>]/i.test(trimmed) || /<rdf:RDF[\s>]/i.test(trimmed) || /<channel[\s>]/i.test(trimmed);
  if (!isAtom && !isRss) {
    return null;
  }

  const items: ParsedFeedItem[] = [];

  if (isAtom) {
    const entries = [...trimmed.matchAll(/<entry\b[^>]*>([\s\S]*?)<\/entry>/gi)];
    for (const entry of entries) {
      const block = entry[1];
      const title = extractTagText(block, ['title']);
      const link = extractAtomLink(block, feedUrl) || extractTagRaw(block, ['id']);
      if (!title || !link) continue;
      const guid = extractTagRaw(block, ['id']) || link;
      const author = extractTagText(block, ['author>\\s*<name', 'name', 'dc:creator', 'author']) || null;
      const rawContent = extractTagRaw(block, ['content']);
      const rawSummary = extractTagRaw(block, ['summary', 'description']);
      const descRaw = stripHtml(rawSummary || rawContent);
      const contentPreview = extractParagraphsFromHtml(rawContent || rawSummary);
      const imageUrl = extractFeedImageUrl(block, [rawContent, rawSummary], link);
      const publishedRaw = extractTagRaw(block, ['published', 'updated', 'dc:date']);
      items.push({
        guid: guid.trim(),
        title: title.slice(0, 300),
        url: link.trim(),
        author: author ? author.slice(0, 120) : null,
        description: descRaw.slice(0, 600),
        imageUrl,
        contentPreview,
        publishedAt: parseDateIso(publishedRaw),
        tags: extractCategories(block),
      });
    }
    return { feedType: 'atom', items };
  }

  const rssItems = [...trimmed.matchAll(/<item\b[^>]*>([\s\S]*?)<\/item>/gi)];
  for (const item of rssItems) {
    const block = item[1];
    const title = extractTagText(block, ['title']);
    let link = extractTagRaw(block, ['link']);
    if (!link) {
      link = extractAtomLink(block, feedUrl);
    }
    if (link) {
      try {
        link = new URL(link, feedUrl).toString();
      } catch {
        // leave as-is
      }
    }
    if (!title || !link) continue;
    const guid = extractTagRaw(block, ['guid']) || link;
    const author = extractTagText(block, ['dc:creator', 'author', 'itunes:author']) || null;
    const rawEncoded = extractTagRaw(block, ['content:encoded', 'content']);
    const rawDesc = extractTagRaw(block, ['description', 'summary']);
    const descRaw = stripHtml(rawDesc || rawEncoded);
    const contentPreview = extractParagraphsFromHtml(rawEncoded || rawDesc);
    const imageUrl = extractFeedImageUrl(block, [rawEncoded, rawDesc], link);
    const publishedRaw = extractTagRaw(block, ['pubDate', 'dc:date', 'published', 'updated']);
    items.push({
      guid: guid.trim(),
      title: title.slice(0, 300),
      url: link.trim(),
      author: author ? author.slice(0, 120) : null,
      description: descRaw.slice(0, 600),
      imageUrl,
      contentPreview,
      publishedAt: parseDateIso(publishedRaw),
      tags: extractCategories(block),
    });
  }
  return { feedType: 'rss', items };
}

async function fetchHttpWithHeaders(
  url: string,
  opts: {
    etag?: string | null;
    lastModified?: string | null;
    userAgent?: string;
    accept?: string;
  } = {}
): Promise<{
  status: number;
  body: string;
  etag: string | null;
  lastModified: string | null;
  contentType: string;
}> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  const headers: Record<string, string> = {
    'User-Agent':
      opts.userAgent ||
      'Mozilla/5.0 (compatible; WorkspaceFeedReader/1.0)',
    Accept:
      opts.accept ||
      'application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9, text/html;q=0.5, */*;q=0.3',
  };
  if (opts.etag) headers['If-None-Match'] = opts.etag;
  if (opts.lastModified) headers['If-Modified-Since'] = opts.lastModified;

  try {
    const res = await fetch(url, {
      method: 'GET',
      headers,
      redirect: 'follow',
      signal: controller.signal,
    });
    const body = res.status === 304 ? '' : await res.text();
    return {
      status: res.status,
      body,
      etag: res.headers.get('etag'),
      lastModified: res.headers.get('last-modified'),
      contentType: res.headers.get('content-type') || '',
    };
  } finally {
    clearTimeout(timer);
  }
}

async function fetchFeedWithRetry(
  url: string,
  etag?: string | null,
  lastModified?: string | null
) {
  let attempt = await fetchHttpWithHeaders(url, { etag, lastModified });
  const headLower = attempt.body.trim().slice(0, 200).toLowerCase();
  const looksLikeHtmlChallenge =
    attempt.status === 200 &&
    (headLower.startsWith('<!doctype html') || headLower.startsWith('<html'));

  if (attempt.status === 403 || attempt.status === 406 || looksLikeHtmlChallenge) {
    attempt = await fetchHttpWithHeaders(url, {
      etag,
      lastModified,
      userAgent: 'curl/8.5.0',
    });
  } else if (attempt.status === 429 || attempt.status >= 500) {
    await new Promise((r) => setTimeout(r, 800));
    attempt = await fetchHttpWithHeaders(url, { etag, lastModified });
  }
  return attempt;
}

export async function testFeedConnection(rawFeedUrl: string): Promise<{
  ok: boolean;
  feedUrl: string;
  httpStatus: number | null;
  feedType: TechFeedType;
  itemCount: number;
  sampleTitles: string[];
  error: string | null;
}> {
  const validated = validatePublicHttpsUrl(rawFeedUrl);
  if (!validated) {
    return {
      ok: false,
      feedUrl: rawFeedUrl,
      httpStatus: null,
      feedType: 'unverified',
      itemCount: 0,
      sampleTitles: [],
      error: 'Only public HTTP/HTTPS feed URLs are allowed.',
    };
  }

  try {
    const res = await fetchFeedWithRetry(validated.toString());
    if (res.status < 200 || res.status >= 300) {
      return {
        ok: false,
        feedUrl: validated.toString(),
        httpStatus: res.status,
        feedType: 'unverified',
        itemCount: 0,
        sampleTitles: [],
        error: `HTTP ${res.status} returned by upstream server.`,
      };
    }

    const parsed = parseRssOrAtomXml(res.body, validated.toString());
    if (!parsed) {
      return {
        ok: false,
        feedUrl: validated.toString(),
        httpStatus: res.status,
        feedType: 'unverified',
        itemCount: 0,
        sampleTitles: [],
        error: 'Response is not valid RSS or Atom XML.',
      };
    }

    return {
      ok: true,
      feedUrl: validated.toString(),
      httpStatus: res.status,
      feedType: parsed.feedType,
      itemCount: parsed.items.length,
      sampleTitles: parsed.items.slice(0, 3).map((i) => i.title),
      error: null,
    };
  } catch (err) {
    return {
      ok: false,
      feedUrl: validated.toString(),
      httpStatus: null,
      feedType: 'unverified',
      itemCount: 0,
      sampleTitles: [],
      error: err instanceof Error ? err.message : 'Feed test failed',
    };
  }
}

export async function discoverFeedsForSite(rawSiteUrl: string): Promise<DiscoveryResult> {
  const validated = validatePublicHttpsUrl(rawSiteUrl);
  if (!validated) {
    return {
      siteUrl: rawSiteUrl,
      httpStatus: null,
      candidates: [],
      sitemapUrl: null,
      note: 'Invalid or private URL.',
    };
  }

  const candidateUrls = new Map<string, string>();
  let siteHttpStatus: number | null = null;
  let sitemapUrl: string | null = null;

  try {
    const pageRes = await fetchHttpWithHeaders(validated.toString(), {
      userAgent: 'curl/8.5.0',
      accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    });
    siteHttpStatus = pageRes.status;

    const directParsed = parseRssOrAtomXml(pageRes.body, validated.toString());
    if (directParsed) {
      candidateUrls.set(validated.toString(), 'Direct Feed URL');
    } else if (pageRes.status >= 200 && pageRes.status < 300) {
      const linkMatches = pageRes.body.matchAll(/<link\b([^>]*)>/gi);
      for (const m of linkMatches) {
        const attrs = m[1] || '';
        const typeMatch = attrs.match(/type=["']([^"']+)["']/i);
        const relMatch = attrs.match(/rel=["']([^"']+)["']/i);
        const hrefMatch = attrs.match(/href=["']([^"']+)["']/i);
        const titleMatch = attrs.match(/title=["']([^"']+)["']/i);

        const typeVal = (typeMatch?.[1] || '').toLowerCase();
        const relVal = (relMatch?.[1] || '').toLowerCase();
        if (
          hrefMatch?.[1] &&
          (relVal.includes('alternate') || relVal.includes('feed')) &&
          (typeVal.includes('rss') || typeVal.includes('atom') || typeVal.includes('xml'))
        ) {
          try {
            const abs = new URL(decodeXmlEntities(hrefMatch[1]), validated).toString();
            candidateUrls.set(abs, titleMatch?.[1] || 'Discovered RSS/Atom Link');
          } catch {
            // ignore invalid href
          }
        }
      }
    }
  } catch {
    // proceed to common path probes
  }

  const baseOrigin = validated.origin;
  const trimmedPath = validated.pathname.replace(/\/+$/, '');
  const commonPaths = [
    `${trimmedPath}/feed`,
    `${trimmedPath}/feed/`,
    `${trimmedPath}/rss`,
    `${trimmedPath}/rss.xml`,
    `${trimmedPath}/feed.xml`,
    `${trimmedPath}/index.xml`,
    `${trimmedPath}/atom.xml`,
    '/feed/',
    '/rss.xml',
    '/feed.xml',
  ];
  for (const p of commonPaths) {
    try {
      const u = new URL(p, baseOrigin).toString();
      if (!candidateUrls.has(u)) {
        candidateUrls.set(u, 'Common Feed Path Probe');
      }
    } catch {
      // ignore
    }
  }

  // Probe up to 8 candidate URLs
  const toProbe = Array.from(candidateUrls.entries()).slice(0, 8);
  const verifiedCandidates: DiscoveryCandidate[] = [];

  await Promise.all(
    toProbe.map(async ([url, title]) => {
      const tested = await testFeedConnection(url);
      if (tested.ok && tested.feedType !== 'unverified') {
        verifiedCandidates.push({
          url: tested.feedUrl,
          title,
          feedType: tested.feedType,
          verified: true,
          httpStatus: tested.httpStatus,
          itemCount: tested.itemCount,
        });
      }
    })
  );

  // Also check sitemap.xml for transparency if no RSS found
  if (verifiedCandidates.length === 0) {
    try {
      const smUrl = `${baseOrigin}/sitemap.xml`;
      const smRes = await fetchHttpWithHeaders(smUrl, { userAgent: 'curl/8.5.0' });
      if (
        smRes.status === 200 &&
        (smRes.body.includes('<urlset') || smRes.body.includes('<sitemapindex'))
      ) {
        sitemapUrl = smUrl;
      }
    } catch {
      // ignore
    }
  }

  return {
    siteUrl: validated.toString(),
    httpStatus: siteHttpStatus,
    candidates: verifiedCandidates,
    sitemapUrl,
    note:
      verifiedCandidates.length > 0
        ? `Found ${verifiedCandidates.length} verified RSS/Atom feed(s).`
        : sitemapUrl
          ? 'No RSS/Atom feed detected; sitemap.xml exists (not mislabeled as RSS).'
          : 'No valid RSS or Atom feed discovered for this URL.',
  };
}

const KEYWORD_CATEGORY_RULES: Array<{ categoryId: string; keywords: string[] }> = [
  { categoryId: 'cat-kubernetes', keywords: ['kubernetes', 'k8s', 'kubectl', 'helm', 'kubelet', 'crd', 'ingress'] },
  { categoryId: 'cat-openshift', keywords: ['openshift', 'rosa', 'aro', 'okd', 'red hat openshift'] },
  { categoryId: 'cat-istio', keywords: ['istio', 'service mesh', 'envoy', 'ambient mesh'] },
  { categoryId: 'cat-nginx', keywords: ['nginx', 'nginx plus', 'openresty'] },
  { categoryId: 'cat-aws', keywords: ['aws', 'amazon web services', 'eks', 'ec2', 's3', 'lambda', 'bedrock', 'iam'] },
  { categoryId: 'cat-cloudflare', keywords: ['cloudflare', 'workers', 'zero trust', 'r2', 'waf', 'ddos'] },
  { categoryId: 'cat-github', keywords: ['github', 'copilot', 'github actions', 'pull request'] },
  { categoryId: 'cat-security', keywords: ['cve-', 'vulnerability', 'advisory', 'ransomware', 'zero-day', 'exploit', 'security', 'malware', 'phishing', 'threat'] },
  { categoryId: 'cat-java', keywords: ['java', 'jdk', 'jvm', 'spring boot', 'quarkus', 'jakarta', 'wildfly', 'maven', 'gradle'] },
  { categoryId: 'cat-ai', keywords: ['llm', 'artificial intelligence', 'machine learning', 'generative ai', 'transformer', 'rag', 'agentic', 'openai', 'gemini', 'deepmind', 'hugging face'] },
  { categoryId: 'cat-elasticsearch', keywords: ['elasticsearch', 'elastic', 'kibana', 'opensearch', 'logstash'] },
  { categoryId: 'cat-devops', keywords: ['devops', 'ci/cd', 'opentelemetry', 'observability', 'ansible', 'terraform', 'gitops', 'sre', 'pipeline'] },
  { categoryId: 'cat-jenkins', keywords: ['jenkins', 'jenkinsfile'] },
  { categoryId: 'cat-powercurve', keywords: ['powercurve', 'power curve'] },
  { categoryId: 'cat-evam', keywords: ['evam'] },
  { categoryId: 'cat-provenir', keywords: ['provenir'] },
];

function resolveArticleCategories(
  sourceCategoryIds: string[],
  item: ParsedFeedItem
): string[] {
  const matched = new Set<string>(sourceCategoryIds);
  const haystack = `${item.title} ${item.description} ${item.tags.join(' ')}`.toLowerCase();

  for (const rule of KEYWORD_CATEGORY_RULES) {
    if (rule.keywords.some((kw) => haystack.includes(kw))) {
      matched.add(rule.categoryId);
    }
  }

  // Refine shared Red Hat feeds so OpenShift-only vs Kubernetes-only stay clean when possible
  if (
    sourceCategoryIds.includes('cat-openshift') &&
    sourceCategoryIds.includes('cat-kubernetes')
  ) {
    const mentionsOpenShift = haystack.includes('openshift') || haystack.includes('rosa') || haystack.includes('okd');
    const mentionsK8s = haystack.includes('kubernetes') || haystack.includes('k8s') || haystack.includes('kube');
    if (mentionsOpenShift && !mentionsK8s) {
      matched.delete('cat-kubernetes');
    }
  }

  return Array.from(matched);
}

function passesKeywordFilter(source: TechHubSource, item: ParsedFeedItem): boolean {
  if (!source.keywordFilter || source.keywordFilter.length === 0) return true;
  const hay = `${item.title} ${item.description} ${item.tags.join(' ')}`.toLowerCase();
  return source.keywordFilter.some((kw) => hay.includes(kw.toLowerCase()));
}

function buildDedupeLookups(db: TechHubDatabase) {
  const guidSet = new Set<string>();
  const urlSet = new Set<string>();
  const hashSet = new Set<string>();

  for (const a of db.articles) {
    if (a.guid) guidSet.add(a.guid.toLowerCase());
    if (a.canonicalUrl) urlSet.add(a.canonicalUrl.toLowerCase());
    if (a.contentHash) hashSet.add(a.contentHash);
  }
  return { guidSet, urlSet, hashSet };
}

export async function scanSingleSource(
  sourceId: string,
  trigger: 'startup' | 'scheduled' | 'manual' | 'source' = 'source'
): Promise<{
  ok: boolean;
  source: TechHubSource | null;
  newAdded: number;
  duplicatesSkipped: number;
  error: string | null;
}> {
  if (activeSourceScans.has(sourceId)) {
    return {
      ok: false,
      source: null,
      newAdded: 0,
      duplicatesSkipped: 0,
      error: 'Scan already in progress for this source.',
    };
  }

  const db = loadTechHubDb();
  const source = db.sources.find((s) => s.id === sourceId);
  if (!source) {
    return { ok: false, source: null, newAdded: 0, duplicatesSkipped: 0, error: 'Source not found.' };
  }

  const startedIso = new Date().toISOString();
  const startMs = Date.now();

  if (!source.feedUrl || source.validationStatus === 'unverified' || source.feedType === 'unverified') {
    const entry: ScanHistoryRecord = {
      id: makeId('scan'),
      startedAt: startedIso,
      finishedAt: new Date().toISOString(),
      trigger,
      sourceId: source.id,
      sourceName: source.name,
      status: 'skipped',
      httpStatus: null,
      itemsFound: 0,
      newAdded: 0,
      duplicatesSkipped: 0,
      errorMessage: source.validationNote || 'Unverified source; skipped.',
      durationMs: Date.now() - startMs,
    };
    db.scanHistory.unshift(entry);
    db.scanHistory = db.scanHistory.slice(0, MAX_SCAN_HISTORY);
    await saveTechHubDb(db);
    return { ok: false, source, newAdded: 0, duplicatesSkipped: 0, error: entry.errorMessage };
  }

  activeSourceScans.add(sourceId);
  try {
    const res = await fetchFeedWithRetry(source.feedUrl, source.etag, source.lastModified);
    const nowIso = new Date().toISOString();
    source.lastScanAt = nowIso;
    source.lastHttpStatus = res.status;
    source.updatedAt = nowIso;

    if (res.status === 304) {
      source.lastSuccessAt = nowIso;
      source.lastError = null;
      source.validationStatus = 'verified';
      const entry: ScanHistoryRecord = {
        id: makeId('scan'),
        startedAt: startedIso,
        finishedAt: nowIso,
        trigger,
        sourceId: source.id,
        sourceName: source.name,
        status: 'not_modified',
        httpStatus: 304,
        itemsFound: 0,
        newAdded: 0,
        duplicatesSkipped: 0,
        errorMessage: null,
        durationMs: Date.now() - startMs,
      };
      db.scanHistory.unshift(entry);
      db.scanHistory = db.scanHistory.slice(0, MAX_SCAN_HISTORY);
      await saveTechHubDb(db);
      return { ok: true, source, newAdded: 0, duplicatesSkipped: 0, error: null };
    }

    if (res.status < 200 || res.status >= 300) {
      const errMsg = `Upstream returned HTTP ${res.status}.`;
      source.lastError = errMsg;
      source.validationStatus = 'error';
      const entry: ScanHistoryRecord = {
        id: makeId('scan'),
        startedAt: startedIso,
        finishedAt: nowIso,
        trigger,
        sourceId: source.id,
        sourceName: source.name,
        status: 'error',
        httpStatus: res.status,
        itemsFound: 0,
        newAdded: 0,
        duplicatesSkipped: 0,
        errorMessage: errMsg,
        durationMs: Date.now() - startMs,
      };
      db.scanHistory.unshift(entry);
      db.scanHistory = db.scanHistory.slice(0, MAX_SCAN_HISTORY);
      await saveTechHubDb(db);
      return { ok: false, source, newAdded: 0, duplicatesSkipped: 0, error: errMsg };
    }

    const parsed = parseRssOrAtomXml(res.body, source.feedUrl);
    if (!parsed) {
      const errMsg = 'Response body is not valid RSS or Atom XML.';
      source.lastError = errMsg;
      source.validationStatus = 'error';
      const entry: ScanHistoryRecord = {
        id: makeId('scan'),
        startedAt: startedIso,
        finishedAt: nowIso,
        trigger,
        sourceId: source.id,
        sourceName: source.name,
        status: 'error',
        httpStatus: res.status,
        itemsFound: 0,
        newAdded: 0,
        duplicatesSkipped: 0,
        errorMessage: errMsg,
        durationMs: Date.now() - startMs,
      };
      db.scanHistory.unshift(entry);
      db.scanHistory = db.scanHistory.slice(0, MAX_SCAN_HISTORY);
      await saveTechHubDb(db);
      return { ok: false, source, newAdded: 0, duplicatesSkipped: 0, error: errMsg };
    }

    if (res.etag) source.etag = res.etag;
    if (res.lastModified) source.lastModified = res.lastModified;
    source.feedType = parsed.feedType;
    source.validationStatus = 'verified';
    source.lastSuccessAt = nowIso;
    source.lastError = null;

    const linkedCatIds = db.sourceCategories
      .filter((sc) => sc.sourceId === source.id)
      .map((sc) => sc.categoryId);

    const lookups = buildDedupeLookups(db);
    let newAdded = 0;
    let duplicatesSkipped = 0;
    const newlyInserted: TechHubArticle[] = [];

    const byGuid = new Map<string, TechHubArticle>();
    const byUrl = new Map<string, TechHubArticle>();
    for (const existingArt of db.articles) {
      if (existingArt.guid) byGuid.set(existingArt.guid.toLowerCase(), existingArt);
      if (existingArt.canonicalUrl) byUrl.set(existingArt.canonicalUrl.toLowerCase(), existingArt);
    }

    for (const item of parsed.items) {
      if (!passesKeywordFilter(source, item)) continue;

      const canonicalUrl = normalizeCanonicalUrl(item.url);
      const contentHash = computeContentHash(item.title, canonicalUrl, item.publishedAt);
      const guidKey = item.guid.toLowerCase();
      const urlKey = canonicalUrl.toLowerCase();

      // Strict deduplication: NEVER re-import or unarchive existing/archived items
      if (
        lookups.guidSet.has(guidKey) ||
        lookups.urlSet.has(urlKey) ||
        lookups.hashSet.has(contentHash)
      ) {
        const matched = byGuid.get(guidKey) || byUrl.get(urlKey);
        if (matched) {
          if (!matched.imageUrl && item.imageUrl) {
            matched.imageUrl = item.imageUrl;
          }
          if ((!matched.contentPreview || matched.contentPreview.length === 0) && item.contentPreview.length > 0) {
            matched.contentPreview = item.contentPreview;
          }
        }
        duplicatesSkipped++;
        continue;
      }

      lookups.guidSet.add(guidKey);
      lookups.urlSet.add(urlKey);
      lookups.hashSet.add(contentHash);

      const articleId = makeId('art');
      const newArticle: TechHubArticle = {
        id: articleId,
        guid: item.guid,
        canonicalUrl,
        contentHash,
        sourceId: source.id,
        title: item.title,
        url: item.url,
        author: item.author,
        description: item.description,
        imageUrl: item.imageUrl,
        contentPreview: item.contentPreview,
        publishedAt: item.publishedAt,
        fetchedAt: nowIso,
        isArchived: false,
        archivedAt: null,
        aiSummaryTr: null,
        aiTechnicalConcepts: [],
        aiKeyPoints: [],
        aiDomainRelevance: [],
        aiImportance: null,
        aiGeneratedAt: null,
        aiModel: null,
      };

      db.articles.push(newArticle);
      newlyInserted.push(newArticle);

      const catIds = resolveArticleCategories(linkedCatIds, item);
      for (const cid of catIds) {
        db.articleCategories.push({ articleId, categoryId: cid });
      }
      for (const tag of item.tags) {
        db.articleTags.push({ articleId, tag, origin: 'feed' });
      }
      db.articleUserState.push({
        articleId,
        isRead: false,
        isFavorite: false,
        readAt: null,
        updatedAt: nowIso,
      });

      newAdded++;
    }

    source.totalFetched = db.articles.filter((a) => a.sourceId === source.id).length;

    // Optional automatic AI summarization for newly discovered items
    if (
      db.aiConfig.enabled &&
      db.aiConfig.autoSummarizeOnScan &&
      isGeminiConfigured() &&
      newlyInserted.length > 0
    ) {
      const catNameMap = new Map(db.categories.map((c) => [c.id, c.name]));
      const slice = newlyInserted.slice(0, Math.max(1, db.aiConfig.maxAutoPerScan));
      for (const art of slice) {
        const artCatIds = db.articleCategories
          .filter((ac) => ac.articleId === art.id)
          .map((ac) => catNameMap.get(ac.categoryId) || '');
        const aiRes = await analyzeArticleWithAi(art, source.name, artCatIds.filter(Boolean));
        if (aiRes.ok) {
          art.aiSummaryTr = aiRes.analysis.turkishSummary;
          art.aiTechnicalConcepts = aiRes.analysis.technicalConcepts;
          art.aiKeyPoints = aiRes.analysis.keyPoints;
          art.aiDomainRelevance = aiRes.analysis.domainRelevance;
          art.aiImportance = aiRes.analysis.importance;
          art.aiGeneratedAt = new Date().toISOString();
          art.aiModel = 'gemini-4-hydrogen';
          for (const tag of aiRes.analysis.suggestedTags) {
            db.articleTags.push({ articleId: art.id, tag, origin: 'ai' });
          }
        }
      }
    }

    const entry: ScanHistoryRecord = {
      id: makeId('scan'),
      startedAt: startedIso,
      finishedAt: new Date().toISOString(),
      trigger,
      sourceId: source.id,
      sourceName: source.name,
      status: 'success',
      httpStatus: res.status,
      itemsFound: parsed.items.length,
      newAdded,
      duplicatesSkipped,
      errorMessage: null,
      durationMs: Date.now() - startMs,
    };
    db.scanHistory.unshift(entry);
    db.scanHistory = db.scanHistory.slice(0, MAX_SCAN_HISTORY);
    await saveTechHubDb(db);

    return { ok: true, source, newAdded, duplicatesSkipped, error: null };
  } catch (err) {
    const nowIso = new Date().toISOString();
    const errMsg = err instanceof Error ? err.message : 'Feed scan failed';
    source.lastScanAt = nowIso;
    source.lastError = errMsg;
    source.validationStatus = 'error';
    source.updatedAt = nowIso;

    const entry: ScanHistoryRecord = {
      id: makeId('scan'),
      startedAt: startedIso,
      finishedAt: nowIso,
      trigger,
      sourceId: source.id,
      sourceName: source.name,
      status: 'error',
      httpStatus: null,
      itemsFound: 0,
      newAdded: 0,
      duplicatesSkipped: 0,
      errorMessage: errMsg,
      durationMs: Date.now() - startMs,
    };
    db.scanHistory.unshift(entry);
    db.scanHistory = db.scanHistory.slice(0, MAX_SCAN_HISTORY);
    await saveTechHubDb(db);
    return { ok: false, source, newAdded: 0, duplicatesSkipped: 0, error: errMsg };
  } finally {
    activeSourceScans.delete(sourceId);
  }
}

export async function runGlobalScan(
  trigger: 'startup' | 'scheduled' | 'manual' = 'manual'
): Promise<{
  alreadyRunning: boolean;
  scannedSources: number;
  succeeded: number;
  failed: number;
  newAdded: number;
  duplicatesSkipped: number;
}> {
  if (isGlobalScanRunning) {
    return {
      alreadyRunning: true,
      scannedSources: 0,
      succeeded: 0,
      failed: 0,
      newAdded: 0,
      duplicatesSkipped: 0,
    };
  }

  isGlobalScanRunning = true;
  const db = loadTechHubDb();
  const startedAt = new Date().toISOString();
  const enabledSources = db.sources.filter(
    (s) => s.enabled && Boolean(s.feedUrl) && s.feedType !== 'unverified'
  );

  let succeeded = 0;
  let failed = 0;
  let newAdded = 0;
  let duplicatesSkipped = 0;

  try {
    let cursor = 0;
    const worker = async () => {
      while (cursor < enabledSources.length) {
        const idx = cursor++;
        const src = enabledSources[idx];
        const res = await scanSingleSource(src.id, trigger);
        if (res.ok) succeeded++;
        else failed++;
        newAdded += res.newAdded;
        duplicatesSkipped += res.duplicatesSkipped;
      }
    };

    const workers = Array.from(
      { length: Math.min(MAX_CONCURRENCY, Math.max(1, enabledSources.length)) },
      () => worker()
    );
    await Promise.all(workers);

    const latestDb = loadTechHubDb();
    const nowIso = new Date().toISOString();
    latestDb.scheduler.lastGlobalScanAt = startedAt;
    if (succeeded > 0) {
      latestDb.scheduler.lastSuccessfulGlobalScanAt = nowIso;
    }
    await saveTechHubDb(latestDb);

    return {
      alreadyRunning: false,
      scannedSources: enabledSources.length,
      succeeded,
      failed,
      newAdded,
      duplicatesSkipped,
    };
  } finally {
    isGlobalScanRunning = false;
  }
}

export function getScanStatus() {
  const db = loadTechHubDb();
  return {
    isGlobalScanRunning,
    activeSourceIds: Array.from(activeSourceScans),
    scheduler: db.scheduler,
  };
}

export function startBackendScheduler(): void {
  if (schedulerTimer) return;

  const db = loadTechHubDb();
  const lastMs = db.scheduler.lastGlobalScanAt
    ? Date.parse(db.scheduler.lastGlobalScanAt)
    : 0;
  const intervalMs = Math.max(1, db.scheduler.intervalHours || 3) * 60 * 60 * 1000;

  // Run initial startup scan if database has no articles or >= intervalHours elapsed
  if (db.articles.length === 0 || Date.now() - lastMs >= intervalMs) {
    setTimeout(() => {
      void runGlobalScan('startup');
    }, 1500);
  }

  schedulerTimer = setInterval(() => {
    const latest = loadTechHubDb();
    if (!latest.scheduler.autoSyncEnabled) return;
    const latestLast = latest.scheduler.lastGlobalScanAt
      ? Date.parse(latest.scheduler.lastGlobalScanAt)
      : 0;
    const targetMs =
      Math.max(1, latest.scheduler.intervalHours || 3) * 60 * 60 * 1000 ||
      THREE_HOURS_MS;
    if (Date.now() - latestLast >= targetMs) {
      void runGlobalScan('scheduled');
    }
  }, SCHEDULER_POLL_MS);
}
