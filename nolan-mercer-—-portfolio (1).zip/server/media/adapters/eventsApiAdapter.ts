import {
  MediaEvent,
  MediaEventAttendanceMode,
  MediaEventStatus,
  MediaEventType,
  MediaSource,
  makeMediaId,
  normalizeMediaUrl,
} from '../mediaDb.ts';
import { validatePublicHttpUrl } from './httpClient.ts';
import { stripHtml } from './rssAtomAdapter.ts';

function extractTimeAndZone(rawIso: string): {
  iso: string | null;
  startTime: string | null;
  timezone: string | null;
} {
  const trimmed = (rawIso || '').trim();
  if (!trimmed) return { iso: null, startTime: null, timezone: null };
  const ts = Date.parse(trimmed);
  if (Number.isNaN(ts)) return { iso: null, startTime: null, timezone: null };
  const iso = new Date(ts).toISOString();

  const timeMatch = trimmed.match(/T(\d{2}:\d{2})(?::\d{2})?(Z|[+-]\d{2}:?\d{2})?/i);
  const localHHmm = timeMatch?.[1] || null;
  const offset = timeMatch?.[2] || null;
  const timezone = offset
    ? offset.toUpperCase() === 'Z'
      ? 'UTC'
      : `UTC${offset}`
    : 'UTC';

  return {
    iso,
    startTime: localHHmm ? `${localHHmm} (${timezone})` : null,
    timezone,
  };
}

function finalizeVerificationAndStatus(params: {
  startIso: string | null;
  endIso: string | null;
  registrationUrl: string | null;
  nowMs: number;
  nowIso: string;
}): {
  status: MediaEventStatus;
  verificationStatus: 'verified' | 'unverified';
  verificationNote: string | null;
  isArchived: boolean;
  archivedAt: string | null;
} {
  if (!params.startIso || !params.registrationUrl) {
    return {
      status: 'unverified',
      verificationStatus: 'unverified',
      verificationNote: !params.startIso
        ? 'Etkinlik başlangıç tarihi API yanıtında doğrulanamadı.'
        : 'Kayıt bağlantısı API yanıtında doğrulanamadı.',
      isArchived: false,
      archivedAt: null,
    };
  }

  const startMs = Date.parse(params.startIso);
  const endMs = params.endIso
    ? Date.parse(params.endIso)
    : startMs + 4 * 3600_000;

  if (endMs < params.nowMs) {
    return {
      status: 'past',
      verificationStatus: 'verified',
      verificationNote: null,
      isArchived: true,
      archivedAt: params.nowIso,
    };
  }

  if (startMs <= params.nowMs && endMs >= params.nowMs) {
    return {
      status: 'ongoing',
      verificationStatus: 'verified',
      verificationNote: null,
      isArchived: false,
      archivedAt: null,
    };
  }

  return {
    status: 'upcoming',
    verificationStatus: 'verified',
    verificationNote: null,
    isArchived: false,
    archivedAt: null,
  };
}

function inferEventType(text: string): MediaEventType {
  const lower = text.toLowerCase();
  if (lower.includes('webinar')) return 'webinar';
  if (lower.includes('summit')) return 'summit';
  if (lower.includes('meetup') || lower.includes('chapter')) return 'meetup';
  return 'conference';
}

export function parseEventsApiJson(
  jsonText: string,
  source: MediaSource
): MediaEvent[] {
  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    throw new Error('Etkinlik API yanıtı geçerli JSON formatında değil.');
  }

  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();
  const events: MediaEvent[] = [];
  const seen = new Set<string>();

  // 1) CNCF Community / Bevy JSON API: { results: [...] }
  if (
    parsed &&
    typeof parsed === 'object' &&
    !Array.isArray(parsed) &&
    Array.isArray((parsed as { results?: unknown[] }).results)
  ) {
    const results = (parsed as { results: Array<Record<string, unknown>> }).results;
    for (const raw of results) {
      const title = typeof raw.title === 'string' ? raw.title.trim() : '';
      if (!title) continue;

      const rawUrl = typeof raw.url === 'string' ? raw.url.trim() : '';
      const validUrl = validatePublicHttpUrl(rawUrl)?.toString() || null;
      const startParsed = extractTimeAndZone(
        typeof raw.start_date === 'string' ? raw.start_date : ''
      );
      const endParsed = extractTimeAndZone(
        typeof raw.end_date === 'string' ? raw.end_date : ''
      );

      const chapter =
        raw.chapter && typeof raw.chapter === 'object'
          ? (raw.chapter as Record<string, unknown>)
          : null;
      const chapterTitle =
        typeof chapter?.title === 'string' ? chapter.title.trim() : '';
      const city = typeof chapter?.city === 'string' ? chapter.city.trim() : '';
      const country =
        typeof chapter?.country_name === 'string'
          ? chapter.country_name.trim()
          : '';
      const chapterLoc =
        typeof chapter?.chapter_location === 'string'
          ? chapter.chapter_location.trim()
          : '';
      const rawDesc =
        typeof raw.description_short === 'string'
          ? raw.description_short
          : typeof raw.description === 'string'
            ? raw.description
            : typeof chapter?.description === 'string'
              ? chapter.description
              : '';
      const description = stripHtml(rawDesc).slice(0, 1000);

      const isVirtual =
        Boolean(raw.is_virtual_event) ||
        /\b(virtual|online|webinar)\b/i.test(`${title} ${chapterLoc}`);
      const locationStr =
        [city, country].filter(Boolean).join(', ') || chapterLoc || null;
      const attendanceMode: MediaEventAttendanceMode =
        isVirtual && locationStr && !/virtual|online/i.test(locationStr)
          ? 'hybrid'
          : isVirtual
            ? 'online'
            : locationStr
              ? 'physical'
              : 'unknown';

      const organizer = chapterTitle ? `CNCF · ${chapterTitle}` : source.name;
      const originalUrl = validUrl || source.websiteUrl;
      const canonicalUrl = normalizeMediaUrl(originalUrl);
      const guid = raw.id ? `cncf-${String(raw.id)}` : canonicalUrl;
      if (seen.has(guid)) continue;
      seen.add(guid);

      const state = finalizeVerificationAndStatus({
        startIso: startParsed.iso,
        endIso: endParsed.iso,
        registrationUrl: validUrl,
        nowMs,
        nowIso,
      });

      events.push({
        id: makeMediaId('mevt', `${source.id}:${guid}`),
        guid,
        canonicalUrl,
        eventName: title,
        organizer,
        startDate: startParsed.iso,
        startTime: startParsed.startTime,
        endDate: endParsed.iso,
        timezone:
          (typeof raw.timezone === 'string' && raw.timezone.trim()) ||
          startParsed.timezone,
        attendanceMode,
        location: locationStr,
        description,
        registrationUrl: validUrl,
        originalUrl,
        sourceId: source.id,
        matchedSourceIds: [source.id],
        category: source.category,
        categories: source.categories.length > 0 ? source.categories : [source.category],
        eventType: inferEventType(`${title} ${chapterTitle}`),
        status: state.status,
        verificationStatus: state.verificationStatus,
        verificationNote: state.verificationNote,
        publishedAt: startParsed.iso,
        updatedAt: null,
        fetchedAt: nowIso,
        isFavorite: false,
        isArchived: state.isArchived,
        archivedAt: state.archivedAt,
      });
    }
    return events;
  }

  // 2) Generic / Eventbrite / Meetup / Sessionize array or { events: [...] }
  const arrayCandidate: Array<Record<string, unknown>> = Array.isArray(parsed)
    ? (parsed as Array<Record<string, unknown>>)
    : parsed &&
        typeof parsed === 'object' &&
        Array.isArray((parsed as { events?: unknown[] }).events)
      ? (parsed as { events: Array<Record<string, unknown>> }).events
      : parsed &&
          typeof parsed === 'object' &&
          Array.isArray((parsed as { items?: unknown[] }).items)
        ? (parsed as { items: Array<Record<string, unknown>> }).items
        : [];

  for (const raw of arrayCandidate) {
    const rawNameObj = raw.name as { text?: string } | string | undefined;
    const title =
      typeof raw.title === 'string'
        ? raw.title.trim()
        : typeof rawNameObj === 'string'
          ? rawNameObj.trim()
          : typeof rawNameObj?.text === 'string'
            ? rawNameObj.text.trim()
            : '';
    if (!title) continue;

    const rawUrl =
      (typeof raw.url === 'string' && raw.url) ||
      (typeof raw.registrationUrl === 'string' && raw.registrationUrl) ||
      (typeof raw.link === 'string' && raw.link) ||
      '';
    const validUrl = validatePublicHttpUrl(rawUrl)?.toString() || null;

    const startRawObj = raw.start as { utc?: string; local?: string; timezone?: string } | undefined;
    const endRawObj = raw.end as { utc?: string; local?: string } | undefined;

    const startStr =
      (typeof raw.startDate === 'string' && raw.startDate) ||
      (typeof raw.startsAt === 'string' && raw.startsAt) ||
      (typeof raw.start_date === 'string' && raw.start_date) ||
      startRawObj?.local ||
      startRawObj?.utc ||
      '';
    const endStr =
      (typeof raw.endDate === 'string' && raw.endDate) ||
      (typeof raw.endsAt === 'string' && raw.endsAt) ||
      (typeof raw.end_date === 'string' && raw.end_date) ||
      endRawObj?.local ||
      endRawObj?.utc ||
      '';

    const startParsed = extractTimeAndZone(startStr);
    const endParsed = extractTimeAndZone(endStr);

    const rawDescObj = raw.description as { text?: string } | string | undefined;
    const descStr =
      typeof rawDescObj === 'string'
        ? rawDescObj
        : typeof rawDescObj?.text === 'string'
          ? rawDescObj.text
          : typeof raw.summary === 'string'
            ? raw.summary
            : '';
    const description = stripHtml(descStr).slice(0, 1000);

    const location =
      (typeof raw.location === 'string' && raw.location.trim()) ||
      (typeof raw.room === 'string' && raw.room.trim()) ||
      null;
    const isOnline =
      Boolean(raw.online_event) ||
      Boolean(raw.isOnline) ||
      /\b(online|virtual|webinar)\b/i.test(`${title} ${location || ''}`);
    const attendanceMode: MediaEventAttendanceMode =
      isOnline && location && !/online|virtual/i.test(location)
        ? 'hybrid'
        : isOnline
          ? 'online'
          : location
            ? 'physical'
            : 'unknown';

    const originalUrl = validUrl || source.websiteUrl;
    const canonicalUrl = normalizeMediaUrl(originalUrl);
    const guid = raw.id ? `${source.id}-${String(raw.id)}` : canonicalUrl;
    if (!guid || seen.has(guid)) continue;
    seen.add(guid);

    const state = finalizeVerificationAndStatus({
      startIso: startParsed.iso,
      endIso: endParsed.iso,
      registrationUrl: validUrl,
      nowMs,
      nowIso,
    });

    events.push({
      id: makeMediaId('mevt', `${source.id}:${guid}`),
      guid,
      canonicalUrl,
      eventName: title,
      organizer:
        (typeof raw.organizer === 'string' && raw.organizer.trim()) || source.name,
      startDate: startParsed.iso,
      startTime: startParsed.startTime,
      endDate: endParsed.iso,
      timezone:
        (typeof raw.timezone === 'string' && raw.timezone.trim()) ||
        startRawObj?.timezone ||
        startParsed.timezone,
      attendanceMode,
      location,
      description,
      registrationUrl: validUrl,
      originalUrl,
      sourceId: source.id,
      matchedSourceIds: [source.id],
      category: source.category,
      categories: source.categories.length > 0 ? source.categories : [source.category],
      eventType: inferEventType(`${title} ${description}`),
      status: state.status,
      verificationStatus: state.verificationStatus,
      verificationNote: state.verificationNote,
      publishedAt: startParsed.iso,
      updatedAt: null,
      fetchedAt: nowIso,
      isFavorite: false,
      isArchived: state.isArchived,
      archivedAt: state.archivedAt,
    });
  }

  if (events.length === 0) {
    throw new Error('Etkinlik API yanıtında ayrıştırılabilir etkinlik kaydı bulunamadı.');
  }

  return events;
}
