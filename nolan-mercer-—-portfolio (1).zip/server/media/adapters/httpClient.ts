import net from 'net';

const DEFAULT_TIMEOUT_MS = 20_000;
const HOST_SPACING_MS = 180;

const hostLastRequestMs = new Map<string, number>();

function isPrivateOrBlockedHost(hostname: string): boolean {
  const host = hostname.trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (
    host === 'localhost' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host.endsWith('.localhost')
  ) {
    return true;
  }
  const ipVersion = net.isIP(host);
  if (ipVersion === 4) {
    const parts = host.split('.').map(Number);
    if (parts[0] === 10 || parts[0] === 127 || parts[0] === 0) return true;
    if (parts[0] === 169 && parts[1] === 254) return true;
    if (parts[0] === 192 && parts[1] === 168) return true;
    if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  }
  if (ipVersion === 6) {
    if (
      host === '::1' ||
      host.startsWith('fc') ||
      host.startsWith('fd') ||
      host.startsWith('fe80')
    ) {
      return true;
    }
  }
  return false;
}

export function validatePublicHttpUrl(rawUrl: string): URL | null {
  try {
    const parsed = new URL(rawUrl.trim());
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return null;
    }
    if (parsed.username || parsed.password) return null;
    if (isPrivateOrBlockedHost(parsed.hostname)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export interface HttpFetchResponse {
  ok: boolean;
  httpStatus: number | null;
  contentType: string;
  body: string;
  finalUrl: string;
  durationMs: number;
  error: string | null;
}

async function waitForHostSlot(hostname: string): Promise<void> {
  const key = hostname.toLowerCase();
  const prev = hostLastRequestMs.get(key) || 0;
  const elapsed = Date.now() - prev;
  if (elapsed < HOST_SPACING_MS) {
    await new Promise((r) => setTimeout(r, HOST_SPACING_MS - elapsed));
  }
  hostLastRequestMs.set(key, Date.now());
}

async function fetchOnce(
  targetUrl: string,
  timeoutMs: number,
  acceptHeader: string
): Promise<HttpFetchResponse> {
  const started = Date.now();
  const parsed = validatePublicHttpUrl(targetUrl);
  if (!parsed) {
    return {
      ok: false,
      httpStatus: null,
      contentType: '',
      body: '',
      finalUrl: targetUrl,
      durationMs: 0,
      error: 'Geçersiz veya erişime kapalı URL (yalnızca genel HTTP/HTTPS adresleri desteklenir).',
    };
  }

  await waitForHostSlot(parsed.hostname);

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);

  try {
    const res = await fetch(parsed.toString(), {
      method: 'GET',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; WorkspaceMediaCollector/1.0; +https://localhost)',
        Accept: acceptHeader,
      },
      redirect: 'follow',
      signal: ctrl.signal,
    });
    const body = await res.text();
    const contentType = (res.headers.get('content-type') || '').toLowerCase();
    const durationMs = Date.now() - started;

    if (!res.ok) {
      return {
        ok: false,
        httpStatus: res.status,
        contentType,
        body,
        finalUrl: res.url || targetUrl,
        durationMs,
        error:
          res.status === 429
            ? 'Rate limit aşıldı (HTTP 429).'
            : `Uzak sunucu HTTP ${res.status} hatası döndürdü.`,
      };
    }

    if (!body.trim()) {
      return {
        ok: false,
        httpStatus: res.status,
        contentType,
        body: '',
        finalUrl: res.url || targetUrl,
        durationMs,
        error: 'Uzak sunucu boş içerik döndürdü.',
      };
    }

    return {
      ok: true,
      httpStatus: res.status,
      contentType,
      body,
      finalUrl: res.url || targetUrl,
      durationMs,
      error: null,
    };
  } catch (err) {
    const isTimeout =
      err instanceof Error &&
      (err.name === 'AbortError' || err.message.toLowerCase().includes('abort'));
    return {
      ok: false,
      httpStatus: isTimeout ? 504 : null,
      contentType: '',
      body: '',
      finalUrl: targetUrl,
      durationMs: Date.now() - started,
      error: isTimeout
        ? `İstek ${Math.round(timeoutMs / 1000)} saniye içinde zaman aşımına uğradı.`
        : err instanceof Error
          ? err.message
          : 'Ağ bağlantı hatası.',
    };
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchWithRetry(
  targetUrl: string,
  options?: {
    timeoutMs?: number;
    maxRetries?: number;
    accept?: string;
  }
): Promise<HttpFetchResponse> {
  const timeoutMs = options?.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const maxRetries = options?.maxRetries ?? 1;
  const accept =
    options?.accept ??
    'application/rss+xml, application/atom+xml, text/calendar, application/json, application/xml, text/xml;q=0.9, */*;q=0.8';

  let last = await fetchOnce(targetUrl, timeoutMs, accept);
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const transient =
      !last.ok &&
      (last.httpStatus === null ||
        last.httpStatus === 504 ||
        last.httpStatus === 429 ||
        last.httpStatus >= 500);
    if (!transient) break;
    await new Promise((r) => setTimeout(r, 700 * (attempt + 1)));
    last = await fetchOnce(targetUrl, timeoutMs, accept);
  }
  return last;
}
