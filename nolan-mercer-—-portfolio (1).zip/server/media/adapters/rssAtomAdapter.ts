import {
  MediaEvent,
  MediaEventAttendanceMode,
  MediaEventStatus,
  MediaPodcastEpisode,
  MediaPodcastSeries,
  MediaSource,
  makeMediaId,
  normalizeMediaUrl,
} from '../mediaDb.ts';
import { fetchWithRetry, validatePublicHttpUrl } from './httpClient.ts';

export function decodeXmlEntities(input: string): string {
  return (input || '')
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_m, dec) => {
      const code = Number(dec);
      return Number.isFinite(code) ? String.fromCodePoint(code) : '';
    })
    .replace(/&#x([0-9a-fA-F]+);/g, (_m, hex) => {
      const code = parseInt(hex, 16);
      return Number.isFinite(code) ? String.fromCodePoint(code) : '';
    });
}

export function stripHtml(input: string): string {
  return decodeXmlEntities(input)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function extractTagText(block: string, tagNames: string[]): string {
  for (const tag of tagNames) {
    const escaped = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(
      `<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`,
      'i'
    );
    const match = block.match(regex);
    if (match && match[1]) {
      const cleaned = stripHtml(match[1]);
      if (cleaned) return cleaned;
    }
  }
  return '';
}

export function extractTagRaw(block: string, tagNames: string[]): string {
  for (const tag of tagNames) {
    const escaped = tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(
      `<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`,
      'i'
    );
    const match = block.match(regex);
    if (match && match[1]) {
      const cleaned = decodeXmlEntities(match[1]).trim();
      if (cleaned) return cleaned;
    }
  }
  return '';
}

export function extractSafeIsoDate(raw: string): string | null {
  const cleaned = (raw || '').trim();
  if (!cleaned) return null;
  const ts = Date.parse(cleaned);
  if (Number.isNaN(ts)) return null;
  return new Date(ts).toISOString();
}

export function parseDurationInput(raw: string): {
  duration: string | null;
  durationSeconds: number | null;
} {
  const cleaned = (raw || '').trim();
  if (!cleaned) return { duration: null, durationSeconds: null };

  if (/^\d+$/.test(cleaned)) {
    const total = Number(cleaned);
    if (!Number.isFinite(total) || total <= 0) {
      return { duration: null, durationSeconds: null };
    }
    const hrs = Math.floor(total / 3600);
    const mins = Math.floor((total % 3600) / 60);
    const secs = total % 60;
    const formatted =
      hrs > 0
        ? `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
        : `${mins}:${String(secs).padStart(2, '0')}`;
    return { duration: formatted, durationSeconds: total };
  }

  const parts = cleaned.split(':').map((p) => Number(p.trim()));
  if (parts.every((n) => Number.isFinite(n) && n >= 0)) {
    if (parts.length === 3) {
      const total = parts[0] * 3600 + parts[1] * 60 + parts[2];
      return {
        duration: `${parts[0]}:${String(parts[1]).padStart(2, '0')}:${String(parts[2]).padStart(2, '0')}`,
        durationSeconds: total,
      };
    }
    if (parts.length === 2) {
      const total = parts[0] * 60 + parts[1];
      return {
        duration: `${parts[0]}:${String(parts[1]).padStart(2, '0')}`,
        durationSeconds: total,
      };
    }
  }

  return { duration: cleaned, durationSeconds: null };
}

function resolveHttpUrl(candidate: string, baseUrl: string): string | null {
  const raw = decodeXmlEntities(candidate || '').trim();
  if (!raw) return null;
  try {
    const resolved = new URL(raw, baseUrl);
    if (resolved.protocol !== 'https:' && resolved.protocol !== 'http:') return null;
    return resolved.toString();
  } catch {
    return null;
  }
}

function extractAtomLink(block: string, relWanted: string, baseUrl: string): string | null {
  const linkTags = block.matchAll(/<link\b([^>]*?)\/?>(?:<\/link>)?/gi);
  let fallbackHref: string | null = null;

  for (const m of linkTags) {
    const attrs = m[1] || '';
    const hrefMatch = attrs.match(/\bhref=["']([^"']+)["']/i);
    if (!hrefMatch?.[1]) continue;
    const relMatch = attrs.match(/\brel=["']([^"']+)["']/i);
    const rel = (relMatch?.[1] || 'alternate').toLowerCase();
    const resolved = resolveHttpUrl(hrefMatch[1], baseUrl);
    if (!resolved) continue;

    if (rel === relWanted) return resolved;
    if (!fallbackHref && rel === 'alternate') {
      fallbackHref = resolved;
    }
  }
  return relWanted === 'alternate' ? fallbackHref : null;
}

function extractFeedArtwork(headerXml: string, baseUrl: string): string | null {
  const itunesMatch = headerXml.match(
    /<itunes:image\b[^>]*\bhref=["']([^"']+)["'][^>]*>/i
  );
  if (itunesMatch?.[1]) {
    const u = resolveHttpUrl(itunesMatch[1], baseUrl);
    if (u) return u;
  }
  const imageBlock = headerXml.match(/<image\b[^>]*>([\s\S]*?)<\/image>/i);
  if (imageBlock?.[1]) {
    const url = extractTagRaw(imageBlock[1], ['url']);
    const u = resolveHttpUrl(url, baseUrl);
    if (u) return u;
  }
  const logoOrIcon = extractTagRaw(headerXml, ['logo', 'icon']);
  if (logoOrIcon) {
    const u = resolveHttpUrl(logoOrIcon, baseUrl);
    if (u) return u;
  }
  const mediaThumb = headerXml.match(
    /<media:thumbnail\b[^>]*\burl=["']([^"']+)["'][^>]*>/i
  );
  if (mediaThumb?.[1]) {
    const u = resolveHttpUrl(mediaThumb[1], baseUrl);
    if (u) return u;
  }
  return null;
}

function extractAudioEnclosure(block: string, baseUrl: string): string | null {
  const enclosures = block.matchAll(/<enclosure\b([^>]*?)\/?>(?:<\/enclosure>)?/gi);
  for (const m of enclosures) {
    const attrs = m[1] || '';
    const urlMatch = attrs.match(/\burl=["']([^"']+)["']/i);
    if (!urlMatch?.[1]) continue;
    const typeMatch = attrs.match(/\btype=["']([^"']+)["']/i);
    const typeLower = (typeMatch?.[1] || '').toLowerCase();
    if (!typeLower || typeLower.startsWith('audio/') || typeLower.includes('mpeg') || typeLower.includes('ogg')) {
      const resolved = resolveHttpUrl(urlMatch[1], baseUrl);
      if (resolved) return resolved;
    }
  }

  const mediaContents = block.matchAll(/<media:content\b([^>]*?)\/?>(?:<\/media:content>)?/gi);
  for (const m of mediaContents) {
    const attrs = m[1] || '';
    const urlMatch = attrs.match(/\burl=["']([^"']+)["']/i);
    if (!urlMatch?.[1]) continue;
    const typeMatch = attrs.match(/\btype=["']([^"']+)["']/i);
    const mediumMatch = attrs.match(/\bmedium=["']([^"']+)["']/i);
    if (
      (mediumMatch?.[1] || '').toLowerCase() === 'audio' ||
      (typeMatch?.[1] || '').toLowerCase().startsWith('audio/')
    ) {
      const resolved = resolveHttpUrl(urlMatch[1], baseUrl);
      if (resolved) return resolved;
    }
  }

  return extractAtomLink(block, 'enclosure', baseUrl);
}

export function detectXmlFeedFormat(xml: string): 'rss' | 'atom' | null {
  const head = (xml || '').trim().slice(0, 1200).toLowerCase();
  if (!head || head.startsWith('<!doctype html') || head.startsWith('<html')) {
    return null;
  }
  if (xml.includes('<rss') && xml.includes('<channel')) return 'rss';
  if (xml.includes('<feed') && xml.includes('<entry')) return 'atom';
  if (xml.includes('<rss') || xml.includes('<item>')) return 'rss';
  if (xml.includes('<feed')) return 'atom';
  return null;
}

export interface ParsedPodcastFeedResult {
  feedFormat: 'rss' | 'atom';
  series: MediaPodcastSeries;
  episodes: MediaPodcastEpisode[];
}

export function parsePodcastFeed(
  xml: string,
  feedUrl: string,
  source: MediaSource
): ParsedPodcastFeedResult {
  const feedFormat = detectXmlFeedFormat(xml);
  if (!feedFormat) {
    throw new Error('Yanıt geçerli bir RSS 2.0 veya Atom podcast feed formatında değil.');
  }

  const nowIso = new Date().toISOString();
  const isAtom = feedFormat === 'atom';
  const itemSplitToken = isAtom ? '<entry' : '<item';
  const firstIdx = xml.indexOf(itemSplitToken);
  const headerXml = firstIdx > 0 ? xml.slice(0, firstIdx) : xml;

  const seriesTitle =
    extractTagText(headerXml, ['title']) || source.name;
  const seriesDesc = extractTagText(headerXml, [
    'itunes:summary',
    'description',
    'subtitle',
  ]).slice(0, 1000);
  const seriesAuthor =
    extractTagText(headerXml, ['itunes:author', 'author', 'dc:creator']) || null;
  const ownerName = extractTagText(headerXml, ['itunes:name']);
  const publisher = ownerName || seriesAuthor || source.name;
  const seriesArtwork = extractFeedArtwork(headerXml, feedUrl);
  const language = extractTagText(headerXml, ['language']) || null;
  const seriesLinkRaw = isAtom
    ? extractAtomLink(headerXml, 'alternate', feedUrl) || ''
    : extractTagRaw(headerXml, ['link']);
  const websiteUrl =
    resolveHttpUrl(seriesLinkRaw, feedUrl) || source.websiteUrl || feedUrl;

  const seriesId = makeMediaId('mser', normalizeMediaUrl(feedUrl));

  const blockRegex = isAtom
    ? /<entry\b[^>]*>([\s\S]*?)<\/entry>/gi
    : /<item\b[^>]*>([\s\S]*?)<\/item>/gi;
  const blocks = Array.from(xml.matchAll(blockRegex));

  const episodes: MediaPodcastEpisode[] = [];
  const seenKeys = new Set<string>();

  for (const match of blocks) {
    const block = match[1] || '';
    const title = extractTagText(block, ['title']);
    if (!title) continue;

    const linkRaw = isAtom
      ? extractAtomLink(block, 'alternate', feedUrl) || ''
      : extractTagRaw(block, ['link']);
    const audioUrl = extractAudioEnclosure(block, feedUrl);
    const originalUrl =
      resolveHttpUrl(linkRaw, feedUrl) || audioUrl || websiteUrl;

    const guidRaw = extractTagRaw(block, ['guid', 'id']);
    const canonicalUrl = normalizeMediaUrl(originalUrl);
    const guid = guidRaw || canonicalUrl || makeMediaId('mep-guid', `${seriesId}:${title}`);
    const dedupKey = guid || canonicalUrl;
    if (seenKeys.has(dedupKey)) continue;
    seenKeys.add(dedupKey);

    const publishedAt = extractSafeIsoDate(
      extractTagRaw(block, ['pubDate', 'published', 'dc:date', 'updated'])
    );
    const updatedAt = extractSafeIsoDate(
      extractTagRaw(block, ['atom:updated', 'updated'])
    );
    const description = extractTagText(block, [
      'itunes:summary',
      'description',
      'summary',
      'content:encoded',
      'content',
    ]).slice(0, 1200);
    const epArtwork = extractFeedArtwork(block, feedUrl) || seriesArtwork;
    const { duration, durationSeconds } = parseDurationInput(
      extractTagText(block, ['itunes:duration'])
    );

    const epId = makeMediaId('mep', `${seriesId}:${guid || canonicalUrl}`);
    episodes.push({
      id: epId,
      guid,
      canonicalUrl,
      seriesId,
      seriesTitle,
      publisher,
      title,
      description,
      publishedAt,
      updatedAt,
      artworkUrl: epArtwork,
      duration,
      durationSeconds,
      audioUrl,
      originalUrl,
      category: source.category,
      categories: source.categories.length > 0 ? source.categories : [source.category],
      sourceId: source.id,
      matchedSourceIds: [source.id],
      isPlayed: false,
      isFavorite: false,
      isArchived: false,
      archivedAt: null,
      playbackPosition: 0,
      fetchedAt: nowIso,
    });
  }

  if (episodes.length === 0) {
    throw new Error('Podcast feedi geçerli bölüm (<item>/<entry>) içermiyor.');
  }

  const series: MediaPodcastSeries = {
    id: seriesId,
    sourceId: source.id,
    title: seriesTitle,
    publisher,
    author: seriesAuthor,
    description: seriesDesc || source.description,
    artworkUrl: seriesArtwork,
    websiteUrl,
    feedUrl,
    language,
    category: source.category,
    categories: source.categories.length > 0 ? source.categories : [source.category],
    lastSyncedAt: nowIso,
    isFollowed: false,
    isFavorite: false,
    episodeCount: episodes.length,
  };

  return { feedFormat, series, episodes };
}

function inferAttendanceMode(
  textParts: Array<string | null | undefined>
): MediaEventAttendanceMode {
  const combined = textParts.filter(Boolean).join(' ').toLowerCase();
  const hasOnline = /\b(online|virtual|webinar|livestream|zoom|teams|remote)\b/.test(
    combined
  );
  const hasPhysical = /\b(in-person|venue|convention center|hotel|hall|street|conference center|city)\b/.test(
    combined
  );
  if (hasOnline && hasPhysical) return 'hybrid';
  if (hasOnline) return 'online';
  if (hasPhysical) return 'physical';
  return 'unknown';
}

function formatUtcTimeHHmm(iso: string | null): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')} UTC`;
}

export function parseEventsRssAtomFeed(
  xml: string,
  source: MediaSource
): { feedFormat: 'rss' | 'atom'; events: MediaEvent[] } {
  const feedFormat = detectXmlFeedFormat(xml);
  if (!feedFormat) {
    throw new Error('Yanıt geçerli bir RSS veya Atom etkinlik feedi değil.');
  }

  const isAtom = feedFormat === 'atom';
  const blockRegex = isAtom
    ? /<entry\b[^>]*>([\s\S]*?)<\/entry>/gi
    : /<item\b[^>]*>([\s\S]*?)<\/item>/gi;
  const blocks = Array.from(xml.matchAll(blockRegex));
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();

  const events: MediaEvent[] = [];
  const seen = new Set<string>();

  for (const match of blocks) {
    const block = match[1] || '';
    const title = extractTagText(block, ['title']);
    if (!title) continue;

    const linkRaw = isAtom
      ? extractAtomLink(block, 'alternate', source.feedOrEndpoint) || ''
      : extractTagRaw(block, ['link']);
    const originalUrl =
      resolveHttpUrl(linkRaw, source.feedOrEndpoint) || source.websiteUrl;
    const registrationUrl = resolveHttpUrl(linkRaw, source.feedOrEndpoint);

    const guidRaw = extractTagRaw(block, ['guid', 'id']);
    const canonicalUrl = normalizeMediaUrl(originalUrl);
    const guid = guidRaw || canonicalUrl;
    if (!guid || seen.has(guid)) continue;
    seen.add(guid);

    // Only accept explicit event date tags as verified event startDate; never fabricate from article pubDate!
    const explicitStart = extractSafeIsoDate(
      extractTagRaw(block, ['ev:startdate', 'dtstart', 'event:startdate'])
    );
    const explicitEnd = extractSafeIsoDate(
      extractTagRaw(block, ['ev:enddate', 'dtend', 'event:enddate'])
    );
    const publishedAt = extractSafeIsoDate(
      extractTagRaw(block, ['pubDate', 'published', 'dc:date', 'updated'])
    );
    const updatedAt = extractSafeIsoDate(
      extractTagRaw(block, ['atom:updated', 'updated'])
    );
    const location =
      extractTagText(block, ['ev:location', 'location']) || null;
    const description = extractTagText(block, [
      'description',
      'summary',
      'content:encoded',
      'content',
    ]).slice(0, 1000);

    const hasVerifiedDateAndLink = Boolean(explicitStart && registrationUrl);
    let status: MediaEventStatus = 'unverified';
    let isArchived = false;
    let archivedAt: string | null = null;
    let verificationStatus: 'verified' | 'unverified' = 'unverified';
    let verificationNote: string | null = null;

    if (hasVerifiedDateAndLink && explicitStart) {
      verificationStatus = 'verified';
      const startMs = Date.parse(explicitStart);
      const endMs = explicitEnd ? Date.parse(explicitEnd) : startMs + 86_400_000;
      if (endMs < nowMs) {
        status = 'past';
        isArchived = true;
        archivedAt = nowIso;
      } else if (startMs <= nowMs && endMs >= nowMs) {
        status = 'ongoing';
      } else {
        status = 'upcoming';
      }
    } else {
      verificationStatus = 'unverified';
      status = 'unverified';
      verificationNote = !explicitStart
        ? 'Feed öğesinde açık etkinlik başlangıç tarihi (ev:startdate / dtstart) bulunamadı; yayın tarihi etkinlik tarihi olarak varsayılmadı.'
        : 'Kayıt bağlantısı doğrulanamadı.';
    }

    const combinedText = `${title} ${description}`.toLowerCase();
    const eventType = combinedText.includes('webinar')
      ? 'webinar'
      : combinedText.includes('meetup')
        ? 'meetup'
        : combinedText.includes('summit')
          ? 'summit'
          : 'conference';

    events.push({
      id: makeMediaId('mevt', `${source.id}:${guid}`),
      guid,
      canonicalUrl,
      eventName: title,
      organizer: source.name,
      startDate: explicitStart,
      startTime: formatUtcTimeHHmm(explicitStart),
      endDate: explicitEnd,
      timezone: explicitStart ? 'UTC' : null,
      attendanceMode: inferAttendanceMode([title, description, location]),
      location,
      description,
      registrationUrl,
      originalUrl,
      sourceId: source.id,
      matchedSourceIds: [source.id],
      category: source.category,
      categories: source.categories.length > 0 ? source.categories : [source.category],
      eventType,
      status,
      verificationStatus,
      verificationNote,
      publishedAt,
      updatedAt,
      fetchedAt: nowIso,
      isFavorite: false,
      isArchived,
      archivedAt,
    });
  }

  return { feedFormat, events };
}

export async function resolveApplePodcastRss(rawUrl: string): Promise<{
  ok: boolean;
  feedUrl?: string;
  podcastName?: string;
  artistName?: string;
  artworkUrl?: string;
  websiteUrl?: string;
  error?: string;
}> {
  const parsed = validatePublicHttpUrl(rawUrl);
  if (!parsed) {
    return { ok: false, error: 'Geçersiz Apple Podcasts URL formatı.' };
  }
  const host = parsed.hostname.toLowerCase();
  if (!host.includes('podcasts.apple.com') && !host.includes('itunes.apple.com')) {
    return { ok: false, error: 'URL podcasts.apple.com veya itunes.apple.com alan adında olmalıdır.' };
  }

  const idMatch = rawUrl.match(/\/id(\d+)/i) || rawUrl.match(/[?&]id=(\d+)/i);
  if (!idMatch?.[1]) {
    return { ok: false, error: 'Apple Podcasts URL içinde podcast ID (id...) bulunamadı.' };
  }

  const lookupUrl = `https://itunes.apple.com/lookup?id=${encodeURIComponent(idMatch[1])}&entity=podcast`;
  const res = await fetchWithRetry(lookupUrl, {
    timeoutMs: 15_000,
    maxRetries: 1,
    accept: 'application/json',
  });
  if (!res.ok) {
    return {
      ok: false,
      error: res.error || 'Apple iTunes Lookup API yanıt vermedi.',
    };
  }

  try {
    const json = JSON.parse(res.body) as {
      resultCount?: number;
      results?: Array<{
        feedUrl?: string;
        collectionName?: string;
        artistName?: string;
        artworkUrl600?: string;
        collectionViewUrl?: string;
      }>;
    };
    const item = json.results?.[0];
    if (!item?.feedUrl) {
      return {
        ok: false,
        error: 'Apple Podcasts kaydında açık RSS feedUrl bilgisi bulunamadı.',
      };
    }
    return {
      ok: true,
      feedUrl: item.feedUrl,
      podcastName: item.collectionName,
      artistName: item.artistName,
      artworkUrl: item.artworkUrl600,
      websiteUrl: item.collectionViewUrl || rawUrl,
    };
  } catch {
    return { ok: false, error: 'Apple Lookup API JSON yanıtı ayrıştırılamadı.' };
  }
}

export function isSpotifyPodcastUrl(rawUrl: string): boolean {
  try {
    const host = new URL(rawUrl).hostname.toLowerCase();
    return host === 'open.spotify.com' || host.endsWith('.spotify.com');
  } catch {
    return false;
  }
}
