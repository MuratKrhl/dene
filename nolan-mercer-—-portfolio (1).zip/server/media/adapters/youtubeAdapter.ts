import {
  MediaSource,
  MediaVideo,
  YouTubeQuotaTracker,
  YouTubeTargetKind,
  makeMediaId,
  normalizeMediaUrl,
} from '../mediaDb.ts';
import { fetchWithRetry } from './httpClient.ts';
import {
  extractSafeIsoDate,
  extractTagRaw,
  extractTagText,
} from './rssAtomAdapter.ts';

export interface ParsedYouTubeTarget {
  kind: YouTubeTargetKind;
  id: string;
  canonicalEndpoint: string;
  needsHandleResolution?: boolean;
  handle?: string;
}

export function parseIso8601Duration(isoDuration: string): {
  duration: string | null;
  durationSeconds: number | null;
} {
  const m = (isoDuration || '').match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/i);
  if (!m) return { duration: null, durationSeconds: null };
  const h = Number(m[1] || 0);
  const min = Number(m[2] || 0);
  const s = Number(m[3] || 0);
  const total = h * 3600 + min * 60 + s;
  if (total <= 0) return { duration: null, durationSeconds: null };
  const formatted =
    h > 0
      ? `${h}:${String(min).padStart(2, '0')}:${String(s).padStart(2, '0')}`
      : `${min}:${String(s).padStart(2, '0')}`;
  return { duration: formatted, durationSeconds: total };
}

export function parseYouTubeTarget(rawInput: string): ParsedYouTubeTarget | null {
  const input = (rawInput || '').trim();
  if (!input) return null;

  // Direct IDs
  if (/^UC[a-zA-Z0-9_-]{20,30}$/.test(input)) {
    return {
      kind: 'channel',
      id: input,
      canonicalEndpoint: input,
    };
  }
  if (/^(PL|UU|OL|FL|LL|RD)[a-zA-Z0-9_-]{10,50}$/.test(input)) {
    return {
      kind: 'playlist',
      id: input,
      canonicalEndpoint: input,
    };
  }
  if (/^[a-zA-Z0-9_-]{11}$/.test(input)) {
    return {
      kind: 'video',
      id: input,
      canonicalEndpoint: `https://www.youtube.com/watch?v=${input}`,
    };
  }
  if (input.startsWith('@') && input.length > 2) {
    const cleanHandle = input.slice(1).split(/[/?#]/)[0];
    return {
      kind: 'channel',
      id: '',
      canonicalEndpoint: `https://www.youtube.com/@${cleanHandle}`,
      needsHandleResolution: true,
      handle: cleanHandle,
    };
  }

  try {
    const parsed = new URL(input);
    const host = parsed.hostname.toLowerCase();

    // youtu.be/<videoId>
    if (host === 'youtu.be') {
      const vid = parsed.pathname.replace(/^\/+/, '').split('/')[0];
      if (/^[a-zA-Z0-9_-]{11}$/.test(vid)) {
        return {
          kind: 'video',
          id: vid,
          canonicalEndpoint: `https://www.youtube.com/watch?v=${vid}`,
        };
      }
      return null;
    }

    if (!host.includes('youtube.com') && !host.includes('youtube-nocookie.com')) {
      return null;
    }

    // feeds/videos.xml?channel_id=... or ?playlist_id=...
    const qChannel = parsed.searchParams.get('channel_id')?.trim();
    if (qChannel && /^UC[a-zA-Z0-9_-]{20,30}$/.test(qChannel)) {
      return { kind: 'channel', id: qChannel, canonicalEndpoint: qChannel };
    }
    const qPlaylist =
      parsed.searchParams.get('playlist_id')?.trim() ||
      parsed.searchParams.get('list')?.trim();
    if (qPlaylist && /^[a-zA-Z0-9_-]{10,60}$/.test(qPlaylist)) {
      return { kind: 'playlist', id: qPlaylist, canonicalEndpoint: qPlaylist };
    }

    // /watch?v= or /shorts/<id> or /embed/<id>
    const qVideo = parsed.searchParams.get('v')?.trim();
    if (qVideo && /^[a-zA-Z0-9_-]{11}$/.test(qVideo)) {
      return {
        kind: 'video',
        id: qVideo,
        canonicalEndpoint: `https://www.youtube.com/watch?v=${qVideo}`,
      };
    }

    const pathMatchVideo = parsed.pathname.match(/^\/(?:shorts|embed|live)\/([a-zA-Z0-9_-]{11})/);
    if (pathMatchVideo?.[1]) {
      return {
        kind: 'video',
        id: pathMatchVideo[1],
        canonicalEndpoint: `https://www.youtube.com/watch?v=${pathMatchVideo[1]}`,
      };
    }

    // /channel/UC...
    const pathMatchChannel = parsed.pathname.match(/^\/channel\/(UC[a-zA-Z0-9_-]{20,30})/);
    if (pathMatchChannel?.[1]) {
      return {
        kind: 'channel',
        id: pathMatchChannel[1],
        canonicalEndpoint: pathMatchChannel[1],
      };
    }

    // /@handle
    const handleMatch = parsed.pathname.match(/^\/@([^/?#]+)/);
    if (handleMatch?.[1]) {
      return {
        kind: 'channel',
        id: '',
        canonicalEndpoint: `https://www.youtube.com/@${handleMatch[1]}`,
        needsHandleResolution: true,
        handle: handleMatch[1],
      };
    }
  } catch {
    return null;
  }

  return null;
}

export function resetQuotaIfNewDay(quota: YouTubeQuotaTracker): void {
  const today = new Date().toISOString().slice(0, 10);
  if (quota.lastResetDate !== today) {
    quota.lastResetDate = today;
    quota.requestsToday = 0;
    quota.quotaUnitsEstimateToday = 0;
    quota.quotaExceededUntil = null;
    quota.lastError = null;
  }
}

export async function resolveYouTubeHandle(
  handle: string,
  quota: YouTubeQuotaTracker
): Promise<{ ok: boolean; channelId?: string; title?: string; error?: string }> {
  const apiKey = process.env.YOUTUBE_API_KEY?.trim();
  resetQuotaIfNewDay(quota);

  if (apiKey) {
    const url = `https://www.googleapis.com/youtube/v3/channels?part=id,snippet&forHandle=${encodeURIComponent(
      handle
    )}&key=${encodeURIComponent(apiKey)}`;
    const res = await fetchWithRetry(url, { timeoutMs: 15_000, maxRetries: 0, accept: 'application/json' });
    quota.requestsToday += 1;
    quota.quotaUnitsEstimateToday += 1;
    if (res.ok) {
      try {
        const json = JSON.parse(res.body) as {
          items?: Array<{ id?: string; snippet?: { title?: string } }>;
        };
        const ch = json.items?.[0];
        if (ch?.id) {
          return { ok: true, channelId: ch.id, title: ch.snippet?.title };
        }
      } catch {
        // fallback below
      }
    }
  }

  const htmlRes = await fetchWithRetry(`https://www.youtube.com/@${encodeURIComponent(handle)}`, {
    timeoutMs: 15_000,
    maxRetries: 0,
    accept: 'text/html',
  });
  if (htmlRes.ok) {
    const idMatch =
      htmlRes.body.match(/<meta\s+itemprop="identifier"\s+content="(UC[a-zA-Z0-9_-]{20,30})"/i) ||
      htmlRes.body.match(/"externalId":"(UC[a-zA-Z0-9_-]{20,30})"/);
    if (idMatch?.[1]) {
      const titleMatch = htmlRes.body.match(/<title>([^<]+)<\/title>/i);
      return {
        ok: true,
        channelId: idMatch[1],
        title: titleMatch?.[1]?.replace(/\s*-\s*YouTube\s*$/i, '').trim(),
      };
    }
  }

  return {
    ok: false,
    error: `@${handle} kanalı için YouTube Channel ID çözümlenemedi. Lütfen doğrudan UC... biçiminde Channel ID girin.`,
  };
}

function parseYouTubeAtomXml(
  xml: string,
  source: MediaSource,
  targetKind: 'channel' | 'playlist',
  targetId: string
): MediaVideo[] {
  if (!xml.includes('<feed') && !xml.includes('<entry')) {
    throw new Error('YouTube Atom feed yanıtı ayrıştırılamadı.');
  }

  const nowIso = new Date().toISOString();
  const feedHeader = xml.slice(0, xml.indexOf('<entry') > 0 ? xml.indexOf('<entry') : xml.length);
  const feedTitle = extractTagText(feedHeader, ['title']) || source.name;

  const entries = Array.from(xml.matchAll(/<entry\b[^>]*>([\s\S]*?)<\/entry>/gi));
  const videos: MediaVideo[] = [];
  const seen = new Set<string>();

  for (const match of entries) {
    const block = match[1] || '';
    const videoId = extractTagRaw(block, ['yt:videoId']);
    const title = extractTagText(block, ['title']);
    if (!videoId || !title || seen.has(videoId)) continue;
    seen.add(videoId);

    const channelId = extractTagRaw(block, ['yt:channelId']) || (targetKind === 'channel' ? targetId : '');
    const channelName = extractTagText(block, ['author name', 'name']) || feedTitle;
    const description = extractTagText(block, ['media:description', 'summary']).slice(0, 1200);
    const publishedAt = extractSafeIsoDate(extractTagRaw(block, ['published']));
    const updatedAt = extractSafeIsoDate(extractTagRaw(block, ['updated']));
    const thumbMatch = block.match(/<media:thumbnail\b[^>]*\burl=["']([^"']+)["'][^>]*>/i);
    const thumbnailUrl =
      thumbMatch?.[1] || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;

    const originalUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const embedUrl = `https://www.youtube.com/embed/${videoId}`;

    videos.push({
      id: makeMediaId('mvid', videoId),
      videoId,
      guid: `yt:video:${videoId}`,
      canonicalUrl: normalizeMediaUrl(originalUrl),
      title,
      description,
      channelName,
      channelId,
      playlistId: targetKind === 'playlist' ? targetId : null,
      playlistName: targetKind === 'playlist' ? feedTitle : `${channelName} Uploads`,
      publishedAt,
      updatedAt,
      thumbnailUrl,
      embedUrl,
      originalUrl,
      duration: null,
      durationSeconds: null,
      category: source.category,
      categories: source.categories.length > 0 ? source.categories : [source.category],
      sourceId: source.id,
      matchedSourceIds: [source.id],
      fetchedAt: nowIso,
      isWatched: false,
      isFavorite: false,
      isArchived: false,
      archivedAt: null,
    });
  }

  return videos;
}

export interface YouTubeFetchOutcome {
  ok: boolean;
  usedMode: 'youtube-data-api-v3' | 'atom-fallback' | 'blocked';
  videos: MediaVideo[];
  httpStatus: number | null;
  note: string | null;
  error: string | null;
}

export async function fetchYouTubeVideos(
  source: MediaSource,
  quota: YouTubeQuotaTracker
): Promise<YouTubeFetchOutcome> {
  resetQuotaIfNewDay(quota);

  const parsedTarget =
    source.youtubeTargetKind && source.youtubeTargetId
      ? {
          kind: source.youtubeTargetKind,
          id: source.youtubeTargetId,
          canonicalEndpoint: source.feedOrEndpoint,
        }
      : parseYouTubeTarget(source.feedOrEndpoint || source.websiteUrl);

  if (!parsedTarget || !parsedTarget.id) {
    return {
      ok: false,
      usedMode: 'blocked',
      videos: [],
      httpStatus: null,
      note: null,
      error:
        'Geçerli bir YouTube Channel ID (UC...), Playlist ID (PL...) veya Video ID belirtilmedi.',
    };
  }

  const apiKey = process.env.YOUTUBE_API_KEY?.trim();
  const inQuotaCooldown =
    quota.quotaExceededUntil !== null &&
    Date.parse(quota.quotaExceededUntil) > Date.now();

  if (apiKey && !inQuotaCooldown) {
    const nowIso = new Date().toISOString();
    try {
      let playlistIdToRead: string | null = null;
      let playlistName: string | null = null;
      let resolvedChannelTitle = source.name;
      let resolvedChannelId = parsedTarget.kind === 'channel' ? parsedTarget.id : '';
      let videoIds: string[] = [];

      if (parsedTarget.kind === 'channel') {
        const chUrl = `https://www.googleapis.com/youtube/v3/channels?part=contentDetails,snippet&id=${encodeURIComponent(
          parsedTarget.id
        )}&key=${encodeURIComponent(apiKey)}`;
        const chRes = await fetchWithRetry(chUrl, {
          timeoutMs: 15_000,
          maxRetries: 0,
          accept: 'application/json',
        });
        quota.requestsToday += 1;
        quota.quotaUnitsEstimateToday += 1;

        if (chRes.httpStatus === 403 || chRes.httpStatus === 429) {
          quota.quotaExceededUntil = new Date(Date.now() + 6 * 3600_000).toISOString();
          quota.lastError = `YouTube Data API kota/yetki sınırı (HTTP ${chRes.httpStatus}).`;
        } else if (chRes.ok) {
          const chJson = JSON.parse(chRes.body) as {
            items?: Array<{
              snippet?: { title?: string };
              contentDetails?: { relatedPlaylists?: { uploads?: string } };
            }>;
          };
          const chItem = chJson.items?.[0];
          resolvedChannelTitle = chItem?.snippet?.title || source.name;
          playlistIdToRead =
            chItem?.contentDetails?.relatedPlaylists?.uploads || null;
          playlistName = `${resolvedChannelTitle} Uploads`;
        } else {
          return {
            ok: false,
            usedMode: 'youtube-data-api-v3',
            videos: [],
            httpStatus: chRes.httpStatus,
            note: null,
            error: chRes.error || 'YouTube Data API channels sorgusu başarısız.',
          };
        }
      } else if (parsedTarget.kind === 'playlist') {
        playlistIdToRead = parsedTarget.id;
        const plMetaRes = await fetchWithRetry(
          `https://www.googleapis.com/youtube/v3/playlists?part=snippet&id=${encodeURIComponent(
            parsedTarget.id
          )}&key=${encodeURIComponent(apiKey)}`,
          { timeoutMs: 15_000, maxRetries: 0, accept: 'application/json' }
        );
        quota.requestsToday += 1;
        quota.quotaUnitsEstimateToday += 1;
        if (plMetaRes.httpStatus === 403 || plMetaRes.httpStatus === 429) {
          quota.quotaExceededUntil = new Date(Date.now() + 6 * 3600_000).toISOString();
          quota.lastError = `YouTube Data API kota/yetki sınırı (HTTP ${plMetaRes.httpStatus}).`;
        } else if (plMetaRes.ok) {
          const plMeta = JSON.parse(plMetaRes.body) as {
            items?: Array<{
              snippet?: { title?: string; channelId?: string; channelTitle?: string };
            }>;
          };
          playlistName = plMeta.items?.[0]?.snippet?.title || source.name;
          resolvedChannelId = plMeta.items?.[0]?.snippet?.channelId || '';
          resolvedChannelTitle =
            plMeta.items?.[0]?.snippet?.channelTitle || source.name;
        }
      } else if (parsedTarget.kind === 'video') {
        videoIds = [parsedTarget.id];
      }

      if (playlistIdToRead && !quota.quotaExceededUntil) {
        const plItemsRes = await fetchWithRetry(
          `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&playlistId=${encodeURIComponent(
            playlistIdToRead
          )}&maxResults=20&key=${encodeURIComponent(apiKey)}`,
          { timeoutMs: 15_000, maxRetries: 0, accept: 'application/json' }
        );
        quota.requestsToday += 1;
        quota.quotaUnitsEstimateToday += 1;
        if (plItemsRes.httpStatus === 403 || plItemsRes.httpStatus === 429) {
          quota.quotaExceededUntil = new Date(Date.now() + 6 * 3600_000).toISOString();
          quota.lastError = `YouTube Data API kota sınırı (HTTP ${plItemsRes.httpStatus}).`;
        } else if (!plItemsRes.ok) {
          return {
            ok: false,
            usedMode: 'youtube-data-api-v3',
            videos: [],
            httpStatus: plItemsRes.httpStatus,
            note: null,
            error: plItemsRes.error || 'Playlist öğeleri alınamadı.',
          };
        } else {
          const plJson = JSON.parse(plItemsRes.body) as {
            items?: Array<{
              contentDetails?: { videoId?: string };
            }>;
          };
          videoIds = (plJson.items || [])
            .map((i) => i.contentDetails?.videoId)
            .filter((v): v is string => Boolean(v));
        }
      }

      if (videoIds.length > 0 && !quota.quotaExceededUntil) {
        const vidRes = await fetchWithRetry(
          `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id=${encodeURIComponent(
            videoIds.slice(0, 25).join(',')
          )}&key=${encodeURIComponent(apiKey)}`,
          { timeoutMs: 15_000, maxRetries: 0, accept: 'application/json' }
        );
        quota.requestsToday += 1;
        quota.quotaUnitsEstimateToday += 1;

        if (vidRes.httpStatus === 403 || vidRes.httpStatus === 429) {
          quota.quotaExceededUntil = new Date(Date.now() + 6 * 3600_000).toISOString();
          quota.lastError = `YouTube Data API kota sınırı (HTTP ${vidRes.httpStatus}).`;
        } else if (!vidRes.ok) {
          return {
            ok: false,
            usedMode: 'youtube-data-api-v3',
            videos: [],
            httpStatus: vidRes.httpStatus,
            note: null,
            error: vidRes.error || 'YouTube video detayları alınamadı.',
          };
        } else {
          const vidJson = JSON.parse(vidRes.body) as {
            items?: Array<{
              id?: string;
              snippet?: {
                title?: string;
                description?: string;
                publishedAt?: string;
                channelId?: string;
                channelTitle?: string;
                thumbnails?: {
                  maxres?: { url?: string };
                  high?: { url?: string };
                  medium?: { url?: string };
                };
              };
              contentDetails?: { duration?: string };
            }>;
          };

          const videos: MediaVideo[] = (vidJson.items || [])
            .filter((v) => Boolean(v.id && v.snippet?.title))
            .map((v) => {
              const videoId = v.id!;
              const sn = v.snippet!;
              const thumbs = sn.thumbnails;
              const { duration, durationSeconds } = parseIso8601Duration(
                v.contentDetails?.duration || ''
              );
              const originalUrl = `https://www.youtube.com/watch?v=${videoId}`;
              return {
                id: makeMediaId('mvid', videoId),
                videoId,
                guid: `yt:video:${videoId}`,
                canonicalUrl: normalizeMediaUrl(originalUrl),
                title: sn.title || 'YouTube Video',
                description: (sn.description || '').slice(0, 1200),
                channelName: sn.channelTitle || resolvedChannelTitle,
                channelId: sn.channelId || resolvedChannelId,
                playlistId:
                  parsedTarget.kind === 'playlist' ? parsedTarget.id : null,
                playlistName:
                  playlistName || `${sn.channelTitle || source.name} Uploads`,
                publishedAt: extractSafeIsoDate(sn.publishedAt || ''),
                updatedAt: null,
                thumbnailUrl:
                  thumbs?.maxres?.url ||
                  thumbs?.high?.url ||
                  thumbs?.medium?.url ||
                  `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
                embedUrl: `https://www.youtube.com/embed/${videoId}`,
                originalUrl,
                duration,
                durationSeconds,
                category: source.category,
                categories:
                  source.categories.length > 0
                    ? source.categories
                    : [source.category],
                sourceId: source.id,
                matchedSourceIds: [source.id],
                fetchedAt: nowIso,
                isWatched: false,
                isFavorite: false,
                isArchived: false,
                archivedAt: null,
              };
            });

          return {
            ok: true,
            usedMode: 'youtube-data-api-v3',
            videos,
            httpStatus: vidRes.httpStatus,
            note: 'YouTube Data API v3 ile senkronize edildi.',
            error: null,
          };
        }
      }
    } catch (err) {
      return {
        ok: false,
        usedMode: 'youtube-data-api-v3',
        videos: [],
        httpStatus: null,
        note: null,
        error: err instanceof Error ? err.message : 'YouTube API hatası.',
      };
    }
  }

  // Fallback or API key missing:
  if (parsedTarget.kind === 'video') {
    return {
      ok: false,
      usedMode: 'blocked',
      videos: [],
      httpStatus: null,
      note: null,
      error: inQuotaCooldown
        ? 'YouTube Data API günlük kotası doldu; tekil Video ID beklemede.'
        : 'Tekil Video ID içerikleri için sunucuda YOUTUBE_API_KEY tanımlı olmalıdır.',
    };
  }

  const atomUrl =
    parsedTarget.kind === 'channel'
      ? `https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(
          parsedTarget.id
        )}`
      : `https://www.youtube.com/feeds/videos.xml?playlist_id=${encodeURIComponent(
          parsedTarget.id
        )}`;

  const atomRes = await fetchWithRetry(atomUrl, {
    timeoutMs: 20_000,
    maxRetries: 1,
    accept: 'application/atom+xml, application/xml, text/xml',
  });
  if (!atomRes.ok) {
    return {
      ok: false,
      usedMode: 'atom-fallback',
      videos: [],
      httpStatus: atomRes.httpStatus,
      note: null,
      error: atomRes.error || 'YouTube Atom feed alınamadı.',
    };
  }

  try {
    const videos = parseYouTubeAtomXml(
      atomRes.body,
      source,
      parsedTarget.kind,
      parsedTarget.id
    );
    return {
      ok: true,
      usedMode: 'atom-fallback',
      videos,
      httpStatus: atomRes.httpStatus,
      note: apiKey
        ? 'YouTube API kota beklemesi nedeniyle resmi YouTube Atom feed kullanıldı.'
        : 'YOUTUBE_API_KEY tanımlı değil; resmi YouTube Atom feed kullanıldı (video süresi yalnızca Data API v3 ile gelir).',
      error: null,
    };
  } catch (err) {
    return {
      ok: false,
      usedMode: 'atom-fallback',
      videos: [],
      httpStatus: atomRes.httpStatus,
      note: null,
      error: err instanceof Error ? err.message : 'YouTube Atom ayrıştırma hatası.',
    };
  }
}
