import {
  MediaEvent,
  MediaEventAttendanceMode,
  MediaEventStatus,
  MediaSource,
  makeMediaId,
  normalizeMediaUrl,
} from '../mediaDb.ts';
import { validatePublicHttpUrl } from './httpClient.ts';

function unfoldIcalLines(ics: string): string[] {
  const normalized = (ics || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const rawLines = normalized.split('\n');
  const unfolded: string[] = [];
  for (const line of rawLines) {
    if ((line.startsWith(' ') || line.startsWith('\t')) && unfolded.length > 0) {
      unfolded[unfolded.length - 1] += line.slice(1);
    } else {
      unfolded.push(line);
    }
  }
  return unfolded;
}

function unescapeIcalText(value: string): string {
  return (value || '')
    .replace(/\\n/gi, '\n')
    .replace(/\\,/g, ',')
    .replace(/\\;/g, ';')
    .replace(/\\\\/g, '\\')
    .trim();
}

interface ParsedIcalDate {
  iso: string | null;
  timeLabel: string | null;
  timezone: string | null;
  isAllDay: boolean;
}

function parseIcalDateValue(rawVal: string, paramsPart: string): ParsedIcalDate {
  const val = (rawVal || '').trim();
  const tzMatch = paramsPart.match(/TZID=([^;:]+)/i);
  const tzid = tzMatch?.[1]?.trim() || null;

  // All-day YYYYMMDD
  if (/^\d{8}$/.test(val)) {
    const y = val.slice(0, 4);
    const m = val.slice(4, 6);
    const d = val.slice(6, 8);
    const iso = `${y}-${m}-${d}T00:00:00.000Z`;
    return {
      iso: Number.isNaN(Date.parse(iso)) ? null : iso,
      timeLabel: null,
      timezone: tzid || 'All Day',
      isAllDay: true,
    };
  }

  // DateTime YYYYMMDDTHHMMSS(Z?)
  const dtMatch = val.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z)?$/i);
  if (dtMatch) {
    const [, y, m, d, hh, mm, ss, zFlag] = dtMatch;
    const isUtc = Boolean(zFlag);
    const isoCandidate = `${y}-${m}-${d}T${hh}:${mm}:${ss}${isUtc ? 'Z' : 'Z'}`;
    if (Number.isNaN(Date.parse(isoCandidate))) {
      return { iso: null, timeLabel: null, timezone: tzid, isAllDay: false };
    }
    return {
      iso: new Date(isoCandidate).toISOString(),
      timeLabel: `${hh}:${mm}${isUtc ? ' UTC' : ''}`,
      timezone: isUtc ? 'UTC' : tzid || 'Local',
      isAllDay: false,
    };
  }

  // Fallback standard ISO string
  const ts = Date.parse(val);
  if (!Number.isNaN(ts)) {
    const d = new Date(ts);
    return {
      iso: d.toISOString(),
      timeLabel: `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')} UTC`,
      timezone: tzid || 'UTC',
      isAllDay: false,
    };
  }

  return { iso: null, timeLabel: null, timezone: tzid, isAllDay: false };
}

function inferAttendance(location: string | null, title: string, desc: string): MediaEventAttendanceMode {
  const combined = `${location || ''} ${title} ${desc}`.toLowerCase();
  const hasUrl = /https?:\/\/|zoom\.us|teams\.microsoft|meet\.google|webinar|virtual|online/.test(
    combined
  );
  const hasPhysical = Boolean(
    location &&
      !/^(online|virtual|remote|tbd|n\/a)$/i.test(location.trim()) &&
      !/^https?:\/\//i.test(location.trim())
  );
  if (hasUrl && hasPhysical) return 'hybrid';
  if (hasUrl) return 'online';
  if (hasPhysical) return 'physical';
  return 'unknown';
}

export function isIcalPayload(body: string, contentType: string): boolean {
  if (contentType.toLowerCase().includes('text/calendar')) return true;
  const head = (body || '').slice(0, 500);
  return head.includes('BEGIN:VCALENDAR') || body.includes('BEGIN:VEVENT');
}

export function parseIcalEvents(
  icsText: string,
  source: MediaSource
): MediaEvent[] {
  if (!icsText.includes('BEGIN:VCALENDAR') && !icsText.includes('BEGIN:VEVENT')) {
    throw new Error('Yanıt geçerli bir iCalendar (.ics) dosyası değil.');
  }

  const lines = unfoldIcalLines(icsText);
  const events: MediaEvent[] = [];
  const seen = new Set<string>();
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();

  let inEvent = false;
  let currentProps: Array<{ key: string; params: string; value: string }> = [];

  const flushEvent = () => {
    if (currentProps.length === 0) return;

    const getProp = (name: string) =>
      currentProps.find((p) => p.key.toUpperCase() === name.toUpperCase());

    const summary = unescapeIcalText(getProp('SUMMARY')?.value || '');
    if (!summary) return;

    const uid = unescapeIcalText(getProp('UID')?.value || '');
    const description = unescapeIcalText(getProp('DESCRIPTION')?.value || '').slice(0, 1200);
    const locationRaw = unescapeIcalText(getProp('LOCATION')?.value || '');
    const location = locationRaw || null;

    const urlProp = getProp('URL')?.value?.trim() || '';
    const validatedEventUrl = urlProp ? validatePublicHttpUrl(urlProp)?.toString() || null : null;

    const orgProp = getProp('ORGANIZER');
    let organizer = source.name;
    if (orgProp) {
      const cnMatch = orgProp.params.match(/CN="?([^";]+)"?/i);
      if (cnMatch?.[1]) {
        organizer = unescapeIcalText(cnMatch[1]);
      } else if (orgProp.value) {
        organizer = orgProp.value.replace(/^mailto:/i, '').trim() || source.name;
      }
    }

    const dtStartProp = getProp('DTSTART');
    const dtEndProp = getProp('DTEND');
    const lastModProp = getProp('LAST-MODIFIED') || getProp('DTSTAMP');

    const startParsed = dtStartProp
      ? parseIcalDateValue(dtStartProp.value, dtStartProp.params)
      : { iso: null, timeLabel: null, timezone: null, isAllDay: false };
    const endParsed = dtEndProp
      ? parseIcalDateValue(dtEndProp.value, dtEndProp.params)
      : { iso: null, timeLabel: null, timezone: null, isAllDay: false };

    const originalUrl = validatedEventUrl || source.websiteUrl || source.feedOrEndpoint;
    const registrationUrl = validatedEventUrl;
    const canonicalUrl = normalizeMediaUrl(originalUrl);
    const guid = uid || `${canonicalUrl}:${startParsed.iso || summary}`;
    if (seen.has(guid)) return;
    seen.add(guid);

    const hasVerifiedDateAndReg = Boolean(startParsed.iso && registrationUrl);
    let status: MediaEventStatus = 'unverified';
    let isArchived = false;
    let archivedAt: string | null = null;
    let verificationStatus: 'verified' | 'unverified' = 'unverified';
    let verificationNote: string | null = null;

    if (hasVerifiedDateAndReg && startParsed.iso) {
      verificationStatus = 'verified';
      const startMs = Date.parse(startParsed.iso);
      const endMs = endParsed.iso
        ? Date.parse(endParsed.iso)
        : startMs + (startParsed.isAllDay ? 86_400_000 : 3 * 3600_000);
      if (endMs < nowMs) {
        status = 'past';
        isArchived = true;
        archivedAt = nowIso;
      } else if (startMs <= nowMs && endMs >= nowMs) {
        status = 'ongoing';
      } else {
        status = 'upcoming';
      }
    } else {
      verificationStatus = 'unverified';
      status = 'unverified';
      verificationNote = !startParsed.iso
        ? 'iCal kaydında geçerli DTSTART tarihi bulunamadı.'
        : 'iCal kaydında doğrulanmış kayıt bağlantısı (URL) bulunamadı.';
    }

    const combinedText = `${summary} ${description}`.toLowerCase();
    const eventType = combinedText.includes('webinar')
      ? 'webinar'
      : combinedText.includes('meetup')
        ? 'meetup'
        : combinedText.includes('summit')
          ? 'summit'
          : 'conference';

    const updatedAt = lastModProp
      ? parseIcalDateValue(lastModProp.value, lastModProp.params).iso
      : null;

    events.push({
      id: makeMediaId('mevt', `${source.id}:${guid}`),
      guid,
      canonicalUrl,
      eventName: summary,
      organizer,
      startDate: startParsed.iso,
      startTime: startParsed.timeLabel,
      endDate: endParsed.iso,
      timezone: startParsed.timezone,
      attendanceMode: inferAttendance(location, summary, description),
      location,
      description,
      registrationUrl,
      originalUrl,
      sourceId: source.id,
      matchedSourceIds: [source.id],
      category: source.category,
      categories: source.categories.length > 0 ? source.categories : [source.category],
      eventType,
      status,
      verificationStatus,
      verificationNote,
      publishedAt: startParsed.iso,
      updatedAt,
      fetchedAt: nowIso,
      isFavorite: false,
      isArchived,
      archivedAt,
    });
  };

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed === 'BEGIN:VEVENT') {
      inEvent = true;
      currentProps = [];
      continue;
    }
    if (trimmed === 'END:VEVENT') {
      if (inEvent) flushEvent();
      inEvent = false;
      currentProps = [];
      continue;
    }
    if (!inEvent) continue;

    const colonIdx = line.indexOf(':');
    if (colonIdx <= 0) continue;
    const left = line.slice(0, colonIdx);
    const value = line.slice(colonIdx + 1);
    const semiIdx = left.indexOf(';');
    const key = semiIdx >= 0 ? left.slice(0, semiIdx) : left;
    const params = semiIdx >= 0 ? left.slice(semiIdx + 1) : '';
    currentProps.push({ key, params, value });
  }

  return events;
}
