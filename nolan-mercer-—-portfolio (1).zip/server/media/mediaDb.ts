import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '..', '..', 'data');
const DB_FILE_PATH = path.join(DATA_DIR, 'tech-media-hub.json');
const DB_TMP_PATH = path.join(DATA_DIR, 'tech-media-hub.json.tmp');

export type MediaContentType = 'podcast' | 'event' | 'youtube';
export type MediaSourceType =
  | 'rss'
  | 'atom'
  | 'ical'
  | 'youtube-api'
  | 'official-api'
  | 'manual'
  | 'unsupported';
export type MediaVerificationStatus = 'verified' | 'unverified' | 'error';
export type YouTubeTargetKind = 'channel' | 'playlist' | 'video';

export interface MediaSource {
  id: string;
  name: string;
  description: string;
  contentType: MediaContentType;
  sourceType: MediaSourceType;
  websiteUrl: string;
  feedOrEndpoint: string;
  youtubeTargetKind?: YouTubeTargetKind;
  youtubeTargetId?: string;
  category: string;
  categories: string[];
  enabled: boolean;
  verificationStatus: MediaVerificationStatus;
  verificationNote: string | null;
  lastSuccessfulSyncAt: string | null;
  lastAttemptedSyncAt: string | null;
  nextSyncAt: string | null;
  syncIntervalHours: number; // 1, 3, 6, 12, 24, or 0 (manual)
  lastError: string | null;
  lastHttpStatus: number | null;
  consecutiveFailures: number;
  collectedCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface MediaPodcastSeries {
  id: string;
  sourceId: string;
  title: string;
  publisher: string | null;
  author: string | null;
  description: string;
  artworkUrl: string | null;
  websiteUrl: string;
  feedUrl: string;
  language: string | null;
  category: string;
  categories: string[];
  lastSyncedAt: string | null;
  isFollowed: boolean;
  isFavorite: boolean;
  episodeCount: number;
}

export interface MediaPodcastEpisode {
  id: string;
  guid: string;
  canonicalUrl: string;
  seriesId: string;
  seriesTitle: string;
  publisher: string | null;
  title: string;
  description: string;
  publishedAt: string | null;
  updatedAt: string | null;
  artworkUrl: string | null;
  duration: string | null;
  durationSeconds: number | null;
  audioUrl: string | null;
  originalUrl: string;
  category: string;
  categories: string[];
  sourceId: string;
  matchedSourceIds: string[];
  isPlayed: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  playbackPosition: number;
  fetchedAt: string;
}

export type MediaEventAttendanceMode = 'online' | 'physical' | 'hybrid' | 'unknown';
export type MediaEventStatus = 'upcoming' | 'ongoing' | 'past' | 'unverified';
export type MediaEventType = 'conference' | 'webinar' | 'summit' | 'meetup';

export interface MediaEvent {
  id: string;
  guid: string;
  canonicalUrl: string;
  eventName: string;
  organizer: string;
  startDate: string | null;
  startTime: string | null;
  endDate: string | null;
  timezone: string | null;
  attendanceMode: MediaEventAttendanceMode;
  location: string | null;
  description: string;
  registrationUrl: string | null;
  originalUrl: string;
  sourceId: string;
  matchedSourceIds: string[];
  category: string;
  categories: string[];
  eventType: MediaEventType;
  status: MediaEventStatus;
  verificationStatus: 'verified' | 'unverified';
  verificationNote: string | null;
  publishedAt: string | null;
  updatedAt: string | null;
  fetchedAt: string;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  isManual?: boolean;
}

export interface MediaVideo {
  id: string;
  videoId: string;
  guid: string;
  canonicalUrl: string;
  title: string;
  description: string;
  channelName: string;
  channelId: string;
  playlistId: string | null;
  playlistName: string | null;
  publishedAt: string | null;
  updatedAt: string | null;
  thumbnailUrl: string | null;
  embedUrl: string;
  originalUrl: string;
  duration: string | null;
  durationSeconds: number | null;
  category: string;
  categories: string[];
  sourceId: string;
  matchedSourceIds: string[];
  fetchedAt: string;
  isWatched: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  isManual?: boolean;
}

export interface MediaSyncHistoryEntry {
  syncId: string;
  startedAt: string;
  finishedAt: string;
  contentType: MediaContentType | 'all';
  sourceId: string;
  sourceName: string;
  trigger: 'startup' | 'scheduled' | 'manual' | 'retry' | 'test';
  status: 'success' | 'partial' | 'error' | 'unsupported';
  httpStatus: number | null;
  newItems: number;
  duplicatesSkipped: number;
  updatedItems: number;
  errors: number;
  errorMessage: string | null;
  durationMs: number;
}

export interface TypeScheduleConfig {
  autoSyncEnabled: boolean;
  intervalHours: number; // default 3
  lastSyncAt: string | null;
  lastSuccessfulSyncAt: string | null;
}

export interface MediaSchedulerConfig {
  podcast: TypeScheduleConfig;
  event: TypeScheduleConfig;
  youtube: TypeScheduleConfig;
}

export interface YouTubeQuotaTracker {
  lastResetDate: string; // YYYY-MM-DD
  requestsToday: number;
  quotaUnitsEstimateToday: number;
  quotaExceededUntil: string | null;
  lastError: string | null;
}

export interface MediaHubDatabase {
  schemaVersion: number;
  sources: MediaSource[];
  podcastSeries: MediaPodcastSeries[];
  podcastEpisodes: MediaPodcastEpisode[];
  events: MediaEvent[];
  videos: MediaVideo[];
  syncHistory: MediaSyncHistoryEntry[];
  scheduler: MediaSchedulerConfig;
  youtubeQuota: YouTubeQuotaTracker;
}

const NOW_ISO = '2026-11-19T00:00:00.000Z';

function makeSeedSource(
  partial: Omit<
    MediaSource,
    | 'lastSuccessfulSyncAt'
    | 'lastAttemptedSyncAt'
    | 'nextSyncAt'
    | 'lastHttpStatus'
    | 'consecutiveFailures'
    | 'collectedCount'
    | 'createdAt'
    | 'updatedAt'
  >
): MediaSource {
  return {
    ...partial,
    lastSuccessfulSyncAt: null,
    lastAttemptedSyncAt: null,
    nextSyncAt: null,
    lastHttpStatus: null,
    consecutiveFailures: 0,
    collectedCount: 0,
    createdAt: NOW_ISO,
    updatedAt: NOW_ISO,
  };
}

const INITIAL_MEDIA_SOURCES: MediaSource[] = [
  // ======================== PODCASTS (Verified Official RSS 2.0) ========================
  makeSeedSource({
    id: 'msrc-pod-kubernetes',
    name: 'Kubernetes Podcast from Google',
    description:
      'Weekly interviews and news from the Kubernetes and cloud-native open-source ecosystem.',
    contentType: 'podcast',
    sourceType: 'rss',
    websiteUrl: 'https://kubernetespodcast.com/',
    feedOrEndpoint: 'https://kubernetespodcast.com/feeds/audio.xml',
    category: 'Kubernetes',
    categories: ['Kubernetes', 'DevOps'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Verified official RSS 2.0 podcast feed with MP3 enclosures.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-pod-aws',
    name: 'AWS Podcast',
    description:
      'Official AWS Podcast covering cloud architecture, containers, security, and platform launches.',
    contentType: 'podcast',
    sourceType: 'rss',
    websiteUrl: 'https://aws.amazon.com/podcasts/aws-podcast/',
    feedOrEndpoint: 'https://d3gih7jbfe3jlq.cloudfront.net/aws-podcast.rss',
    category: 'AWS',
    categories: ['AWS', 'Security'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Verified official RSS 2.0 podcast feed.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-pod-changelog',
    name: 'The Changelog',
    description:
      'Conversations with hackers, platform engineers, and open-source maintainers.',
    contentType: 'podcast',
    sourceType: 'rss',
    websiteUrl: 'https://changelog.com/podcast',
    feedOrEndpoint: 'https://changelog.com/podcast/feed',
    category: 'DevOps',
    categories: ['DevOps', 'GitHub', 'AI'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Verified official RSS 2.0 podcast feed.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-pod-sedaily',
    name: 'Software Engineering Daily',
    description:
      'Technical deep-dives on distributed systems, AI engineering, databases, and cloud infrastructure.',
    contentType: 'podcast',
    sourceType: 'rss',
    websiteUrl: 'https://softwareengineeringdaily.com/',
    feedOrEndpoint: 'https://softwareengineeringdaily.com/feed/podcast/',
    category: 'AI',
    categories: ['AI', 'Kubernetes', 'Elasticsearch'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Verified official RSS 2.0 podcast feed.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-pod-redhat-compiler',
    name: 'Compiler (Red Hat)',
    description:
      'Red Hat podcast on enterprise Linux, OpenShift, open-source engineering, and infrastructure.',
    contentType: 'podcast',
    sourceType: 'rss',
    websiteUrl: 'https://www.redhat.com/en/compiler-podcast',
    feedOrEndpoint: 'https://feeds.simplecast.com/Ynq4lw9w',
    category: 'OpenShift',
    categories: ['OpenShift', 'Kubernetes', 'Security'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Verified official Simplecast RSS 2.0 feed.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-pod-seradio',
    name: 'Software Engineering Radio',
    description:
      'In-depth educational episodes for software architects, Java/backend teams, and reliability engineers.',
    contentType: 'podcast',
    sourceType: 'rss',
    websiteUrl: 'https://se-radio.net/',
    feedOrEndpoint: 'https://seradio.libsyn.com/rss',
    category: 'Java',
    categories: ['Java', 'Security', 'DevOps'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Verified official Libsyn RSS 2.0 feed.',
    syncIntervalHours: 3,
    lastError: null,
  }),

  // ======================== EVENTS (Official API + RSS + Honest Portals) ========================
  makeSeedSource({
    id: 'msrc-evt-cncf-community',
    name: 'CNCF Community Events API',
    description:
      'Official CNCF Community (KCDs, Kubernetes & Cloud Native meetups) JSON API with verified dates, timezones, and registration links.',
    contentType: 'event',
    sourceType: 'official-api',
    websiteUrl: 'https://community.cncf.io/',
    feedOrEndpoint: 'https://community.cncf.io/api/event/?status=Live&page_size=20',
    category: 'Kubernetes',
    categories: ['Kubernetes', 'Istio', 'OpenShift'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Verified official CNCF Community Events JSON API.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-evt-linux-foundation',
    name: 'Linux Foundation Events',
    description:
      'Official Linux Foundation summits, KubeCon announcements, and open-source event feed.',
    contentType: 'event',
    sourceType: 'rss',
    websiteUrl: 'https://events.linuxfoundation.org/',
    feedOrEndpoint: 'https://events.linuxfoundation.org/feed/',
    category: 'Kubernetes',
    categories: ['Kubernetes', 'DevOps', 'Security'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Verified official RSS 2.0 feed (events without explicit DTSTART are marked unverified).',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-evt-redhat-summit',
    name: 'Red Hat Summit & Events',
    description:
      'Official Red Hat events portal. Does not publish an active public RSS/iCal feed; keep disabled until a valid RSS/iCal URL is added.',
    contentType: 'event',
    sourceType: 'manual',
    websiteUrl: 'https://www.redhat.com/en/summit',
    feedOrEndpoint: '',
    category: 'OpenShift',
    categories: ['OpenShift', 'Kubernetes'],
    enabled: false,
    verificationStatus: 'unverified',
    verificationNote: 'No public RSS/iCal/API schedule endpoint verified. Disabled by policy.',
    syncIntervalHours: 0,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-evt-microsoft-reactor',
    name: 'Microsoft Events & Reactor',
    description:
      'Official Microsoft Developer & Reactor events portal. Requires explicit iCal/RSS/Eventbrite endpoint to enable automated sync.',
    contentType: 'event',
    sourceType: 'manual',
    websiteUrl: 'https://developer.microsoft.com/en-us/reactor/',
    feedOrEndpoint: '',
    category: 'AI',
    categories: ['AI', 'Kubernetes', 'DevOps'],
    enabled: false,
    verificationStatus: 'unverified',
    verificationNote: 'Portal only; supply an iCal (.ics) or API endpoint and validate to enable.',
    syncIntervalHours: 0,
    lastError: null,
  }),

  // ======================== YOUTUBE (Official Channel / Playlist IDs) ========================
  makeSeedSource({
    id: 'msrc-yt-redhat',
    name: 'Red Hat YouTube',
    description:
      'Official Red Hat engineering talks, OpenShift demos, Ansible automation, and enterprise Linux sessions.',
    contentType: 'youtube',
    sourceType: 'youtube-api',
    websiteUrl: 'https://www.youtube.com/@RedHat',
    feedOrEndpoint: 'UCp6NUFV9mSEK6RxUiEVymVg',
    youtubeTargetKind: 'channel',
    youtubeTargetId: 'UCp6NUFV9mSEK6RxUiEVymVg',
    category: 'OpenShift',
    categories: ['OpenShift', 'Kubernetes', 'DevOps'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Official YouTube Channel ID (Data API v3 with YOUTUBE_API_KEY, or public Atom feed).',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-yt-cncf',
    name: 'CNCF YouTube',
    description:
      'Cloud Native Computing Foundation talks, KubeCon keynotes, Istio, and cloud-native updates.',
    contentType: 'youtube',
    sourceType: 'youtube-api',
    websiteUrl: 'https://www.youtube.com/@cncf',
    feedOrEndpoint: 'UCvqbFHwN-nwalWPjPUKpvTA',
    youtubeTargetKind: 'channel',
    youtubeTargetId: 'UCvqbFHwN-nwalWPjPUKpvTA',
    category: 'Kubernetes',
    categories: ['Kubernetes', 'Istio', 'DevOps'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Official YouTube Channel ID.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-yt-k8s-community',
    name: 'Kubernetes Community',
    description:
      'Official Kubernetes SIG meetings, contributor briefings, and release walkthroughs.',
    contentType: 'youtube',
    sourceType: 'youtube-api',
    websiteUrl: 'https://www.youtube.com/@KubernetesCommunity',
    feedOrEndpoint: 'UCZ2bu0qutTOM0tHYa_jkIwg',
    youtubeTargetKind: 'channel',
    youtubeTargetId: 'UCZ2bu0qutTOM0tHYa_jkIwg',
    category: 'Kubernetes',
    categories: ['Kubernetes'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Official YouTube Channel ID.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-yt-aws-developers',
    name: 'AWS Developers',
    description:
      'AWS architecture deep dives, EKS/ECS container engineering, and serverless tooling.',
    contentType: 'youtube',
    sourceType: 'youtube-api',
    websiteUrl: 'https://www.youtube.com/@AWSDevelopers',
    feedOrEndpoint: 'UCT-nPlVzJI-ccQXlxjSvJmw',
    youtubeTargetKind: 'channel',
    youtubeTargetId: 'UCT-nPlVzJI-ccQXlxjSvJmw',
    category: 'AWS',
    categories: ['AWS', 'Kubernetes', 'DevOps'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Official YouTube Channel ID.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-yt-github',
    name: 'GitHub YouTube',
    description:
      'GitHub Actions, Copilot engineering, security workflows, and DevOps briefings.',
    contentType: 'youtube',
    sourceType: 'youtube-api',
    websiteUrl: 'https://www.youtube.com/@GitHub',
    feedOrEndpoint: 'UC7c3Kb6jYCRj4JOHHZTxKsQ',
    youtubeTargetKind: 'channel',
    youtubeTargetId: 'UC7c3Kb6jYCRj4JOHHZTxKsQ',
    category: 'GitHub',
    categories: ['GitHub', 'DevOps', 'AI'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Official YouTube Channel ID.',
    syncIntervalHours: 3,
    lastError: null,
  }),
  makeSeedSource({
    id: 'msrc-yt-cloudflare',
    name: 'Cloudflare YouTube',
    description:
      'Edge networking, Cloudflare Workers, Zero Trust security, and global infrastructure talks.',
    contentType: 'youtube',
    sourceType: 'youtube-api',
    websiteUrl: 'https://www.youtube.com/@Cloudflare',
    feedOrEndpoint: 'UCgv3xMy6kECn0boYP9d2o-g',
    youtubeTargetKind: 'channel',
    youtubeTargetId: 'UCgv3xMy6kECn0boYP9d2o-g',
    category: 'Cloudflare',
    categories: ['Cloudflare', 'Security'],
    enabled: true,
    verificationStatus: 'verified',
    verificationNote: 'Official YouTube Channel ID.',
    syncIntervalHours: 3,
    lastError: null,
  }),
];

function createDefaultDb(): MediaHubDatabase {
  const today = new Date().toISOString().slice(0, 10);
  return {
    schemaVersion: 1,
    sources: INITIAL_MEDIA_SOURCES.map((s) => ({ ...s })),
    podcastSeries: [],
    podcastEpisodes: [],
    events: [],
    videos: [],
    syncHistory: [],
    scheduler: {
      podcast: {
        autoSyncEnabled: true,
        intervalHours: 3,
        lastSyncAt: null,
        lastSuccessfulSyncAt: null,
      },
      event: {
        autoSyncEnabled: true,
        intervalHours: 3,
        lastSyncAt: null,
        lastSuccessfulSyncAt: null,
      },
      youtube: {
        autoSyncEnabled: true,
        intervalHours: 3,
        lastSyncAt: null,
        lastSuccessfulSyncAt: null,
      },
    },
    youtubeQuota: {
      lastResetDate: today,
      requestsToday: 0,
      quotaUnitsEstimateToday: 0,
      quotaExceededUntil: null,
      lastError: null,
    },
  };
}

let cachedDb: MediaHubDatabase | null = null;
let writeQueue: Promise<void> = Promise.resolve();

function mergeCanonicalSources(savedSources: MediaSource[]): MediaSource[] {
  const savedById = new Map(savedSources.map((s) => [s.id, s]));
  const canonicalIds = new Set(INITIAL_MEDIA_SOURCES.map((s) => s.id));

  const mergedCanonical = INITIAL_MEDIA_SOURCES.map((seed) => {
    const existing = savedById.get(seed.id);
    if (!existing) return { ...seed };
    return {
      ...seed,
      enabled:
        existing.verificationStatus === 'unverified'
          ? false
          : typeof existing.enabled === 'boolean'
            ? existing.enabled
            : seed.enabled,
      syncIntervalHours:
        typeof existing.syncIntervalHours === 'number'
          ? existing.syncIntervalHours
          : seed.syncIntervalHours,
      lastSuccessfulSyncAt: existing.lastSuccessfulSyncAt || null,
      lastAttemptedSyncAt: existing.lastAttemptedSyncAt || null,
      nextSyncAt: existing.nextSyncAt || null,
      lastError: existing.lastError || null,
      lastHttpStatus: existing.lastHttpStatus ?? null,
      consecutiveFailures: existing.consecutiveFailures || 0,
      collectedCount: existing.collectedCount || 0,
      verificationStatus: existing.verificationStatus || seed.verificationStatus,
      verificationNote: existing.verificationNote ?? seed.verificationNote,
      updatedAt: existing.updatedAt || seed.updatedAt,
    };
  });

  const customSources = savedSources.filter((s) => !canonicalIds.has(s.id));
  return [...mergedCanonical, ...customSources];
}

export function loadMediaDb(): MediaHubDatabase {
  if (cachedDb) return cachedDb;

  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_FILE_PATH)) {
      const raw = fs.readFileSync(DB_FILE_PATH, 'utf8');
      const parsed = JSON.parse(raw) as Partial<MediaHubDatabase>;
      const defaults = createDefaultDb();
      const db: MediaHubDatabase = {
        schemaVersion: 1,
        sources: Array.isArray(parsed.sources)
          ? mergeCanonicalSources(parsed.sources)
          : defaults.sources,
        podcastSeries: Array.isArray(parsed.podcastSeries)
          ? parsed.podcastSeries
          : [],
        podcastEpisodes: Array.isArray(parsed.podcastEpisodes)
          ? parsed.podcastEpisodes
          : [],
        events: Array.isArray(parsed.events) ? parsed.events : [],
        videos: Array.isArray(parsed.videos) ? parsed.videos : [],
        syncHistory: Array.isArray(parsed.syncHistory) ? parsed.syncHistory : [],
        scheduler: {
          podcast: {
            ...defaults.scheduler.podcast,
            ...(parsed.scheduler?.podcast || {}),
          },
          event: {
            ...defaults.scheduler.event,
            ...(parsed.scheduler?.event || {}),
          },
          youtube: {
            ...defaults.scheduler.youtube,
            ...(parsed.scheduler?.youtube || {}),
          },
        },
        youtubeQuota: {
          ...defaults.youtubeQuota,
          ...(parsed.youtubeQuota || {}),
        },
      };
      cachedDb = db;
      return db;
    }
  } catch (err) {
    console.warn('[mediaDb] Failed reading media DB; initializing defaults:', err);
  }

  cachedDb = createDefaultDb();
  return cachedDb;
}

export async function saveMediaDb(db: MediaHubDatabase): Promise<void> {
  cachedDb = db;
  writeQueue = writeQueue.then(async () => {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const serialized = JSON.stringify(db, null, 2);
    await fs.promises.writeFile(DB_TMP_PATH, serialized, 'utf8');
    await fs.promises.rename(DB_TMP_PATH, DB_FILE_PATH);
  });
  return writeQueue;
}

export function makeMediaId(prefix: string, seed?: string): string {
  if (seed) {
    const hash = crypto
      .createHash('sha1')
      .update(seed)
      .digest('hex')
      .slice(0, 14);
    return `${prefix}-${hash}`;
  }
  return `${prefix}-${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}`;
}

export function normalizeMediaUrl(rawUrl: string): string {
  const trimmed = (rawUrl || '').trim();
  if (!trimmed) return '';
  try {
    const parsed = new URL(trimmed);
    const trackingParams = [
      'utm_source',
      'utm_medium',
      'utm_campaign',
      'utm_term',
      'utm_content',
      'fbclid',
      'gclid',
      'ref',
      'source',
    ];
    for (const p of trackingParams) {
      parsed.searchParams.delete(p);
    }
    parsed.hash = '';
    let out = parsed.toString();
    if (out.endsWith('/') && parsed.pathname !== '/') {
      out = out.slice(0, -1);
    }
    return out;
  } catch {
    return trimmed.toLowerCase();
  }
}
