import express, { Router } from 'express';
import type { Request, Response } from 'express';
import {
  MediaContentType,
  MediaEvent,
  MediaSource,
  MediaVideo,
  loadMediaDb,
  makeMediaId,
  normalizeMediaUrl,
  saveMediaDb,
} from './mediaDb.ts';
import {
  detectDuplicateSource,
  getMediaSyncStatus,
  reconcilePastEvents,
  retryFailedMediaSources,
  syncMediaByType,
  syncSingleMediaSource,
  testAndValidateMediaSource,
} from './mediaCollector.ts';
import { validatePublicHttpUrl } from './adapters/httpClient.ts';
import { parseYouTubeTarget } from './adapters/youtubeAdapter.ts';

function isValidContentType(val: unknown): val is MediaContentType {
  return val === 'podcast' || val === 'event' || val === 'youtube';
}

export function createMediaRouter(): Router {
  const router = Router();
  router.use(express.json({ limit: '1mb' }));

  // ==================== STATUS & SCHEDULER ====================
  router.get('/status', (_req: Request, res: Response) => {
    res.json(getMediaSyncStatus());
  });

  router.patch('/scheduler', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const body = req.body as Partial<
      Record<
        MediaContentType,
        { autoSyncEnabled?: boolean; intervalHours?: number }
      >
    >;

    const allowedIntervals = new Set([0, 1, 3, 6, 12, 24]);
    for (const ct of ['podcast', 'event', 'youtube'] as MediaContentType[]) {
      const patch = body?.[ct];
      if (!patch) continue;
      if (typeof patch.autoSyncEnabled === 'boolean') {
        db.scheduler[ct].autoSyncEnabled = patch.autoSyncEnabled;
      }
      if (
        typeof patch.intervalHours === 'number' &&
        allowedIntervals.has(patch.intervalHours)
      ) {
        db.scheduler[ct].intervalHours = patch.intervalHours;
      }
    }

    await saveMediaDb(db);
    res.json({ scheduler: db.scheduler });
  });

  // ==================== SHARED SOURCES ====================
  router.get('/sources', (req: Request, res: Response) => {
    const db = loadMediaDb();
    const contentTypeFilter =
      typeof req.query.contentType === 'string' ? req.query.contentType : '';

    const sources = db.sources.filter((s) =>
      isValidContentType(contentTypeFilter)
        ? s.contentType === contentTypeFilter
        : true
    );
    res.json({ sources });
  });

  router.post('/sources/test', async (req: Request, res: Response) => {
    const body = req.body as {
      contentType?: MediaContentType;
      sourceType?: MediaSource['sourceType'];
      feedOrEndpoint?: string;
      websiteUrl?: string;
      name?: string;
      category?: string;
      excludeId?: string;
    };

    if (!isValidContentType(body.contentType)) {
      res.status(400).json({ error: 'Geçerli contentType (podcast | event | youtube) gereklidir.' });
      return;
    }

    const result = await testAndValidateMediaSource({
      contentType: body.contentType,
      sourceType: body.sourceType,
      feedOrEndpoint: body.feedOrEndpoint || '',
      websiteUrl: body.websiteUrl,
      name: body.name,
      category: body.category,
    });

    const db = loadMediaDb();
    const dup = detectDuplicateSource(db, {
      contentType: body.contentType,
      feedOrEndpoint: result.feedOrEndpoint || body.feedOrEndpoint || '',
      youtubeTargetId: result.youtubeTargetId,
      excludeId: body.excludeId,
    });

    res.json({
      ...result,
      duplicateSource: dup
        ? { id: dup.id, name: dup.name, feedOrEndpoint: dup.feedOrEndpoint }
        : null,
    });
  });

  router.post('/sources', async (req: Request, res: Response) => {
    const body = req.body as {
      name?: string;
      description?: string;
      contentType?: MediaContentType;
      sourceType?: MediaSource['sourceType'];
      websiteUrl?: string;
      feedOrEndpoint?: string;
      category?: string;
      categories?: string[];
      syncIntervalHours?: number;
      enabled?: boolean;
    };

    const name = (body.name || '').trim();
    if (!name) {
      res.status(400).json({ error: 'Kaynak adı (Source Name) zorunludur.' });
      return;
    }
    if (!isValidContentType(body.contentType)) {
      res.status(400).json({ error: 'Geçerli bir Content Type seçin (podcast, event, youtube).' });
      return;
    }

    const rawWebsite = (body.websiteUrl || '').trim();
    if (rawWebsite && !validatePublicHttpUrl(rawWebsite)) {
      res.status(400).json({ error: 'Website URL geçerli bir genel HTTP/HTTPS adresi olmalıdır.' });
      return;
    }

    const rawEndpoint = (body.feedOrEndpoint || '').trim();
    const db = loadMediaDb();

    // Pre-check duplicate on raw endpoint before network test
    const prelimYt =
      body.contentType === 'youtube' ? parseYouTubeTarget(rawEndpoint) : null;
    const preDup = detectDuplicateSource(db, {
      contentType: body.contentType,
      feedOrEndpoint: prelimYt?.canonicalEndpoint || rawEndpoint,
      youtubeTargetId: prelimYt?.id || undefined,
    });
    if (preDup) {
      res.status(409).json({
        error: `Bu kaynak zaten kayıtlı: "${preDup.name}" (${preDup.feedOrEndpoint}).`,
        duplicateSource: preDup,
      });
      return;
    }

    // Strict verification policy: test live feed/API before enabling
    let verificationStatus: MediaSource['verificationStatus'] = 'unverified';
    let verificationNote: string | null = 'Kaynak adresi henüz doğrulanmadı.';
    let detectedSourceType: MediaSource['sourceType'] =
      body.sourceType || (body.contentType === 'youtube' ? 'youtube-api' : 'rss');
    let finalEndpoint = rawEndpoint;
    let finalWebsite = rawWebsite;
    let youtubeTargetKind: MediaSource['youtubeTargetKind'];
    let youtubeTargetId: string | undefined;
    let lastHttpStatus: number | null = null;
    let lastError: string | null = null;
    let enabled = false;

    if (rawEndpoint) {
      const test = await testAndValidateMediaSource({
        contentType: body.contentType,
        sourceType: body.sourceType,
        feedOrEndpoint: rawEndpoint,
        websiteUrl: rawWebsite,
        name,
        category: body.category,
      });
      lastHttpStatus = test.httpStatus;
      if (test.feedOrEndpoint) finalEndpoint = test.feedOrEndpoint;
      if (!finalWebsite && test.websiteUrl) finalWebsite = test.websiteUrl;
      youtubeTargetKind = test.youtubeTargetKind;
      youtubeTargetId = test.youtubeTargetId;

      // Re-check duplicate after canonical resolution (e.g. Apple Podcasts -> RSS URL or @handle -> UC...)
      const postDup = detectDuplicateSource(db, {
        contentType: body.contentType,
        feedOrEndpoint: finalEndpoint,
        youtubeTargetId,
      });
      if (postDup) {
        res.status(409).json({
          error: `Çözümlenen kaynak zaten kayıtlı: "${postDup.name}" (${postDup.feedOrEndpoint}).`,
          duplicateSource: postDup,
        });
        return;
      }

      if (test.ok) {
        verificationStatus = 'verified';
        detectedSourceType = test.detectedSourceType;
        verificationNote =
          test.warning ||
          `Canlı doğrulandı (${test.detectedSourceType.toUpperCase()}, ${test.itemCount} kayıt).`;
        enabled = body.enabled !== false;
      } else {
        if (body.enabled === true) {
          res.status(400).json({
            error:
              test.error ||
              'Kaynak canlı doğrulamadan geçemediği için aktif edilemez.',
            testResult: test,
          });
          return;
        }
        verificationStatus = 'unverified';
        detectedSourceType =
          test.detectedSourceType === 'unsupported' ? 'unsupported' : detectedSourceType;
        verificationNote = test.error || 'Doğrulama başarısız; kaynak pasif kaydedildi.';
        lastError = test.error;
        enabled = false;
      }
    } else if (body.enabled === true) {
      res.status(400).json({
        error: 'Doğrulanmış RSS/API/YouTube adresi olmadan kaynak aktif edilemez.',
      });
      return;
    }

    const categories = Array.isArray(body.categories)
      ? Array.from(new Set(body.categories.map((c) => c.trim()).filter(Boolean)))
      : [];
    const primaryCat = (body.category || categories[0] || 'Engineering').trim();
    if (categories.length === 0) categories.push(primaryCat);

    const allowedIntervals = new Set([0, 1, 3, 6, 12, 24]);
    const interval =
      typeof body.syncIntervalHours === 'number' &&
      allowedIntervals.has(body.syncIntervalHours)
        ? body.syncIntervalHours
        : 3;

    const nowIso = new Date().toISOString();
    const newSource: MediaSource = {
      id: makeMediaId('msrc'),
      name,
      description: (body.description || `${primaryCat} ${body.contentType} source`).trim(),
      contentType: body.contentType,
      sourceType: detectedSourceType,
      websiteUrl: finalWebsite || finalEndpoint,
      feedOrEndpoint: finalEndpoint,
      youtubeTargetKind,
      youtubeTargetId,
      category: primaryCat,
      categories,
      enabled,
      verificationStatus,
      verificationNote,
      lastSuccessfulSyncAt: null,
      lastAttemptedSyncAt: null,
      nextSyncAt:
        enabled && interval > 0
          ? new Date(Date.now() + interval * 3600_000).toISOString()
          : null,
      syncIntervalHours: interval,
      lastError,
      lastHttpStatus,
      consecutiveFailures: 0,
      collectedCount: 0,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    db.sources.push(newSource);
    await saveMediaDb(db);

    res.status(201).json({ source: newSource });
  });

  router.patch('/sources/:id', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const source = db.sources.find((s) => s.id === req.params.id);
    if (!source) {
      res.status(404).json({ error: 'Kaynak bulunamadı.' });
      return;
    }

    const body = req.body as {
      name?: string;
      description?: string;
      websiteUrl?: string;
      feedOrEndpoint?: string;
      category?: string;
      categories?: string[];
      syncIntervalHours?: number;
      enabled?: boolean;
    };

    if (typeof body.name === 'string' && body.name.trim()) {
      source.name = body.name.trim();
    }
    if (typeof body.description === 'string') {
      source.description = body.description.trim();
    }
    if (typeof body.websiteUrl === 'string') {
      const cleanedSite = body.websiteUrl.trim();
      if (cleanedSite && !validatePublicHttpUrl(cleanedSite)) {
        res.status(400).json({ error: 'Website URL geçerli bir HTTP/HTTPS adresi olmalıdır.' });
        return;
      }
      source.websiteUrl = cleanedSite;
    }

    if (typeof body.feedOrEndpoint === 'string') {
      const cleanedEndpoint = body.feedOrEndpoint.trim();
      if (cleanedEndpoint !== source.feedOrEndpoint) {
        if (!cleanedEndpoint) {
          source.feedOrEndpoint = '';
          source.verificationStatus = 'unverified';
          source.verificationNote = 'Feed/API adresi temizlendi; kaynak devre dışı bırakıldı.';
          source.enabled = false;
        } else {
          const test = await testAndValidateMediaSource({
            contentType: source.contentType,
            sourceType: source.sourceType,
            feedOrEndpoint: cleanedEndpoint,
            websiteUrl: source.websiteUrl,
            name: source.name,
            category: body.category || source.category,
          });
          const dup = detectDuplicateSource(db, {
            contentType: source.contentType,
            feedOrEndpoint: test.feedOrEndpoint || cleanedEndpoint,
            youtubeTargetId: test.youtubeTargetId,
            excludeId: source.id,
          });
          if (dup) {
            res.status(409).json({
              error: `Bu adres başka bir kaynakta zaten kayıtlı: "${dup.name}".`,
            });
            return;
          }

          source.feedOrEndpoint = test.feedOrEndpoint || cleanedEndpoint;
          source.youtubeTargetKind = test.youtubeTargetKind;
          source.youtubeTargetId = test.youtubeTargetId;
          source.lastHttpStatus = test.httpStatus;

          if (test.ok) {
            source.sourceType = test.detectedSourceType;
            source.verificationStatus = 'verified';
            source.verificationNote =
              test.warning || `Canlı doğrulandı (${test.itemCount} kayıt).`;
            source.lastError = null;
          } else {
            source.verificationStatus = 'unverified';
            source.verificationNote = test.error || 'Doğrulama başarısız.';
            source.lastError = test.error;
            source.enabled = false;
          }
        }
      }
    }

    if (typeof body.enabled === 'boolean') {
      if (
        body.enabled &&
        (source.verificationStatus === 'unverified' ||
          !source.feedOrEndpoint.trim() ||
          source.sourceType === 'manual' ||
          source.sourceType === 'unsupported')
      ) {
        res.status(400).json({
          error:
            'Doğrulanmamış bir kaynak aktif edilemez. Önce geçerli feed/API/YouTube adresini test edip doğrulayın.',
        });
        return;
      }
      source.enabled = body.enabled;
    }

    if (Array.isArray(body.categories)) {
      const cleaned = Array.from(
        new Set(body.categories.map((c) => c.trim()).filter(Boolean))
      );
      if (cleaned.length > 0) {
        source.categories = cleaned;
        source.category = cleaned[0];
      }
    }
    if (typeof body.category === 'string' && body.category.trim()) {
      source.category = body.category.trim();
      if (!source.categories.includes(source.category)) {
        source.categories = [source.category, ...source.categories];
      }
    }

    const allowedIntervals = new Set([0, 1, 3, 6, 12, 24]);
    if (
      typeof body.syncIntervalHours === 'number' &&
      allowedIntervals.has(body.syncIntervalHours)
    ) {
      source.syncIntervalHours = body.syncIntervalHours;
      source.nextSyncAt =
        source.enabled && body.syncIntervalHours > 0
          ? new Date(Date.now() + body.syncIntervalHours * 3600_000).toISOString()
          : null;
    }

    source.updatedAt = new Date().toISOString();
    await saveMediaDb(db);
    res.json({ source });
  });

  router.delete('/sources/:id', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const exists = db.sources.some((s) => s.id === req.params.id);
    if (!exists) {
      res.status(404).json({ error: 'Kaynak bulunamadı.' });
      return;
    }
    db.sources = db.sources.filter((s) => s.id !== req.params.id);
    await saveMediaDb(db);
    res.json({ ok: true });
  });

  router.post('/sources/:id/test', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const source = db.sources.find((s) => s.id === req.params.id);
    if (!source) {
      res.status(404).json({ error: 'Kaynak bulunamadı.' });
      return;
    }

    if (!source.feedOrEndpoint.trim()) {
      res.json({
        ok: false,
        source,
        error:
          source.verificationNote ||
          'Bu kaynak için kayıtlı bir RSS/iCal/API/YouTube adresi yok.',
      });
      return;
    }

    const result = await testAndValidateMediaSource({
      contentType: source.contentType,
      sourceType: source.sourceType,
      feedOrEndpoint: source.feedOrEndpoint,
      websiteUrl: source.websiteUrl,
      name: source.name,
      category: source.category,
    });

    source.lastHttpStatus = result.httpStatus;
    source.updatedAt = new Date().toISOString();
    if (result.ok) {
      source.sourceType = result.detectedSourceType;
      source.feedOrEndpoint = result.feedOrEndpoint || source.feedOrEndpoint;
      source.youtubeTargetKind = result.youtubeTargetKind;
      source.youtubeTargetId = result.youtubeTargetId;
      source.verificationStatus = 'verified';
      source.verificationNote =
        result.warning || `Canlı doğrulandı (${result.itemCount} kayıt).`;
      source.lastError = null;
    } else {
      source.verificationStatus = 'error';
      source.lastError = result.error;
    }

    await saveMediaDb(db);
    res.json({ ...result, source });
  });

  // ==================== SYNC TRIGGERS & HISTORY ====================
  router.post('/sources/:id/sync', async (req: Request, res: Response) => {
    const entry = await syncSingleMediaSource(req.params.id, 'manual');
    res.status(entry.status === 'error' ? 400 : 200).json({ result: entry });
  });

  router.post('/sync', async (req: Request, res: Response) => {
    const rawType = req.body?.contentType;
    const targetType: MediaContentType | 'all' = isValidContentType(rawType)
      ? rawType
      : 'all';
    const outcome = await syncMediaByType(targetType, 'manual');
    res.json(outcome);
  });

  router.post('/retry-failed', async (req: Request, res: Response) => {
    const rawType = req.body?.contentType;
    const targetType = isValidContentType(rawType) ? rawType : undefined;
    const results = await retryFailedMediaSources(targetType);
    res.json({ results });
  });

  router.get('/sync-history', (req: Request, res: Response) => {
    const db = loadMediaDb();
    const contentType =
      typeof req.query.contentType === 'string' ? req.query.contentType : '';
    const limit = Math.min(300, Math.max(1, Number(req.query.limit) || 150));

    const history = db.syncHistory
      .filter((h) =>
        isValidContentType(contentType) ? h.contentType === contentType : true
      )
      .slice(0, limit);
    res.json({ history });
  });

  router.delete('/sync-history', async (_req: Request, res: Response) => {
    const db = loadMediaDb();
    db.syncHistory = [];
    await saveMediaDb(db);
    res.json({ ok: true });
  });

  // ==================== PODCASTS ====================
  router.get('/podcasts', (_req: Request, res: Response) => {
    const db = loadMediaDb();
    res.json({
      series: db.podcastSeries,
      episodes: db.podcastEpisodes,
    });
  });

  router.patch('/podcasts/series/:id', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const ser = db.podcastSeries.find((s) => s.id === req.params.id);
    if (!ser) {
      res.status(404).json({ error: 'Podcast serisi bulunamadı.' });
      return;
    }
    const body = req.body as { isFollowed?: boolean; isFavorite?: boolean };
    if (typeof body.isFollowed === 'boolean') ser.isFollowed = body.isFollowed;
    if (typeof body.isFavorite === 'boolean') ser.isFavorite = body.isFavorite;
    await saveMediaDb(db);
    res.json({ series: ser });
  });

  router.patch('/podcasts/episodes/:id', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const ep = db.podcastEpisodes.find((e) => e.id === req.params.id);
    if (!ep) {
      res.status(404).json({ error: 'Podcast bölümü bulunamadı.' });
      return;
    }
    const body = req.body as {
      isPlayed?: boolean;
      isFavorite?: boolean;
      isArchived?: boolean;
      playbackPosition?: number;
    };
    if (typeof body.isPlayed === 'boolean') ep.isPlayed = body.isPlayed;
    if (typeof body.isFavorite === 'boolean') ep.isFavorite = body.isFavorite;
    if (typeof body.isArchived === 'boolean') {
      ep.isArchived = body.isArchived;
      ep.archivedAt = body.isArchived ? new Date().toISOString() : null;
    }
    if (typeof body.playbackPosition === 'number' && Number.isFinite(body.playbackPosition)) {
      ep.playbackPosition = Math.max(0, body.playbackPosition);
    }
    await saveMediaDb(db);
    res.json({ episode: ep });
  });

  router.delete('/podcasts/episodes/:id', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const before = db.podcastEpisodes.length;
    db.podcastEpisodes = db.podcastEpisodes.filter((e) => e.id !== req.params.id);
    if (db.podcastEpisodes.length === before) {
      res.status(404).json({ error: 'Podcast bölümü bulunamadı.' });
      return;
    }
    for (const s of db.podcastSeries) {
      s.episodeCount = db.podcastEpisodes.filter((e) => e.seriesId === s.id).length;
    }
    await saveMediaDb(db);
    res.json({ ok: true });
  });

  // ==================== EVENTS ====================
  router.get('/events', async (_req: Request, res: Response) => {
    const db = loadMediaDb();
    if (reconcilePastEvents(db)) {
      await saveMediaDb(db);
    }
    res.json({ events: db.events });
  });

  router.post('/events', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const body = req.body as {
      eventName?: string;
      organizer?: string;
      startDate?: string;
      startTime?: string;
      endDate?: string;
      timezone?: string;
      attendanceMode?: MediaEvent['attendanceMode'];
      location?: string;
      eventType?: MediaEvent['eventType'];
      registrationUrl?: string;
      description?: string;
      category?: string;
    };

    const eventName = (body.eventName || '').trim();
    const organizer = (body.organizer || '').trim() || 'Manual Event';
    const rawRegUrl = (body.registrationUrl || '').trim();
    if (!eventName) {
      res.status(400).json({ error: 'Etkinlik adı zorunludur.' });
      return;
    }

    const validRegUrl = rawRegUrl ? validatePublicHttpUrl(rawRegUrl)?.toString() || null : null;
    if (rawRegUrl && !validRegUrl) {
      res.status(400).json({ error: 'Kayıt URL geçerli bir HTTP/HTTPS adresi olmalıdır.' });
      return;
    }

    const startIso =
      body.startDate && !Number.isNaN(Date.parse(body.startDate))
        ? new Date(body.startDate).toISOString()
        : null;
    const endIso =
      body.endDate && !Number.isNaN(Date.parse(body.endDate))
        ? new Date(body.endDate).toISOString()
        : null;

    const canonicalUrl = normalizeMediaUrl(validRegUrl || `manual://${eventName}`);
    if (
      db.events.some(
        (e) =>
          e.eventName.toLowerCase() === eventName.toLowerCase() &&
          e.canonicalUrl === canonicalUrl
      )
    ) {
      res.status(409).json({ error: 'Bu etkinlik zaten kayıtlı.' });
      return;
    }

    const nowIso = new Date().toISOString();
    const verified = Boolean(startIso && validRegUrl);

    const newEvent: MediaEvent = {
      id: makeMediaId('mevt'),
      guid: `manual-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      canonicalUrl,
      eventName,
      organizer,
      startDate: startIso,
      startTime: (body.startTime || '').trim() || null,
      endDate: endIso,
      timezone: (body.timezone || '').trim() || (startIso ? 'UTC' : null),
      attendanceMode: body.attendanceMode || 'unknown',
      location: (body.location || '').trim() || null,
      description: (body.description || '').trim(),
      registrationUrl: validRegUrl,
      originalUrl: validRegUrl || '',
      sourceId: 'manual-event',
      matchedSourceIds: ['manual-event'],
      category: (body.category || 'Engineering').trim(),
      categories: [(body.category || 'Engineering').trim()],
      eventType: body.eventType || 'conference',
      status: verified ? 'upcoming' : 'unverified',
      verificationStatus: verified ? 'verified' : 'unverified',
      verificationNote: verified
        ? null
        : 'Başlangıç tarihi veya kayıt bağlantısı doğrulanmadığı için Unverified işaretlendi.',
      publishedAt: nowIso,
      updatedAt: null,
      fetchedAt: nowIso,
      isFavorite: false,
      isArchived: false,
      archivedAt: null,
      isManual: true,
    };

    db.events.unshift(newEvent);
    reconcilePastEvents(db);
    await saveMediaDb(db);
    res.status(201).json({ event: newEvent });
  });

  router.patch('/events/:id', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const evt = db.events.find((e) => e.id === req.params.id);
    if (!evt) {
      res.status(404).json({ error: 'Etkinlik bulunamadı.' });
      return;
    }
    const body = req.body as { isFavorite?: boolean; isArchived?: boolean };
    if (typeof body.isFavorite === 'boolean') evt.isFavorite = body.isFavorite;
    if (typeof body.isArchived === 'boolean') {
      evt.isArchived = body.isArchived;
      evt.archivedAt = body.isArchived ? new Date().toISOString() : null;
    }
    await saveMediaDb(db);
    res.json({ event: evt });
  });

  router.delete('/events/:id', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const before = db.events.length;
    db.events = db.events.filter((e) => e.id !== req.params.id);
    if (db.events.length === before) {
      res.status(404).json({ error: 'Etkinlik bulunamadı.' });
      return;
    }
    await saveMediaDb(db);
    res.json({ ok: true });
  });

  // ==================== YOUTUBE & VIDEOS ====================
  router.get('/videos', (_req: Request, res: Response) => {
    const db = loadMediaDb();
    res.json({
      videos: db.videos,
      youtubeApiConfigured: Boolean(process.env.YOUTUBE_API_KEY?.trim()),
      youtubeQuota: db.youtubeQuota,
    });
  });

  router.post('/videos', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const body = req.body as {
      title?: string;
      channelName?: string;
      videoUrl?: string;
      category?: string;
      duration?: string;
      description?: string;
    };

    const rawUrl = (body.videoUrl || '').trim();
    const validUrl = validatePublicHttpUrl(rawUrl)?.toString();
    if (!validUrl) {
      res.status(400).json({ error: 'Geçerli bir video URL adresi girin.' });
      return;
    }

    const ytTarget = parseYouTubeTarget(validUrl);
    const videoId =
      ytTarget?.kind === 'video'
        ? ytTarget.id
        : makeMediaId('mvid-ext', normalizeMediaUrl(validUrl));
    const title = (body.title || '').trim();
    if (!title) {
      res.status(400).json({ error: 'Video başlığı zorunludur.' });
      return;
    }

    const canonicalUrl = normalizeMediaUrl(validUrl);
    if (
      db.videos.some(
        (v) => v.videoId === videoId || v.canonicalUrl === canonicalUrl
      )
    ) {
      res.status(409).json({ error: 'Bu video zaten kayıtlı.' });
      return;
    }

    const nowIso = new Date().toISOString();
    const newVideo: MediaVideo = {
      id: makeMediaId('mvid'),
      videoId,
      guid: ytTarget?.kind === 'video' ? `yt:video:${videoId}` : canonicalUrl,
      canonicalUrl,
      title,
      description: (body.description || '').trim(),
      channelName: (body.channelName || '').trim() || 'Engineering Channel',
      channelId: '',
      playlistId: null,
      playlistName: 'Manual Selections',
      publishedAt: nowIso,
      updatedAt: null,
      thumbnailUrl:
        ytTarget?.kind === 'video'
          ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`
          : null,
      embedUrl:
        ytTarget?.kind === 'video'
          ? `https://www.youtube.com/embed/${videoId}`
          : '',
      originalUrl: validUrl,
      duration: (body.duration || '').trim() || null,
      durationSeconds: null,
      category: (body.category || 'Engineering').trim(),
      categories: [(body.category || 'Engineering').trim()],
      sourceId: 'manual-video',
      matchedSourceIds: ['manual-video'],
      fetchedAt: nowIso,
      isWatched: false,
      isFavorite: false,
      isArchived: false,
      archivedAt: null,
      isManual: true,
    };

    db.videos.unshift(newVideo);
    await saveMediaDb(db);
    res.status(201).json({ video: newVideo });
  });

  router.patch('/videos/:id', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const vid = db.videos.find((v) => v.id === req.params.id);
    if (!vid) {
      res.status(404).json({ error: 'Video bulunamadı.' });
      return;
    }
    const body = req.body as {
      isWatched?: boolean;
      isFavorite?: boolean;
      isArchived?: boolean;
    };
    if (typeof body.isWatched === 'boolean') vid.isWatched = body.isWatched;
    if (typeof body.isFavorite === 'boolean') vid.isFavorite = body.isFavorite;
    if (typeof body.isArchived === 'boolean') {
      vid.isArchived = body.isArchived;
      vid.archivedAt = body.isArchived ? new Date().toISOString() : null;
    }
    await saveMediaDb(db);
    res.json({ video: vid });
  });

  router.delete('/videos/:id', async (req: Request, res: Response) => {
    const db = loadMediaDb();
    const before = db.videos.length;
    db.videos = db.videos.filter((v) => v.id !== req.params.id);
    if (db.videos.length === before) {
      res.status(404).json({ error: 'Video bulunamadı.' });
      return;
    }
    await saveMediaDb(db);
    res.json({ ok: true });
  });

  return router;
}
