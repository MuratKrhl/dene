import {
  MediaContentType,
  MediaEvent,
  MediaHubDatabase,
  MediaPodcastEpisode,
  MediaPodcastSeries,
  MediaSource,
  MediaSourceType,
  MediaSyncHistoryEntry,
  MediaVideo,
  YouTubeTargetKind,
  loadMediaDb,
  makeMediaId,
  normalizeMediaUrl,
  saveMediaDb,
} from './mediaDb.ts';
import { parseEventsApiJson } from './adapters/eventsApiAdapter.ts';
import { fetchWithRetry, validatePublicHttpUrl } from './adapters/httpClient.ts';
import { isIcalPayload, parseIcalEvents } from './adapters/icalAdapter.ts';
import {
  detectXmlFeedFormat,
  isSpotifyPodcastUrl,
  parseEventsRssAtomFeed,
  parsePodcastFeed,
  resolveApplePodcastRss,
} from './adapters/rssAtomAdapter.ts';
import {
  fetchYouTubeVideos,
  parseYouTubeTarget,
  resetQuotaIfNewDay,
  resolveYouTubeHandle,
} from './adapters/youtubeAdapter.ts';

const MAX_SYNC_HISTORY = 300;
const SCHEDULER_POLL_MS = 60_000;

const activeTypeLocks = new Set<MediaContentType>();
const activeSourceLocks = new Set<string>();
let schedulerTimer: NodeJS.Timeout | null = null;

export function reconcilePastEvents(db: MediaHubDatabase, nowMs: number = Date.now()): boolean {
  let changed = false;
  const nowIso = new Date(nowMs).toISOString();

  for (const evt of db.events) {
    if (evt.verificationStatus === 'unverified' || !evt.startDate || !evt.registrationUrl) {
      if (evt.status !== 'unverified') {
        evt.status = 'unverified';
        changed = true;
      }
      continue;
    }

    const startMs = Date.parse(evt.startDate);
    if (Number.isNaN(startMs)) continue;
    const endMs = evt.endDate ? Date.parse(evt.endDate) : startMs + 24 * 3600_000;

    if (endMs < nowMs) {
      if (evt.status !== 'past' || !evt.isArchived) {
        evt.status = 'past';
        evt.isArchived = true;
        evt.archivedAt = evt.archivedAt || nowIso;
        changed = true;
      }
    } else if (startMs <= nowMs && endMs >= nowMs) {
      if (evt.status !== 'ongoing') {
        evt.status = 'ongoing';
        changed = true;
      }
    } else if (evt.status !== 'upcoming') {
      evt.status = 'upcoming';
      changed = true;
    }
  }

  return changed;
}

export function detectDuplicateSource(
  db: MediaHubDatabase,
  params: {
    contentType: MediaContentType;
    feedOrEndpoint: string;
    youtubeTargetId?: string;
    excludeId?: string;
  }
): MediaSource | null {
  const normEndpoint = normalizeMediaUrl(params.feedOrEndpoint);
  const ytId = (params.youtubeTargetId || '').trim();

  for (const src of db.sources) {
    if (params.excludeId && src.id === params.excludeId) continue;
    if (src.contentType !== params.contentType) continue;

    if (ytId && src.youtubeTargetId && src.youtubeTargetId === ytId) {
      return src;
    }
    if (normEndpoint && normalizeMediaUrl(src.feedOrEndpoint) === normEndpoint) {
      return src;
    }
  }
  return null;
}

export interface TestMediaSourceInput {
  contentType: MediaContentType;
  sourceType?: MediaSourceType;
  feedOrEndpoint: string;
  websiteUrl?: string;
  name?: string;
  category?: string;
}

export interface TestMediaSourceResult {
  ok: boolean;
  detectedSourceType: MediaSourceType;
  feedOrEndpoint: string;
  websiteUrl?: string;
  resolvedName?: string;
  resolvedAuthor?: string;
  artworkUrl?: string;
  youtubeTargetKind?: YouTubeTargetKind;
  youtubeTargetId?: string;
  httpStatus: number | null;
  itemCount: number;
  sampleTitles: string[];
  warning?: string | null;
  error: string | null;
  durationMs: number;
}

export async function testAndValidateMediaSource(
  input: TestMediaSourceInput
): Promise<TestMediaSourceResult> {
  const started = Date.now();
  const db = loadMediaDb();
  const rawEndpoint = (input.feedOrEndpoint || '').trim();

  if (!rawEndpoint) {
    return {
      ok: false,
      detectedSourceType: 'unsupported',
      feedOrEndpoint: '',
      httpStatus: null,
      itemCount: 0,
      sampleTitles: [],
      error: 'Feed, API veya YouTube hedef adresi boş bırakılamaz.',
      durationMs: Date.now() - started,
    };
  }

  // ==================== YOUTUBE ====================
  if (input.contentType === 'youtube') {
    let target = parseYouTubeTarget(rawEndpoint);
    if (!target) {
      return {
        ok: false,
        detectedSourceType: 'youtube-api',
        feedOrEndpoint: rawEndpoint,
        httpStatus: null,
        itemCount: 0,
        sampleTitles: [],
        error:
          'Geçerli bir YouTube Channel ID (UC...), Playlist ID (PL...), Video ID veya YouTube URL / @handle girin.',
        durationMs: Date.now() - started,
      };
    }

    let resolvedName = input.name?.trim();
    if (target.needsHandleResolution && target.handle) {
      const resolved = await resolveYouTubeHandle(target.handle, db.youtubeQuota);
      await saveMediaDb(db);
      if (!resolved.ok || !resolved.channelId) {
        return {
          ok: false,
          detectedSourceType: 'youtube-api',
          feedOrEndpoint: rawEndpoint,
          httpStatus: null,
          itemCount: 0,
          sampleTitles: [],
          error: resolved.error || 'YouTube handle çözümlenemedi.',
          durationMs: Date.now() - started,
        };
      }
      target = {
        kind: 'channel',
        id: resolved.channelId,
        canonicalEndpoint: resolved.channelId,
      };
      if (!resolvedName && resolved.title) resolvedName = resolved.title;
    }

    const tempSource: MediaSource = {
      id: 'test-yt',
      name: resolvedName || 'YouTube Test',
      description: '',
      contentType: 'youtube',
      sourceType: 'youtube-api',
      websiteUrl:
        input.websiteUrl ||
        (target.kind === 'channel'
          ? `https://www.youtube.com/channel/${target.id}`
          : target.kind === 'playlist'
            ? `https://www.youtube.com/playlist?list=${target.id}`
            : `https://www.youtube.com/watch?v=${target.id}`),
      feedOrEndpoint: target.canonicalEndpoint,
      youtubeTargetKind: target.kind,
      youtubeTargetId: target.id,
      category: input.category || 'Engineering',
      categories: [input.category || 'Engineering'],
      enabled: true,
      verificationStatus: 'unverified',
      verificationNote: null,
      lastSuccessfulSyncAt: null,
      lastAttemptedSyncAt: null,
      nextSyncAt: null,
      syncIntervalHours: 3,
      lastError: null,
      lastHttpStatus: null,
      consecutiveFailures: 0,
      collectedCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const ytRes = await fetchYouTubeVideos(tempSource, db.youtubeQuota);
    await saveMediaDb(db);

    if (!ytRes.ok) {
      return {
        ok: false,
        detectedSourceType: 'youtube-api',
        feedOrEndpoint: target.canonicalEndpoint,
        youtubeTargetKind: target.kind,
        youtubeTargetId: target.id,
        httpStatus: ytRes.httpStatus,
        itemCount: 0,
        sampleTitles: [],
        error: ytRes.error || 'YouTube kaynağı doğrulanamadı.',
        durationMs: Date.now() - started,
      };
    }

    return {
      ok: true,
      detectedSourceType: 'youtube-api',
      feedOrEndpoint: target.canonicalEndpoint,
      websiteUrl: tempSource.websiteUrl,
      resolvedName:
        resolvedName || ytRes.videos[0]?.channelName || tempSource.name,
      youtubeTargetKind: target.kind,
      youtubeTargetId: target.id,
      httpStatus: ytRes.httpStatus,
      itemCount: ytRes.videos.length,
      sampleTitles: ytRes.videos.slice(0, 3).map((v) => v.title),
      warning: ytRes.note,
      error: null,
      durationMs: Date.now() - started,
    };
  }

  // ==================== PODCAST ====================
  if (input.contentType === 'podcast') {
    if (isSpotifyPodcastUrl(rawEndpoint)) {
      return {
        ok: false,
        detectedSourceType: 'unsupported',
        feedOrEndpoint: rawEndpoint,
        httpStatus: null,
        itemCount: 0,
        sampleTitles: [],
        error:
          'Spotify bağlantıları herkese açık RSS ses akışı sunmaz ve Spotify Web API OAuth erişimi gerektirir. Lütfen yayıncının resmi RSS adresini veya Apple Podcasts bağlantısını kullanın.',
        durationMs: Date.now() - started,
      };
    }

    let targetFeedUrl = rawEndpoint;
    let resolvedWebsite = input.websiteUrl;
    let resolvedName = input.name?.trim();
    let resolvedAuthor: string | undefined;
    let artworkUrl: string | undefined;

    if (
      rawEndpoint.includes('podcasts.apple.com') ||
      rawEndpoint.includes('itunes.apple.com')
    ) {
      const apple = await resolveApplePodcastRss(rawEndpoint);
      if (!apple.ok || !apple.feedUrl) {
        return {
          ok: false,
          detectedSourceType: 'rss',
          feedOrEndpoint: rawEndpoint,
          httpStatus: null,
          itemCount: 0,
          sampleTitles: [],
          error: apple.error || 'Apple Podcasts RSS adresi çözümlenemedi.',
          durationMs: Date.now() - started,
        };
      }
      targetFeedUrl = apple.feedUrl;
      resolvedName = resolvedName || apple.podcastName;
      resolvedAuthor = apple.artistName;
      artworkUrl = apple.artworkUrl;
      resolvedWebsite = resolvedWebsite || apple.websiteUrl;
    }

    if (!validatePublicHttpUrl(targetFeedUrl)) {
      return {
        ok: false,
        detectedSourceType: 'rss',
        feedOrEndpoint: targetFeedUrl,
        httpStatus: null,
        itemCount: 0,
        sampleTitles: [],
        error: 'Geçerli bir genel HTTP/HTTPS podcast RSS URL adresi girin.',
        durationMs: Date.now() - started,
      };
    }

    const res = await fetchWithRetry(targetFeedUrl, {
      timeoutMs: 20_000,
      maxRetries: 1,
      accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml',
    });
    if (!res.ok) {
      return {
        ok: false,
        detectedSourceType: 'rss',
        feedOrEndpoint: targetFeedUrl,
        httpStatus: res.httpStatus,
        itemCount: 0,
        sampleTitles: [],
        error: res.error || 'Podcast RSS feed bağlantısı başarısız.',
        durationMs: Date.now() - started,
      };
    }

    try {
      const dummySource: MediaSource = {
        id: 'test-pod',
        name: resolvedName || 'Podcast Test',
        description: '',
        contentType: 'podcast',
        sourceType: 'rss',
        websiteUrl: resolvedWebsite || targetFeedUrl,
        feedOrEndpoint: targetFeedUrl,
        category: input.category || 'Engineering',
        categories: [input.category || 'Engineering'],
        enabled: true,
        verificationStatus: 'unverified',
        verificationNote: null,
        lastSuccessfulSyncAt: null,
        lastAttemptedSyncAt: null,
        nextSyncAt: null,
        syncIntervalHours: 3,
        lastError: null,
        lastHttpStatus: res.httpStatus,
        consecutiveFailures: 0,
        collectedCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const parsed = parsePodcastFeed(res.body, res.finalUrl || targetFeedUrl, dummySource);
      return {
        ok: true,
        detectedSourceType: parsed.feedFormat,
        feedOrEndpoint: targetFeedUrl,
        websiteUrl: parsed.series.websiteUrl || resolvedWebsite,
        resolvedName: parsed.series.title || resolvedName,
        resolvedAuthor: parsed.series.publisher || resolvedAuthor,
        artworkUrl: parsed.series.artworkUrl || artworkUrl,
        httpStatus: res.httpStatus,
        itemCount: parsed.episodes.length,
        sampleTitles: parsed.episodes.slice(0, 3).map((e) => e.title),
        warning: parsed.episodes.some((e) => e.audioUrl)
          ? null
          : 'Bölümler bulundu ancak doğrudan MP3/audio enclosure bağlantısı tespit edilemedi.',
        error: null,
        durationMs: Date.now() - started,
      };
    } catch (err) {
      return {
        ok: false,
        detectedSourceType: 'rss',
        feedOrEndpoint: targetFeedUrl,
        httpStatus: res.httpStatus,
        itemCount: 0,
        sampleTitles: [],
        error:
          err instanceof Error
            ? err.message
            : 'Podcast RSS feed ayrıştırılamadı.',
        durationMs: Date.now() - started,
      };
    }
  }

  // ==================== EVENT (iCal / Official JSON API / RSS-Atom) ====================
  if (!validatePublicHttpUrl(rawEndpoint)) {
    return {
      ok: false,
      detectedSourceType: input.sourceType || 'manual',
      feedOrEndpoint: rawEndpoint,
      httpStatus: null,
      itemCount: 0,
      sampleTitles: [],
      error: 'Geçerli bir genel HTTP/HTTPS etkinlik feed/API/iCal URL adresi girin.',
      durationMs: Date.now() - started,
    };
  }

  const res = await fetchWithRetry(rawEndpoint, {
    timeoutMs: 20_000,
    maxRetries: 1,
    accept:
      'text/calendar, application/json, application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9',
  });
  if (!res.ok) {
    return {
      ok: false,
      detectedSourceType: input.sourceType || 'official-api',
      feedOrEndpoint: rawEndpoint,
      httpStatus: res.httpStatus,
      itemCount: 0,
      sampleTitles: [],
      error: res.error || 'Etkinlik kaynağına erişilemedi.',
      durationMs: Date.now() - started,
    };
  }

  const tempEventSource: MediaSource = {
    id: 'test-evt',
    name: input.name?.trim() || 'Event Test',
    description: '',
    contentType: 'event',
    sourceType: input.sourceType || 'official-api',
    websiteUrl: input.websiteUrl || rawEndpoint,
    feedOrEndpoint: rawEndpoint,
    category: input.category || 'Kubernetes',
    categories: [input.category || 'Kubernetes'],
    enabled: true,
    verificationStatus: 'unverified',
    verificationNote: null,
    lastSuccessfulSyncAt: null,
    lastAttemptedSyncAt: null,
    nextSyncAt: null,
    syncIntervalHours: 3,
    lastError: null,
    lastHttpStatus: res.httpStatus,
    consecutiveFailures: 0,
    collectedCount: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  try {
    if (isIcalPayload(res.body, res.contentType)) {
      const events = parseIcalEvents(res.body, tempEventSource);
      const unverifiedCount = events.filter(
        (e) => e.verificationStatus === 'unverified'
      ).length;
      return {
        ok: events.length > 0,
        detectedSourceType: 'ical',
        feedOrEndpoint: rawEndpoint,
        httpStatus: res.httpStatus,
        itemCount: events.length,
        sampleTitles: events.slice(0, 3).map((e) => e.eventName),
        warning:
          unverifiedCount > 0
            ? `${unverifiedCount} iCal etkinliğinde eksik tarih/kayıt bağlantısı nedeniyle Unverified işaretlendi.`
            : null,
        error: events.length === 0 ? 'iCal dosyasında VEVENT kaydı bulunamadı.' : null,
        durationMs: Date.now() - started,
      };
    }

    const trimmed = res.body.trim();
    if (
      res.contentType.includes('json') ||
      trimmed.startsWith('{') ||
      trimmed.startsWith('[')
    ) {
      const events = parseEventsApiJson(res.body, tempEventSource);
      return {
        ok: true,
        detectedSourceType: 'official-api',
        feedOrEndpoint: rawEndpoint,
        httpStatus: res.httpStatus,
        itemCount: events.length,
        sampleTitles: events.slice(0, 3).map((e) => e.eventName),
        error: null,
        durationMs: Date.now() - started,
      };
    }

    const xmlFormat = detectXmlFeedFormat(res.body);
    if (xmlFormat) {
      const parsed = parseEventsRssAtomFeed(res.body, tempEventSource);
      const unverifiedCount = parsed.events.filter(
        (e) => e.verificationStatus === 'unverified'
      ).length;
      return {
        ok: parsed.events.length > 0,
        detectedSourceType: xmlFormat,
        feedOrEndpoint: rawEndpoint,
        httpStatus: res.httpStatus,
        itemCount: parsed.events.length,
        sampleTitles: parsed.events.slice(0, 3).map((e) => e.eventName),
        warning:
          unverifiedCount > 0
            ? `${unverifiedCount}/${parsed.events.length} kayıt açık etkinlik tarihi içermediği için Unverified olarak işaretlenecek.`
            : null,
        error:
          parsed.events.length === 0
            ? 'RSS/Atom feed içinde etkinlik kaydı bulunamadı.'
            : null,
        durationMs: Date.now() - started,
      };
    }

    return {
      ok: false,
      detectedSourceType: 'unsupported',
      feedOrEndpoint: rawEndpoint,
      httpStatus: res.httpStatus,
      itemCount: 0,
      sampleTitles: [],
      error:
        'Yanıt desteklenen bir etkinlik formatında (iCal .ics, JSON API, RSS 2.0 veya Atom) değil.',
      durationMs: Date.now() - started,
    };
  } catch (err) {
    return {
      ok: false,
      detectedSourceType: input.sourceType || 'official-api',
      feedOrEndpoint: rawEndpoint,
      httpStatus: res.httpStatus,
      itemCount: 0,
      sampleTitles: [],
      error: err instanceof Error ? err.message : 'Etkinlik doğrulama hatası.',
      durationMs: Date.now() - started,
    };
  }
}

function mergePodcastSeries(
  db: MediaHubDatabase,
  incoming: MediaPodcastSeries
): void {
  const idx = db.podcastSeries.findIndex(
    (s) => s.id === incoming.id || normalizeMediaUrl(s.feedUrl) === normalizeMediaUrl(incoming.feedUrl)
  );
  if (idx >= 0) {
    const existing = db.podcastSeries[idx];
    db.podcastSeries[idx] = {
      ...incoming,
      id: existing.id,
      isFollowed: existing.isFollowed,
      isFavorite: existing.isFavorite,
    };
  } else {
    db.podcastSeries.push(incoming);
  }
}

function mergePodcastEpisodes(
  db: MediaHubDatabase,
  incoming: MediaPodcastEpisode[],
  sourceId: string
): { newItems: number; duplicatesSkipped: number; updatedItems: number } {
  let newItems = 0;
  let duplicatesSkipped = 0;
  let updatedItems = 0;

  for (const ep of incoming) {
    const existing = db.podcastEpisodes.find(
      (e) =>
        (ep.guid && e.guid === ep.guid) ||
        (ep.canonicalUrl && e.canonicalUrl === ep.canonicalUrl)
    );
    if (!existing) {
      db.podcastEpisodes.push(ep);
      newItems += 1;
    } else {
      const mergedSources = existing.matchedSourceIds.includes(sourceId)
        ? existing.matchedSourceIds
        : [...existing.matchedSourceIds, sourceId];
      const changed =
        existing.title !== ep.title ||
        existing.audioUrl !== ep.audioUrl ||
        existing.duration !== ep.duration ||
        mergedSources.length !== existing.matchedSourceIds.length;
      if (changed) {
        existing.title = ep.title;
        existing.description = ep.description || existing.description;
        existing.audioUrl = ep.audioUrl || existing.audioUrl;
        existing.artworkUrl = ep.artworkUrl || existing.artworkUrl;
        existing.duration = ep.duration || existing.duration;
        existing.durationSeconds = ep.durationSeconds || existing.durationSeconds;
        existing.updatedAt = ep.updatedAt || existing.updatedAt;
        existing.matchedSourceIds = mergedSources;
        updatedItems += 1;
      } else {
        duplicatesSkipped += 1;
      }
    }
  }

  return { newItems, duplicatesSkipped, updatedItems };
}

function mergeEvents(
  db: MediaHubDatabase,
  incoming: MediaEvent[],
  sourceId: string
): { newItems: number; duplicatesSkipped: number; updatedItems: number } {
  let newItems = 0;
  let duplicatesSkipped = 0;
  let updatedItems = 0;

  for (const evt of incoming) {
    const existing = db.events.find(
      (e) =>
        (evt.guid && e.guid === evt.guid) ||
        (evt.canonicalUrl &&
          e.canonicalUrl === evt.canonicalUrl &&
          e.eventName === evt.eventName)
    );
    if (!existing) {
      db.events.push(evt);
      newItems += 1;
    } else {
      const mergedSources = existing.matchedSourceIds.includes(sourceId)
        ? existing.matchedSourceIds
        : [...existing.matchedSourceIds, sourceId];
      const changed =
        existing.startDate !== evt.startDate ||
        existing.location !== evt.location ||
        existing.registrationUrl !== evt.registrationUrl ||
        existing.verificationStatus !== evt.verificationStatus ||
        mergedSources.length !== existing.matchedSourceIds.length;
      if (changed) {
        existing.eventName = evt.eventName;
        existing.startDate = evt.startDate;
        existing.startTime = evt.startTime;
        existing.endDate = evt.endDate;
        existing.timezone = evt.timezone;
        existing.attendanceMode = evt.attendanceMode;
        existing.location = evt.location;
        existing.description = evt.description || existing.description;
        existing.registrationUrl = evt.registrationUrl;
        existing.verificationStatus = evt.verificationStatus;
        existing.verificationNote = evt.verificationNote;
        existing.status = evt.status;
        existing.isArchived = existing.isArchived || evt.isArchived;
        existing.archivedAt = existing.archivedAt || evt.archivedAt;
        existing.updatedAt = evt.updatedAt || existing.updatedAt;
        existing.matchedSourceIds = mergedSources;
        updatedItems += 1;
      } else {
        duplicatesSkipped += 1;
      }
    }
  }

  return { newItems, duplicatesSkipped, updatedItems };
}

function mergeVideos(
  db: MediaHubDatabase,
  incoming: MediaVideo[],
  sourceId: string
): { newItems: number; duplicatesSkipped: number; updatedItems: number } {
  let newItems = 0;
  let duplicatesSkipped = 0;
  let updatedItems = 0;

  for (const vid of incoming) {
    const existing = db.videos.find(
      (v) =>
        v.videoId === vid.videoId ||
        (vid.canonicalUrl && v.canonicalUrl === vid.canonicalUrl)
    );
    if (!existing) {
      db.videos.push(vid);
      newItems += 1;
    } else {
      const mergedSources = existing.matchedSourceIds.includes(sourceId)
        ? existing.matchedSourceIds
        : [...existing.matchedSourceIds, sourceId];
      const changed =
        existing.title !== vid.title ||
        (!existing.duration && Boolean(vid.duration)) ||
        mergedSources.length !== existing.matchedSourceIds.length;
      if (changed) {
        existing.title = vid.title;
        existing.description = vid.description || existing.description;
        existing.thumbnailUrl = vid.thumbnailUrl || existing.thumbnailUrl;
        existing.duration = vid.duration || existing.duration;
        existing.durationSeconds = vid.durationSeconds || existing.durationSeconds;
        existing.updatedAt = vid.updatedAt || existing.updatedAt;
        existing.matchedSourceIds = mergedSources;
        updatedItems += 1;
      } else {
        duplicatesSkipped += 1;
      }
    }
  }

  return { newItems, duplicatesSkipped, updatedItems };
}

function computeNextSyncIso(intervalHours: number): string | null {
  if (!intervalHours || intervalHours <= 0) return null;
  return new Date(Date.now() + intervalHours * 3600_000).toISOString();
}

function countItemsForSource(db: MediaHubDatabase, source: MediaSource): number {
  if (source.contentType === 'podcast') {
    return db.podcastEpisodes.filter((e) => e.matchedSourceIds.includes(source.id)).length;
  }
  if (source.contentType === 'event') {
    return db.events.filter((e) => e.matchedSourceIds.includes(source.id)).length;
  }
  return db.videos.filter((v) => v.matchedSourceIds.includes(source.id)).length;
}

export async function syncSingleMediaSource(
  sourceId: string,
  trigger: MediaSyncHistoryEntry['trigger'] = 'manual'
): Promise<MediaSyncHistoryEntry> {
  const db = loadMediaDb();
  const source = db.sources.find((s) => s.id === sourceId);
  const startedMs = Date.now();
  const startedAt = new Date(startedMs).toISOString();

  if (!source) {
    return {
      syncId: makeMediaId('msync'),
      startedAt,
      finishedAt: new Date().toISOString(),
      contentType: 'all',
      sourceId,
      sourceName: 'Unknown Source',
      trigger,
      status: 'error',
      httpStatus: null,
      newItems: 0,
      duplicatesSkipped: 0,
      updatedItems: 0,
      errors: 1,
      errorMessage: 'Kaynak bulunamadı.',
      durationMs: Date.now() - startedMs,
    };
  }

  if (activeSourceLocks.has(sourceId)) {
    return {
      syncId: makeMediaId('msync'),
      startedAt,
      finishedAt: new Date().toISOString(),
      contentType: source.contentType,
      sourceId: source.id,
      sourceName: source.name,
      trigger,
      status: 'error',
      httpStatus: null,
      newItems: 0,
      duplicatesSkipped: 0,
      updatedItems: 0,
      errors: 1,
      errorMessage: 'Bu kaynak için halihazırda aktif bir senkronizasyon çalışıyor.',
      durationMs: Date.now() - startedMs,
    };
  }

  if (
    source.verificationStatus === 'unverified' ||
    source.sourceType === 'manual' ||
    source.sourceType === 'unsupported' ||
    !source.feedOrEndpoint.trim()
  ) {
    const entry: MediaSyncHistoryEntry = {
      syncId: makeMediaId('msync'),
      startedAt,
      finishedAt: new Date().toISOString(),
      contentType: source.contentType,
      sourceId: source.id,
      sourceName: source.name,
      trigger,
      status: 'unsupported',
      httpStatus: null,
      newItems: 0,
      duplicatesSkipped: 0,
      updatedItems: 0,
      errors: 0,
      errorMessage:
        source.verificationNote ||
        'Kaynak doğrulanmamış veya yalnızca manuel girişe açık.',
      durationMs: Date.now() - startedMs,
    };
    return entry;
  }

  activeSourceLocks.add(sourceId);
  source.lastAttemptedSyncAt = startedAt;

  let status: MediaSyncHistoryEntry['status'] = 'success';
  let httpStatus: number | null = null;
  let newItems = 0;
  let duplicatesSkipped = 0;
  let updatedItems = 0;
  let errors = 0;
  let errorMessage: string | null = null;

  try {
    if (source.contentType === 'podcast') {
      const res = await fetchWithRetry(source.feedOrEndpoint, {
        timeoutMs: 20_000,
        maxRetries: 1,
        accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml',
      });
      httpStatus = res.httpStatus;
      if (!res.ok) {
        throw new Error(res.error || 'Podcast RSS feed alınamadı.');
      }
      const parsed = parsePodcastFeed(
        res.body,
        res.finalUrl || source.feedOrEndpoint,
        source
      );
      mergePodcastSeries(db, parsed.series);
      const merged = mergePodcastEpisodes(db, parsed.episodes, source.id);
      newItems = merged.newItems;
      duplicatesSkipped = merged.duplicatesSkipped;
      updatedItems = merged.updatedItems;

      const ser = db.podcastSeries.find((s) => s.id === parsed.series.id);
      if (ser) {
        ser.episodeCount = db.podcastEpisodes.filter(
          (e) => e.seriesId === ser.id
        ).length;
        ser.lastSyncedAt = new Date().toISOString();
      }
      source.sourceType = parsed.feedFormat;
      source.verificationStatus = 'verified';
      source.lastError = null;
      source.consecutiveFailures = 0;
    } else if (source.contentType === 'event') {
      const res = await fetchWithRetry(source.feedOrEndpoint, {
        timeoutMs: 20_000,
        maxRetries: 1,
        accept:
          'text/calendar, application/json, application/rss+xml, application/atom+xml, application/xml, text/xml',
      });
      httpStatus = res.httpStatus;
      if (!res.ok) {
        throw new Error(res.error || 'Etkinlik kaynağı alınamadı.');
      }

      let parsedEvents: MediaEvent[] = [];
      if (isIcalPayload(res.body, res.contentType)) {
        parsedEvents = parseIcalEvents(res.body, source);
        source.sourceType = 'ical';
      } else if (
        res.contentType.includes('json') ||
        res.body.trim().startsWith('{') ||
        res.body.trim().startsWith('[')
      ) {
        parsedEvents = parseEventsApiJson(res.body, source);
        source.sourceType = 'official-api';
      } else {
        const xmlOut = parseEventsRssAtomFeed(res.body, source);
        parsedEvents = xmlOut.events;
        source.sourceType = xmlOut.feedFormat;
      }

      const merged = mergeEvents(db, parsedEvents, source.id);
      newItems = merged.newItems;
      duplicatesSkipped = merged.duplicatesSkipped;
      updatedItems = merged.updatedItems;
      reconcilePastEvents(db);

      source.verificationStatus = 'verified';
      source.lastError = null;
      source.consecutiveFailures = 0;
    } else if (source.contentType === 'youtube') {
      const ytRes = await fetchYouTubeVideos(source, db.youtubeQuota);
      httpStatus = ytRes.httpStatus;
      if (!ytRes.ok) {
        throw new Error(ytRes.error || 'YouTube senkronizasyonu başarısız.');
      }
      const merged = mergeVideos(db, ytRes.videos, source.id);
      newItems = merged.newItems;
      duplicatesSkipped = merged.duplicatesSkipped;
      updatedItems = merged.updatedItems;

      source.verificationStatus = 'verified';
      source.verificationNote = ytRes.note || source.verificationNote;
      source.lastError = null;
      source.consecutiveFailures = 0;
    }

    const nowIso = new Date().toISOString();
    source.lastSuccessfulSyncAt = nowIso;
    source.nextSyncAt = computeNextSyncIso(source.syncIntervalHours);
    source.lastHttpStatus = httpStatus;
    source.collectedCount = countItemsForSource(db, source);
    source.updatedAt = nowIso;
  } catch (err) {
    status = 'error';
    errors = 1;
    errorMessage = err instanceof Error ? err.message : 'Bilinmeyen senkronizasyon hatası.';
    source.lastError = errorMessage;
    source.lastHttpStatus = httpStatus;
    source.consecutiveFailures += 1;
    source.verificationStatus = 'error';
    source.nextSyncAt = computeNextSyncIso(source.syncIntervalHours);
    source.updatedAt = new Date().toISOString();
  } finally {
    activeSourceLocks.delete(sourceId);
  }

  const entry: MediaSyncHistoryEntry = {
    syncId: makeMediaId('msync'),
    startedAt,
    finishedAt: new Date().toISOString(),
    contentType: source.contentType,
    sourceId: source.id,
    sourceName: source.name,
    trigger,
    status,
    httpStatus,
    newItems,
    duplicatesSkipped,
    updatedItems,
    errors,
    errorMessage,
    durationMs: Date.now() - startedMs,
  };

  db.syncHistory.unshift(entry);
  if (db.syncHistory.length > MAX_SYNC_HISTORY) {
    db.syncHistory = db.syncHistory.slice(0, MAX_SYNC_HISTORY);
  }
  await saveMediaDb(db);
  return entry;
}

export async function syncMediaByType(
  targetType: MediaContentType | 'all',
  trigger: MediaSyncHistoryEntry['trigger'] = 'manual'
): Promise<{
  skippedDueToLock?: boolean;
  results: MediaSyncHistoryEntry[];
}> {
  const typesToSync: MediaContentType[] =
    targetType === 'all' ? ['podcast', 'event', 'youtube'] : [targetType];

  const unlockedTypes = typesToSync.filter((t) => !activeTypeLocks.has(t));
  if (unlockedTypes.length === 0) {
    return { skippedDueToLock: true, results: [] };
  }

  for (const t of unlockedTypes) activeTypeLocks.add(t);
  const allResults: MediaSyncHistoryEntry[] = [];

  try {
    const db = loadMediaDb();
    reconcilePastEvents(db);
    await saveMediaDb(db);

    for (const ct of unlockedTypes) {
      const dbLatest = loadMediaDb();
      const eligibleSources = dbLatest.sources.filter(
        (s) =>
          s.contentType === ct &&
          s.enabled &&
          s.verificationStatus !== 'unverified' &&
          s.sourceType !== 'manual' &&
          s.sourceType !== 'unsupported' &&
          Boolean(s.feedOrEndpoint.trim())
      );

      for (const src of eligibleSources) {
        const res = await syncSingleMediaSource(src.id, trigger);
        allResults.push(res);
      }

      const dbAfter = loadMediaDb();
      const nowIso = new Date().toISOString();
      dbAfter.scheduler[ct].lastSyncAt = nowIso;
      const typeResults = allResults.filter((r) => r.contentType === ct);
      if (typeResults.some((r) => r.status === 'success') || eligibleSources.length === 0) {
        dbAfter.scheduler[ct].lastSuccessfulSyncAt = nowIso;
      }
      await saveMediaDb(dbAfter);
    }

    return { results: allResults };
  } finally {
    for (const t of unlockedTypes) activeTypeLocks.delete(t);
  }
}

export async function retryFailedMediaSources(
  targetType?: MediaContentType
): Promise<MediaSyncHistoryEntry[]> {
  const db = loadMediaDb();
  const failed = db.sources.filter(
    (s) =>
      s.enabled &&
      (s.verificationStatus === 'error' || Boolean(s.lastError)) &&
      s.sourceType !== 'manual' &&
      s.sourceType !== 'unsupported' &&
      (!targetType || s.contentType === targetType)
  );
  const results: MediaSyncHistoryEntry[] = [];
  for (const src of failed) {
    const res = await syncSingleMediaSource(src.id, 'retry');
    results.push(res);
  }
  return results;
}

export function getMediaSyncStatus() {
  const db = loadMediaDb();
  reconcilePastEvents(db);
  resetQuotaIfNewDay(db.youtubeQuota);

  return {
    activeTypeLocks: Array.from(activeTypeLocks),
    activeSourceLocks: Array.from(activeSourceLocks),
    youtubeApiConfigured: Boolean(process.env.YOUTUBE_API_KEY?.trim()),
    youtubeQuota: db.youtubeQuota,
    scheduler: db.scheduler,
    counts: {
      sourcesTotal: db.sources.length,
      sourcesVerifiedEnabled: db.sources.filter(
        (s) => s.enabled && s.verificationStatus === 'verified'
      ).length,
      sourcesFailed: db.sources.filter(
        (s) => s.enabled && (s.verificationStatus === 'error' || Boolean(s.lastError))
      ).length,
      sourcesUnverified: db.sources.filter(
        (s) => s.verificationStatus === 'unverified'
      ).length,
      podcastSeries: db.podcastSeries.length,
      podcastEpisodes: db.podcastEpisodes.length,
      eventsActive: db.events.filter(
        (e) => !e.isArchived && e.status !== 'past'
      ).length,
      eventsPast: db.events.filter(
        (e) => e.isArchived || e.status === 'past'
      ).length,
      eventsUnverified: db.events.filter(
        (e) => e.verificationStatus === 'unverified'
      ).length,
      videos: db.videos.length,
    },
  };
}

function isTypeDue(
  lastSyncAt: string | null,
  intervalHours: number,
  nowMs: number
): boolean {
  if (!intervalHours || intervalHours <= 0) return false;
  if (!lastSyncAt) return true;
  const lastMs = Date.parse(lastSyncAt);
  if (Number.isNaN(lastMs)) return true;
  return nowMs - lastMs >= intervalHours * 3600_000;
}

export function startMediaScheduler(): void {
  if (schedulerTimer) return;

  const checkDue = async (trigger: 'startup' | 'scheduled') => {
    const db = loadMediaDb();
    reconcilePastEvents(db);
    await saveMediaDb(db);

    const nowMs = Date.now();
    const types: MediaContentType[] = ['podcast', 'event', 'youtube'];
    for (const ct of types) {
      const cfg = db.scheduler[ct];
      if (!cfg.autoSyncEnabled) continue;
      if (activeTypeLocks.has(ct)) continue;
      if (isTypeDue(cfg.lastSyncAt, cfg.intervalHours, nowMs)) {
        void syncMediaByType(ct, trigger);
      }
    }
  };

  setTimeout(() => {
    void checkDue('startup');
  }, 5_000);

  schedulerTimer = setInterval(() => {
    void checkDue('scheduled');
  }, SCHEDULER_POLL_MS);
}
