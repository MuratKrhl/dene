export type MediumSourceStatus = 'idle' | 'syncing' | 'success' | 'error';

export type MediumArticleRetentionStatus = 'active' | 'archived';

/** Active Medium articles window in days (based strictly on publishedAt). */
export const MEDIUM_RETENTION_DAYS = 30;

export type MediumCategoryName =
  | 'Java'
  | 'JBoss'
  | 'Kubernetes'
  | 'OpenShift'
  | 'Nginx'
  | 'DevOps'
  | 'AI'
  | 'Google Cloud'
  | 'Azure'
  | 'AWS';

export interface MediumSource {
  id: string;
  name: MediumCategoryName;
  rssUrl: string;
  tag: string;
  enabled: boolean;
  lastFetchedAt: string | null;
  lastSuccessfulFetchAt: string | null;
  status: MediumSourceStatus;
  errorMessage: string | null;
  lastArticleCount?: number;
}

export interface MediumArticle {
  id: string;
  title: string;
  author: string;
  publishedAt: string;
  summary: string;
  contentSnippet: string;
  image: string | null;
  articleUrl: string;
  guid: string;
  source: 'medium';
  sourceCategory: MediumCategoryName;
  sourceTag: string;
  /** All Medium categories that yielded this article (for cross-tag deduplication). */
  sourceCategories: MediumCategoryName[];
  /** All normalized tags associated with this article across feeds & RSS item tags. */
  sourceTags: string[];
  isRead: boolean;
  isFavorite: boolean;
  fetchedAt: string;
  /** Retention classification derived from publishedAt (active <= 30d, archived > 30d; never auto-deleted). */
  retentionStatus?: MediumArticleRetentionStatus;
  /** ISO timestamp when this article transitioned to Archive (> 30 days old). */
  archivedAt?: string | null;
  /** Only populated when RSS content provides enough text to estimate reading time reliably. */
  readingTime: string | null;
  /** Plain text paragraphs extracted directly from RSS description/content if present. */
  rssParagraphs?: string[];
  featured?: boolean;
}

export interface ParsedMediumFeedItem {
  title: string;
  author: string;
  publishedAt: string;
  summary: string;
  contentSnippet: string;
  image: string | null;
  articleUrl: string;
  guid: string;
  itemTags: string[];
  readingTime: string | null;
  rssParagraphs: string[];
}

export interface MediumParseResult {
  feedTitle: string;
  items: ParsedMediumFeedItem[];
  skippedInvalidCount: number;
}

export interface MediumSourceSyncReport {
  sourceId: string;
  sourceName: MediumCategoryName;
  rssUrl: string;
  ok: boolean;
  fetchedCount: number;
  newCount: number;
  mergedDuplicateCount: number;
  errorMessage: string | null;
  durationMs: number;
}

export type MediumSyncIntervalHours = 1 | 3 | 6 | 12 | 24;

export const MEDIUM_SYNC_INTERVAL_OPTIONS: MediumSyncIntervalHours[] = [
  1, 3, 6, 12, 24,
];

/** Real limit enforced by Medium RSS tag feeds (no fake pagination). */
export const MEDIUM_RSS_REAL_FEED_LIMIT = 10;

export interface MediumSyncSummary {
  syncedAt: string;
  lastSuccessfulSyncAt: string | null;
  totalSources: number;
  succeededSources: number;
  failedSources: number;
  newArticlesAdded: number;
  duplicatesMerged: number;
  duplicatesSkipped: number;
  totalStoredArticles: number;
  reports: MediumSourceSyncReport[];
  partialFailure: boolean;
  isInitialImport?: boolean;
  message: string;
}

export interface MediumSyncConfig {
  configVersion?: number;
  /** Enables or pauses automatic scheduled sync while the Workspace app is open. */
  autoSyncEnabled: boolean;
  /** Configurable auto-sync interval in hours (1, 3, 6, 12, 24; default 3h). */
  autoSyncIntervalHours: MediumSyncIntervalHours;
  /** Real RSS feed limit (10 latest articles per tag; no fake pagination). */
  maxArticlesPerFeed: number;
  /** Request timeout per RSS feed in milliseconds (default 20,000ms). */
  requestTimeoutMs: number;
}

/**
 * Contract for a future server-side/cron scheduler when real-time background sync
 * is needed even while all browser tabs are closed.
 */
export interface MediumBackgroundSyncScheduler {
  readonly mode: 'browser-open' | 'backend-scheduler';
  getNextRunAt(
    summary: MediumSyncSummary | null,
    config: MediumSyncConfig
  ): string | null;
  triggerScheduledSync(): Promise<void>;
}

/**
 * Storage abstraction layer so client persistence (localStorage)
 * can be swapped for a backend API / database adapter without changing UI code.
 */
export interface MediumStorageAdapter {
  loadArticles(): Promise<MediumArticle[]> | MediumArticle[];
  saveArticles(articles: MediumArticle[]): Promise<void> | void;
  loadSources(): Promise<MediumSource[]> | MediumSource[];
  saveSources(sources: MediumSource[]): Promise<void> | void;
  loadLastSyncSummary(): Promise<MediumSyncSummary | null> | MediumSyncSummary | null;
  saveLastSyncSummary(summary: MediumSyncSummary): Promise<void> | void;
  loadSyncConfig(): Promise<MediumSyncConfig> | MediumSyncConfig;
  saveSyncConfig(config: MediumSyncConfig): Promise<void> | void;
}
