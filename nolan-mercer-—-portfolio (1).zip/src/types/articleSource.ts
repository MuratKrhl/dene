export type FeedSourceType = 'rss' | 'atom' | 'json-feed' | 'unsupported';

export type ArticleSourceStatus =
  | 'idle'
  | 'syncing'
  | 'success'
  | 'error'
  | 'unsupported';

export type ArticleSourceGroup =
  | 'Medium'
  | 'Red Hat'
  | 'Kubernetes'
  | 'AWS'
  | 'Cloudflare'
  | 'GitHub'
  | 'Security'
  | 'AI'
  | 'Java';

export type ArticleContentType = 'article' | 'security-advisory';

export interface ArticleSource {
  id: string;
  name: string;
  description: string;
  websiteUrl: string;
  feedUrl: string;
  sourceType: FeedSourceType;
  /** High-level source filter group shown in the Knowledge Hub Blog sidebar */
  sourceGroup: ArticleSourceGroup;
  /** Primary editorial category */
  category: string;
  /** Topic tags associated with this source */
  tags: string[];
  /** Default content classification (CISA uses 'security-advisory') */
  defaultContentType: ArticleContentType;
  enabled: boolean;
  /** Fetch interval in minutes (default 180 = 3 hours) */
  fetchInterval: number;
  /** Upper cap per sync to keep local metadata store responsive */
  maxArticlesPerFetch: number;
  lastFetchedAt: string | null;
  lastSuccessfulFetchAt: string | null;
  status: ArticleSourceStatus;
  errorMessage: string | null;
  lastArticleCount?: number;
}

export interface ArticleSourceSyncReport {
  sourceId: string;
  sourceName: string;
  sourceGroup: ArticleSourceGroup;
  feedUrl: string;
  sourceType: FeedSourceType;
  ok: boolean;
  unsupported?: boolean;
  fetchedCount: number;
  newCount: number;
  duplicatesSkipped: number;
  errorMessage: string | null;
  durationMs: number;
}

export type AggregationSyncIntervalHours = 1 | 3 | 6 | 12 | 24;

export const AGGREGATION_SYNC_INTERVAL_OPTIONS: AggregationSyncIntervalHours[] = [
  1, 3, 6, 12, 24,
];

export interface AggregationSyncSummary {
  syncedAt: string;
  lastSuccessfulSyncAt: string | null;
  totalSources: number;
  enabledSources: number;
  succeededSources: number;
  failedSources: number;
  unsupportedSources: number;
  newArticlesAdded: number;
  duplicatesSkipped: number;
  totalStoredArticles: number;
  reports: ArticleSourceSyncReport[];
  partialFailure: boolean;
  isInitialImport?: boolean;
  message: string;
}

export interface AggregationSyncConfig {
  configVersion: number;
  autoSyncEnabled: boolean;
  autoSyncIntervalHours: AggregationSyncIntervalHours;
  requestTimeoutMs: number;
}
