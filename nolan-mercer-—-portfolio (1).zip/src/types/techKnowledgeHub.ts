export type FeedValidationStatus = 'verified' | 'unverified' | 'error';
export type TechFeedType = 'rss' | 'atom' | 'unverified';
export type AiImportanceLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export interface TechHubCategoryDto {
  id: string;
  slug: string;
  name: string;
  sortOrder: number;
  activeArticleCount: number;
  archivedArticleCount: number;
  sourceCount: number;
}

export interface TechHubSourceDto {
  id: string;
  name: string;
  siteUrl: string;
  feedUrl: string;
  feedType: TechFeedType;
  validationStatus: FeedValidationStatus;
  validationNote: string | null;
  enabled: boolean;
  keywordFilter: string[] | null;
  etag: string | null;
  lastModified: string | null;
  lastScanAt: string | null;
  lastSuccessAt: string | null;
  lastError: string | null;
  lastHttpStatus: number | null;
  totalFetched: number;
  createdAt: string;
  updatedAt: string;
  categoryIds: string[];
  categoryNames: string[];
}

export interface TechHubArticleDto {
  id: string;
  guid: string;
  canonicalUrl: string;
  contentHash: string;
  sourceId: string;
  sourceName: string;
  sourceSiteUrl?: string;
  title: string;
  url: string;
  author: string | null;
  description: string;
  imageUrl?: string | null;
  contentPreview?: string[];
  publishedAt: string | null;
  fetchedAt: string;
  isArchived: boolean;
  archivedAt: string | null;
  aiSummaryTr: string | null;
  aiTechnicalConcepts: string[];
  aiKeyPoints: string[];
  aiDomainRelevance: string[];
  aiImportance: AiImportanceLevel | null;
  aiGeneratedAt: string | null;
  aiModel: string | null;
  categoryIds: string[];
  categories: Array<{ id: string; slug: string; name: string }>;
  tags: string[];
  isRead: boolean;
  isFavorite: boolean;
  note: string;
}

export interface SimilarArticleDto {
  id: string;
  title: string;
  sourceName: string;
  url: string;
  publishedAt: string | null;
  score: number;
}

export interface TechHubScanHistoryDto {
  id: string;
  startedAt: string;
  finishedAt: string;
  trigger: 'startup' | 'scheduled' | 'manual' | 'source';
  sourceId: string | null;
  sourceName: string;
  status: 'success' | 'not_modified' | 'partial' | 'error' | 'skipped';
  httpStatus: number | null;
  itemsFound: number;
  newAdded: number;
  duplicatesSkipped: number;
  errorMessage: string | null;
  durationMs: number;
}

export interface TechHubStatusDto {
  isGlobalScanRunning: boolean;
  activeSourceIds: string[];
  scheduler: {
    intervalHours: number;
    autoSyncEnabled: boolean;
    lastGlobalScanAt: string | null;
    lastSuccessfulGlobalScanAt: string | null;
  };
  aiConfig: {
    enabled: boolean;
    autoSummarizeOnScan: boolean;
    maxAutoPerScan: number;
    focusDomains: string[];
  };
  geminiConfigured: boolean;
  totals: {
    categories: number;
    sources: number;
    verifiedActiveSources: number;
    unverifiedSources: number;
    errorSources: number;
    activeArticles: number;
    archivedArticles: number;
    favoriteArticles: number;
    totalArticles: number;
  };
}

export interface TechHubDiscoveryResult {
  siteUrl: string;
  httpStatus: number | null;
  candidates: Array<{
    url: string;
    title: string;
    feedType: 'rss' | 'atom';
    verified: boolean;
    httpStatus: number | null;
    itemCount: number;
  }>;
  sitemapUrl: string | null;
  note: string;
}

export interface TechHubFeedTestResult {
  ok: boolean;
  feedUrl: string;
  httpStatus: number | null;
  feedType: TechFeedType;
  itemCount: number;
  sampleTitles: string[];
  error: string | null;
}
