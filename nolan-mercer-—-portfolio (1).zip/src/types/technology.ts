export type TechSubTab =
  | 'overview'
  | 'podcasts'
  | 'videos'
  | 'events'
  | 'knowledge-hub'
  | 'discover'
  | 'sources'
  | 'security'
  | 'saved'
  | 'settings';

export type TechContentType =
  | 'article'
  | 'video'
  | 'podcast'
  | 'learning'
  | 'security'
  | 'event';

export type TechSourceType =
  | 'rss'
  | 'atom'
  | 'json-feed'
  | 'youtube-api'
  | 'official-api'
  | 'manual'
  | 'unsupported';

export type TechSourceStatus =
  | 'idle'
  | 'syncing'
  | 'success'
  | 'error'
  | 'unsupported';

export type DateStatus = 'valid' | 'unknown';

export interface TechSource {
  id: string;
  name: string;
  description: string;
  websiteUrl: string;
  feedUrl: string;
  channelId?: string;
  sourceType: TechSourceType;
  contentType: Exclude<TechContentType, 'article'>;
  category: string;
  tags: string[];
  enabled: boolean;
  syncInterval: number; // minutes (0 = disabled, 180 = 3h default)
  lastFetchedAt: string | null;
  lastSuccessfulFetchAt: string | null;
  nextFetchAt: string | null;
  status: TechSourceStatus;
  errorMessage: string | null;
  consecutiveFailures: number;
  itemCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface TechVideo {
  id: string;
  videoId: string;
  guid: string;
  title: string;
  description: string;
  channelName: string;
  channelId: string;
  publishedAt: string | null;
  updatedAt: string | null;
  dateStatus: DateStatus;
  thumbnailUrl: string | null;
  videoUrl: string;
  embedUrl?: string;
  duration: string | null;
  durationSeconds: number | null;
  category: string;
  tags: string[];
  sourceId: string;
  matchedSourceIds: string[];
  playlistId?: string | null;
  playlistName?: string | null;
  fetchedAt: string;
  isWatched: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  userNotes?: string;
  isManual?: boolean;
}

export interface PodcastSeries {
  id: string;
  title: string;
  description: string;
  author: string | null;
  publisher: string | null;
  artworkUrl: string | null;
  websiteUrl: string;
  feedUrl: string;
  language: string | null;
  category: string;
  tags: string[];
  sourceId: string;
  lastFetchedAt: string | null;
  status: TechSourceStatus;
  isFollowed: boolean;
  isFavorite: boolean;
  episodeCount: number;
}

export interface PodcastEpisode {
  id: string;
  guid: string;
  seriesId: string;
  seriesTitle: string;
  publisher?: string | null;
  title: string;
  description: string;
  publishedAt: string | null;
  updatedAt: string | null;
  dateStatus: DateStatus;
  duration: string | null;
  durationSeconds: number | null;
  audioUrl: string | null;
  artworkUrl: string | null;
  episodeUrl: string;
  contentType: 'podcast-episode';
  category: string;
  tags: string[];
  sourceId: string;
  matchedSourceIds: string[];
  isPlayed: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  playbackPosition: number; // seconds
  fetchedAt: string;
  userNotes?: string;
}

export type LearningContentKind =
  | 'course'
  | 'tutorial'
  | 'lab'
  | 'learning-path'
  | 'documentation';

export type LearningProgressStatus =
  | 'not-started'
  | 'in-progress'
  | 'completed';

export interface LearningItem {
  id: string;
  guid: string;
  title: string;
  description: string;
  platform: string;
  category: string;
  contentType: LearningContentKind;
  level: string | null;
  duration: string | null;
  url: string;
  sourceId: string;
  matchedSourceIds: string[];
  tags: string[];
  publishedAt: string | null;
  updatedAt: string | null;
  dateStatus: DateStatus;
  learningStatus: LearningProgressStatus;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  fetchedAt: string;
  isManual?: boolean;
  userNotes?: string;
}

export type SecurityRecordKind =
  | 'cve'
  | 'security-advisory'
  | 'vulnerability-news'
  | 'exploit'
  | 'malware'
  | 'security-research';

export type SecuritySeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export interface SecurityRecord {
  id: string;
  guid: string;
  cveId: string | null;
  title: string;
  description: string;
  publishedAt: string | null;
  modifiedAt: string | null;
  dateStatus: DateStatus;
  cvss: number | null;
  severity: SecuritySeverity | null;
  affectedProducts: string[];
  references: string[];
  url: string;
  source: string;
  sourceId: string;
  matchedSourceIds: string[];
  contentType: SecurityRecordKind;
  status: string;
  tags: string[];
  isRead: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  fetchedAt: string;
  userNotes?: string;
}

export type TechEventType = 'conference' | 'webinar' | 'summit' | 'meetup';
export type TechEventStatus = 'upcoming' | 'ongoing' | 'past' | 'unverified' | 'unknown';
export type TechEventAttendanceMode = 'online' | 'physical' | 'hybrid' | 'unknown';

export interface TechEvent {
  id: string;
  guid: string;
  eventName: string;
  organizer: string;
  startDate: string | null;
  startTime?: string | null;
  endDate: string | null;
  timezone?: string | null;
  attendanceMode?: TechEventAttendanceMode;
  publishedAt: string | null;
  dateStatus: DateStatus;
  location: string | null;
  eventType: TechEventType;
  description: string;
  registrationUrl: string;
  sourceUrl: string;
  sourceId: string;
  matchedSourceIds: string[];
  tags: string[];
  status: TechEventStatus;
  verificationStatus?: 'verified' | 'unverified';
  verificationNote?: string | null;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  fetchedAt: string;
  isManual?: boolean;
  userNotes?: string;
}

export interface TechSyncHistoryEntry {
  syncId: string;
  startedAt: string;
  finishedAt: string;
  contentType: TechContentType | 'all';
  sourceId: string;
  sourceName: string;
  status: 'success' | 'partial' | 'error' | 'unsupported';
  newItems: number;
  duplicates: number;
  updatedItems: number;
  errors: number;
  errorMessage: string | null;
  durationMs: number;
}

export type TechSyncIntervalHours = 0 | 1 | 3 | 6 | 12 | 24;

export const TECH_SYNC_INTERVAL_OPTIONS: TechSyncIntervalHours[] = [
  1, 3, 6, 12, 24, 0,
];

export interface TechSettings {
  schemaVersion: number;
  globalAutoSync: boolean;
  defaultSyncIntervalHours: TechSyncIntervalHours;
  activeWindowDays: number;
  requestTimeoutMs: number;
  retryCount: 0 | 1;
  lastGlobalSyncAt: string | null;
  lastSuccessfulSyncAt: string | null;
}

export interface PodcastPlayerState {
  currentEpisodeId: string | null;
  currentSeriesId: string | null;
  volume: number;
  playbackRate: number;
  lastUpdatedAt: string | null;
}

export interface TechnologyBackupPayload {
  exportedAt: string;
  schemaVersion: number;
  sources: TechSource[];
  videos: TechVideo[];
  podcastSeries: PodcastSeries[];
  podcastEpisodes: PodcastEpisode[];
  learningItems: LearningItem[];
  securityRecords: SecurityRecord[];
  events: TechEvent[];
  syncHistory: TechSyncHistoryEntry[];
  settings: TechSettings;
  playerState: PodcastPlayerState;
}
