import { ArticleContentType, ArticleSourceGroup, FeedSourceType } from './articleSource';

export const ARTICLE_RETENTION_DAYS = 30;

export interface RawFeedItem {
  guid: string;
  title: string;
  /** Null when feed does not supply an author; never fabricated */
  author: string | null;
  /** ISO-8601 timestamp, or null when missing/unparseable; never fabricated */
  publishedAt: string | null;
  updatedAt: string | null;
  /** Plain-text sanitized summary from description/summary */
  summary: string;
  /** Plain-text sanitized snippet extracted from content/description */
  contentSnippet: string;
  /** Sanitized multi-paragraph text when feed includes fuller body; empty string if summary-only */
  content: string;
  /** Safe HTTPS image URL extracted from media/enclosure/content, or null */
  imageUrl: string | null;
  articleUrl: string;
  tags: string[];
  paragraphs: string[];
  readingTime: string | null;
}

export interface FeedParseResult {
  feedTitle: string;
  items: RawFeedItem[];
  skippedInvalidCount: number;
}

export interface AggregatedArticle {
  id: string;
  guid: string;
  title: string;
  /** Author if present in feed; null otherwise (never invented) */
  author: string | null;
  /** ISO publication timestamp if valid in feed; null otherwise (never invented) */
  publishedAt: string | null;
  updatedAt: string | null;
  summary: string;
  contentSnippet: string;
  content: string;
  imageUrl: string | null;
  articleUrl: string;
  sourceId: string;
  sourceName: string;
  sourceGroup: ArticleSourceGroup;
  sourceType: FeedSourceType;
  /** All source IDs that matched this deduplicated article */
  matchedSourceIds: string[];
  /** All source names that matched this deduplicated article */
  matchedSourceNames: string[];
  /** All source groups that matched this deduplicated article */
  matchedSourceGroups: ArticleSourceGroup[];
  category: string;
  categories: string[];
  tags: string[];
  contentType: ArticleContentType;
  isRead: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  fetchedAt: string;
  readingTime: string | null;
  paragraphs: string[];
  featured?: boolean;
}
