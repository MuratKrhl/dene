import { useCallback, useEffect, useState } from 'react';
import { AppRoute, Navbar } from './components/Navbar';
import { HomePage } from './pages/HomePage';
import { WorkPage } from './pages/WorkPage';
import { ProjectDetailPage } from './pages/ProjectDetailPage';
import { AboutPage } from './pages/AboutPage';
import { JournalPage } from './pages/JournalPage';
import { ArticleDetailPage } from './pages/ArticleDetailPage';
import { ToolsPage } from './pages/ToolsPage';
import { KnowledgeHubPage, KnowledgeHubTabKey } from './pages/KnowledgeHubPage';
import { ContactPage } from './pages/ContactPage';
import { AdminPage, AdminTabKey } from './pages/AdminPage';
import { LoginPage } from './pages/LoginPage';
import { DocumentViewerPage } from './nfs/components/DocumentViewerPage';
import { EnvironmentDetailPage } from './pages/EnvironmentDetailPage';
import { GitHubRepoDetailPage } from './github/components/GitHubRepoDetailPage';
import { OneNoteDetailPage } from './pages/OneNoteDetailPage';
import { GitHubExplorerSubTab } from './github/types';
import { TechSubTab } from './types/technology';
import { ENVIRONMENT_TABS, EnvironmentTabKey } from './data/environmentData';
import { PM_TABS, ProjectManagementTabKey } from './data/projectManagementData';
import { PodcastPlayerProvider } from './context/PodcastPlayerContext';
import { PodcastMiniPlayer } from './components/technology/PodcastMiniPlayer';

const AUTH_STORAGE_KEY = 'mk-workspace-auth-v1';

const VALID_ENV_TABS = new Set<string>(ENVIRONMENT_TABS.map((t) => t.key));
const VALID_PM_TABS = new Set<string>(PM_TABS.map((t) => t.key));
const VALID_GITHUB_SUBTABS = new Set<string>([
  'discover',
  'recently-added',
  'trending',
  'saved',
  'categories',
  'settings',
  'sync-history',
]);
const VALID_TECH_SUBTABS = new Set<string>([
  'overview',
  'podcasts',
  'videos',
  'events',
  'knowledge-hub',
  'discover',
  'sources',
  'security',
  'saved',
  'settings',
]);

const LEGACY_DISCOVER_PRESETS = new Set<string>([
  'articles',
  'learning',
]);

function parseRoute(pathname: string): AppRoute {
  const clean = pathname.replace(/\/+$/, '') || '/';

  if (clean === '/') return { page: 'home' };

  const viewerPrefix = '/quick-access/nfs/viewer/';
  if (clean.startsWith(viewerPrefix)) {
    const rest = clean.slice(viewerPrefix.length);
    const parts = rest.split('/').filter(Boolean);
    if (parts.length >= 2) {
      return {
        page: 'nfs-viewer',
        sourceId: decodeURIComponent(parts[0]),
        fileId: decodeURIComponent(parts.slice(1).join('/')),
      };
    }
  }

  const sourcePrefix = '/quick-access/nfs/source/';
  if (clean.startsWith(sourcePrefix)) {
    const sourceId = decodeURIComponent(clean.slice(sourcePrefix.length));
    if (sourceId) {
      return { page: 'quick-access', tab: 'nfs', nfsSourceId: sourceId };
    }
  }

  if (clean === '/quick-access/nfs' || clean === '/nfs') {
    return { page: 'quick-access', tab: 'nfs' };
  }
  if (clean === '/quick-access' || clean === '/work') {
    return { page: 'quick-access', tab: 'bookmarks' };
  }
  if (clean.startsWith('/work/')) {
    return { page: 'project', slug: clean.slice('/work/'.length) };
  }
  if (clean === '/environment' || clean === '/about') {
    return { page: 'environment', tab: 'sunucu' };
  }
  if (clean.startsWith('/environment/')) {
    const parts = clean
      .slice('/environment/'.length)
      .split('/')
      .filter(Boolean);
    const sub = parts[0] || 'sunucu';
    const tab = VALID_ENV_TABS.has(sub) ? (sub as EnvironmentTabKey) : 'sunucu';
    if (parts.length >= 2) {
      return {
        page: 'environment-detail',
        tab,
        slug: decodeURIComponent(parts.slice(1).join('/')),
      };
    }
    return { page: 'environment', tab };
  }
  if (clean === '/project-management' || clean === '/journal') {
    return { page: 'project-management', tab: 'bulgu-takip' };
  }
  if (clean.startsWith('/project-management/')) {
    const sub = clean.slice('/project-management/'.length).split('/')[0] || 'bulgu-takip';
    const tab = VALID_PM_TABS.has(sub)
      ? (sub as ProjectManagementTabKey)
      : 'bulgu-takip';
    return { page: 'project-management', tab };
  }
  if (clean.startsWith('/journal/')) {
    return { page: 'article', slug: clean.slice('/journal/'.length) };
  }
  if (clean === '/tools') return { page: 'tools' };
  if (clean === '/knowledge-hub' || clean === '/knowledge-hub/onenote') {
    return { page: 'knowledge-hub', tab: 'onenote' };
  }
  if (clean === '/knowledge-hub/onenote/new') {
    return { page: 'onenote-page' };
  }
  if (clean.startsWith('/knowledge-hub/onenote/page/')) {
    const fileId = decodeURIComponent(
      clean.slice('/knowledge-hub/onenote/page/'.length)
    );
    if (fileId) {
      return { page: 'onenote-page', fileId };
    }
  }
  if (clean === '/workspace/blog' || clean === '/knowledge-hub/blog') {
    return {
      page: 'knowledge-hub',
      tab: 'blog',
      hubSection: 'articles',
    };
  }
  if (
    clean === '/workspace/blog/favorites' ||
    clean === '/knowledge-hub/blog/favorites'
  ) {
    return {
      page: 'knowledge-hub',
      tab: 'blog',
      hubSection: 'favorites',
    };
  }
  if (
    clean === '/workspace/blog/archive' ||
    clean === '/knowledge-hub/blog/archive'
  ) {
    return {
      page: 'knowledge-hub',
      tab: 'blog',
      hubSection: 'archive',
    };
  }
  if (
    clean === '/workspace/blog/sources' ||
    clean === '/knowledge-hub/blog/sources'
  ) {
    return {
      page: 'knowledge-hub',
      tab: 'blog',
      hubSection: 'sources',
    };
  }
  if (
    clean === '/workspace/blog/history' ||
    clean === '/knowledge-hub/blog/history'
  ) {
    return {
      page: 'knowledge-hub',
      tab: 'blog',
      hubSection: 'history',
    };
  }
  if (clean.startsWith('/workspace/blog/article/')) {
    const articleId = decodeURIComponent(
      clean.slice('/workspace/blog/article/'.length)
    );
    if (articleId) {
      return {
        page: 'knowledge-hub',
        tab: 'blog',
        hubSection: 'article',
        hubArticleId: articleId,
      };
    }
  }
  if (clean.startsWith('/knowledge-hub/blog/article/')) {
    const articleId = decodeURIComponent(
      clean.slice('/knowledge-hub/blog/article/'.length)
    );
    if (articleId) {
      return {
        page: 'knowledge-hub',
        tab: 'blog',
        hubSection: 'article',
        hubArticleId: articleId,
      };
    }
  }
  if (clean === '/knowledge-hub/technology') {
    return { page: 'knowledge-hub', tab: 'technology', technologySubTab: 'overview' };
  }
  if (clean === '/knowledge-hub/technology/knowledge-hub') {
    return {
      page: 'knowledge-hub',
      tab: 'technology',
      technologySubTab: 'knowledge-hub',
      hubSection: 'articles',
    };
  }
  if (clean.startsWith('/knowledge-hub/technology/knowledge-hub/article/')) {
    const articleId = decodeURIComponent(
      clean.slice('/knowledge-hub/technology/knowledge-hub/article/'.length)
    );
    if (articleId) {
      return {
        page: 'knowledge-hub',
        tab: 'technology',
        technologySubTab: 'knowledge-hub',
        hubSection: 'article',
        hubArticleId: articleId,
      };
    }
  }
  if (clean.startsWith('/knowledge-hub/technology/knowledge-hub/')) {
    const subSection = clean
      .slice('/knowledge-hub/technology/knowledge-hub/'.length)
      .split('/')[0];
    const mappedSection =
      subSection === 'archive' ||
      subSection === 'favorites' ||
      subSection === 'sources' ||
      subSection === 'history'
        ? subSection
        : 'articles';
    return {
      page: 'knowledge-hub',
      tab: 'technology',
      technologySubTab: 'knowledge-hub',
      hubSection: mappedSection,
    };
  }
  if (clean.startsWith('/knowledge-hub/technology/podcasts/')) {
    const seriesId = decodeURIComponent(
      clean.slice('/knowledge-hub/technology/podcasts/'.length)
    );
    return {
      page: 'knowledge-hub',
      tab: 'technology',
      technologySubTab: 'podcasts',
      podcastSeriesId: seriesId || undefined,
    };
  }
  if (clean.startsWith('/knowledge-hub/technology/')) {
    const sub =
      clean.slice('/knowledge-hub/technology/'.length).split('/')[0] || 'overview';
    if (sub === 'sync-history') {
      return {
        page: 'knowledge-hub',
        tab: 'technology',
        technologySubTab: 'sources',
        showTechSyncHistory: true,
      };
    }
    if (LEGACY_DISCOVER_PRESETS.has(sub)) {
      return {
        page: 'knowledge-hub',
        tab: 'technology',
        technologySubTab: 'discover',
        legacyTechPreset: sub,
      };
    }
    const technologySubTab = VALID_TECH_SUBTABS.has(sub)
      ? (sub as TechSubTab)
      : 'overview';
    return { page: 'knowledge-hub', tab: 'technology', technologySubTab };
  }
  if (clean === '/knowledge-hub/user-management') {
    return { page: 'knowledge-hub', tab: 'user-management' };
  }
  if (clean === '/knowledge-hub/github') {
    return { page: 'knowledge-hub', tab: 'github', githubSubTab: 'discover' };
  }
  if (clean.startsWith('/knowledge-hub/github/repositories/')) {
    const rest = clean.slice('/knowledge-hub/github/repositories/'.length);
    const parts = rest.split('/').filter(Boolean);
    if (parts.length >= 2) {
      return {
        page: 'github-repo-detail',
        owner: decodeURIComponent(parts[0]),
        repo: decodeURIComponent(parts[1]),
      };
    }
  }
  if (clean.startsWith('/knowledge-hub/github/')) {
    const sub = clean.slice('/knowledge-hub/github/'.length).split('/')[0] || 'discover';
    const githubSubTab = VALID_GITHUB_SUBTABS.has(sub)
      ? (sub as GitHubExplorerSubTab)
      : 'discover';
    return { page: 'knowledge-hub', tab: 'github', githubSubTab };
  }
  if (clean === '/admin' || clean === '/admin/bookmarks') {
    return { page: 'admin', tab: 'bookmarks' };
  }
  if (clean === '/admin/nfs' || clean === '/admin/network-file-system') {
    return { page: 'admin', tab: 'nfs' };
  }
  if (clean === '/admin/environment' || clean === '/admin/data-imports') {
    return { page: 'admin', tab: 'environment' };
  }
  if (clean === '/admin/project-management' || clean === '/admin/pm') {
    return { page: 'admin', tab: 'project-management' };
  }
  if (clean === '/admin/onenote') {
    return { page: 'admin', tab: 'onenote' };
  }
  if (clean === '/contact') return { page: 'contact' };

  return { page: 'home' };
}

export default function App() {
  const [route, setRoute] = useState<AppRoute>(() =>
    parseRoute(window.location.pathname)
  );
  const [authUser, setAuthUser] = useState<string | null>(() => {
    try {
      const raw = localStorage.getItem(AUTH_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.authenticated && typeof parsed.username === 'string') {
          return parsed.username;
        }
      }
    } catch {
      // Ignore storage access errors
    }
    return null;
  });

  useEffect(() => {
    document.documentElement.classList.remove('dark');
    document.documentElement.removeAttribute('data-theme');
    try {
      localStorage.removeItem('nm-theme');
    } catch {
      // Ignore storage failures
    }
  }, []);

  useEffect(() => {
    const handlePopState = () => {
      setRoute(parseRoute(window.location.pathname));
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleNavigate = useCallback((path: string) => {
    const currentFull = window.location.pathname + window.location.search;
    if (currentFull !== path) {
      window.history.pushState({ fromWorkspaceApp: true }, '', path);
    }
    const pathnameOnly = path.split('?')[0] || '/';
    setRoute(parseRoute(pathnameOnly));
    window.scrollTo(0, 0);
  }, []);

  const handleLoginSuccess = useCallback((username: string) => {
    setAuthUser(username);
    try {
      localStorage.setItem(
        AUTH_STORAGE_KEY,
        JSON.stringify({ authenticated: true, username, loggedInAt: Date.now() })
      );
    } catch {
      // Ignore storage failures
    }
    if (window.location.pathname === '/login') {
      window.history.replaceState({ fromWorkspaceApp: true }, '', '/');
      setRoute({ page: 'home' });
    }
  }, []);

  const handleLogout = useCallback(() => {
    setAuthUser(null);
    try {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    } catch {
      // Ignore storage failures
    }
    window.scrollTo(0, 0);
  }, []);

  if (!authUser || window.location.pathname === '/login') {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  if (route.page === 'nfs-viewer') {
    return (
      <div className="min-h-screen flex flex-col bg-[#FAFAFA] text-[#09090B]">
        <DocumentViewerPage
          sourceId={route.sourceId}
          fileId={route.fileId}
          onNavigate={handleNavigate}
        />
      </div>
    );
  }

  return (
    <PodcastPlayerProvider>
      <div className="min-h-screen flex flex-col bg-[#FAFAFA] text-[#09090B]">
        <Navbar
          currentRoute={route}
          onNavigate={handleNavigate}
          currentUser={authUser}
          onLogout={handleLogout}
        />

        <main key={route.page} className="flex-1 bg-[#FAFAFA] animate-page-enter">
          {route.page === 'home' && <HomePage onNavigate={handleNavigate} />}
          {route.page === 'quick-access' && (
            <WorkPage
              onNavigate={handleNavigate}
              initialTab={route.tab || 'bookmarks'}
              nfsSourceId={route.nfsSourceId}
            />
          )}
          {route.page === 'project' && (
            <ProjectDetailPage slug={route.slug} onNavigate={handleNavigate} />
          )}
          {route.page === 'environment' && (
            <AboutPage
              onNavigate={handleNavigate}
              initialTab={route.tab || 'sunucu'}
            />
          )}
          {route.page === 'environment-detail' && (
            <EnvironmentDetailPage
              tab={route.tab}
              slug={route.slug}
              onNavigate={handleNavigate}
            />
          )}
          {route.page === 'project-management' && (
            <JournalPage
              onNavigate={handleNavigate}
              initialTab={route.tab || 'bulgu-takip'}
            />
          )}
          {route.page === 'article' && (
            <ArticleDetailPage slug={route.slug} onNavigate={handleNavigate} />
          )}
          {route.page === 'tools' && <ToolsPage onNavigate={handleNavigate} />}
          {route.page === 'knowledge-hub' && (
            <KnowledgeHubPage
              onNavigate={handleNavigate}
              initialTab={(route.tab as KnowledgeHubTabKey) || 'onenote'}
              githubSubTab={route.githubSubTab}
              technologySubTab={route.technologySubTab}
              hubSection={route.hubSection}
              hubArticleId={route.hubArticleId}
              podcastSeriesId={route.podcastSeriesId}
              legacyTechPreset={route.legacyTechPreset}
              showTechSyncHistory={route.showTechSyncHistory}
            />
          )}
          {route.page === 'github-repo-detail' && (
            <GitHubRepoDetailPage
              owner={route.owner}
              repoName={route.repo}
              onNavigate={handleNavigate}
            />
          )}
          {route.page === 'onenote-page' && (
            <OneNoteDetailPage
              fileId={route.fileId}
              onNavigate={handleNavigate}
            />
          )}
          {route.page === 'admin' &&
            (authUser === 'Admin' ? (
              <AdminPage
                onNavigate={handleNavigate}
                initialTab={(route.tab as AdminTabKey) || 'bookmarks'}
              />
            ) : (
              <HomePage onNavigate={handleNavigate} />
            ))}
          {route.page === 'contact' && <ContactPage />}
        </main>

        <PodcastMiniPlayer />
      </div>
    </PodcastPlayerProvider>
  );
}
