import {
  ConnectionStatus,
  NfsNode,
  NfsSource,
  ProviderCapabilities,
  SourceType,
} from '../types';

export interface ConnectionTestResult {
  ok: boolean;
  status: ConnectionStatus;
  message: string;
  latencyMs?: number;
  protocolDetail: string;
}

export interface StorageProviderAdapter {
  readonly type: SourceType;
  readonly label: string;
  getCapabilities(source: NfsSource): ProviderCapabilities;
  connect(source: NfsSource): Promise<ConnectionTestResult>;
  testConnection(source: NfsSource, mountedFileCount?: number): ConnectionTestResult;
  listFolders(nodes: NfsNode[], sourceId: string, parentId: string | null): NfsNode[];
  listFiles(nodes: NfsNode[], sourceId: string, parentId: string | null): NfsNode[];
  searchFiles(nodes: NfsNode[], sourceId: string, query: string): NfsNode[];
  getMetadata(node: NfsNode): {
    owner: string;
    group: string;
    permissions: string;
    path: string;
  };
  getPermissions(node: NfsNode, source: NfsSource): string;
  refresh(source: NfsSource): ConnectionTestResult;
}

class WindowsShareAdapter implements StorageProviderAdapter {
  readonly type: SourceType = 'windows_share';
  readonly label = 'Windows SMB / Mapped Drive';

  getCapabilities(source: NfsSource): ProviderCapabilities {
    return {
      canBrowse: source.enabled,
      canRead: source.enabled,
      canDownload: source.enabled,
      supportsPermissions: true,
      supportsShared: true,
      supportsExternalOpen: false,
      supportsWrite: false,
    };
  }

  async connect(source: NfsSource): Promise<ConnectionTestResult> {
    return this.testConnection(source);
  }

  testConnection(source: NfsSource): ConnectionTestResult {
    const clean = source.path.trim();
    if (!clean) {
      return {
        ok: false,
        status: 'Error',
        message: 'Windows share UNC or drive path is required.',
        protocolDetail: 'SMB 3.1.1',
      };
    }

    if (source.type === 'mapped_drive') {
      const valid = /^[A-Za-z]:\\/.test(clean);
      return valid
        ? {
            ok: false,
            status: 'Demo Mode',
            message:
              'Mapped drive path syntax is valid. Direct drive-letter access requires a Windows companion bridge; serving local demo metadata and sample payloads.',
            protocolDetail: 'Windows Mapped Drive',
          }
        : {
            ok: false,
            status: 'Error',
            message: 'Invalid drive path. Expected format such as Z:\\Operations\\Documents.',
            protocolDetail: 'Windows Mapped Drive',
          };
    }

    const validUnc = /^\\\\[^\\]+\\[^\\]+/.test(clean);
    return validUnc
      ? {
          ok: false,
          status: 'Demo Mode',
          message:
            'UNC path syntax verified. Browsers cannot connect to SMB shares directly without an authorized backend gateway; running in Demo Mode.',
          protocolDetail: 'SMB 3.1.1 / UNC',
        }
      : {
          ok: false,
          status: 'Error',
          message: 'Invalid UNC syntax. Expected \\\\server\\share\\folder.',
          protocolDetail: 'SMB 3.1.1 / UNC',
        };
  }

  listFolders(nodes: NfsNode[], sourceId: string, parentId: string | null) {
    return nodes.filter(
      (n) => n.sourceId === sourceId && n.kind === 'folder' && n.parentId === parentId
    );
  }

  listFiles(nodes: NfsNode[], sourceId: string, parentId: string | null) {
    return nodes.filter(
      (n) => n.sourceId === sourceId && n.kind === 'file' && n.parentId === parentId
    );
  }

  searchFiles(nodes: NfsNode[], sourceId: string, query: string) {
    const q = query.trim().toLowerCase();
    return nodes.filter(
      (n) =>
        n.sourceId === sourceId &&
        (n.name.toLowerCase().includes(q) || n.path.toLowerCase().includes(q))
    );
  }

  getMetadata(node: NfsNode) {
    return {
      owner: node.owner || node.author || 'CORP\\DomainUsers',
      group: node.group || 'Finance-Ops',
      permissions: node.permissions || 'Read & Execute',
      path: node.path,
    };
  }

  getPermissions(node: NfsNode) {
    return node.permissions || 'CORP\\ReadOnly';
  }

  refresh(source: NfsSource) {
    return this.testConnection(source);
  }
}

class NFSAdapter implements StorageProviderAdapter {
  readonly type: SourceType = 'nfs_share';
  readonly label = 'NFS Network Export';

  getCapabilities(source: NfsSource): ProviderCapabilities {
    return {
      canBrowse: source.enabled,
      canRead: source.enabled,
      canDownload: source.enabled,
      supportsPermissions: true,
      supportsShared: false,
      supportsExternalOpen: false,
      supportsWrite: false,
    };
  }

  async connect(source: NfsSource): Promise<ConnectionTestResult> {
    return this.testConnection(source);
  }

  testConnection(source: NfsSource): ConnectionTestResult {
    const clean = source.path.trim();
    const version = source.nfsVersion || 'v4';
    const validNfs = /^([a-zA-Z0-9._-]+):\/.+/i.test(clean);
    if (!validNfs) {
      return {
        ok: false,
        status: 'Error',
        message: 'Invalid NFS export syntax. Expected host:/export/path (e.g. 10.0.4.12:/exports/workspace).',
        protocolDetail: `NFS${version}`,
      };
    }

    return {
      ok: false,
      status: 'Demo Mode',
      message: `NFS${version} export target validated (${clean}). Web browsers require a server-side NFS RPC proxy for live mounts; running in Demo Mode.`,
      protocolDetail: `NFS${version} (TCP/2049)`,
    };
  }

  listFolders(nodes: NfsNode[], sourceId: string, parentId: string | null) {
    return nodes.filter(
      (n) => n.sourceId === sourceId && n.kind === 'folder' && n.parentId === parentId
    );
  }

  listFiles(nodes: NfsNode[], sourceId: string, parentId: string | null) {
    return nodes.filter(
      (n) => n.sourceId === sourceId && n.kind === 'file' && n.parentId === parentId
    );
  }

  searchFiles(nodes: NfsNode[], sourceId: string, query: string) {
    const q = query.trim().toLowerCase();
    return nodes.filter(
      (n) =>
        n.sourceId === sourceId &&
        (n.name.toLowerCase().includes(q) || n.path.toLowerCase().includes(q))
    );
  }

  getMetadata(node: NfsNode) {
    return {
      owner: node.owner || 'murat',
      group: node.group || 'engineering',
      permissions: node.permissions || (node.kind === 'folder' ? 'drwxr-xr-x' : '-rw-r--r--'),
      path: node.path,
    };
  }

  getPermissions(node: NfsNode) {
    return node.permissions || (node.kind === 'folder' ? 'drwxr-xr-x' : '-rw-r--r--');
  }

  refresh(source: NfsSource) {
    return this.testConnection(source);
  }
}

class SharePointAdapter implements StorageProviderAdapter {
  readonly type: SourceType = 'sharepoint';
  readonly label = 'SharePoint / Microsoft Graph';

  getCapabilities(source: NfsSource): ProviderCapabilities {
    return {
      canBrowse: source.enabled,
      canRead: source.enabled,
      canDownload: source.enabled,
      supportsPermissions: true,
      supportsShared: true,
      supportsExternalOpen: true,
      supportsWrite: false,
    };
  }

  async connect(source: NfsSource): Promise<ConnectionTestResult> {
    return this.testConnection(source);
  }

  testConnection(source: NfsSource): ConnectionTestResult {
    const clean = source.path.trim();
    const valid = /^https:\/\/.+\.sharepoint\.com\/.+/i.test(clean);
    if (!valid) {
      return {
        ok: false,
        status: 'Error',
        message: 'Invalid SharePoint URL. Expected https://<tenant>.sharepoint.com/sites/...',
        protocolDetail: 'Microsoft Graph v1.0',
      };
    }

    return {
      ok: false,
      status: 'Authentication Required',
      message:
        'SharePoint endpoint verified. Delegated Microsoft Entra ID (Files.Read.All / Sites.Read.All) token is required for live Graph API access.',
      protocolDetail: 'Microsoft Graph OAuth2',
    };
  }

  listFolders(nodes: NfsNode[], sourceId: string, parentId: string | null) {
    return nodes.filter(
      (n) => n.sourceId === sourceId && n.kind === 'folder' && n.parentId === parentId
    );
  }

  listFiles(nodes: NfsNode[], sourceId: string, parentId: string | null) {
    return nodes.filter(
      (n) => n.sourceId === sourceId && n.kind === 'file' && n.parentId === parentId
    );
  }

  searchFiles(nodes: NfsNode[], sourceId: string, query: string) {
    const q = query.trim().toLowerCase();
    return nodes.filter(
      (n) =>
        n.sourceId === sourceId &&
        (n.name.toLowerCase().includes(q) || n.path.toLowerCase().includes(q))
    );
  }

  getMetadata(node: NfsNode) {
    return {
      owner: node.owner || node.author || 'Site Owner',
      group: node.group || 'Engineering Members',
      permissions: node.permissions || 'Graph: Read',
      path: node.path,
    };
  }

  getPermissions(node: NfsNode) {
    return node.permissions || 'Site Members (Read)';
  }

  refresh(source: NfsSource) {
    return this.testConnection(source);
  }
}

class LocalFolderAdapter implements StorageProviderAdapter {
  readonly type: SourceType = 'local_folder';
  readonly label = 'Local Workstation Folder';

  getCapabilities(source: NfsSource): ProviderCapabilities {
    const live = source.status === 'Connected';
    return {
      canBrowse: source.enabled && live,
      canRead: source.enabled && live,
      canDownload: source.enabled && live,
      supportsPermissions: false,
      supportsShared: false,
      supportsExternalOpen: false,
      supportsWrite: false,
    };
  }

  async connect(source: NfsSource): Promise<ConnectionTestResult> {
    return this.testConnection(source);
  }

  testConnection(source: NfsSource, mountedFileCount = 0): ConnectionTestResult {
    if (mountedFileCount > 0 || source.status === 'Connected') {
      return {
        ok: true,
        status: 'Connected',
        message: `Local directory handle active (${mountedFileCount || 'mounted'} files readable in browser memory).`,
        latencyMs: 4,
        protocolDetail: 'Browser File System API',
      };
    }

    return {
      ok: false,
      status: 'Disconnected',
      message: 'Select a local folder to authorize browser read access.',
      protocolDetail: 'Browser File System API',
    };
  }

  listFolders(nodes: NfsNode[], sourceId: string, parentId: string | null) {
    return nodes.filter(
      (n) => n.sourceId === sourceId && n.kind === 'folder' && n.parentId === parentId
    );
  }

  listFiles(nodes: NfsNode[], sourceId: string, parentId: string | null) {
    return nodes.filter(
      (n) => n.sourceId === sourceId && n.kind === 'file' && n.parentId === parentId
    );
  }

  searchFiles(nodes: NfsNode[], sourceId: string, query: string) {
    const q = query.trim().toLowerCase();
    return nodes.filter(
      (n) =>
        n.sourceId === sourceId &&
        (n.name.toLowerCase().includes(q) || n.path.toLowerCase().includes(q))
    );
  }

  getMetadata(node: NfsNode) {
    return {
      owner: 'Local User',
      group: 'Workstation',
      permissions: 'Browser Read-Only',
      path: node.path,
    };
  }

  getPermissions() {
    return 'Read-Only (Browser)';
  }

  refresh(source: NfsSource) {
    return this.testConnection(source);
  }
}

const windowsAdapter = new WindowsShareAdapter();
const nfsAdapter = new NFSAdapter();
const sharePointAdapter = new SharePointAdapter();
const localAdapter = new LocalFolderAdapter();

export function getAdapterForSource(source: NfsSource): StorageProviderAdapter {
  switch (source.type) {
    case 'windows_share':
    case 'mapped_drive':
      return windowsAdapter;
    case 'nfs_share':
      return nfsAdapter;
    case 'sharepoint':
      return sharePointAdapter;
    case 'local_folder':
      return localAdapter;
  }
}
