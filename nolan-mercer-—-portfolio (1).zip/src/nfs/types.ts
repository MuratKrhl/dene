export type SourceType =
  | 'windows_share'
  | 'mapped_drive'
  | 'nfs_share'
  | 'sharepoint'
  | 'local_folder';

export type NfsVersion = 'v2' | 'v3' | 'v4';

export type ConnectionStatus =
  | 'Connected'
  | 'Disconnected'
  | 'Authentication Required'
  | 'Error'
  | 'Demo Mode';

export type DocFormat =
  | 'PDF'
  | 'DOCX'
  | 'DOC'
  | 'XLSX'
  | 'XLS'
  | 'PPTX'
  | 'PPT'
  | 'CSV'
  | 'TSV'
  | 'TXT'
  | 'JSON'
  | 'XML'
  | 'YAML'
  | 'MD'
  | 'PNG'
  | 'JPG'
  | 'SVG'
  | 'ZIP'
  | 'OTHER';

export interface ProviderCapabilities {
  canBrowse: boolean;
  canRead: boolean;
  canDownload: boolean;
  supportsPermissions: boolean;
  supportsShared: boolean;
  supportsExternalOpen: boolean;
  supportsWrite: boolean;
}

export interface NfsSource {
  id: string;
  name: string;
  type: SourceType;
  path: string;
  description: string;
  status: ConnectionStatus;
  lastAccessed: string;
  lastSynced: string;
  enabled: boolean;
  isDemo?: boolean;
  nfsVersion?: NfsVersion;
  serverAddress?: string;
  exportPath?: string;
  documentLibrary?: string;
  lastError?: string;
}

export interface NfsNode {
  id: string;
  sourceId: string;
  parentId: string | null;
  name: string;
  kind: 'folder' | 'file';
  extension?: DocFormat;
  sizeBytes: number;
  sizeLabel: string;
  modifiedAt: string;
  modifiedTimestamp: number;
  path: string;
  starred?: boolean;
  shared?: boolean;
  author?: string;
  owner?: string;
  group?: string;
  permissions?: string;
  externalUrl?: string;
  fileObject?: File;
  sampleKey?: string;
}

export type NfsNavSection =
  | 'all'
  | 'recent'
  | 'starred'
  | 'shared'
  | 'windows_shares'
  | 'nfs_shares'
  | 'sharepoint'
  | 'local_files'
  | 'folder';

export type NfsSortField = 'name' | 'modified' | 'size' | 'type';
export type NfsSortOrder = 'asc' | 'desc';
export type NfsViewMode = 'list' | 'grid' | 'gallery';
export type DateFilter = 'all' | '7d' | '30d' | 'year';
export type SizeFilter = 'all' | 'small' | 'medium' | 'large';
export type TypeFilterGroup =
  | 'All'
  | 'PDF'
  | 'Word'
  | 'Excel'
  | 'PowerPoint'
  | 'CSV/TSV'
  | 'Text/Code'
  | 'Images'
  | 'Archives';

export interface RecentFileEntry {
  nodeId: string;
  sourceId: string;
  name: string;
  path: string;
  extension?: DocFormat;
  lastOpenedAt: number;
  lastOpenedLabel: string;
}

export interface NfsActivityEntry {
  id: string;
  timestamp: string;
  action: string;
  target: string;
  status: 'ok' | 'info' | 'warn' | 'error';
}
