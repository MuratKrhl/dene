import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowDownUp,
  Check,
  ChevronDown,
  ChevronRight,
  Clock,
  Command,
  Copy,
  Download,
  ExternalLink,
  Eye,
  Folder,
  FolderOpen,
  FolderUp,
  Globe,
  HardDrive,
  Info,
  LayoutGrid,
  LayoutList,
  List,
  MoreHorizontal,
  Network,
  RefreshCw,
  Search,
  Server,
  Share2,
  SlidersHorizontal,
  Star,
} from 'lucide-react';
import {
  DateFilter,
  DocFormat,
  NfsActivityEntry,
  NfsNavSection,
  NfsNode,
  NfsSortField,
  NfsSortOrder,
  NfsSource,
  NfsViewMode,
  RecentFileEntry,
  SizeFilter,
  TypeFilterGroup,
} from '../types';
import { getAdapterForSource } from '../providers/storageAdapters';
import {
  DEFAULT_EXPLORER_STATE,
  appendActivityLog,
  loadActivityLog,
  loadAllNodes,
  loadExplorerState,
  loadRecentEntries,
  loadSources,
  loadStarredIds,
  saveExplorerState,
  saveSources,
  saveStarredIds,
} from '../services/nfsStore';
import { getMimeType, resolveNodeArrayBuffer } from '../sampleDocuments';
import { FileTypeIcon } from './FileTypeIcon';
import { FileDetailsPanel } from './FileDetailsPanel';
import { CommandPalette } from './CommandPalette';

interface NfsExplorerProps {
  onNavigate: (path: string) => void;
  initialSourceId?: string;
}

const TYPE_GROUPS: TypeFilterGroup[] = [
  'All',
  'PDF',
  'Word',
  'Excel',
  'PowerPoint',
  'CSV/TSV',
  'Text/Code',
  'Images',
  'Archives',
];

function matchesTypeGroup(ext: DocFormat | undefined, group: TypeFilterGroup): boolean {
  if (group === 'All') return true;
  if (!ext) return false;
  switch (group) {
    case 'PDF':
      return ext === 'PDF';
    case 'Word':
      return ext === 'DOCX' || ext === 'DOC';
    case 'Excel':
      return ext === 'XLSX' || ext === 'XLS';
    case 'PowerPoint':
      return ext === 'PPTX' || ext === 'PPT';
    case 'CSV/TSV':
      return ext === 'CSV' || ext === 'TSV';
    case 'Text/Code':
      return ext === 'TXT' || ext === 'JSON' || ext === 'XML' || ext === 'YAML' || ext === 'MD';
    case 'Images':
      return ext === 'PNG' || ext === 'JPG' || ext === 'SVG';
    case 'Archives':
      return ext === 'ZIP';
  }
}

export const NfsExplorer: React.FC<NfsExplorerProps> = ({
  onNavigate,
  initialSourceId,
}) => {
  const initialState = useMemo(() => {
    const saved = loadExplorerState();
    if (initialSourceId) {
      return {
        ...saved,
        navSection: 'folder' as NfsNavSection,
        activeSourceId: initialSourceId,
        activeFolderId:
          saved.activeSourceId === initialSourceId ? saved.activeFolderId : null,
      };
    }
    return saved;
  }, [initialSourceId]);

  const [sources, setSources] = useState<NfsSource[]>(() => loadSources());
  const [nodes, setNodes] = useState<NfsNode[]>(() => loadAllNodes());
  const [recentEntries, setRecentEntries] = useState<RecentFileEntry[]>(() =>
    loadRecentEntries()
  );
  const [activity, setActivity] = useState<NfsActivityEntry[]>(() =>
    loadActivityLog()
  );

  // Navigation & Tree State
  const [navSection, setNavSection] = useState<NfsNavSection>(
    initialState.navSection
  );
  const [activeSourceId, setActiveSourceId] = useState<string | null>(
    initialState.activeSourceId
  );
  const [activeFolderId, setActiveFolderId] = useState<string | null>(
    initialState.activeFolderId
  );
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({
    'src-win-finance': true,
    'src-nfs-workspace': true,
    'src-mapped-z': true,
    'src-sharepoint-eng': true,
  });

  // Toolbar & View State (persisted for Browser Back restoration)
  const [searchQuery, setSearchQuery] = useState(initialState.searchQuery);
  const [searchInFolderOnly, setSearchInFolderOnly] = useState(false);
  const [typeFilter, setTypeFilter] = useState<TypeFilterGroup>(
    initialState.typeFilter
  );
  const [dateFilter, setDateFilter] = useState<DateFilter>(
    initialState.dateFilter
  );
  const [sizeFilter, setSizeFilter] = useState<SizeFilter>(
    initialState.sizeFilter
  );
  const [sortField, setSortField] = useState<NfsSortField>(
    initialState.sortField
  );
  const [sortOrder, setSortOrder] = useState<NfsSortOrder>(
    initialState.sortOrder
  );
  const [viewMode, setViewMode] = useState<NfsViewMode>(initialState.viewMode);

  const [selectedIds, setSelectedIds] = useState<Record<string, boolean>>({});
  const [focusedNodeId, setFocusedNodeId] = useState<string | null>(null);
  const [showDetailsPanel, setShowDetailsPanel] = useState(false);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [copiedPathId, setCopiedPathId] = useState<string | null>(null);
  const [syncNotice, setSyncNotice] = useState('');

  // View Settings & Modals
  const [showViewSettings, setShowViewSettings] = useState(false);
  const [showExtensions, setShowExtensions] = useState(true);
  const [compactRows, setCompactRows] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);

  // Sync state to sessionStorage so Browser Back restores exact Explorer state
  useEffect(() => {
    saveExplorerState({
      navSection,
      activeSourceId,
      activeFolderId,
      searchQuery,
      typeFilter,
      dateFilter,
      sizeFilter,
      sortField,
      sortOrder,
      viewMode,
    });
  }, [
    navSection,
    activeSourceId,
    activeFolderId,
    searchQuery,
    typeFilter,
    dateFilter,
    sizeFilter,
    sortField,
    sortOrder,
    viewMode,
  ]);

  // Ctrl+K / Cmd+K shortcut for Command Palette
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandOpen((open) => !open);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const sourceMap = useMemo(() => {
    const map = new Map<string, NfsSource>();
    sources.forEach((s) => map.set(s.id, s));
    return map;
  }, [sources]);

  const nodeMap = useMemo(() => {
    const map = new Map<string, NfsNode>();
    nodes.forEach((n) => map.set(n.id, n));
    return map;
  }, [nodes]);

  const hasLocalSource = useMemo(
    () => sources.some((s) => s.type === 'local_folder'),
    [sources]
  );

  const supportsAnyShared = useMemo(
    () =>
      sources.some(
        (s) => s.enabled && getAdapterForSource(s).getCapabilities(s).supportsShared
      ),
    [sources]
  );

  const breadcrumbs = useMemo(() => {
    const rootLabels: Record<NfsNavSection, string> = {
      all: 'All Files',
      recent: 'Recent',
      starred: 'Starred',
      shared: 'Shared with Me',
      windows_shares: 'Windows Shares',
      nfs_shares: 'NFS Shares',
      sharepoint: 'SharePoint',
      local_files: 'Local Files',
      folder: 'All Files',
    };

    const trail: Array<{ label: string; onClick: () => void }> = [
      {
        label: rootLabels[navSection],
        onClick: () => {
          setActiveSourceId(null);
          setActiveFolderId(null);
          if (navSection === 'folder') setNavSection('all');
        },
      },
    ];

    if (activeSourceId) {
      const src = sourceMap.get(activeSourceId);
      if (src) {
        trail.push({
          label: src.name,
          onClick: () => {
            setNavSection('folder');
            setActiveFolderId(null);
          },
        });
      }
    }

    if (activeFolderId) {
      const folderChain: NfsNode[] = [];
      let cursor: NfsNode | undefined = nodeMap.get(activeFolderId);
      while (cursor) {
        folderChain.unshift(cursor);
        cursor = cursor.parentId ? nodeMap.get(cursor.parentId) : undefined;
      }
      folderChain.forEach((fld) => {
        trail.push({
          label: fld.name,
          onClick: () => {
            setNavSection('folder');
            setActiveSourceId(fld.sourceId);
            setActiveFolderId(fld.id);
          },
        });
      });
    }

    return trail;
  }, [navSection, activeSourceId, activeFolderId, sourceMap, nodeMap]);

  const visibleNodes = useMemo(() => {
    const enabledSourceIds = new Set(
      sources.filter((s) => s.enabled).map((s) => s.id)
    );
    const q = searchQuery.trim().toLowerCase();
    let filtered = nodes.filter((n) => enabledSourceIds.has(n.sourceId));

    if (navSection === 'folder' && activeSourceId) {
      const folderScoped = filtered.filter(
        (n) =>
          n.sourceId === activeSourceId &&
          (activeFolderId ? n.parentId === activeFolderId : n.parentId === null)
      );
      if (q && searchInFolderOnly) {
        filtered = folderScoped.filter((n) =>
          n.name.toLowerCase().includes(q)
        );
      } else if (!q) {
        filtered = folderScoped;
      }
    } else if (navSection === 'recent') {
      const recentOrder = new Map(
        recentEntries.map((r, idx) => [r.nodeId, idx])
      );
      filtered = filtered
        .filter((n) => n.kind === 'file' && recentOrder.has(n.id))
        .sort(
          (a, b) =>
            (recentOrder.get(a.id) ?? 999) - (recentOrder.get(b.id) ?? 999)
        );
    } else if (navSection === 'starred') {
      filtered = filtered.filter((n) => n.starred);
    } else if (navSection === 'shared') {
      filtered = filtered.filter((n) => {
        const src = sourceMap.get(n.sourceId);
        return (
          Boolean(n.shared) &&
          Boolean(src && getAdapterForSource(src).getCapabilities(src).supportsShared)
        );
      });
    } else if (navSection === 'windows_shares') {
      filtered = filtered.filter((n) => {
        const t = sourceMap.get(n.sourceId)?.type;
        return t === 'windows_share' || t === 'mapped_drive';
      });
    } else if (navSection === 'nfs_shares') {
      filtered = filtered.filter(
        (n) => sourceMap.get(n.sourceId)?.type === 'nfs_share'
      );
    } else if (navSection === 'sharepoint') {
      filtered = filtered.filter(
        (n) => sourceMap.get(n.sourceId)?.type === 'sharepoint'
      );
    } else if (navSection === 'local_files') {
      filtered = filtered.filter(
        (n) => sourceMap.get(n.sourceId)?.type === 'local_folder'
      );
    }

    if (q && !(navSection === 'folder' && searchInFolderOnly)) {
      filtered = filtered.filter((n) => {
        const srcName = sourceMap.get(n.sourceId)?.name.toLowerCase() || '';
        return (
          n.name.toLowerCase().includes(q) ||
          (n.extension || '').toLowerCase().includes(q) ||
          n.path.toLowerCase().includes(q) ||
          srcName.includes(q)
        );
      });
    }

    if (typeFilter !== 'All') {
      filtered = filtered.filter(
        (n) => n.kind === 'file' && matchesTypeGroup(n.extension, typeFilter)
      );
    }

    if (dateFilter !== 'all') {
      const refNow = 1794865000000;
      const dayMs = 86400000;
      const cutoff =
        dateFilter === '7d'
          ? refNow - 7 * dayMs
          : dateFilter === '30d'
            ? refNow - 30 * dayMs
            : refNow - 365 * dayMs;
      filtered = filtered.filter((n) => n.modifiedTimestamp >= cutoff);
    }

    if (sizeFilter !== 'all') {
      filtered = filtered.filter((n) => {
        if (n.kind === 'folder') return false;
        if (sizeFilter === 'small') return n.sizeBytes < 100 * 1024;
        if (sizeFilter === 'medium')
          return n.sizeBytes >= 100 * 1024 && n.sizeBytes <= 1024 * 1024;
        return n.sizeBytes > 1024 * 1024;
      });
    }

    if (navSection === 'recent' && !q) {
      return filtered;
    }

    return [...filtered].sort((a, b) => {
      if (a.kind !== b.kind) {
        return a.kind === 'folder' ? -1 : 1;
      }
      let cmp = 0;
      if (sortField === 'name') {
        cmp = a.name.localeCompare(b.name);
      } else if (sortField === 'modified') {
        cmp = a.modifiedTimestamp - b.modifiedTimestamp;
      } else if (sortField === 'size') {
        cmp = a.sizeBytes - b.sizeBytes;
      } else {
        cmp = (a.extension || 'Folder').localeCompare(b.extension || 'Folder');
      }
      return sortOrder === 'asc' ? cmp : -cmp;
    });
  }, [
    nodes,
    sources,
    searchQuery,
    searchInFolderOnly,
    navSection,
    activeSourceId,
    activeFolderId,
    typeFilter,
    dateFilter,
    sizeFilter,
    sortField,
    sortOrder,
    sourceMap,
    recentEntries,
  ]);

  const selectedCount = Object.values(selectedIds).filter(Boolean).length;
  const recentMap = useMemo(
    () => new Map(recentEntries.map((r) => [r.nodeId, r])),
    [recentEntries]
  );

  const handleOpenNode = (node: NfsNode) => {
    setOpenMenuId(null);
    if (node.kind === 'folder') {
      setNavSection('folder');
      setActiveSourceId(node.sourceId);
      setActiveFolderId(node.id);
      setExpandedIds((prev) => ({
        ...prev,
        [node.sourceId]: true,
        [node.id]: true,
      }));
      return;
    }

    // CRITICAL: Navigate to dedicated full-page Document Viewer route!
    onNavigate(
      `/quick-access/nfs/viewer/${encodeURIComponent(node.sourceId)}/${encodeURIComponent(node.id)}`
    );
  };

  const handleToggleStar = (id: string) => {
    const starred = loadStarredIds();
    const target = nodeMap.get(id);
    if (starred.has(id)) {
      starred.delete(id);
      setActivity(appendActivityLog('Unstarred', target?.name || id, 'info'));
    } else {
      starred.add(id);
      setActivity(appendActivityLog('Starred', target?.name || id, 'ok'));
    }
    saveStarredIds(starred);
    setNodes(loadAllNodes());
  };

  const handleDownloadNode = async (node: NfsNode) => {
    if (node.kind !== 'file') return;
    const buffer = await resolveNodeArrayBuffer(node);
    const blob = new Blob([buffer], { type: getMimeType(node.extension) });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = node.name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    setActivity(appendActivityLog('Downloaded', node.name, 'ok'));
  };

  const handleCopyPath = async (node: NfsNode) => {
    try {
      await navigator.clipboard.writeText(node.path);
      setCopiedPathId(node.id);
      window.setTimeout(() => setCopiedPathId(null), 1600);
    } catch {
      setCopiedPathId(null);
    }
  };

  const handleBulkStar = () => {
    const starred = loadStarredIds();
    Object.entries(selectedIds).forEach(([id, checked]) => {
      if (checked) starred.add(id);
    });
    saveStarredIds(starred);
    setNodes(loadAllNodes());
    setSelectedIds({});
  };

  const handleBulkDownload = async () => {
    const targets = visibleNodes.filter(
      (n) => selectedIds[n.id] && n.kind === 'file'
    );
    for (const file of targets) {
      await handleDownloadNode(file);
    }
    setSelectedIds({});
  };

  const handleRefreshAll = () => {
    const stamp = new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
    const updated = sources.map((s) => {
      const res = getAdapterForSource(s).refresh(s);
      return { ...s, status: res.status, lastSynced: `Today · ${stamp}` };
    });
    setSources(updated);
    saveSources(updated);
    setNodes(loadAllNodes());
    setRecentEntries(loadRecentEntries());
    setActivity(appendActivityLog('Refreshed Sources', `${updated.length} sources checked`, 'info'));
    setSyncNotice(`Sources refreshed at ${stamp}`);
    window.setTimeout(() => setSyncNotice(''), 2500);
  };

  const handleToggleSort = (field: NfsSortField) => {
    if (sortField === field) {
      setSortOrder((o) => (o === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const displayFileName = (node: NfsNode) => {
    if (showExtensions || node.kind === 'folder') return node.name;
    return node.name.replace(/\.[^/.]+$/, '');
  };

  const hasConnectedLocal = sources.some(
    (s) => s.type === 'local_folder' && s.status === 'Connected'
  );

  const renderFolderTree = (
    sourceId: string,
    parentId: string | null,
    depth = 0
  ) => {
    const childFolders = nodes.filter(
      (n) =>
        n.sourceId === sourceId && n.kind === 'folder' && n.parentId === parentId
    );
    if (childFolders.length === 0) return null;

    return (
      <div className="space-y-0.5">
        {childFolders.map((folder) => {
          const isOpen = expandedIds[folder.id];
          const isActive =
            navSection === 'folder' && activeFolderId === folder.id;
          const hasSubFolders = nodes.some(
            (n) => n.kind === 'folder' && n.parentId === folder.id
          );

          return (
            <div key={folder.id}>
              <div
                className="flex items-center"
                style={{ paddingLeft: `${depth * 12 + 16}px` }}
              >
                {hasSubFolders ? (
                  <button
                    type="button"
                    onClick={() =>
                      setExpandedIds((p) => ({
                        ...p,
                        [folder.id]: !p[folder.id],
                      }))
                    }
                    aria-label={`Toggle ${folder.name}`}
                    className="p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
                  >
                    {isOpen ? (
                      <ChevronDown className="w-3 h-3" />
                    ) : (
                      <ChevronRight className="w-3 h-3" />
                    )}
                  </button>
                ) : (
                  <span className="w-5 shrink-0" />
                )}

                <button
                  type="button"
                  onClick={() => {
                    setNavSection('folder');
                    setActiveSourceId(sourceId);
                    setActiveFolderId(folder.id);
                  }}
                  className={`flex-1 px-2 py-1.5 rounded-lg text-xs flex items-center gap-2 transition-colors cursor-pointer truncate ${
                    isActive
                      ? 'bg-[#2563EB]/10 dark:bg-blue-500/15 text-[#2563EB] dark:text-blue-400 font-medium'
                      : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-900 hover:text-[#09090B] dark:hover:text-zinc-200'
                  }`}
                >
                  {isActive ? (
                    <FolderOpen className="w-3.5 h-3.5 shrink-0" />
                  ) : (
                    <Folder className="w-3.5 h-3.5 shrink-0" />
                  )}
                  <span className="truncate">{folder.name}</span>
                </button>
              </div>
              {isOpen && renderFolderTree(sourceId, folder.id, depth + 1)}
            </div>
          );
        })}
      </div>
    );
  };

  const navItems: Array<{
    id: NfsNavSection;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    visible?: boolean;
  }> = [
    { id: 'all', label: 'All Files', icon: Folder, visible: true },
    { id: 'recent', label: 'Recent', icon: Clock, visible: true },
    { id: 'starred', label: 'Starred', icon: Star, visible: true },
    {
      id: 'shared',
      label: 'Shared with Me',
      icon: Share2,
      visible: supportsAnyShared,
    },
    { id: 'windows_shares', label: 'Windows Shares', icon: Server, visible: true },
    { id: 'nfs_shares', label: 'NFS Shares', icon: Network, visible: true },
    { id: 'sharepoint', label: 'SharePoint', icon: Globe, visible: true },
    {
      id: 'local_files',
      label: 'Local Files',
      icon: FolderUp,
      visible: hasLocalSource,
    },
  ];

  const focusedNode = focusedNodeId ? nodeMap.get(focusedNodeId) || null : null;

  return (
    <div className="space-y-4">
      {/* Page Header */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2.5">
            <h2 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
              NFS Explorer
            </h2>
            <span className="text-xs font-mono text-zinc-500 dark:text-zinc-400 tabular-nums">
              · {hasConnectedLocal ? 'Local Folder Connected' : 'Demo Mode'} ·{' '}
              {sources.filter((s) => s.enabled).length} Active Sources
            </span>
          </div>
          <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400">
            Unified enterprise file explorer across Windows SMB, NFS exports, SharePoint, and local mounts. Click any document to open in the full-page Document Center.
          </p>
          {syncNotice && (
            <p className="text-xs font-mono text-[#2563EB] dark:text-blue-400">
              {syncNotice}
            </p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0 relative">
          <button
            type="button"
            onClick={() => setCommandOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Command className="w-3.5 h-3.5" />
            <span>Quick Jump (Ctrl+K)</span>
          </button>

          <button
            type="button"
            onClick={handleRefreshAll}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-[#09090B] dark:text-[#FAFAFA] hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>

          <button
            type="button"
            onClick={() => setShowDetailsPanel((v) => !v)}
            aria-pressed={showDetailsPanel}
            className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
              showDetailsPanel
                ? 'border-[#2563EB] bg-[#2563EB]/10 text-[#2563EB] dark:text-blue-400'
                : 'border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-[#09090B] dark:text-[#FAFAFA]'
            }`}
          >
            <Info className="w-3.5 h-3.5" />
            <span>Details</span>
          </button>

          <button
            type="button"
            onClick={() => setShowViewSettings((v) => !v)}
            aria-expanded={showViewSettings}
            aria-label="View settings"
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-[#09090B] dark:text-[#FAFAFA] hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>View Settings</span>
          </button>

          {showViewSettings && (
            <div className="absolute right-0 top-11 z-30 w-64 p-4 rounded-xl bg-white dark:bg-[#141418] border border-zinc-200 dark:border-zinc-800 shadow-lg space-y-3 text-xs">
              <div className="font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                Explorer Preferences
              </div>
              <label className="flex items-center justify-between gap-2 cursor-pointer">
                <span className="text-zinc-600 dark:text-zinc-400">
                  Show file extensions
                </span>
                <input
                  type="checkbox"
                  checked={showExtensions}
                  onChange={(e) => setShowExtensions(e.target.checked)}
                />
              </label>
              <label className="flex items-center justify-between gap-2 cursor-pointer">
                <span className="text-zinc-600 dark:text-zinc-400">
                  Compact row density
                </span>
                <input
                  type="checkbox"
                  checked={compactRows}
                  onChange={(e) => setCompactRows(e.target.checked)}
                />
              </label>
              {activeFolderId && (
                <label className="flex items-center justify-between gap-2 cursor-pointer">
                  <span className="text-zinc-600 dark:text-zinc-400">
                    Search current folder only
                  </span>
                  <input
                    type="checkbox"
                    checked={searchInFolderOnly}
                    onChange={(e) => setSearchInFolderOnly(e.target.checked)}
                  />
                </label>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main Layout */}
      <div className="flex flex-col lg:flex-row gap-5 items-start">
        {/* Internal NFS Navigation & Source Trees */}
        <aside className="w-full lg:w-[240px] xl:w-[252px] shrink-0 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-3.5 space-y-5">
          <nav aria-label="NFS Explorer Views" className="space-y-1">
            {navItems
              .filter((i) => i.visible !== false)
              .map((item) => {
                const Icon = item.icon;
                const active = navSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setNavSection(item.id);
                      setActiveSourceId(null);
                      setActiveFolderId(null);
                    }}
                    className={`w-full px-3 py-2 rounded-lg text-xs font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
                      active
                        ? 'bg-zinc-200/70 dark:bg-zinc-800 text-[#09090B] dark:text-[#FAFAFA]'
                        : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-900 hover:text-[#09090B] dark:hover:text-zinc-200'
                    }`}
                  >
                    <Icon
                      className={`w-3.5 h-3.5 shrink-0 ${
                        active ? 'text-[#2563EB] dark:text-blue-400' : ''
                      }`}
                    />
                    <span>{item.label}</span>
                  </button>
                );
              })}
          </nav>

          {/* Registered Sources & Folder Hierarchy */}
          <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 space-y-2">
            <div className="px-2 flex items-center justify-between text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
              <span>Storage Sources</span>
            </div>

            <div className="space-y-1">
              {sources.map((src) => {
                const isExpanded = expandedIds[src.id] ?? true;
                const isSourceSelected =
                  navSection === 'folder' &&
                  activeSourceId === src.id &&
                  activeFolderId === null;

                return (
                  <div key={src.id} className="space-y-0.5">
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedIds((p) => ({
                            ...p,
                            [src.id]: !p[src.id],
                          }))
                        }
                        aria-label={`Expand ${src.name}`}
                        className="p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
                      >
                        {isExpanded ? (
                          <ChevronDown className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setNavSection('folder');
                          setActiveSourceId(src.id);
                          setActiveFolderId(null);
                        }}
                        className={`flex-1 px-2 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between gap-2 transition-colors cursor-pointer truncate ${
                          isSourceSelected
                            ? 'bg-zinc-200/70 dark:bg-zinc-800 text-[#09090B] dark:text-[#FAFAFA]'
                            : 'text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-900'
                        } ${!src.enabled ? 'opacity-50' : ''}`}
                      >
                        <span className="inline-flex items-center gap-2 truncate">
                          {src.type === 'sharepoint' ? (
                            <Globe className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400 shrink-0" />
                          ) : src.type === 'nfs_share' ? (
                            <Network className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400 shrink-0" />
                          ) : src.type === 'mapped_drive' ? (
                            <HardDrive className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                          ) : src.type === 'local_folder' ? (
                            <FolderUp className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          ) : (
                            <Server className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                          )}
                          <span className="truncate">{src.name}</span>
                        </span>
                      </button>
                    </div>

                    {isExpanded && renderFolderTree(src.id, null)}
                  </div>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Main Explorer Pane */}
        <div className="flex-1 min-w-0 w-full space-y-3.5">
          {/* Toolbar */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-3">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              {/* Breadcrumbs */}
              <nav
                aria-label="Folder breadcrumbs"
                className="flex items-center flex-wrap gap-1 text-xs font-medium"
              >
                {breadcrumbs.map((crumb, idx) => (
                  <React.Fragment key={`${crumb.label}-${idx}`}>
                    {idx > 0 && (
                      <ChevronRight
                        className="w-3.5 h-3.5 text-zinc-400"
                        aria-hidden="true"
                      />
                    )}
                    <button
                      type="button"
                      onClick={crumb.onClick}
                      className={`px-2 py-1 rounded-md transition-colors cursor-pointer ${
                        idx === breadcrumbs.length - 1
                          ? 'bg-zinc-100 dark:bg-zinc-800 text-[#09090B] dark:text-[#FAFAFA]'
                          : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-[#FAFAFA]'
                      }`}
                    >
                      {crumb.label}
                    </button>
                  </React.Fragment>
                ))}
              </nav>

              {/* Search + View Switcher (List / Grid / Gallery) */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative w-full sm:w-56">
                  <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={
                      searchInFolderOnly && activeFolderId
                        ? 'Search in current folder...'
                        : 'Search files, ext, folder, source...'
                    }
                    aria-label="Search NFS files and folders"
                    className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
                  />
                </div>

                <div
                  role="group"
                  aria-label="Switch explorer view"
                  className="inline-flex items-center p-0.5 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
                >
                  <button
                    type="button"
                    onClick={() => setViewMode('list')}
                    aria-label="List view"
                    aria-pressed={viewMode === 'list'}
                    className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                      viewMode === 'list'
                        ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                        : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
                    }`}
                  >
                    <List className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode('grid')}
                    aria-label="Grid view"
                    aria-pressed={viewMode === 'grid'}
                    className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                      viewMode === 'grid'
                        ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                        : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
                    }`}
                  >
                    <LayoutGrid className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode('gallery')}
                    aria-label="Gallery view"
                    aria-pressed={viewMode === 'gallery'}
                    className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                      viewMode === 'gallery'
                        ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                        : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
                    }`}
                  >
                    <LayoutList className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* File Type Filters + Date/Size Filters + Sort Controls */}
            <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800 flex flex-col gap-3">
              <div className="flex flex-wrap items-center gap-1">
                {TYPE_GROUPS.map((fmt) => {
                  const active = typeFilter === fmt;
                  return (
                    <button
                      key={fmt}
                      type="button"
                      onClick={() => setTypeFilter(fmt)}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer whitespace-nowrap ${
                        active
                          ? 'bg-[#2563EB] text-white'
                          : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                      }`}
                    >
                      {fmt}
                    </button>
                  );
                })}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    aria-label="Filter by modified date"
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value as DateFilter)}
                    className="px-2.5 py-1 rounded-md bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
                  >
                    <option value="all">Modified: Any time</option>
                    <option value="7d">Last 7 days</option>
                    <option value="30d">Last 30 days</option>
                    <option value="year">This year</option>
                  </select>

                  <select
                    aria-label="Filter by file size"
                    value={sizeFilter}
                    onChange={(e) => setSizeFilter(e.target.value as SizeFilter)}
                    className="px-2.5 py-1 rounded-md bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
                  >
                    <option value="all">Size: Any</option>
                    <option value="small">&lt; 100 KB</option>
                    <option value="medium">100 KB – 1 MB</option>
                    <option value="large">&gt; 1 MB</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-zinc-500 dark:text-zinc-400">Sort:</span>
                  {(['name', 'modified', 'size', 'type'] as NfsSortField[]).map(
                    (field) => {
                      const active = sortField === field;
                      return (
                        <button
                          key={field}
                          type="button"
                          onClick={() => handleToggleSort(field)}
                          className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs capitalize transition-colors cursor-pointer ${
                            active
                              ? 'bg-zinc-100 dark:bg-zinc-800 text-[#09090B] dark:text-[#FAFAFA] font-medium'
                              : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
                          }`}
                        >
                          <span>{field}</span>
                          {active && <ArrowDownUp className="w-3 h-3" />}
                        </button>
                      );
                    }
                  )}
                </div>
              </div>
            </div>

            {/* Multi-Selection Action Bar */}
            {selectedCount > 0 && (
              <div className="p-3 rounded-xl bg-[#2563EB]/8 dark:bg-blue-500/10 border border-[#2563EB]/20 flex flex-wrap items-center justify-between gap-3 text-xs">
                <span className="font-medium text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                  {selectedCount} item{selectedCount > 1 ? 's' : ''} selected
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleBulkStar}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 font-medium cursor-pointer"
                  >
                    <Star className="w-3.5 h-3.5" />
                    <span>Star</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleBulkDownload}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#2563EB] text-white font-medium cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedIds({})}
                    className="px-2.5 py-1.5 text-zinc-600 dark:text-zinc-400 hover:underline cursor-pointer"
                  >
                    Clear
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Empty State */}
          {visibleNodes.length === 0 ? (
            <div className="py-16 text-center rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-3">
              <p className="text-sm font-medium text-[#09090B] dark:text-[#FAFAFA]">
                No matching documents or folders
              </p>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Adjust active filters or reset to inspect all configured sources.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery(DEFAULT_EXPLORER_STATE.searchQuery);
                  setTypeFilter(DEFAULT_EXPLORER_STATE.typeFilter);
                  setDateFilter(DEFAULT_EXPLORER_STATE.dateFilter);
                  setSizeFilter(DEFAULT_EXPLORER_STATE.sizeFilter);
                  setNavSection('all');
                  setActiveSourceId(null);
                  setActiveFolderId(null);
                }}
                className="px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] text-white cursor-pointer"
              >
                Reset Explorer Filters
              </button>
            </div>
          ) : viewMode === 'grid' ? (
            /* GRID VIEW */
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {visibleNodes.map((node) => {
                const isSelected = Boolean(selectedIds[node.id]);
                const src = sourceMap.get(node.sourceId);
                const srcName = src?.name || 'Source';
                const caps = src ? getAdapterForSource(src).getCapabilities(src) : null;

                return (
                  <div
                    key={node.id}
                    onClick={() => setFocusedNodeId(node.id)}
                    className={`group relative p-4 rounded-2xl bg-white dark:bg-[#111114] border transition-colors flex flex-col justify-between gap-4 ${
                      isSelected || focusedNodeId === node.id
                        ? 'border-[#2563EB] dark:border-blue-500'
                        : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3 min-w-0">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          aria-label={`Select ${node.name}`}
                          onClick={(e) => e.stopPropagation()}
                          onChange={(e) =>
                            setSelectedIds((prev) => ({
                              ...prev,
                              [node.id]: e.target.checked,
                            }))
                          }
                          className="rounded border-zinc-300 dark:border-zinc-700 cursor-pointer"
                        />
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenNode(node);
                          }}
                          className="cursor-pointer"
                        >
                          <FileTypeIcon
                            kind={node.kind}
                            extension={node.extension}
                            size="md"
                          />
                        </button>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleStar(node.id);
                          }}
                          aria-label={node.starred ? 'Unstar' : 'Star'}
                          className={`p-1.5 rounded-md cursor-pointer ${
                            node.starred
                              ? 'text-[#2563EB] dark:text-blue-400'
                              : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
                          }`}
                        >
                          <Star
                            className={`w-3.5 h-3.5 ${
                              node.starred ? 'fill-current' : ''
                            }`}
                          />
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setOpenMenuId((cur) => (cur === node.id ? null : node.id));
                          }}
                          aria-label={`Actions for ${node.name}`}
                          className="p-1.5 rounded-md text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
                        >
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenNode(node);
                      }}
                      className="text-left space-y-1 cursor-pointer"
                    >
                      <div className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA] truncate hover:text-[#2563EB] dark:hover:text-blue-400">
                        {displayFileName(node)}
                      </div>
                      <div className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                        {srcName}
                      </div>
                    </button>

                    <div className="pt-2.5 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                      <span>
                        {node.kind === 'folder' ? 'Folder' : node.extension} ·{' '}
                        {node.sizeLabel}
                      </span>
                      <span>{node.modifiedAt}</span>
                    </div>

                    {openMenuId === node.id && (
                      <div className="absolute right-3 top-12 z-20 w-48 py-1.5 rounded-xl bg-white dark:bg-[#18181B] border border-zinc-200 dark:border-zinc-700 shadow-lg text-xs">
                        <button
                          type="button"
                          onClick={() => handleOpenNode(node)}
                          className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{node.kind === 'folder' ? 'Open Folder' : 'Open Document'}</span>
                        </button>
                        {node.kind === 'file' && (
                          <button
                            type="button"
                            onClick={() => {
                              handleDownloadNode(node);
                              setOpenMenuId(null);
                            }}
                            className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>Download</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            handleCopyPath(node);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Path</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setFocusedNodeId(node.id);
                            setShowDetailsPanel(true);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                        >
                          <Info className="w-3.5 h-3.5" />
                          <span>View Details</span>
                        </button>
                        {node.externalUrl && caps?.supportsExternalOpen && (
                          <a
                            href={node.externalUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>Open Externally</span>
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : viewMode === 'gallery' ? (
            /* GALLERY VIEW */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {visibleNodes.map((node) => {
                const src = sourceMap.get(node.sourceId);
                return (
                  <article
                    key={node.id}
                    onClick={() => setFocusedNodeId(node.id)}
                    className={`rounded-2xl bg-white dark:bg-[#111114] border overflow-hidden transition-colors cursor-pointer ${
                      focusedNodeId === node.id
                        ? 'border-[#2563EB]'
                        : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenNode(node);
                      }}
                      className="w-full aspect-[16/9] bg-[#FAFAFA] dark:bg-zinc-900/70 border-b border-zinc-200 dark:border-zinc-800 flex flex-col items-center justify-center gap-3 p-6 cursor-pointer hover:bg-zinc-100/70 dark:hover:bg-zinc-900 transition-colors"
                    >
                      <FileTypeIcon
                        kind={node.kind}
                        extension={node.extension}
                        size="lg"
                      />
                      <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400">
                        {node.kind === 'folder'
                          ? 'Open Folder'
                          : `Open ${node.extension} in Full-Page Viewer`}
                      </span>
                    </button>

                    <div className="p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenNode(node);
                          }}
                          className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA] hover:text-[#2563EB] truncate block text-left cursor-pointer"
                        >
                          {displayFileName(node)}
                        </button>
                        <div className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate tabular-nums">
                          {src?.name} · {node.sizeLabel} · {node.modifiedAt}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleStar(node.id);
                        }}
                        aria-label={node.starred ? 'Unstar' : 'Star'}
                        className={`p-1.5 rounded-md cursor-pointer ${
                          node.starred ? 'text-[#2563EB]' : 'text-zinc-400'
                        }`}
                      >
                        <Star
                          className={`w-4 h-4 ${node.starred ? 'fill-current' : ''}`}
                        />
                      </button>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            /* LIST VIEW (Name, Type, Size, Modified, Owner, Permissions, Source, Actions) */
            <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                    <th className="w-9 pl-3.5 pr-1.5 py-2.5">
                      <input
                        type="checkbox"
                        aria-label="Select all visible items"
                        checked={
                          visibleNodes.length > 0 &&
                          visibleNodes.every((n) => selectedIds[n.id])
                        }
                        onChange={(e) => {
                          const checked = e.target.checked;
                          const next: Record<string, boolean> = {};
                          if (checked) {
                            visibleNodes.forEach((n) => {
                              next[n.id] = true;
                            });
                          }
                          setSelectedIds(next);
                        }}
                        className="rounded border-zinc-300 dark:border-zinc-700 cursor-pointer"
                      />
                    </th>
                    <th className="px-2.5 py-2.5">
                      <button
                        type="button"
                        onClick={() => handleToggleSort('name')}
                        className="inline-flex items-center gap-1 hover:text-[#09090B] dark:hover:text-[#FAFAFA] cursor-pointer"
                      >
                        <span>Name</span>
                        <ArrowDownUp className="w-3 h-3" />
                      </button>
                    </th>
                    <th className="px-2 py-2.5 whitespace-nowrap">Type</th>
                    <th className="px-2 py-2.5 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => handleToggleSort('size')}
                        className="inline-flex items-center gap-1 hover:text-[#09090B] dark:hover:text-[#FAFAFA] cursor-pointer"
                      >
                        <span>Size</span>
                        <ArrowDownUp className="w-3 h-3" />
                      </button>
                    </th>
                    <th className="px-2 py-2.5 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => handleToggleSort('modified')}
                        className="inline-flex items-center gap-1 hover:text-[#09090B] dark:hover:text-[#FAFAFA] cursor-pointer"
                      >
                        <span>Modified</span>
                        <ArrowDownUp className="w-3 h-3" />
                      </button>
                    </th>
                    {!showDetailsPanel && (
                      <th className="px-2 py-2.5 hidden xl:table-cell whitespace-nowrap">
                        Owner
                      </th>
                    )}
                    {!showDetailsPanel && (
                      <th className="px-2 py-2.5 hidden lg:table-cell whitespace-nowrap">
                        Permissions
                      </th>
                    )}
                    <th className="px-2 py-2.5 hidden md:table-cell whitespace-nowrap">
                      Source
                    </th>
                    <th className="pl-2 pr-3.5 py-2.5 text-right whitespace-nowrap">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/80 text-xs">
                  {visibleNodes.map((node) => {
                    const isSelected = Boolean(selectedIds[node.id]);
                    const src = sourceMap.get(node.sourceId);
                    const adapter = src ? getAdapterForSource(src) : null;
                    const caps = src && adapter ? adapter.getCapabilities(src) : null;
                    const recentInfo = recentMap.get(node.id);

                    return (
                      <tr
                        key={node.id}
                        onClick={() => setFocusedNodeId(node.id)}
                        className={`transition-colors ${
                          isSelected || focusedNodeId === node.id
                            ? 'bg-[#2563EB]/6 dark:bg-blue-500/10'
                            : 'hover:bg-zinc-50 dark:hover:bg-zinc-900/40'
                        }`}
                      >
                        <td className="pl-3.5 pr-1.5 py-2.5">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            aria-label={`Select ${node.name}`}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) =>
                              setSelectedIds((prev) => ({
                                ...prev,
                                [node.id]: e.target.checked,
                              }))
                            }
                            className="rounded border-zinc-300 dark:border-zinc-700 cursor-pointer"
                          />
                        </td>

                        <td className={`px-2.5 ${compactRows ? 'py-2' : 'py-2.5'}`}>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenNode(node);
                            }}
                            className="flex items-center gap-2.5 text-left group cursor-pointer max-w-[190px] xl:max-w-[230px]"
                          >
                            <FileTypeIcon
                              kind={node.kind}
                              extension={node.extension}
                              size="sm"
                            />
                            <div className="min-w-0">
                              <div className="font-medium text-[#09090B] dark:text-[#FAFAFA] group-hover:text-[#2563EB] dark:group-hover:text-blue-400 truncate">
                                {displayFileName(node)}
                              </div>
                              {navSection === 'recent' && recentInfo && (
                                <div className="text-[10px] text-zinc-400 tabular-nums">
                                  Opened {recentInfo.lastOpenedLabel}
                                </div>
                              )}
                            </div>
                          </button>
                        </td>

                        <td className="px-2 font-mono text-[11px] text-zinc-600 dark:text-zinc-400 whitespace-nowrap">
                          {node.kind === 'folder' ? 'Folder' : node.extension}
                        </td>

                        <td className="px-2 font-mono text-[11px] text-zinc-600 dark:text-zinc-400 tabular-nums whitespace-nowrap">
                          {node.sizeLabel}
                        </td>

                        <td className="px-2 text-zinc-600 dark:text-zinc-400 tabular-nums whitespace-nowrap">
                          {node.modifiedAt}
                        </td>

                        {!showDetailsPanel && (
                          <td className="px-2 text-zinc-600 dark:text-zinc-400 max-w-[100px] truncate hidden xl:table-cell">
                            {node.owner || node.author || '—'}
                          </td>
                        )}

                        {!showDetailsPanel && (
                          <td className="px-2 font-mono text-[11px] text-zinc-500 dark:text-zinc-400 whitespace-nowrap hidden lg:table-cell">
                            {src && adapter && caps?.supportsPermissions
                              ? adapter.getPermissions(node, src)
                              : '—'}
                          </td>
                        )}

                        <td className="px-2 text-zinc-600 dark:text-zinc-400 max-w-[125px] truncate hidden md:table-cell">
                          {src?.name || 'Source'}
                        </td>

                        <td className="pl-2 pr-3.5 text-right whitespace-nowrap">
                          <div className="inline-flex items-center justify-end gap-0.5">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleToggleStar(node.id);
                              }}
                              aria-label={node.starred ? 'Unstar' : 'Star'}
                              className={`p-1.5 rounded-md cursor-pointer ${
                                node.starred
                                  ? 'text-[#2563EB] dark:text-blue-400'
                                  : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
                              }`}
                            >
                              <Star
                                className={`w-3.5 h-3.5 ${
                                  node.starred ? 'fill-current' : ''
                                }`}
                              />
                            </button>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenNode(node);
                              }}
                              aria-label={
                                node.kind === 'folder'
                                  ? `Open ${node.name}`
                                  : `Open ${node.name} in Document Center`
                              }
                              className="p-1.5 rounded-md text-zinc-500 hover:text-[#2563EB] dark:hover:text-blue-400 cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>

                            {node.kind === 'file' && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDownloadNode(node);
                                }}
                                aria-label={`Download ${node.name}`}
                                className="p-1.5 rounded-md text-zinc-500 hover:text-[#2563EB] dark:hover:text-blue-400 cursor-pointer"
                              >
                                <Download className="w-3.5 h-3.5" />
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleCopyPath(node);
                              }}
                              aria-label={`Copy path for ${node.name}`}
                              className="p-1.5 rounded-md text-zinc-500 hover:text-[#09090B] dark:hover:text-white cursor-pointer"
                            >
                              {copiedPathId === node.id ? (
                                <Check className="w-3.5 h-3.5 text-[#2563EB]" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Optional Details & Activity Panel */}
        {showDetailsPanel && (
          <div className="w-full lg:w-[272px] xl:w-[292px] shrink-0">
            <FileDetailsPanel
              node={focusedNode}
              source={focusedNode ? sourceMap.get(focusedNode.sourceId) : undefined}
              activity={activity}
              onClose={() => setShowDetailsPanel(false)}
              onOpenNode={handleOpenNode}
              onDownloadNode={handleDownloadNode}
              onToggleStar={handleToggleStar}
              onCopyPath={handleCopyPath}
            />
          </div>
        )}
      </div>

      <CommandPalette
        isOpen={commandOpen}
        onClose={() => setCommandOpen(false)}
        sources={sources}
        nodes={nodes}
        onSelectNode={handleOpenNode}
        onSelectSource={(id) => {
          setNavSection('folder');
          setActiveSourceId(id);
          setActiveFolderId(null);
          setExpandedIds((prev) => ({ ...prev, [id]: true }));
        }}
      />
    </div>
  );
};
