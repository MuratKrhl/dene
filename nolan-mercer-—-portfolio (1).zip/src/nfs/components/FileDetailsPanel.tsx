import React from 'react';
import { Copy, Download, ExternalLink, Eye, Star, X } from 'lucide-react';
import { NfsActivityEntry, NfsNode, NfsSource } from '../types';
import { getAdapterForSource } from '../providers/storageAdapters';
import { FileTypeIcon } from './FileTypeIcon';

interface FileDetailsPanelProps {
  node: NfsNode | null;
  source: NfsSource | undefined;
  activity: NfsActivityEntry[];
  onClose: () => void;
  onOpenNode: (node: NfsNode) => void;
  onDownloadNode: (node: NfsNode) => void;
  onToggleStar: (id: string) => void;
  onCopyPath: (node: NfsNode) => void;
}

export const FileDetailsPanel: React.FC<FileDetailsPanelProps> = ({
  node,
  source,
  activity,
  onClose,
  onOpenNode,
  onDownloadNode,
  onToggleStar,
  onCopyPath,
}) => {
  if (!node || !source) {
    return (
      <aside className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-5 space-y-5 text-xs">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
            Inspector &amp; Activity
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close details panel"
            className="p-1 rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-zinc-500 dark:text-zinc-400 leading-relaxed">
          Select a file or folder row to inspect permissions, owner metadata, and
          provider capabilities.
        </p>

        <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 space-y-2.5">
          <div className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
            Recent Explorer Activity
          </div>
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {activity.slice(0, 8).map((item) => (
              <div
                key={item.id}
                className="p-2.5 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200/70 dark:border-zinc-800 space-y-0.5"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium text-[#09090B] dark:text-[#FAFAFA]">
                    {item.action}
                  </span>
                  <span className="font-mono text-[10px] text-zinc-400 tabular-nums">
                    {item.timestamp}
                  </span>
                </div>
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                  {item.target}
                </div>
              </div>
            ))}
          </div>
        </div>
      </aside>
    );
  }

  const adapter = getAdapterForSource(source);
  const caps = adapter.getCapabilities(source);
  const meta = adapter.getMetadata(node);

  return (
    <aside className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-5 space-y-5 text-xs">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-3 min-w-0">
          <FileTypeIcon kind={node.kind} extension={node.extension} size="md" />
          <div className="min-w-0">
            <h3 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA] truncate">
              {node.name}
            </h3>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
              {node.kind === 'folder' ? 'Directory' : node.extension} · {node.sizeLabel}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close details panel"
          className="p-1 rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer shrink-0"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => onOpenNode(node)}
          className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white font-medium cursor-pointer"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>{node.kind === 'folder' ? 'Open Folder' : 'Open Viewer'}</span>
        </button>

        {node.kind === 'file' && caps.canDownload && (
          <button
            type="button"
            onClick={() => onDownloadNode(node)}
            aria-label="Download file"
            className="p-2 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        )}

        <button
          type="button"
          onClick={() => onToggleStar(node.id)}
          aria-label={node.starred ? 'Unstar' : 'Star'}
          className={`p-2 rounded-lg border border-zinc-200 dark:border-zinc-800 cursor-pointer ${
            node.starred ? 'text-[#2563EB] dark:text-blue-400' : ''
          }`}
        >
          <Star className={`w-3.5 h-3.5 ${node.starred ? 'fill-current' : ''}`} />
        </button>

        <button
          type="button"
          onClick={() => onCopyPath(node)}
          aria-label="Copy path"
          className="p-2 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
        >
          <Copy className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Metadata Table */}
      <dl className="space-y-3 pt-4 border-t border-zinc-200 dark:border-zinc-800">
        <div>
          <dt className="text-zinc-500 dark:text-zinc-400">Source &amp; Status</dt>
          <dd className="font-medium text-[#09090B] dark:text-[#FAFAFA] mt-0.5">
            {source.name} · {source.status}
          </dd>
        </div>
        <div>
          <dt className="text-zinc-500 dark:text-zinc-400">Modified</dt>
          <dd className="tabular-nums mt-0.5">{node.modifiedAt}</dd>
        </div>
        <div>
          <dt className="text-zinc-500 dark:text-zinc-400">Owner / Group</dt>
          <dd className="font-mono mt-0.5">
            {meta.owner} : {meta.group}
          </dd>
        </div>
        {caps.supportsPermissions && (
          <div>
            <dt className="text-zinc-500 dark:text-zinc-400">Permissions</dt>
            <dd className="font-mono mt-0.5">{meta.permissions}</dd>
          </div>
        )}
        <div>
          <dt className="text-zinc-500 dark:text-zinc-400">Full Path</dt>
          <dd className="font-mono text-[11px] break-all mt-0.5 text-zinc-600 dark:text-zinc-400">
            {node.path}
          </dd>
        </div>
      </dl>

      {node.externalUrl && caps.supportsExternalOpen && (
        <a
          href={node.externalUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-[#2563EB] transition-colors"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          <span>Open in SharePoint</span>
        </a>
      )}
    </aside>
  );
};
