import React, { useEffect, useRef, useState } from 'react';
import {
  Activity,
  Check,
  FolderUp,
  Globe,
  HardDrive,
  Network,
  Pencil,
  RefreshCw,
  Server,
  Trash2,
  X,
} from 'lucide-react';
import {
  ConnectionStatus,
  NfsActivityEntry,
  NfsNode,
  NfsSource,
  NfsVersion,
  SourceType,
} from '../types';
import { getAdapterForSource } from '../providers/storageAdapters';
import { detectDocFormat } from '../services/nfsStore';

interface SourceModalProps {
  isOpen: boolean;
  onClose: () => void;
  sources: NfsSource[];
  activity: NfsActivityEntry[];
  editingSource: NfsSource | null;
  onSaveSource: (source: NfsSource, localFiles?: NfsNode[]) => void;
  onDeleteSource: (sourceId: string) => void;
  onToggleEnabled: (sourceId: string) => void;
  onRefreshSource: (sourceId: string) => void;
  onBrowseSource: (sourceId: string) => void;
  onLogActivity: (action: string, target: string, status?: NfsActivityEntry['status']) => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export const SourceModal: React.FC<SourceModalProps> = ({
  isOpen,
  onClose,
  sources,
  activity,
  editingSource,
  onSaveSource,
  onDeleteSource,
  onToggleEnabled,
  onRefreshSource,
  onBrowseSource,
  onLogActivity,
}) => {
  const [modalTab, setModalTab] = useState<'sources' | 'diagnostics'>('sources');
  const [activeEdit, setActiveEdit] = useState<NfsSource | null>(editingSource);
  const [name, setName] = useState('');
  const [type, setType] = useState<SourceType>('windows_share');
  const [path, setPath] = useState('');
  const [serverAddress, setServerAddress] = useState('');
  const [exportPath, setExportPath] = useState('/exports/workspace');
  const [nfsVersion, setNfsVersion] = useState<NfsVersion>('v4');
  const [documentLibrary, setDocumentLibrary] = useState('Shared Documents');
  const [description, setDescription] = useState('');
  const [testResult, setTestResult] = useState<{
    status: ConnectionStatus;
    message: string;
    protocolDetail: string;
  } | null>(null);
  const [mountedFiles, setMountedFiles] = useState<File[]>([]);
  const [error, setError] = useState('');
  const folderInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setModalTab('sources');
    setActiveEdit(editingSource);
    setName(editingSource?.name || '');
    setType(editingSource?.type || 'windows_share');
    setPath(editingSource?.path || '');
    setServerAddress(editingSource?.serverAddress || '10.0.4.12');
    setExportPath(editingSource?.exportPath || '/exports/workspace');
    setNfsVersion(editingSource?.nfsVersion || 'v4');
    setDocumentLibrary(editingSource?.documentLibrary || 'Shared Documents');
    setDescription(editingSource?.description || '');
    setTestResult(null);
    setMountedFiles([]);
    setError('');
  }, [editingSource, isOpen]);

  if (!isOpen) return null;

  const handleStartEdit = (src: NfsSource) => {
    setActiveEdit(src);
    setName(src.name);
    setType(src.type);
    setPath(src.path);
    setServerAddress(src.serverAddress || '10.0.4.12');
    setExportPath(src.exportPath || '/exports/workspace');
    setNfsVersion(src.nfsVersion || 'v4');
    setDocumentLibrary(src.documentLibrary || 'Shared Documents');
    setDescription(src.description);
    setTestResult(null);
    setMountedFiles([]);
    setError('');
  };

  const placeholderForType = (t: SourceType) => {
    switch (t) {
      case 'windows_share':
        return '\\\\server\\department\\documents';
      case 'mapped_drive':
        return 'Z:\\Operations\\Documents';
      case 'nfs_share':
        return '10.0.4.12:/exports/workspace';
      case 'sharepoint':
        return 'https://company.sharepoint.com/sites/Engineering/Shared%20Documents';
      case 'local_folder':
        return 'Local Directory (Pick folder below)';
    }
  };

  const resolvedPath =
    type === 'nfs_share'
      ? path.trim() || `${serverAddress.trim()}:${exportPath.trim()}`
      : path.trim();

  const handleLocalFolderPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const files = Array.from(fileList);
    setMountedFiles(files);
    const firstRel = (files[0] as File & { webkitRelativePath?: string })
      .webkitRelativePath;
    const rootFolderName = firstRel ? firstRel.split('/')[0] : 'Local Folder';
    if (!name.trim()) setName(rootFolderName);
    setPath(`local://${rootFolderName}`);
    setError('');
    setTestResult({
      status: 'Connected',
      protocolDetail: 'Browser File System API',
      message: `Local folder ready: ${files.length} files scanned directly from disk.`,
    });
  };

  const handleTestConnection = () => {
    const draft: NfsSource = {
      id: activeEdit?.id || 'draft',
      name: name.trim() || 'Draft Source',
      type,
      path: resolvedPath,
      serverAddress,
      exportPath,
      nfsVersion,
      documentLibrary,
      description,
      status: 'Disconnected',
      lastAccessed: '',
      lastSynced: '',
      enabled: true,
    };
    const adapter = getAdapterForSource(draft);
    const res = adapter.testConnection(draft, mountedFiles.length);
    setTestResult({
      status: res.status,
      message: res.message,
      protocolDetail: res.protocolDetail,
    });
    onLogActivity(
      'Tested Connection',
      `${draft.name} (${res.status})`,
      res.ok ? 'ok' : res.status === 'Error' ? 'error' : 'info'
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter a source name.');
      return;
    }
    if (!resolvedPath && type !== 'local_folder') {
      setError('Please enter a network path, NFS export, or SharePoint URL.');
      return;
    }
    if (type === 'local_folder' && mountedFiles.length === 0 && !activeEdit) {
      setError('Please select a local folder from your computer.');
      return;
    }

    const sourceId = activeEdit?.id || `src-${Date.now()}`;
    const draft: NfsSource = {
      id: sourceId,
      name: name.trim(),
      type,
      path: resolvedPath || `local://${name.trim()}`,
      serverAddress: type === 'nfs_share' ? serverAddress.trim() : undefined,
      exportPath: type === 'nfs_share' ? exportPath.trim() : undefined,
      nfsVersion: type === 'nfs_share' ? nfsVersion : undefined,
      documentLibrary: type === 'sharepoint' ? documentLibrary.trim() : undefined,
      description:
        description.trim() ||
        `${type.replace('_', ' ')} storage source configured in Workspace NFS.`,
      status:
        type === 'local_folder' && mountedFiles.length > 0
          ? 'Connected'
          : activeEdit?.status || 'Disconnected',
      lastAccessed: 'Just now',
      lastSynced: 'Just now',
      enabled: activeEdit ? activeEdit.enabled : true,
      isDemo: type !== 'local_folder',
    };

    const adapter = getAdapterForSource(draft);
    const test = adapter.testConnection(draft, mountedFiles.length);
    draft.status = test.status;

    let localNodes: NfsNode[] | undefined;
    if (type === 'local_folder' && mountedFiles.length > 0) {
      const folderMap = new Map<string, NfsNode>();
      const nodes: NfsNode[] = [];
      const nowLabel = new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: '2-digit',
        year: 'numeric',
      });

      mountedFiles.forEach((file, idx) => {
        const ext = detectDocFormat(file.name);
        const relPath =
          (file as File & { webkitRelativePath?: string }).webkitRelativePath ||
          file.name;
        const parts = relPath.split('/');
        let parentId: string | null = null;
        for (let i = 1; i < parts.length - 1; i++) {
          const folderKey = parts.slice(0, i + 1).join('/');
          if (!folderMap.has(folderKey)) {
            const folderNode: NfsNode = {
              id: `loc-fld-${sourceId}-${folderMap.size}`,
              sourceId,
              parentId,
              name: parts[i],
              kind: 'folder',
              sizeBytes: 0,
              sizeLabel: 'Folder',
              modifiedAt: nowLabel,
              modifiedTimestamp: Date.now(),
              path: folderKey,
              owner: 'Local User',
              permissions: 'Browser Read-Only',
            };
            folderMap.set(folderKey, folderNode);
            nodes.push(folderNode);
          }
          parentId = folderMap.get(folderKey)!.id;
        }

        nodes.push({
          id: `loc-file-${sourceId}-${idx}`,
          sourceId,
          parentId,
          name: file.name,
          kind: 'file',
          extension: ext,
          sizeBytes: file.size,
          sizeLabel: formatBytes(file.size),
          modifiedAt: new Date(file.lastModified).toLocaleDateString('en-US', {
            month: 'short',
            day: '2-digit',
            year: 'numeric',
          }),
          modifiedTimestamp: file.lastModified,
          path: relPath,
          fileObject: file,
          author: 'Local Disk',
          owner: 'Local User',
          permissions: 'Browser Read-Only',
        });
      });

      localNodes = nodes;
    }

    onSaveSource(draft, localNodes);
    onLogActivity(
      activeEdit ? 'Updated Source' : 'Added Source',
      `${draft.name} (${draft.status})`,
      test.ok ? 'ok' : 'info'
    );
    onClose();
  };

  const statusBadgeClass = (status: ConnectionStatus) => {
    switch (status) {
      case 'Connected':
        return 'text-emerald-700 dark:text-emerald-400';
      case 'Authentication Required':
        return 'text-amber-700 dark:text-amber-400';
      case 'Error':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-zinc-600 dark:text-zinc-400';
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Storage Source Management"
      className="fixed inset-0 z-50 bg-zinc-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 shadow-xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 border-b border-zinc-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              {activeEdit
                ? `Edit Source — ${activeEdit.name}`
                : 'Storage Sources & Diagnostics'}
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Configure Windows UNC shares, mapped drives, NFS exports, SharePoint, or local folders.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="inline-flex p-0.5 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs">
              <button
                type="button"
                onClick={() => setModalTab('sources')}
                className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                  modalTab === 'sources'
                    ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400'
                }`}
              >
                Sources
              </button>
              <button
                type="button"
                onClick={() => setModalTab('diagnostics')}
                className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                  modalTab === 'diagnostics'
                    ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400'
                }`}
              >
                Diagnostics &amp; Log
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close source dialog"
              className="p-2 rounded-lg text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-8 max-h-[80vh] overflow-y-auto">
          {modalTab === 'sources' ? (
            <>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {[
                    { id: 'windows_share', label: 'Windows UNC', icon: Server },
                    { id: 'mapped_drive', label: 'Mapped Drive', icon: HardDrive },
                    { id: 'nfs_share', label: 'NFS Share', icon: Network },
                    { id: 'sharepoint', label: 'SharePoint', icon: Globe },
                    { id: 'local_folder', label: 'Local Folder', icon: FolderUp },
                  ].map((opt) => {
                    const Icon = opt.icon;
                    const active = type === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => {
                          setType(opt.id as SourceType);
                          setTestResult(null);
                          setError('');
                        }}
                        className={`p-2.5 rounded-xl border text-left transition-colors cursor-pointer flex items-center gap-2 text-xs font-medium ${
                          active
                            ? 'bg-[#2563EB]/10 dark:bg-blue-500/15 border-[#2563EB] dark:border-blue-500 text-[#2563EB] dark:text-blue-400'
                            : 'bg-[#FAFAFA] dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700'
                        }`}
                      >
                        <Icon className="w-4 h-4 shrink-0" />
                        <span className="truncate">{opt.label}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label
                      htmlFor="src-name"
                      className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                    >
                      Display Name *
                    </label>
                    <input
                      id="src-name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Engineering NFSv4"
                      className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label
                      htmlFor="src-path"
                      className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                    >
                      {type === 'sharepoint'
                        ? 'Site / Folder URL *'
                        : type === 'local_folder'
                          ? 'Selected Local Folder'
                          : type === 'nfs_share'
                            ? 'Export Target (host:/path) *'
                            : 'Network / Drive Path *'}
                    </label>
                    {type === 'local_folder' ? (
                      <div>
                        <input
                          ref={folderInputRef}
                          type="file"
                          // @ts-expect-error webkitdirectory is supported across modern browsers
                          webkitdirectory=""
                          multiple
                          onChange={handleLocalFolderPick}
                          className="hidden"
                        />
                        <button
                          type="button"
                          onClick={() => folderInputRef.current?.click()}
                          className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 bg-[#FAFAFA] dark:bg-zinc-900 text-[#09090B] dark:text-[#FAFAFA] hover:border-[#2563EB] transition-colors cursor-pointer text-left truncate"
                        >
                          {mountedFiles.length > 0
                            ? `${path} (${mountedFiles.length} files)`
                            : 'Choose Local Directory...'}
                        </button>
                      </div>
                    ) : (
                      <input
                        id="src-path"
                        type="text"
                        value={path}
                        onChange={(e) => setPath(e.target.value)}
                        placeholder={placeholderForType(type)}
                        className="w-full px-3 py-2 text-xs font-mono rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                      />
                    )}
                  </div>
                </div>

                {/* NFS-specific options */}
                {type === 'nfs_share' && (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800">
                    <div className="space-y-1">
                      <label htmlFor="nfs-host" className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                        Server Address
                      </label>
                      <input
                        id="nfs-host"
                        type="text"
                        value={serverAddress}
                        onChange={(e) => {
                          setServerAddress(e.target.value);
                          setPath(`${e.target.value}:${exportPath}`);
                        }}
                        className="w-full px-2.5 py-1.5 text-xs font-mono rounded-md bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
                      />
                    </div>
                    <div className="space-y-1">
                      <label htmlFor="nfs-export" className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                        Export Path
                      </label>
                      <input
                        id="nfs-export"
                        type="text"
                        value={exportPath}
                        onChange={(e) => {
                          setExportPath(e.target.value);
                          setPath(`${serverAddress}:${e.target.value}`);
                        }}
                        className="w-full px-2.5 py-1.5 text-xs font-mono rounded-md bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
                      />
                    </div>
                    <div className="space-y-1">
                      <label htmlFor="nfs-ver" className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                        NFS Version
                      </label>
                      <select
                        id="nfs-ver"
                        value={nfsVersion}
                        onChange={(e) => setNfsVersion(e.target.value as NfsVersion)}
                        className="w-full px-2.5 py-1.5 text-xs rounded-md bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
                      >
                        <option value="v4">NFSv4 / v4.1 (Recommended)</option>
                        <option value="v3">NFSv3</option>
                        <option value="v2">NFSv2 (Legacy)</option>
                      </select>
                    </div>
                  </div>
                )}

                {/* SharePoint-specific options */}
                {type === 'sharepoint' && (
                  <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 space-y-2 text-xs">
                    <div className="space-y-1">
                      <label htmlFor="sp-lib" className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                        Document Library Name
                      </label>
                      <input
                        id="sp-lib"
                        type="text"
                        value={documentLibrary}
                        onChange={(e) => setDocumentLibrary(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs rounded-md bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
                      />
                    </div>
                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      Microsoft Graph OAuth tokens are never stored in browser localStorage. Unauthenticated libraries remain in Authentication Required state.
                    </p>
                  </div>
                )}

                <div className="space-y-1.5">
                  <label
                    htmlFor="src-desc"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Description
                  </label>
                  <input
                    id="src-desc"
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Optional description of documents stored in this location"
                    className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                  />
                </div>

                {testResult && (
                  <div className="p-3.5 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className={`font-semibold ${statusBadgeClass(testResult.status)}`}>
                        Status: {testResult.status}
                      </span>
                      <span className="font-mono text-[11px] text-zinc-400">
                        {testResult.protocolDetail}
                      </span>
                    </div>
                    <p className="text-zinc-600 dark:text-zinc-400">{testResult.message}</p>
                  </div>
                )}

                {error && (
                  <p role="alert" className="text-xs font-medium text-red-600 dark:text-red-400">
                    {error}
                  </p>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <button
                    type="button"
                    onClick={handleTestConnection}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] hover:bg-zinc-100 dark:hover:bg-zinc-900 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Test Connection</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {activeEdit && (
                      <button
                        type="button"
                        onClick={() => setActiveEdit(null)}
                        className="px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 cursor-pointer"
                      >
                        New Source
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-4 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-900 transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{activeEdit ? 'Update Source' : 'Register Source'}</span>
                    </button>
                  </div>
                </div>
              </form>

              {/* Registered Sources Inventory */}
              {!activeEdit && (
                <div className="pt-6 border-t border-zinc-200 dark:border-zinc-800 space-y-3">
                  <h3 className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                    Registered Sources ({sources.length})
                  </h3>
                  <div className="divide-y divide-zinc-200 dark:divide-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-800 overflow-hidden">
                    {sources.map((src) => (
                      <div
                        key={src.id}
                        className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#FAFAFA] dark:bg-zinc-900/50"
                      >
                        <div className="min-w-0 space-y-1">
                          <div className="flex flex-wrap items-center gap-2 text-xs">
                            <span className="font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                              {src.name}
                            </span>
                            <span className="text-zinc-400">·</span>
                            <span className={`font-medium ${statusBadgeClass(src.status)}`}>
                              {src.status}
                            </span>
                            {src.nfsVersion && (
                              <>
                                <span className="text-zinc-400">·</span>
                                <span className="font-mono text-[11px] text-zinc-500">
                                  NFS{src.nfsVersion}
                                </span>
                              </>
                            )}
                          </div>
                          <div className="text-[11px] font-mono text-zinc-500 dark:text-zinc-400 truncate">
                            {src.path}
                          </div>
                          <div className="text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                            Last sync: {src.lastSynced}
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => onRefreshSource(src.id)}
                            aria-label={`Refresh ${src.name}`}
                            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300 hover:bg-white dark:hover:bg-zinc-800 cursor-pointer"
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onToggleEnabled(src.id)}
                            className="px-2.5 py-1.5 text-[11px] font-medium rounded-md border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-white dark:hover:bg-zinc-800 cursor-pointer"
                          >
                            {src.enabled ? 'Enabled' : 'Disabled'}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              onBrowseSource(src.id);
                              onClose();
                            }}
                            className="px-2.5 py-1.5 text-[11px] font-medium rounded-md bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-[#2563EB] dark:text-blue-400 hover:border-[#2563EB] cursor-pointer"
                          >
                            Browse
                          </button>
                          <button
                            type="button"
                            onClick={() => handleStartEdit(src)}
                            aria-label={`Edit ${src.name}`}
                            className="p-1.5 rounded-md text-zinc-400 hover:text-[#2563EB] dark:hover:text-blue-400 cursor-pointer"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteSource(src.id)}
                            aria-label={`Remove ${src.name}`}
                            className="p-1.5 rounded-md text-zinc-400 hover:text-red-600 dark:hover:text-red-400 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="space-y-6 text-xs">
              <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-2">
                <div className="flex items-center gap-2 font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                  <Activity className="w-4 h-4 text-[#2563EB]" />
                  <span>Browser Connectivity &amp; Security Boundary</span>
                </div>
                <p className="text-zinc-600 dark:text-zinc-400 leading-relaxed">
                  Windows UNC paths, mapped drive letters, and kernel NFS exports require a
                  server-side RPC/SMB proxy to access live network storage. SharePoint requires
                  delegated Microsoft Graph OAuth without persisting access tokens in localStorage.
                  Only Local Folder mounts with active browser directory handles report Connected.
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                  Activity Log ({activity.length})
                </h3>
                <div className="divide-y divide-zinc-200 dark:divide-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-800 overflow-hidden">
                  {activity.map((entry) => (
                    <div
                      key={entry.id}
                      className="px-4 py-3 flex items-center justify-between gap-3 bg-[#FAFAFA] dark:bg-zinc-900/40"
                    >
                      <div className="min-w-0">
                        <span className="font-medium text-[#09090B] dark:text-[#FAFAFA] mr-2">
                          {entry.action}
                        </span>
                        <span className="text-zinc-500 dark:text-zinc-400 truncate">
                          {entry.target}
                        </span>
                      </div>
                      <span className="font-mono text-[11px] text-zinc-400 tabular-nums shrink-0">
                        {entry.timestamp}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
