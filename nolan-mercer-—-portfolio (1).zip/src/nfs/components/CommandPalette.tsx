import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Folder, Plus, Search, Server, X } from 'lucide-react';
import { NfsNode, NfsSource } from '../types';
import { FileTypeIcon } from './FileTypeIcon';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  sources: NfsSource[];
  nodes: NfsNode[];
  onSelectNode: (node: NfsNode) => void;
  onSelectSource: (sourceId: string) => void;
  onAddSource?: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  sources,
  nodes,
  onSelectNode,
  onSelectSource,
  onAddSource,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setQuery('');
    const timer = window.setTimeout(() => inputRef.current?.focus(), 20);
    return () => window.clearTimeout(timer);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, onClose]);

  const matchedSources = useMemo(() => {
    const q = query.trim().toLowerCase();
    return sources.filter(
      (s) =>
        !q ||
        s.name.toLowerCase().includes(q) ||
        s.path.toLowerCase().includes(q)
    );
  }, [sources, query]);

  const matchedNodes = useMemo(() => {
    const q = query.trim().toLowerCase();
    return nodes
      .filter(
        (n) =>
          !q ||
          n.name.toLowerCase().includes(q) ||
          n.path.toLowerCase().includes(q) ||
          (n.extension || '').toLowerCase().includes(q)
      )
      .slice(0, 10);
  }, [nodes, query]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Quick command palette"
      className="fixed inset-0 z-50 bg-zinc-950/65 backdrop-blur-xs flex items-start justify-center p-4 pt-20"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-4 py-3 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-3">
          <Search className="w-4 h-4 text-zinc-400 shrink-0" />
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Jump to document, folder, or storage source..."
            className="flex-1 bg-transparent text-sm text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none"
          />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close command palette"
            className="p-1 rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="max-h-96 overflow-y-auto p-3 space-y-4 text-xs">
          {onAddSource && (
            <div className="space-y-1">
              <div className="px-2 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                Quick Actions
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onAddSource();
                }}
                className="w-full px-3 py-2 rounded-lg flex items-center gap-2.5 hover:bg-zinc-100 dark:hover:bg-zinc-900 text-left cursor-pointer"
              >
                <Plus className="w-4 h-4 text-[#2563EB]" />
                <span className="font-medium">Add New Storage Source</span>
              </button>
            </div>
          )}

          {matchedSources.length > 0 && (
            <div className="space-y-1">
              <div className="px-2 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                Storage Sources
              </div>
              {matchedSources.map((src) => (
                <button
                  key={src.id}
                  type="button"
                  onClick={() => {
                    onSelectSource(src.id);
                    onClose();
                  }}
                  className="w-full px-3 py-2 rounded-lg flex items-center justify-between gap-3 hover:bg-zinc-100 dark:hover:bg-zinc-900 text-left cursor-pointer"
                >
                  <span className="flex items-center gap-2.5 min-w-0">
                    <Server className="w-4 h-4 text-zinc-500 shrink-0" />
                    <span className="font-medium truncate">{src.name}</span>
                  </span>
                  <span className="text-[11px] font-mono text-zinc-400 shrink-0">
                    {src.status}
                  </span>
                </button>
              ))}
            </div>
          )}

          {matchedNodes.length > 0 && (
            <div className="space-y-1">
              <div className="px-2 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                Files &amp; Folders
              </div>
              {matchedNodes.map((node) => (
                <button
                  key={node.id}
                  type="button"
                  onClick={() => {
                    onSelectNode(node);
                    onClose();
                  }}
                  className="w-full px-3 py-2 rounded-lg flex items-center justify-between gap-3 hover:bg-zinc-100 dark:hover:bg-zinc-900 text-left cursor-pointer"
                >
                  <span className="flex items-center gap-2.5 min-w-0">
                    {node.kind === 'folder' ? (
                      <Folder className="w-4 h-4 text-amber-500 shrink-0" />
                    ) : (
                      <FileTypeIcon
                        kind="file"
                        extension={node.extension}
                        size="sm"
                      />
                    )}
                    <span className="truncate font-medium">{node.name}</span>
                  </span>
                  <span className="text-[11px] font-mono text-zinc-400 shrink-0">
                    {node.kind === 'folder' ? 'Folder' : node.extension}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
