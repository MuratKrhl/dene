import React, { Suspense, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  ChevronRight,
  Copy,
  Download,
  ExternalLink,
  Info,
  Maximize2,
  Minimize2,
  MoreHorizontal,
  Printer,
  Star,
} from 'lucide-react';
import {
  appendActivityLog,
  findNodeByRouteParams,
  loadStarredIds,
  recordRecentFile,
  saveStarredIds,
} from '../services/nfsStore';
import { getAdapterForSource } from '../providers/storageAdapters';
import { getMimeType, resolveNodeArrayBuffer } from '../sampleDocuments';
import { FileTypeIcon } from './FileTypeIcon';

const PDFViewer = React.lazy(() =>
  import('../viewers/PDFViewer').then((m) => ({ default: m.PDFViewer }))
);
const WordViewer = React.lazy(() =>
  import('../viewers/WordViewer').then((m) => ({ default: m.WordViewer }))
);
const ExcelViewer = React.lazy(() =>
  import('../viewers/ExcelViewer').then((m) => ({ default: m.ExcelViewer }))
);
const PowerPointViewer = React.lazy(() =>
  import('../viewers/PowerPointViewer').then((m) => ({ default: m.PowerPointViewer }))
);
const CSVViewer = React.lazy(() =>
  import('../viewers/CSVViewer').then((m) => ({ default: m.CSVViewer }))
);
const TextViewer = React.lazy(() =>
  import('../viewers/TextViewer').then((m) => ({ default: m.TextViewer }))
);
const ImageViewer = React.lazy(() =>
  import('../viewers/ImageViewer').then((m) => ({ default: m.ImageViewer }))
);
const ZipViewer = React.lazy(() =>
  import('../viewers/ZipViewer').then((m) => ({ default: m.ZipViewer }))
);

interface DocumentViewerPageProps {
  sourceId: string;
  fileId: string;
  onNavigate: (path: string) => void;
}

export const DocumentViewerPage: React.FC<DocumentViewerPageProps> = ({
  sourceId,
  fileId,
  onNavigate,
}) => {
  const [{ source, node }, setResolved] = useState(() =>
    findNodeByRouteParams(sourceId, fileId)
  );
  const [buffer, setBuffer] = useState<ArrayBuffer | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [starred, setStarred] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [copiedKey, setCopiedKey] = useState<'path' | 'link' | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const stageRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const found = findNodeByRouteParams(sourceId, fileId);
    setResolved(found);
    setStarred(loadStarredIds().has(fileId));
  }, [sourceId, fileId]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setErrorMsg('');
    setBuffer(null);

    if (!source || !node || node.kind !== 'file') {
      setLoading(false);
      setErrorMsg(
        !source
          ? `Storage source "${sourceId}" was not found or has been removed.`
          : 'The requested document could not be located in this storage source.'
      );
      return;
    }

    if (!source.enabled) {
      setLoading(false);
      setErrorMsg(
        `Storage source "${source.name}" is currently disabled. Enable it in Source Management to open documents.`
      );
      return;
    }

    if (source.type === 'local_folder' && !node.fileObject) {
      setLoading(false);
      setErrorMsg(
        'This document belongs to a local workstation folder from a previous browser session. Return to Explorer and re-mount the local directory to grant read access.'
      );
      return;
    }

    resolveNodeArrayBuffer(node)
      .then((buf) => {
        if (cancelled) return;
        setBuffer(buf);
        recordRecentFile(node);
        appendActivityLog('Opened Document', node.name, 'ok');
      })
      .catch((err) => {
        if (!cancelled) {
          setErrorMsg(
            err instanceof Error
              ? err.message
              : 'Failed to load document payload.'
          );
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [source, node, sourceId]);

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const handleBackToExplorer = () => {
    if (window.history.state && (window.history.state as { fromWorkspaceApp?: boolean }).fromWorkspaceApp) {
      window.history.back();
    } else {
      onNavigate('/quick-access/nfs');
    }
  };

  const handleDownload = () => {
    if (!buffer || !node) return;
    const blob = new Blob([buffer], { type: getMimeType(node.extension) });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = node.name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    appendActivityLog('Downloaded File', node.name, 'ok');
  };

  const handleToggleStar = () => {
    const ids = loadStarredIds();
    if (ids.has(fileId)) {
      ids.delete(fileId);
      setStarred(false);
      appendActivityLog('Removed Star', node?.name || fileId, 'info');
    } else {
      ids.add(fileId);
      setStarred(true);
      appendActivityLog('Starred Document', node?.name || fileId, 'ok');
    }
    saveStarredIds(ids);
  };

  const handleCopy = async (kind: 'path' | 'link') => {
    const value =
      kind === 'path' ? node?.path || '' : window.location.href;
    try {
      await navigator.clipboard.writeText(value);
      setCopiedKey(kind);
      window.setTimeout(() => setCopiedKey(null), 1600);
    } catch {
      setCopiedKey(null);
    }
  };

  const handleToggleFullscreen = async () => {
    if (!stageRef.current) return;
    try {
      if (!document.fullscreenElement) {
        await stageRef.current.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      // Fallback if iframe disallows Fullscreen API
      setIsFullscreen((prev) => !prev);
    }
  };

  const adapter = source ? getAdapterForSource(source) : null;
  const capabilities = source && adapter ? adapter.getCapabilities(source) : null;
  const meta = node && adapter ? adapter.getMetadata(node) : null;

  const renderFormatViewer = () => {
    if (!node || !buffer) return null;
    const ext = node.extension || 'OTHER';

    if (ext === 'PDF') {
      return <PDFViewer buffer={buffer} filename={node.name} />;
    }
    if (ext === 'DOCX' || ext === 'DOC') {
      return (
        <WordViewer
          buffer={buffer}
          filename={node.name}
          extension={ext}
          onDownload={handleDownload}
        />
      );
    }
    if (ext === 'XLSX' || ext === 'XLS') {
      return <ExcelViewer buffer={buffer} filename={node.name} />;
    }
    if (ext === 'PPTX' || ext === 'PPT') {
      return (
        <PowerPointViewer
          buffer={buffer}
          filename={node.name}
          extension={ext}
          onDownload={handleDownload}
        />
      );
    }
    if (ext === 'CSV' || ext === 'TSV') {
      return (
        <CSVViewer buffer={buffer} filename={node.name} extension={ext} />
      );
    }
    if (
      ext === 'TXT' ||
      ext === 'JSON' ||
      ext === 'XML' ||
      ext === 'YAML' ||
      ext === 'MD'
    ) {
      return (
        <TextViewer buffer={buffer} filename={node.name} extension={ext} />
      );
    }
    if (ext === 'PNG' || ext === 'JPG' || ext === 'SVG') {
      return (
        <ImageViewer buffer={buffer} filename={node.name} extension={ext} />
      );
    }
    if (ext === 'ZIP') {
      return <ZipViewer buffer={buffer} filename={node.name} />;
    }

    return (
      <div className="max-w-lg mx-auto my-16 p-8 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 text-center space-y-4">
        <FileTypeIcon kind="file" extension="OTHER" size="lg" />
        <div className="space-y-1.5">
          <h2 className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA]">
            Unsupported In-Browser Preview
          </h2>
          <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
            {node.name} cannot be rendered directly inside the browser. Download the
            original file to open it with a native application.
          </p>
        </div>
        <button
          type="button"
          onClick={handleDownload}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download Original File</span>
        </button>
      </div>
    );
  };

  return (
    <div
      ref={stageRef}
      className="min-h-screen flex flex-col bg-[#FAFAFA] dark:bg-[#09090B] text-[#09090B] dark:text-[#FAFAFA]"
    >
      {/* Focused Full-Page Document Center Header */}
      <header className="sticky top-0 z-30 border-b border-zinc-200 dark:border-zinc-800 bg-white/95 dark:bg-[#111114]/95 backdrop-blur-md px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={handleBackToExplorer}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 hover:border-[#2563EB] text-[#09090B] dark:text-[#FAFAFA] transition-colors cursor-pointer shrink-0"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Explorer</span>
          </button>

          {node && (
            <div className="flex items-center gap-3 min-w-0">
              <FileTypeIcon kind="file" extension={node.extension} size="sm" />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                  <button
                    type="button"
                    onClick={() => onNavigate('/quick-access/nfs')}
                    className="hover:text-[#2563EB] cursor-pointer"
                  >
                    NFS Explorer
                  </button>
                  <ChevronRight className="w-3 h-3 shrink-0" />
                  <button
                    type="button"
                    onClick={() =>
                      onNavigate(`/quick-access/nfs/source/${encodeURIComponent(sourceId)}`)
                    }
                    className="hover:text-[#2563EB] truncate cursor-pointer"
                  >
                    {source?.name || sourceId}
                  </button>
                </div>
                <h1 className="font-display text-sm sm:text-base font-semibold truncate">
                  {node.name}
                </h1>
              </div>
            </div>
          )}
        </div>

        {/* Viewer Action Bar */}
        <div className="flex items-center gap-2 shrink-0 relative">
          {node && (
            <span className="hidden xl:inline-block text-[11px] font-mono text-zinc-500 dark:text-zinc-400 tabular-nums mr-2">
              {node.extension} · {node.sizeLabel} · {source?.status}
            </span>
          )}

          {node && (
            <button
              type="button"
              onClick={handleToggleStar}
              aria-label={starred ? 'Remove from Starred' : 'Add to Starred'}
              className={`p-2 rounded-lg border border-zinc-200 dark:border-zinc-800 transition-colors cursor-pointer ${
                starred
                  ? 'text-[#2563EB] dark:text-blue-400 bg-[#2563EB]/10'
                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
              }`}
            >
              <Star className={`w-4 h-4 ${starred ? 'fill-current' : ''}`} />
            </button>
          )}

          {node?.externalUrl && capabilities?.supportsExternalOpen && (
            <a
              href={node.externalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors whitespace-nowrap"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open Externally</span>
            </a>
          )}

          {(node?.extension === 'PDF' ||
            node?.extension === 'DOCX' ||
            node?.extension === 'MD' ||
            node?.extension === 'TXT') && (
            <button
              type="button"
              onClick={() => window.print()}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleDownload}
            disabled={!buffer}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download</span>
          </button>

          <button
            type="button"
            onClick={() => setShowInfo((s) => !s)}
            aria-label="Toggle file metadata panel"
            className={`p-2 rounded-lg border transition-colors cursor-pointer ${
              showInfo
                ? 'border-[#2563EB] text-[#2563EB] dark:text-blue-400'
                : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            <Info className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleToggleFullscreen}
            aria-label={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
            className="p-2 rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            {isFullscreen ? (
              <Minimize2 className="w-4 h-4" />
            ) : (
              <Maximize2 className="w-4 h-4" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setShowMoreMenu((m) => !m)}
            aria-label="More document actions"
            className="p-2 rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>

          {showMoreMenu && node && (
            <div className="absolute right-0 top-12 z-40 w-48 py-1.5 rounded-xl bg-white dark:bg-[#18181B] border border-zinc-200 dark:border-zinc-700 shadow-lg text-xs">
              <button
                type="button"
                onClick={() => {
                  handleCopy('path');
                  setShowMoreMenu(false);
                }}
                className="w-full px-3.5 py-2 text-left flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
              >
                {copiedKey === 'path' ? (
                  <Check className="w-3.5 h-3.5 text-[#2563EB]" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                <span>Copy Storage Path</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  handleCopy('link');
                  setShowMoreMenu(false);
                }}
                className="w-full px-3.5 py-2 text-left flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
              >
                {copiedKey === 'link' ? (
                  <Check className="w-3.5 h-3.5 text-[#2563EB]" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                <span>Copy Viewer URL</span>
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Main Document Viewport + Optional Metadata Sidebar */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
          {loading && (
            <div className="flex-1 p-10 flex flex-col items-center justify-center gap-4">
              <div className="w-full max-w-2xl space-y-3 animate-pulse">
                <div className="h-6 w-1/3 rounded bg-zinc-200 dark:bg-zinc-800 mx-auto" />
                <div className="h-64 w-full rounded-2xl bg-zinc-200 dark:bg-zinc-800" />
              </div>
              <p className="text-xs text-zinc-500">
                Loading document renderer...
              </p>
            </div>
          )}

          {!loading && errorMsg && (
            <div className="flex-1 flex items-center justify-center p-6">
              <div className="max-w-lg w-full p-8 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 text-center space-y-4">
                <div className="w-11 h-11 rounded-xl bg-amber-500/12 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div className="space-y-2">
                  <h2 className="font-display text-lg font-semibold">
                    Document Unavailable
                  </h2>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
                    {errorMsg}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('/quick-access/nfs')}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Return to NFS Explorer</span>
                </button>
              </div>
            </div>
          )}

          {!loading && !errorMsg && buffer && (
            <Suspense
              fallback={
                <div className="flex-1 flex items-center justify-center text-xs text-zinc-500">
                  Initializing format engine...
                </div>
              }
            >
              {renderFormatViewer()}
            </Suspense>
          )}
        </div>

        {/* Optional Metadata & Permissions Drawer */}
        {showInfo && node && source && meta && (
          <aside className="w-80 border-l border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] p-5 overflow-y-auto space-y-5 text-xs shrink-0">
            <div>
              <h2 className="font-display text-sm font-semibold">
                Document Details
              </h2>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5">
                {source.name} ({source.status})
              </p>
            </div>

            <dl className="space-y-3 border-t border-zinc-200 dark:border-zinc-800 pt-4">
              <div>
                <dt className="text-zinc-500 dark:text-zinc-400">Format &amp; Size</dt>
                <dd className="font-mono mt-0.5 tabular-nums">
                  {node.extension} · {node.sizeLabel}
                </dd>
              </div>
              <div>
                <dt className="text-zinc-500 dark:text-zinc-400">Modified</dt>
                <dd className="mt-0.5 tabular-nums">{node.modifiedAt}</dd>
              </div>
              <div>
                <dt className="text-zinc-500 dark:text-zinc-400">Owner / Group</dt>
                <dd className="font-mono mt-0.5">
                  {meta.owner} : {meta.group}
                </dd>
              </div>
              <div>
                <dt className="text-zinc-500 dark:text-zinc-400">Permissions</dt>
                <dd className="font-mono mt-0.5">{meta.permissions}</dd>
              </div>
              <div>
                <dt className="text-zinc-500 dark:text-zinc-400">Storage Path</dt>
                <dd className="font-mono text-[11px] break-all mt-0.5 text-zinc-600 dark:text-zinc-400">
                  {node.path}
                </dd>
              </div>
            </dl>
          </aside>
        )}
      </div>
    </div>
  );
};
