import React from 'react';
import {
  File,
  FileArchive,
  FileCode2,
  FileImage,
  FileSpreadsheet,
  FileText,
  Folder,
  Presentation,
} from 'lucide-react';
import { DocFormat } from '../types';

interface FileTypeIconProps {
  kind: 'folder' | 'file';
  extension?: DocFormat;
  size?: 'sm' | 'md' | 'lg';
}

export const FileTypeIcon: React.FC<FileTypeIconProps> = ({
  kind,
  extension,
  size = 'md',
}) => {
  const boxSize =
    size === 'sm'
      ? 'w-8 h-8 rounded-lg'
      : size === 'lg'
        ? 'w-14 h-14 rounded-2xl'
        : 'w-10 h-10 rounded-xl';
  const iconSize =
    size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-7 h-7' : 'w-5 h-5';

  if (kind === 'folder') {
    return (
      <div
        aria-hidden="true"
        className={`${boxSize} flex items-center justify-center bg-amber-500/12 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400 shrink-0`}
      >
        <Folder className={iconSize} />
      </div>
    );
  }

  switch (extension) {
    case 'PDF':
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-red-500/12 text-red-600 dark:bg-red-500/15 dark:text-red-400 shrink-0`}
        >
          <FileText className={iconSize} />
        </div>
      );
    case 'DOCX':
    case 'DOC':
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-[#2563EB]/12 text-[#2563EB] dark:bg-blue-500/15 dark:text-blue-400 shrink-0`}
        >
          <FileText className={iconSize} />
        </div>
      );
    case 'XLSX':
    case 'XLS':
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-emerald-500/12 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400 shrink-0`}
        >
          <FileSpreadsheet className={iconSize} />
        </div>
      );
    case 'PPTX':
    case 'PPT':
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-orange-500/12 text-orange-600 dark:bg-orange-500/15 dark:text-orange-400 shrink-0`}
        >
          <Presentation className={iconSize} />
        </div>
      );
    case 'CSV':
    case 'TSV':
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-teal-500/12 text-teal-700 dark:bg-teal-500/15 dark:text-teal-400 shrink-0`}
        >
          <FileSpreadsheet className={iconSize} />
        </div>
      );
    case 'JSON':
    case 'XML':
    case 'YAML':
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-violet-500/12 text-violet-700 dark:bg-violet-500/15 dark:text-violet-400 shrink-0`}
        >
          <FileCode2 className={iconSize} />
        </div>
      );
    case 'TXT':
    case 'MD':
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-zinc-200/80 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300 shrink-0`}
        >
          <FileText className={iconSize} />
        </div>
      );
    case 'PNG':
    case 'JPG':
    case 'SVG':
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-sky-500/12 text-sky-700 dark:bg-sky-500/15 dark:text-sky-400 shrink-0`}
        >
          <FileImage className={iconSize} />
        </div>
      );
    case 'ZIP':
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-amber-600/12 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300 shrink-0`}
        >
          <FileArchive className={iconSize} />
        </div>
      );
    default:
      return (
        <div
          aria-hidden="true"
          className={`${boxSize} flex items-center justify-center bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400 shrink-0`}
        >
          <File className={iconSize} />
        </div>
      );
  }
};
