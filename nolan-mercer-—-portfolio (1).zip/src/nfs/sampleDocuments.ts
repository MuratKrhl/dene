import JSZip from 'jszip';
import * as XLSX from 'xlsx';
import { DocFormat, NfsNode } from './types';

function escapePdfText(text: string): string {
  return text.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}

function buildValidPdf(pages: { title: string; lines: string[] }[]): Uint8Array {
  const objects: string[] = [];
  const pageObjectIds: number[] = [];

  objects.push('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
  objects.push('');
  objects.push(
    '3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n'
  );
  objects.push(
    '4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj\n'
  );

  let nextId = 5;
  pages.forEach((page, idx) => {
    const contentId = nextId++;
    const pageId = nextId++;
    pageObjectIds.push(pageId);

    const streamCommands: string[] = [
      'BT',
      '/F2 18 Tf',
      '56 736 Td',
      `(${escapePdfText(page.title)}) Tj`,
      '/F1 11 Tf',
      '0 -28 Td',
    ];

    page.lines.forEach((line) => {
      streamCommands.push(`(${escapePdfText(line)}) Tj`);
      streamCommands.push('0 -18 Td');
    });

    streamCommands.push('/F1 9 Tf');
    streamCommands.push('0 -24 Td');
    streamCommands.push(
      `(${escapePdfText(`Murat Krhl WorkSpace NFS Document Center — Page ${idx + 1} of ${pages.length}`)}) Tj`
    );
    streamCommands.push('ET');

    const streamBody = streamCommands.join('\n');
    objects.push(
      `${contentId} 0 obj\n<< /Length ${streamBody.length} >>\nstream\n${streamBody}\nendstream\nendobj\n`
    );
    objects.push(
      `${pageId} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentId} 0 R >>\nendobj\n`
    );
  });

  objects[1] = `2 0 obj\n<< /Type /Pages /Kids [${pageObjectIds
    .map((id) => `${id} 0 R`)
    .join(' ')}] /Count ${pageObjectIds.length} >>\nendobj\n`;

  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [0];
  for (const obj of objects) {
    offsets.push(pdf.length);
    pdf += obj;
  }

  const xrefStart = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n`;
  pdf += '0000000000 65535 f \n';
  for (let i = 1; i < offsets.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;

  return new TextEncoder().encode(pdf);
}

async function buildDocxBuffer(
  title: string,
  subtitle: string,
  sections: { heading: string; paragraphs: string[] }[],
  tableRows: string[][]
): Promise<ArrayBuffer> {
  const zip = new JSZip();

  zip.file(
    '[Content_Types].xml',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`
  );

  zip.file(
    '_rels/.rels',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`
  );

  const esc = (s: string) =>
    s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const bodyParts: string[] = [
    `<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="36"/></w:rPr><w:t>${esc(title)}</w:t></w:r></w:p>`,
    `<w:p><w:r><w:rPr><w:i/></w:rPr><w:t>${esc(subtitle)}</w:t></w:r></w:p>`,
  ];

  sections.forEach((sec) => {
    bodyParts.push(
      `<w:p><w:pPr><w:pStyle w:val="Heading2"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="28"/></w:rPr><w:t>${esc(sec.heading)}</w:t></w:r></w:p>`
    );
    sec.paragraphs.forEach((p) => {
      bodyParts.push(`<w:p><w:r><w:t>${esc(p)}</w:t></w:r></w:p>`);
    });
  });

  if (tableRows.length > 0) {
    const trs = tableRows
      .map(
        (row, rowIdx) =>
          `<w:tr>${row
            .map(
              (cell) =>
                `<w:tc><w:p><w:r>${rowIdx === 0 ? '<w:rPr><w:b/></w:rPr>' : ''}<w:t>${esc(
                  cell
                )}</w:t></w:r></w:p></w:tc>`
            )
            .join('')}</w:tr>`
      )
      .join('');
    bodyParts.push(`<w:tbl>${trs}</w:tbl>`);
  }

  zip.file(
    'word/document.xml',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>${bodyParts.join('')}</w:body>
</w:document>`
  );

  return zip.generateAsync({ type: 'arraybuffer' });
}

async function buildPptxBuffer(
  slides: { title: string; bullets: string[]; notes: string }[]
): Promise<ArrayBuffer> {
  const zip = new JSZip();
  const esc = (s: string) =>
    s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const slideOverrides = slides
    .map(
      (_, i) =>
        `<Override PartName="/ppt/slides/slide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>
         <Override PartName="/ppt/notesSlides/notesSlide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"/>`
    )
    .join('\n');

  zip.file(
    '[Content_Types].xml',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-officedocument.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  ${slideOverrides}
</Types>`
  );

  zip.file(
    '_rels/.rels',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
</Relationships>`
  );

  zip.file(
    'ppt/presentation.xml',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <p:sldIdLst>${slides
    .map((_, i) => `<p:sldId id="${256 + i}" r:id="rId${i + 1}"/>`)
    .join('')}</p:sldIdLst>
</p:presentation>`
  );

  zip.file(
    'ppt/_rels/presentation.xml.rels',
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  ${slides
    .map(
      (_, i) =>
        `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i + 1}.xml"/>`
    )
    .join('')}
</Relationships>`
  );

  slides.forEach((slide, i) => {
    const bulletParagraphs = slide.bullets
      .map((b) => `<a:p><a:r><a:t>${esc(b)}</a:t></a:r></a:p>`)
      .join('');

    zip.file(
      `ppt/slides/slide${i + 1}.xml`,
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld><p:spTree>
    <p:sp>
      <p:nvSpPr><p:cNvPr id="2" name="Title"/><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr>
      <p:txBody><a:p><a:r><a:t>${esc(slide.title)}</a:t></a:r></a:p></p:txBody>
    </p:sp>
    <p:sp>
      <p:nvSpPr><p:cNvPr id="3" name="Content"/><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr>
      <p:txBody>${bulletParagraphs}</p:txBody>
    </p:sp>
  </p:spTree></p:cSld>
</p:sld>`
    );

    zip.file(
      `ppt/notesSlides/notesSlide${i + 1}.xml`,
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:notes xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld><p:spTree>
    <p:sp><p:txBody><a:p><a:r><a:t>${esc(slide.notes)}</a:t></a:r></a:p></p:txBody></p:sp>
  </p:spTree></p:cSld>
</p:notes>`
    );
  });

  return zip.generateAsync({ type: 'arraybuffer' });
}

function buildWorkbookBuffer(
  sheets: { name: string; rows: (string | number)[][] }[],
  bookType: 'xlsx' | 'xls' = 'xlsx'
): ArrayBuffer {
  const wb = XLSX.utils.book_new();
  sheets.forEach((s) => {
    const ws = XLSX.utils.aoa_to_sheet(s.rows);
    XLSX.utils.book_append_sheet(wb, ws, s.name);
  });
  return XLSX.write(wb, { type: 'array', bookType }) as ArrayBuffer;
}

async function buildSampleZipBuffer(): Promise<ArrayBuffer> {
  const zip = new JSZip();
  zip.file(
    'README.md',
    '# Workspace Design Tokens v4.2\n\nSemantic tokens exported for Light & Dark themes.\n'
  );
  zip.file(
    'tokens/semantic.json',
    JSON.stringify(
      {
        surface: { canvas: { light: '#FAFAFA', dark: '#09090B' } },
        accent: { primary: '#2563EB' },
      },
      null,
      2
    )
  );
  zip.file('tokens/contrast-report.txt', 'WCAG AA Contrast Gate: 48/48 pairs PASSED\n');
  zip.file('css/variables.css', ':root {\n  --ws-accent: #2563EB;\n}\n');
  return zip.generateAsync({ type: 'arraybuffer' });
}

export async function resolveNodeArrayBuffer(node: NfsNode): Promise<ArrayBuffer> {
  if (node.fileObject) {
    return node.fileObject.arrayBuffer();
  }

  const ext = node.extension || 'PDF';

  if (ext === 'PDF') {
    const bytes =
      node.sampleKey === 'nfs-security'
        ? buildValidPdf([
            {
              title: 'Enterprise NFSv4.1 Security & Mount Policy',
              lines: [
                'Document ID: SEC-2026-041   |   Classification: Internal Architecture',
                '1. Transport & Authentication Baseline',
                'All Windows SMB/NFS bridge mounts enforce Kerberos v5 integrity (krb5i).',
                'Read-only archival shares mount with ro,hard,intr,timeo=600.',
                '2. SharePoint & Graph Connector Policy',
                'SharePoint libraries synchronize read tokens via scoped delegated OAuth.',
                'Zero credentials are persisted inside browser localStorage.',
              ],
            },
            {
              title: 'Appendix A — Approved Mount Targets',
              lines: [
                '\\\\corp-fs01.internal\\finance\\documents  ->  Finance & Treasury',
                '10.0.4.12:/exports/workspace              ->  Engineering NFSv4',
                'Z:\\Operations\\Documents                  ->  Engineering Mapped Drive',
                'https://contoso.sharepoint.com/sites/Engineering -> SharePoint Library',
              ],
            },
          ])
        : buildValidPdf([
            {
              title: node.name.replace(/\.pdf$/i, ''),
              lines: [
                `Source Location: ${node.path}`,
                `Last Modified: ${node.modifiedAt}   |   Author: ${node.author || 'Murat Krhl'}`,
                '1. Executive Summary',
                'Consolidated Q4 liquidity reconciliation across 14 Nordic operating entities.',
                'Reconciliation cycle time decreased by 42% following ledger standardization.',
                '2. Key Financial Controls',
                '- Automated multi-currency sweep thresholds across EUR, DKK, SEK, and USD.',
                '- Daily audit trail export directly to NFSv4 archival storage.',
              ],
            },
            {
              title: '2. Operational Metrics & Sign-Off',
              lines: [
                'Treasury Cold-Load Performance: 1.8s median across distributed offices.',
                'Design System Token Compliance: 100% WCAG AA verified in Light & Dark modes.',
                'Opened in Workspace Document Center full-page viewer.',
              ],
            },
          ]);
    return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
  }

  if (ext === 'DOCX') {
    return buildDocxBuffer(
      node.name.replace(/\.docx$/i, ''),
      `Path: ${node.path} · Author: ${node.author || 'Murat Krhl'}`,
      [
        {
          heading: '1. Architecture Scope',
          paragraphs: [
            'This specification defines the unified frontend system architecture, semantic color tokens, and keyboard-first workflows across Workspace modules.',
            'External network shares, NFSv4 exports, mapped Windows drives, and SharePoint libraries are indexed through a unified provider adapter so teams can search and open documents in place.',
          ],
        },
        {
          heading: '2. Supported Document Center Pipelines',
          paragraphs: [
            'Binary documents are parsed directly inside the full-page Document Center using PDF.js, Mammoth.js, SheetJS, Papa Parse, and OOXML slide extraction without mutating source files.',
          ],
        },
      ],
      [
        ['Format', 'Renderer', 'Capabilities'],
        ['PDF', 'PDF.js (pdfjs-dist)', 'Canvas rendering, zoom, page jump, text search'],
        ['DOCX', 'Mammoth.js', 'Headings, paragraphs, tables, inline formatting'],
        ['XLSX / XLS', 'SheetJS (xlsx)', 'Multi-sheet tabs, search, grid zoom'],
        ['CSV / TSV', 'Papa Parse', 'Auto-delimiter, string ID preservation, pagination'],
        ['PPTX', 'OOXML Slide Parser', 'Slide thumbnails, notes, fullscreen presentation'],
      ]
    );
  }

  if (ext === 'XLSX' || ext === 'XLS') {
    return buildWorkbookBuffer(
      [
        {
          name: 'Q4 Summary',
          rows: [
            ['Entity', 'Region', 'Revenue (EUR)', 'Operating Margin', 'Status'],
            ['Krono Nordic AB', 'Stockholm', 4280000, '24.5%', 'Verified'],
            ['Solis Objects ApS', 'Copenhagen', 1940000, '19.8%', 'Verified'],
            ['Meridian Logistics GmbH', 'Hamburg', 6120000, '16.2%', 'In Review'],
            ['Kinetix Audio Labs', 'Berlin', 1350000, '28.1%', 'Verified'],
            ['Baltic Marine Inst.', 'Gdansk', 890000, '12.4%', 'Verified'],
          ],
        },
        {
          name: 'Storage Quotas',
          rows: [
            ['Share Path', 'Protocol', 'Used (GB)', 'Quota (GB)', 'Utilization'],
            ['\\\\corp-fs01\\finance', 'SMB3', 412.4, 1024, '40.3%'],
            ['10.0.4.12:/exports/workspace', 'NFSv4.1', 218.7, 1024, '21.4%'],
            ['Z:\\Operations\\Docs', 'Mapped Drive', 184.0, 512, '35.9%'],
            ['SharePoint / Engineering', 'Graph API', 96.2, 500, '19.2%'],
          ],
        },
      ],
      ext === 'XLS' ? 'xls' : 'xlsx'
    );
  }

  if (ext === 'PPTX') {
    return buildPptxBuffer([
      {
        title: 'Q4 Engineering & Design Systems Review',
        bullets: [
          'Unified 11 product teams onto semantic Tailwind v4 tokens',
          'Reduced UI code duplication by 55% across financial & logistics apps',
          'Zero P1 accessibility regressions across Light & Dark themes',
        ],
        notes: 'Opening slide covering quarterly impact metrics across core product squads.',
      },
      {
        title: 'NFS Explorer & Document Center Architecture',
        bullets: [
          'Unified adapter layer for Windows UNC, NFSv4 exports, Mapped Drives, and SharePoint',
          'Full-page Document Center routes with browser Back & URL persistence',
          'In-app PDF, DOCX, XLSX, PPTX, CSV (Papa Parse), JSON, YAML, XML, and Image viewers',
        ],
        notes: 'Walk through the unified adapter layer connecting local and network sources.',
      },
      {
        title: 'Performance & Contrast Benchmarks',
        bullets: [
          '1.8s median cold load across virtualized financial ledgers',
          'Sub-200ms compositor-only interactive transitions',
          'WCAG AA contrast enforced automatically in CI checks',
        ],
        notes: 'Highlight Core Web Vitals and accessibility testing pipeline.',
      },
      {
        title: 'Q1 2027 Roadmap & Next Steps',
        bullets: [
          'Enable Microsoft Graph delegated OAuth connector for SharePoint sites',
          'Deploy authenticated backend NFS RPC & SMB bridge for live network mounts',
          'Expand Knowledge Hub snippet indexing',
        ],
        notes: 'Closing slide outlining upcoming engineering milestones.',
      },
    ]);
  }

  if (ext === 'JSON') {
    const json = JSON.stringify(
      {
        schema: 'https://workspace.muratkrhl.dev/schemas/tokens.v4.json',
        version: '4.2.0',
        themes: {
          light: { canvas: '#FAFAFA', surface: '#FFFFFF', ink: '#09090B', accent: '#2563EB' },
          dark: { canvas: '#09090B', surface: '#111114', ink: '#FAFAFA', accent: '#60A5FA' },
        },
        nfsProviders: ['windows_share', 'nfs_share', 'mapped_drive', 'sharepoint', 'local_folder'],
      },
      null,
      2
    );
    return new TextEncoder().encode(json).buffer;
  }

  if (ext === 'YAML') {
    const yaml = `version: "3.9"
services:
  nfs-gateway:
    image: workspace/nfs-rpc-bridge:4.1
    ports:
      - "8443:8443"
    environment:
      NFS_DEFAULT_VERSION: "4.1"
      ENFORCE_KRB5I: "true"
      ALLOWED_EXPORTS: "/exports/workspace,/exports/configs"
    volumes:
      - workspace-nfs:/mnt/workspace:ro

volumes:
  workspace-nfs:
    driver: local
    driver_opts:
      type: nfs4
      o: addr=10.0.4.12,ro,hard,intr
      device: ":/exports/workspace"
`;
    return new TextEncoder().encode(yaml).buffer;
  }

  if (ext === 'XML') {
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<NfsExportManifest version="4.1" host="10.0.4.12">
  <Export path="/exports/workspace" protocol="NFSv4.1" security="krb5i">
    <AccessControl group="engineering" permission="ro" rootSquash="true" />
    <AccessControl group="design-sys" permission="ro" rootSquash="true" />
  </Export>
  <SharePointConnector library="Shared Documents" auth="MicrosoftGraphOAuth2" />
</NfsExportManifest>
`;
    return new TextEncoder().encode(xml).buffer;
  }

  if (ext === 'MD') {
    const md = `# NFSv4.1 Mount & Diagnostics Runbook

Standard operational reference for mounting engineering exports into read-only workspace runners.

## Mount Command

\`sudo mount -t nfs4 -o ro,hard,intr,timeo=600 10.0.4.12:/exports/workspace /mnt/workspace\`

## Verification Checklist

- Verify Kerberos ticket (\`klist\`) before mounting \`krb5i\` exports.
- Confirm TCP port \`2049\` reachability across subnet \`10.0.4.0/24\`.
- Never cache SharePoint OAuth tokens inside browser \`localStorage\`.
`;
    return new TextEncoder().encode(md).buffer;
  }

  if (ext === 'TXT') {
    const txt = `MOUNT DIAGNOSTICS SUMMARY — 2026-11-16
==================================================
Source 01: \\\\corp-fs01.internal\\finance\\documents   [Demo Mode - Browser Sandbox]
Source 02: 10.0.4.12:/exports/workspace               [Demo Mode - NFSv4.1 Proxy Ready]
Source 03: Z:\\Operations\\Documents                   [Demo Mode - Desktop Bridge Needed]
Source 04: contoso.sharepoint.com/sites/Engineering   [Authentication Required - OAuth2]

All local sample parsers (PDF.js, Mammoth, SheetJS, Papa Parse, JSZip) verified active.
`;
    return new TextEncoder().encode(txt).buffer;
  }

  if (ext === 'SVG') {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 360" width="760" height="360">
  <rect width="760" height="360" rx="16" fill="#09090B" />
  <rect x="40" y="48" width="190" height="84" rx="12" fill="#111114" stroke="#27272A" stroke-width="1.5" />
  <text x="135" y="84" text-anchor="middle" fill="#FAFAFA" font-family="sans-serif" font-size="14" font-weight="600">Windows UNC / Z:</text>
  <text x="135" y="108" text-anchor="middle" fill="#A1A1AA" font-family="monospace" font-size="11">SMB 3.1.1</text>

  <rect x="40" y="152" width="190" height="84" rx="12" fill="#111114" stroke="#27272A" stroke-width="1.5" />
  <text x="135" y="188" text-anchor="middle" fill="#FAFAFA" font-family="sans-serif" font-size="14" font-weight="600">NFSv4.1 Export</text>
  <text x="135" y="212" text-anchor="middle" fill="#A1A1AA" font-family="monospace" font-size="11">10.0.4.12:/exports</text>

  <rect x="40" y="256" width="190" height="68" rx="12" fill="#111114" stroke="#27272A" stroke-width="1.5" />
  <text x="135" y="286" text-anchor="middle" fill="#FAFAFA" font-family="sans-serif" font-size="14" font-weight="600">SharePoint Graph</text>
  <text x="135" y="306" text-anchor="middle" fill="#A1A1AA" font-family="monospace" font-size="11">OAuth2 Delegated</text>

  <line x1="230" y1="90" x2="335" y2="180" stroke="#2563EB" stroke-width="2" />
  <line x1="230" y1="194" x2="335" y2="180" stroke="#2563EB" stroke-width="2" />
  <line x1="230" y1="290" x2="335" y2="180" stroke="#2563EB" stroke-width="2" />

  <rect x="335" y="128" width="180" height="104" rx="14" fill="#2563EB" />
  <text x="425" y="174" text-anchor="middle" fill="#FFFFFF" font-family="sans-serif" font-size="15" font-weight="700">Provider Adapter</text>
  <text x="425" y="198" text-anchor="middle" fill="#DBEAFE" font-family="monospace" font-size="11">Unified File Service</text>

  <line x1="515" y1="180" x2="575" y2="180" stroke="#60A5FA" stroke-width="2" />

  <rect x="575" y="128" width="145" height="104" rx="14" fill="#111114" stroke="#2563EB" stroke-width="1.5" />
  <text x="647" y="174" text-anchor="middle" fill="#FAFAFA" font-family="sans-serif" font-size="14" font-weight="600">Document Center</text>
  <text x="647" y="198" text-anchor="middle" fill="#60A5FA" font-family="monospace" font-size="11">Full-Page Viewer</text>
</svg>`;
    return new TextEncoder().encode(svg).buffer;
  }

  if (ext === 'ZIP') {
    return buildSampleZipBuffer();
  }

  if (ext === 'TSV') {
    const tsv = [
      'record_code\ttimestamp\tservice\tlatency_ms\tstatus\tregion',
      '00412\t2026-11-16T09:15:00Z\tnfs-gateway\t11.4\t200\teu-north-1',
      '00413\t2026-11-16T09:16:00Z\tgraph-sync\t48.2\t200\teu-west-2',
      '00414\t2026-11-16T09:17:00Z\tpdf-worker\t19.8\t200\teu-north-1',
      '00415\t2026-11-16T09:18:00Z\ttoken-audit\t8.6\t200\teu-central-1',
    ].join('\n');
    return new TextEncoder().encode(tsv).buffer;
  }

  // CSV default (preserving leading zeros on Document Code to verify Papa Parse string fidelity)
  const csv = [
    'Document Code,Title,Format,Department,Owner,Status',
    '00401,Q4 Treasury Liquidity Report,PDF,Finance,Henrik Lindholm,Approved',
    '00402,Design Token Architecture v4,DOCX,Engineering,Murat Krhl,Published',
    '00403,Nordic Entity Revenue Ledger,XLSX,Finance,Maren Solberg,Verified',
    '00404,Q4 Engineering Briefing,PPTX,Platform,Murat Krhl,Final',
    '00405,NFSv4 Security & Mount Policy,PDF,Security,Security Architecture,Approved',
    '00406,Gateway Latency Telemetry,TSV,Platform,Platform SRE,Active',
  ].join('\n');
  return new TextEncoder().encode(csv).buffer;
}

export function getMimeType(ext?: DocFormat): string {
  switch (ext) {
    case 'PDF':
      return 'application/pdf';
    case 'DOCX':
      return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    case 'DOC':
      return 'application/msword';
    case 'XLSX':
      return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    case 'XLS':
      return 'application/vnd.ms-excel';
    case 'PPTX':
      return 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
    case 'PPT':
      return 'application/vnd.ms-powerpoint';
    case 'CSV':
      return 'text/csv;charset=utf-8';
    case 'TSV':
      return 'text/tab-separated-values;charset=utf-8';
    case 'JSON':
      return 'application/json;charset=utf-8';
    case 'XML':
      return 'application/xml;charset=utf-8';
    case 'YAML':
      return 'application/yaml;charset=utf-8';
    case 'MD':
      return 'text/markdown;charset=utf-8';
    case 'TXT':
      return 'text/plain;charset=utf-8';
    case 'SVG':
      return 'image/svg+xml';
    case 'PNG':
      return 'image/png';
    case 'JPG':
      return 'image/jpeg';
    case 'ZIP':
      return 'application/zip';
    default:
      return 'application/octet-stream';
  }
}
