import React, { useEffect, useState } from 'react';
import JSZip from 'jszip';
import { File, Folder } from 'lucide-react';

interface ZipViewerProps {
  buffer: ArrayBuffer;
  filename: string;
}

interface ZipEntryRow {
  name: string;
  dir: boolean;
  date: string;
}

export const ZipViewer: React.FC<ZipViewerProps> = ({ buffer, filename }) => {
  const [entries, setEntries] = useState<ZipEntryRow[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setError('');
    JSZip.loadAsync(buffer)
      .then((zip) => {
        if (cancelled) return;
        const rows: ZipEntryRow[] = Object.values(zip.files).map((f) => ({
          name: f.name,
          dir: f.dir,
          date: f.date
            ? f.date.toLocaleDateString('en-US', {
                month: 'short',
                day: '2-digit',
                year: 'numeric',
              })
            : '—',
        }));
        setEntries(rows);
      })
      .catch((err) => {
        if (!cancelled) {
          setError(
            err instanceof Error
              ? err.message
              : `Unable to inspect ZIP archive ${filename}.`
          );
        }
      });

    return () => {
      cancelled = true;
    };
  }, [buffer, filename]);

  if (error) {
    return (
      <div className="max-w-lg mx-auto my-12 p-6 rounded-2xl bg-white dark:bg-[#111114] border border-red-200 dark:border-red-900/50 text-center space-y-2">
        <p className="text-sm font-semibold text-red-600 dark:text-red-400">
          Archive Inspection Error
        </p>
        <p className="text-xs text-zinc-600 dark:text-zinc-400">{error}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 sm:px-6 py-2.5 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] flex items-center justify-between text-xs shrink-0">
        <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
          Safe ZIP Archive Manifest · {entries.length} entries (read-only inspection)
        </span>
      </div>

      <div className="flex-1 overflow-auto p-6 bg-zinc-100 dark:bg-zinc-950">
        <div className="max-w-4xl mx-auto rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-zinc-50 dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 text-[11px] text-zinc-500">
              <tr>
                <th className="px-4 py-2.5">Archive Entry Path</th>
                <th className="px-4 py-2.5">Kind</th>
                <th className="px-4 py-2.5 text-right">Modified</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
              {entries.map((row) => (
                <tr key={row.name} className="hover:bg-zinc-50 dark:hover:bg-zinc-900/30">
                  <td className="px-4 py-2.5 font-mono text-[#09090B] dark:text-[#FAFAFA] flex items-center gap-2">
                    {row.dir ? (
                      <Folder className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    ) : (
                      <File className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                    )}
                    <span>{row.name}</span>
                  </td>
                  <td className="px-4 py-2.5 text-zinc-500">
                    {row.dir ? 'Directory' : 'File'}
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-zinc-500 tabular-nums">
                    {row.date}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
