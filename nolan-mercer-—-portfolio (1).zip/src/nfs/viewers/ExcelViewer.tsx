import React, { useEffect, useState } from 'react';
import * as XLSX from 'xlsx';
import { Search, ZoomIn, ZoomOut } from 'lucide-react';

interface ExcelViewerProps {
  buffer: ArrayBuffer;
  filename: string;
}

function colLetter(idx: number): string {
  let s = '';
  let n = idx;
  while (n >= 0) {
    s = String.fromCharCode((n % 26) + 65) + s;
    n = Math.floor(n / 26) - 1;
  }
  return s;
}

export const ExcelViewer: React.FC<ExcelViewerProps> = ({ buffer, filename }) => {
  const [workbook, setWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [activeSheet, setActiveSheet] = useState('');
  const [rows, setRows] = useState<(string | number)[][]>([]);
  const [search, setSearch] = useState('');
  const [zoom, setZoom] = useState(1);
  const [error, setError] = useState('');

  useEffect(() => {
    try {
      setError('');
      const wb = XLSX.read(buffer, { type: 'array' });
      setWorkbook(wb);
      setSheetNames(wb.SheetNames);
      const first = wb.SheetNames[0] || '';
      setActiveSheet(first);
      if (first) {
        const parsed = XLSX.utils.sheet_to_json(wb.Sheets[first], {
          header: 1,
          defval: '',
        }) as (string | number)[][];
        setRows(parsed);
      }
    } catch (err) {
      setError(
        err instanceof Error ? err.message : `Unable to read workbook ${filename}.`
      );
    }
  }, [buffer, filename]);

  const handleSelectSheet = (name: string) => {
    if (!workbook) return;
    setActiveSheet(name);
    const parsed = XLSX.utils.sheet_to_json(workbook.Sheets[name], {
      header: 1,
      defval: '',
    }) as (string | number)[][];
    setRows(parsed);
  };

  if (error) {
    return (
      <div className="max-w-lg mx-auto my-12 p-6 rounded-2xl bg-white dark:bg-[#111114] border border-red-200 dark:border-red-900/50 text-center space-y-2">
        <p className="text-sm font-semibold text-red-600 dark:text-red-400">
          Workbook Parse Error
        </p>
        <p className="text-xs text-zinc-600 dark:text-zinc-400">{error}</p>
      </div>
    );
  }

  const maxCols = rows.reduce((max, r) => Math.max(max, r.length), 0);
  const q = search.trim().toLowerCase();

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 sm:px-6 py-2.5 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
        <div className="flex flex-wrap items-center gap-1.5">
          {sheetNames.map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => handleSelectSheet(name)}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                activeSheet === name
                  ? 'bg-[#2563EB] text-white'
                  : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
              }`}
            >
              {name}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <span className="hidden md:inline text-[11px] text-zinc-500 dark:text-zinc-400">
            SheetJS Workbook Viewer (static cached values)
          </span>
          <div className="relative w-48">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Find in cells..."
              aria-label="Search cells"
              className="w-full pl-8 pr-2 py-1 text-xs rounded-md bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            />
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() =>
                setZoom((z) => Math.max(0.75, Number((z - 0.1).toFixed(2))))
              }
              aria-label="Zoom out"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono w-10 text-center tabular-nums">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() =>
                setZoom((z) => Math.min(1.5, Number((z + 0.1).toFixed(2))))
              }
              aria-label="Zoom in"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4 sm:p-6 bg-zinc-100 dark:bg-zinc-950">
        <div
          className="rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-auto max-w-full"
          style={{ fontSize: `${Math.round(zoom * 12)}px` }}
        >
          <table className="w-full border-collapse text-left">
            <thead className="bg-zinc-50 dark:bg-zinc-900 sticky top-0 z-10">
              <tr>
                <th className="w-10 px-2.5 py-2 border-b border-r border-zinc-200 dark:border-zinc-800 font-mono text-[11px] text-zinc-400 text-center">
                  #
                </th>
                {Array.from({ length: maxCols }).map((_, cIdx) => (
                  <th
                    key={cIdx}
                    className="px-3 py-2 border-b border-r border-zinc-200 dark:border-zinc-800 font-mono text-[11px] font-semibold text-zinc-500 dark:text-zinc-400"
                  >
                    {colLetter(cIdx)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, rIdx) => (
                <tr
                  key={rIdx}
                  className={
                    rIdx === 0
                      ? 'bg-zinc-50/70 dark:bg-zinc-900/40 font-semibold'
                      : 'hover:bg-zinc-50 dark:hover:bg-zinc-900/30'
                  }
                >
                  <td className="px-2.5 py-2 border-b border-r border-zinc-200 dark:border-zinc-800 font-mono text-[11px] text-zinc-400 text-center tabular-nums">
                    {rIdx + 1}
                  </td>
                  {Array.from({ length: maxCols }).map((_, cIdx) => {
                    const val = String(row[cIdx] ?? '');
                    const isMatch = q && val.toLowerCase().includes(q);
                    return (
                      <td
                        key={cIdx}
                        className={`px-3 py-2 border-b border-r border-zinc-200 dark:border-zinc-800 whitespace-nowrap tabular-nums ${
                          isMatch
                            ? 'bg-[#2563EB]/15 text-[#2563EB] dark:text-blue-400 font-semibold'
                            : 'text-[#09090B] dark:text-[#FAFAFA]'
                        }`}
                      >
                        {val}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
