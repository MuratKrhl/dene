import React, { useEffect, useState } from 'react';
import JSZip from 'jszip';
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut } from 'lucide-react';
import { DocFormat } from '../types';

interface PowerPointViewerProps {
  buffer: ArrayBuffer;
  filename: string;
  extension?: DocFormat;
  onDownload: () => void;
}

interface ParsedSlide {
  number: number;
  title: string;
  bullets: string[];
  notes: string;
}

export const PowerPointViewer: React.FC<PowerPointViewerProps> = ({
  buffer,
  filename,
  extension,
  onDownload,
}) => {
  const [slides, setSlides] = useState<ParsedSlide[]>([]);
  const [activeIdx, setActiveIdx] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [error, setError] = useState('');

  useEffect(() => {
    if (extension === 'PPT') {
      setError(
        'Legacy binary .PPT decks require a server-side LibreOffice conversion route. Download the original file to view locally.'
      );
      return;
    }

    let cancelled = false;
    setError('');

    const parse = async () => {
      try {
        const zip = await JSZip.loadAsync(buffer);
        const slideFiles = Object.keys(zip.files)
          .filter((k) => /^ppt\/slides\/slide\d+\.xml$/i.test(k))
          .sort((a, b) => {
            const na = parseInt(a.match(/\d+/)?.[0] || '0', 10);
            const nb = parseInt(b.match(/\d+/)?.[0] || '0', 10);
            return na - nb;
          });

        const parser = new DOMParser();
        const parsed: ParsedSlide[] = [];

        for (let idx = 0; idx < slideFiles.length; idx++) {
          const slideXml = await zip.files[slideFiles[idx]].async('text');
          const xmlDoc = parser.parseFromString(slideXml, 'application/xml');
          const shapes = Array.from(xmlDoc.getElementsByTagName('p:sp'));
          const texts: string[] = [];

          shapes.forEach((sp) => {
            const paras = Array.from(sp.getElementsByTagName('a:p'));
            paras.forEach((p) => {
              const runs = Array.from(p.getElementsByTagName('a:t'))
                .map((t) => t.textContent || '')
                .join('')
                .trim();
              if (runs) texts.push(runs);
            });
          });

          const noteKey = `ppt/notesSlides/notesSlide${idx + 1}.xml`;
          let notes = '';
          if (zip.files[noteKey]) {
            const noteXml = await zip.files[noteKey].async('text');
            const noteDoc = parser.parseFromString(noteXml, 'application/xml');
            notes = Array.from(noteDoc.getElementsByTagName('a:t'))
              .map((t) => t.textContent || '')
              .join(' ')
              .trim();
          }

          parsed.push({
            number: idx + 1,
            title: texts[0] || `Slide ${idx + 1}`,
            bullets: texts.slice(1),
            notes,
          });
        }

        if (!cancelled) {
          setSlides(parsed);
          setActiveIdx(0);
        }
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof Error ? err.message : `Unable to parse ${filename}.`
          );
        }
      }
    };

    parse();
    return () => {
      cancelled = true;
    };
  }, [buffer, extension, filename]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        setActiveIdx((i) => Math.min(slides.length - 1, i + 1));
      } else if (e.key === 'ArrowLeft') {
        setActiveIdx((i) => Math.max(0, i - 1));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [slides.length]);

  if (error) {
    return (
      <div className="max-w-lg mx-auto my-12 p-6 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 text-center space-y-3">
        <p className="text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
          {extension === 'PPT' ? 'Legacy .PPT Format Notice' : 'Presentation Parse Error'}
        </p>
        <p className="text-xs text-zinc-600 dark:text-zinc-400">{error}</p>
        <button
          type="button"
          onClick={onDownload}
          className="px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] text-white cursor-pointer"
        >
          Download Original File
        </button>
      </div>
    );
  }

  if (slides.length === 0) {
    return (
      <div className="p-12 text-center text-xs text-zinc-500">
        No slides detected in {filename}.
      </div>
    );
  }

  const current = slides[activeIdx];

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 sm:px-6 py-2.5 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] flex items-center justify-between gap-3 text-xs shrink-0">
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={activeIdx <= 0}
            onClick={() => setActiveIdx((i) => Math.max(0, i - 1))}
            aria-label="Previous slide"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 disabled:opacity-40 cursor-pointer"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono tabular-nums text-zinc-700 dark:text-zinc-300">
            Slide {activeIdx + 1} / {slides.length}
          </span>
          <button
            type="button"
            disabled={activeIdx >= slides.length - 1}
            onClick={() => setActiveIdx((i) => Math.min(slides.length - 1, i + 1))}
            aria-label="Next slide"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 disabled:opacity-40 cursor-pointer"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <span className="hidden sm:inline text-[11px] text-zinc-500 dark:text-zinc-400">
            OOXML Slide Extractor · Arrow keys supported
          </span>
          <div className="flex items-center gap-1 pl-2 border-l border-zinc-200 dark:border-zinc-800">
            <button
              type="button"
              onClick={() =>
                setZoom((z) => Math.max(0.7, Number((z - 0.1).toFixed(2))))
              }
              aria-label="Zoom out"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono w-10 text-center tabular-nums">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() =>
                setZoom((z) => Math.min(1.5, Number((z + 0.1).toFixed(2))))
              }
              aria-label="Zoom in"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 bg-zinc-100 dark:bg-zinc-950">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Thumbnail rail */}
          <div className="lg:col-span-3 space-y-2.5 max-h-[70vh] overflow-y-auto pr-1">
            {slides.map((sl, idx) => (
              <button
                key={sl.number}
                type="button"
                onClick={() => setActiveIdx(idx)}
                className={`w-full p-3.5 rounded-xl border text-left transition-colors cursor-pointer space-y-1 ${
                  activeIdx === idx
                    ? 'bg-white dark:bg-[#111114] border-[#2563EB] dark:border-blue-500 shadow-xs'
                    : 'bg-white/80 dark:bg-zinc-900/60 border-zinc-200 dark:border-zinc-800 hover:border-zinc-300'
                }`}
              >
                <div className="text-[10px] font-mono text-zinc-400 tabular-nums">
                  Slide {sl.number}
                </div>
                <div className="text-xs font-medium text-[#09090B] dark:text-[#FAFAFA] line-clamp-2">
                  {sl.title}
                </div>
              </button>
            ))}
          </div>

          {/* Active slide stage */}
          <div className="lg:col-span-9 space-y-4">
            <div
              className="aspect-[16/9] w-full rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 shadow-md p-8 sm:p-14 flex flex-col justify-between overflow-auto"
              style={{ fontSize: `${Math.round(zoom * 100)}%` }}
            >
              <div className="space-y-6">
                <div className="text-xs font-mono text-[#2563EB] dark:text-blue-400 tabular-nums">
                  SLIDE {current.number} OF {slides.length}
                </div>
                <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
                  {current.title}
                </h2>
                <ul className="space-y-3 text-sm sm:text-base text-zinc-700 dark:text-zinc-300">
                  {current.bullets.map((b, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <span className="text-[#2563EB] dark:text-blue-400 mt-0.5">—</span>
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-6 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between text-[11px] text-zinc-400">
                <span>{filename}</span>
                <span>OOXML Slide Renderer</span>
              </div>
            </div>

            {current.notes && (
              <div className="p-4 rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
                <span className="font-semibold text-[#09090B] dark:text-[#FAFAFA] mr-2">
                  Speaker Notes:
                </span>
                {current.notes}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
