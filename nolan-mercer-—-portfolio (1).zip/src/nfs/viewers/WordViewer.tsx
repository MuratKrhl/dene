import React, { useEffect, useState } from 'react';
import mammoth from 'mammoth';
import { ZoomIn, ZoomOut } from 'lucide-react';
import { DocFormat } from '../types';

interface WordViewerProps {
  buffer: ArrayBuffer;
  filename: string;
  extension?: DocFormat;
  onDownload: () => void;
}

export const WordViewer: React.FC<WordViewerProps> = ({
  buffer,
  filename,
  extension,
  onDownload,
}) => {
  const [html, setHtml] = useState('');
  const [zoom, setZoom] = useState(1);
  const [error, setError] = useState('');

  useEffect(() => {
    if (extension === 'DOC') {
      setHtml('');
      setError(
        'Legacy binary .DOC files require a server-side LibreOffice conversion worker for full layout fidelity. Download the original file to open in Microsoft Word.'
      );
      return;
    }

    let cancelled = false;
    setError('');
    mammoth
      .convertToHtml({ arrayBuffer: buffer.slice(0) })
      .then((res) => {
        if (!cancelled) setHtml(res.value);
      })
      .catch((err) => {
        if (!cancelled) {
          setError(
            err instanceof Error
              ? err.message
              : `Unable to parse ${filename} via Mammoth.js.`
          );
        }
      });

    return () => {
      cancelled = true;
    };
  }, [buffer, extension, filename]);

  if (error) {
    return (
      <div className="max-w-lg mx-auto my-12 p-6 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 text-center space-y-3">
        <p className="text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
          {extension === 'DOC' ? 'Legacy .DOC Format Notice' : 'Document Parse Error'}
        </p>
        <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
          {error}
        </p>
        <button
          type="button"
          onClick={onDownload}
          className="px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] text-white cursor-pointer"
        >
          Download Original File
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 sm:px-6 py-2.5 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] flex items-center justify-between gap-3 text-xs shrink-0">
        <span className="text-zinc-500 dark:text-zinc-400">
          OOXML Word Renderer (Mammoth.js) · Headings, paragraphs, tables &amp; inline formatting
        </span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() =>
              setZoom((z) => Math.max(0.7, Number((z - 0.1).toFixed(2))))
            }
            aria-label="Zoom out"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono w-11 text-center tabular-nums">
            {Math.round(zoom * 100)}%
          </span>
          <button
            type="button"
            onClick={() =>
              setZoom((z) => Math.min(1.6, Number((z + 0.1).toFixed(2))))
            }
            aria-label="Zoom in"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 sm:p-10 bg-zinc-100 dark:bg-zinc-950">
        <article
          className="mx-auto max-w-3xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl shadow-sm p-8 sm:p-14 text-[#09090B] dark:text-[#FAFAFA] space-y-4 [&_h1]:font-display [&_h1]:text-2xl [&_h1]:font-bold [&_h2]:font-display [&_h2]:text-lg [&_h2]:font-semibold [&_h2]:pt-4 [&_p]:text-sm [&_p]:leading-relaxed [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5 [&_img]:max-w-full [&_img]:rounded-lg [&_table]:w-full [&_table]:border-collapse [&_table]:my-4 [&_td]:border [&_td]:border-zinc-200 [&_td]:dark:border-zinc-800 [&_td]:p-2.5 [&_td]:text-xs [&_th]:border [&_th]:p-2.5"
          style={{ fontSize: `${Math.round(zoom * 100)}%` }}
          dangerouslySetInnerHTML={{ __html: html }}
        />
      </div>
    </div>
  );
};
