import React, { useMemo, useState } from 'react';
import Papa from 'papaparse';
import {
  ArrowDownUp,
  ChevronLeft,
  ChevronRight,
  Search,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { DocFormat } from '../types';

interface CSVViewerProps {
  buffer: ArrayBuffer;
  filename: string;
  extension?: DocFormat;
}

const PAGE_SIZE = 100;

export const CSVViewer: React.FC<CSVViewerProps> = ({
  buffer,
  filename,
  extension,
}) => {
  const [encoding, setEncoding] = useState<'utf-8' | 'iso-8859-1'>('utf-8');
  const [hasHeaderRow, setHasHeaderRow] = useState(true);
  const [search, setSearch] = useState('');
  const [sortCol, setSortCol] = useState<number | null>(null);
  const [sortAsc, setSortAsc] = useState(true);
  const [page, setPage] = useState(0);
  const [zoom, setZoom] = useState(1);

  const parsed = useMemo(() => {
    const decoder = new TextDecoder(encoding);
    const text = decoder.decode(buffer);
    const result = Papa.parse<string[]>(text, {
      delimiter: extension === 'TSV' ? '\t' : '', // Auto-detect for CSV
      header: false,
      skipEmptyLines: true,
      dynamicTyping: false, // Preserve leading zeros & raw strings
    });
    return {
      rows: result.data || [],
      delimiter: result.meta?.delimiter || (extension === 'TSV' ? '\t' : ','),
      errors: result.errors || [],
    };
  }, [buffer, encoding, extension]);

  const headers = useMemo(() => {
    if (parsed.rows.length === 0) return [];
    if (hasHeaderRow) return parsed.rows[0];
    const maxLen = parsed.rows.reduce((m, r) => Math.max(m, r.length), 0);
    return Array.from({ length: maxLen }, (_, idx) => `Column ${idx + 1}`);
  }, [parsed.rows, hasHeaderRow]);

  const bodyRows = useMemo(() => {
    const base = hasHeaderRow ? parsed.rows.slice(1) : parsed.rows;
    const q = search.trim().toLowerCase();
    let filtered = q
      ? base.filter((r) => r.some((cell) => String(cell ?? '').toLowerCase().includes(q)))
      : base;

    if (sortCol !== null) {
      filtered = [...filtered].sort((a, b) => {
        const va = String(a[sortCol] ?? '');
        const vb = String(b[sortCol] ?? '');
        const cmp = va.localeCompare(vb, undefined, { numeric: false });
        return sortAsc ? cmp : -cmp;
      });
    }

    return filtered;
  }, [parsed.rows, hasHeaderRow, search, sortCol, sortAsc]);

  const totalPages = Math.max(1, Math.ceil(bodyRows.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);
  const pageRows = bodyRows.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE);

  const handleSort = (colIdx: number) => {
    if (sortCol === colIdx) {
      setSortAsc((a) => !a);
    } else {
      setSortCol(colIdx);
      setSortAsc(true);
    }
    setPage(0);
  };

  const delimiterLabel =
    parsed.delimiter === '\t'
      ? 'TAB (\\t)'
      : parsed.delimiter === ';'
        ? 'Semicolon (;)'
        : parsed.delimiter === '|'
          ? 'Pipe (|)'
          : 'Comma (,)';

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 sm:px-6 py-2.5 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-mono text-[11px] text-zinc-600 dark:text-zinc-400 tabular-nums">
            Papa Parse · Delimiter: {delimiterLabel} · {bodyRows.length} rows
          </span>

          <label className="inline-flex items-center gap-1.5 text-zinc-700 dark:text-zinc-300 cursor-pointer">
            <input
              type="checkbox"
              checked={hasHeaderRow}
              onChange={(e) => {
                setHasHeaderRow(e.target.checked);
                setPage(0);
              }}
            />
            <span>Header row</span>
          </label>

          <select
            aria-label="Character encoding"
            value={encoding}
            onChange={(e) => setEncoding(e.target.value as 'utf-8' | 'iso-8859-1')}
            className="px-2 py-1 rounded-md bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
          >
            <option value="utf-8">UTF-8</option>
            <option value="iso-8859-1">ISO-8859-1</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-48">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(0);
              }}
              placeholder="Filter rows..."
              aria-label="Filter CSV rows"
              className="w-full pl-8 pr-2 py-1 text-xs rounded-md bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            />
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              disabled={safePage <= 0}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              aria-label="Previous page"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono text-[11px] tabular-nums px-1">
              {safePage + 1}/{totalPages}
            </span>
            <button
              type="button"
              disabled={safePage >= totalPages - 1}
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              aria-label="Next page"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 disabled:opacity-40 cursor-pointer"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center gap-1 pl-2 border-l border-zinc-200 dark:border-zinc-800">
            <button
              type="button"
              onClick={() =>
                setZoom((z) => Math.max(0.75, Number((z - 0.1).toFixed(2))))
              }
              aria-label="Zoom out"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono w-10 text-center tabular-nums">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() =>
                setZoom((z) => Math.min(1.5, Number((z + 0.1).toFixed(2))))
              }
              aria-label="Zoom in"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4 sm:p-6 bg-zinc-100 dark:bg-zinc-950">
        {parsed.rows.length === 0 ? (
          <div className="max-w-md mx-auto my-12 p-6 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 text-center text-xs text-zinc-500">
            No tabular records detected in {filename}.
          </div>
        ) : (
          <div
            className="rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-auto max-w-full"
            style={{ fontSize: `${Math.round(zoom * 12)}px` }}
          >
            <table className="w-full border-collapse text-left">
              <thead className="bg-zinc-50 dark:bg-zinc-900 sticky top-0 z-10">
                <tr>
                  <th className="w-12 px-3 py-2.5 border-b border-r border-zinc-200 dark:border-zinc-800 font-mono text-[11px] text-zinc-400 text-center">
                    #
                  </th>
                  {headers.map((col, idx) => (
                    <th
                      key={idx}
                      className="px-3 py-2.5 border-b border-r border-zinc-200 dark:border-zinc-800 font-semibold text-zinc-700 dark:text-zinc-200 whitespace-nowrap"
                    >
                      <button
                        type="button"
                        onClick={() => handleSort(idx)}
                        className="inline-flex items-center gap-1.5 hover:text-[#2563EB] dark:hover:text-blue-400 cursor-pointer"
                      >
                        <span>{col || `Col ${idx + 1}`}</span>
                        <ArrowDownUp className="w-3 h-3 text-zinc-400" />
                      </button>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {pageRows.map((row, rIdx) => {
                  const rowNum = safePage * PAGE_SIZE + rIdx + 1;
                  const q = search.trim().toLowerCase();
                  return (
                    <tr
                      key={rowNum}
                      className="hover:bg-zinc-50 dark:hover:bg-zinc-900/30"
                    >
                      <td className="px-3 py-2 border-b border-r border-zinc-200 dark:border-zinc-800 font-mono text-[11px] text-zinc-400 text-center tabular-nums">
                        {rowNum}
                      </td>
                      {headers.map((_, cIdx) => {
                        const rawVal = String(row[cIdx] ?? '');
                        const match = q && rawVal.toLowerCase().includes(q);
                        return (
                          <td
                            key={cIdx}
                            className={`px-3 py-2 border-b border-r border-zinc-200 dark:border-zinc-800 whitespace-nowrap font-mono text-[12px] tabular-nums ${
                              match
                                ? 'bg-[#2563EB]/15 text-[#2563EB] dark:text-blue-400 font-semibold'
                                : 'text-[#09090B] dark:text-[#FAFAFA]'
                            }`}
                          >
                            {rawVal}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
