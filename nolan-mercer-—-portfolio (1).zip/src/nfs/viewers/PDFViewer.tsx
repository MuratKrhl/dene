import React, { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import {
  ChevronLeft,
  ChevronRight,
  Search,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

interface PDFViewerProps {
  buffer: ArrayBuffer;
  filename: string;
}

export const PDFViewer: React.FC<PDFViewerProps> = ({ buffer, filename }) => {
  const [pdfDoc, setPdfDoc] = useState<pdfjsLib.PDFDocumentProxy | null>(null);
  const [pageNum, setPageNum] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [pageTexts, setPageTexts] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [parseError, setParseError] = useState('');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let cancelled = false;
    setParseError('');
    setPdfDoc(null);
    setPageNum(1);
    setTotalPages(0);
    setPageTexts([]);

    const load = async () => {
      try {
        const doc = await pdfjsLib.getDocument({ data: buffer.slice(0) }).promise;
        if (cancelled) return;
        setPdfDoc(doc);
        setTotalPages(doc.numPages);

        const extracted: string[] = [];
        for (let i = 1; i <= doc.numPages; i++) {
          const page = await doc.getPage(i);
          const content = await page.getTextContent();
          const txt = content.items
            .map((item) => ('str' in item ? item.str : ''))
            .join(' ');
          extracted.push(txt);
        }
        if (!cancelled) setPageTexts(extracted);
      } catch (err) {
        if (!cancelled) {
          setParseError(
            err instanceof Error ? err.message : `Unable to render ${filename}.`
          );
        }
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [buffer, filename]);

  useEffect(() => {
    if (!pdfDoc || !canvasRef.current) return;
    let renderTask: pdfjsLib.RenderTask | null = null;
    let cancelled = false;

    const renderPage = async () => {
      try {
        const page = await pdfDoc.getPage(pageNum);
        if (cancelled || !canvasRef.current) return;
        const viewport = page.getViewport({ scale: 1.35 * zoom });
        const canvas = canvasRef.current;
        const context = canvas.getContext('2d');
        if (!context) return;

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        renderTask = page.render({
          canvasContext: context,
          viewport,
          canvas,
        });
        await renderTask.promise;
      } catch {
        // Cancelled on rapid zoom/page switch
      }
    };

    renderPage();
    return () => {
      cancelled = true;
      renderTask?.cancel();
    };
  }, [pdfDoc, pageNum, zoom]);

  const handleFitWidth = () => {
    if (!containerRef.current) return;
    const avail = Math.max(320, containerRef.current.clientWidth - 64);
    const baseWidth = 612 * 1.35;
    setZoom(Math.max(0.5, Math.min(2.2, Number((avail / baseWidth).toFixed(2)))));
  };

  const handleFitPage = () => {
    setZoom(0.92);
  };

  const matchedPages = searchQuery.trim()
    ? pageTexts
        .map((txt, idx) =>
          txt.toLowerCase().includes(searchQuery.trim().toLowerCase()) ? idx + 1 : -1
        )
        .filter((n) => n > 0)
    : [];

  if (parseError) {
    return (
      <div className="max-w-lg mx-auto my-12 p-6 rounded-2xl bg-white dark:bg-[#111114] border border-red-200 dark:border-red-900/50 text-center space-y-2">
        <p className="text-sm font-semibold text-red-600 dark:text-red-400">
          PDF Rendering Error
        </p>
        <p className="text-xs text-zinc-600 dark:text-zinc-400">{parseError}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Sub-toolbar */}
      <div className="px-4 sm:px-6 py-2.5 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={pageNum <= 1}
            onClick={() => setPageNum((p) => Math.max(1, p - 1))}
            aria-label="Previous page"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 disabled:opacity-40 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono tabular-nums text-zinc-700 dark:text-zinc-300">
            Page {pageNum} / {totalPages || 1}
          </span>
          <button
            type="button"
            disabled={pageNum >= totalPages}
            onClick={() => setPageNum((p) => Math.min(totalPages, p + 1))}
            aria-label="Next page"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 disabled:opacity-40 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-48">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search in PDF..."
              aria-label="Search text inside PDF"
              className="w-full pl-8 pr-2 py-1 text-xs rounded-md bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
            />
          </div>

          {matchedPages.length > 0 && (
            <div className="flex items-center gap-1">
              <span className="text-[11px] text-zinc-500">Hits:</span>
              {matchedPages.map((pg) => (
                <button
                  key={pg}
                  type="button"
                  onClick={() => setPageNum(pg)}
                  className={`px-1.5 py-0.5 rounded font-mono text-[11px] cursor-pointer ${
                    pg === pageNum
                      ? 'bg-[#2563EB] text-white'
                      : 'bg-[#2563EB]/10 text-[#2563EB] dark:text-blue-400'
                  }`}
                >
                  p.{pg}
                </button>
              ))}
            </div>
          )}

          <button
            type="button"
            onClick={handleFitWidth}
            className="px-2.5 py-1 rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            Fit Width
          </button>
          <button
            type="button"
            onClick={handleFitPage}
            className="px-2.5 py-1 rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            Fit Page
          </button>

          <div className="flex items-center gap-1 pl-2 border-l border-zinc-200 dark:border-zinc-800">
            <button
              type="button"
              onClick={() =>
                setZoom((z) => Math.max(0.5, Number((z - 0.15).toFixed(2))))
              }
              aria-label="Zoom out"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono w-11 text-center tabular-nums">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() =>
                setZoom((z) => Math.min(2.2, Number((z + 0.15).toFixed(2))))
              }
              aria-label="Zoom in"
              className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Document Canvas Surface */}
      <div
        ref={containerRef}
        className="flex-1 overflow-auto p-6 sm:p-10 bg-zinc-100 dark:bg-zinc-950 flex flex-col items-center gap-6"
      >
        <div className="rounded-lg shadow-lg overflow-hidden bg-white border border-zinc-200 dark:border-zinc-800">
          <canvas ref={canvasRef} className="block max-w-full h-auto" />
        </div>

        {pageTexts[pageNum - 1] && (
          <details className="w-full max-w-3xl rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-4 text-xs">
            <summary className="cursor-pointer font-medium text-zinc-700 dark:text-zinc-300">
              Selectable Extracted Text (Page {pageNum})
            </summary>
            <p className="mt-3 text-zinc-600 dark:text-zinc-400 leading-relaxed select-text">
              {pageTexts[pageNum - 1]}
            </p>
          </details>
        )}
      </div>
    </div>
  );
};
