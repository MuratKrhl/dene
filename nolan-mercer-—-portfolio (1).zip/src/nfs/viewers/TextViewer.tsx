import React, { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { DocFormat } from '../types';

interface TextViewerProps {
  buffer: ArrayBuffer;
  filename: string;
  extension?: DocFormat;
}

export const TextViewer: React.FC<TextViewerProps> = ({
  buffer,
  filename,
  extension,
}) => {
  const [prettyJson, setPrettyJson] = useState(true);
  const [renderMarkdown, setRenderMarkdown] = useState(true);
  const [search, setSearch] = useState('');

  const rawText = useMemo(() => new TextDecoder('utf-8').decode(buffer), [buffer]);

  const displayText = useMemo(() => {
    if (extension === 'JSON' && prettyJson) {
      try {
        return JSON.stringify(JSON.parse(rawText), null, 2);
      } catch {
        return rawText;
      }
    }
    return rawText;
  }, [rawText, extension, prettyJson]);

  const lines = useMemo(() => displayText.split(/\r?\n/), [displayText]);
  const q = search.trim().toLowerCase();

  const renderMarkdownBlocks = () => {
    return lines.map((line, i) => {
      if (line.startsWith('# ')) {
        return (
          <h1
            key={i}
            className="font-display text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] pt-2"
          >
            {line.slice(2)}
          </h1>
        );
      }
      if (line.startsWith('## ')) {
        return (
          <h2
            key={i}
            className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA] pt-4"
          >
            {line.slice(3)}
          </h2>
        );
      }
      if (line.startsWith('- ')) {
        return (
          <div key={i} className="flex items-start gap-2.5 text-sm text-zinc-700 dark:text-zinc-300 pl-2">
            <span className="text-[#2563EB] dark:text-blue-400">—</span>
            <span>{line.slice(2)}</span>
          </div>
        );
      }
      if (!line.trim()) return <div key={i} className="h-2" />;
      return (
        <p key={i} className="text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed">
          {line}
        </p>
      );
    });
  };

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 sm:px-6 py-2.5 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
        <div className="flex items-center gap-3">
          <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
            {extension} · {lines.length} lines · UTF-8
          </span>
          {extension === 'JSON' && (
            <button
              type="button"
              onClick={() => setPrettyJson((p) => !p)}
              className="px-2.5 py-1 rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
            >
              {prettyJson ? 'View Raw' : 'Format JSON'}
            </button>
          )}
          {extension === 'MD' && (
            <button
              type="button"
              onClick={() => setRenderMarkdown((r) => !r)}
              className="px-2.5 py-1 rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
            >
              {renderMarkdown ? 'View Source' : 'Rendered Preview'}
            </button>
          )}
        </div>

        <div className="relative w-52">
          <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`Search in ${filename}...`}
            aria-label="Search text content"
            className="w-full pl-8 pr-2 py-1 text-xs rounded-md bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
          />
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 sm:p-8 bg-zinc-100 dark:bg-zinc-950">
        {extension === 'MD' && renderMarkdown ? (
          <article className="mx-auto max-w-3xl rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-8 sm:p-12 space-y-2">
            {renderMarkdownBlocks()}
          </article>
        ) : (
          <div className="mx-auto max-w-5xl rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-x-auto">
            <table className="w-full border-collapse font-mono text-xs">
              <tbody>
                {lines.map((line, idx) => {
                  const isMatch = q && line.toLowerCase().includes(q);
                  return (
                    <tr
                      key={idx}
                      className={
                        isMatch
                          ? 'bg-[#2563EB]/12 dark:bg-blue-500/15'
                          : 'hover:bg-zinc-50 dark:hover:bg-zinc-900/40'
                      }
                    >
                      <td className="w-12 select-none px-3 py-1 text-right text-zinc-400 border-r border-zinc-200 dark:border-zinc-800 tabular-nums">
                        {idx + 1}
                      </td>
                      <td className="px-4 py-1 whitespace-pre text-[#09090B] dark:text-[#FAFAFA]">
                        {line || ' '}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
