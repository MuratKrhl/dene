import React, { useEffect, useState } from 'react';
import { ZoomIn, ZoomOut } from 'lucide-react';
import { DocFormat } from '../types';
import { getMimeType } from '../sampleDocuments';

interface ImageViewerProps {
  buffer: ArrayBuffer;
  filename: string;
  extension?: DocFormat;
}

export const ImageViewer: React.FC<ImageViewerProps> = ({
  buffer,
  filename,
  extension,
}) => {
  const [objectUrl, setObjectUrl] = useState('');
  const [zoom, setZoom] = useState(1);
  const [dims, setDims] = useState<{ w: number; h: number } | null>(null);

  useEffect(() => {
    const blob = new Blob([buffer], { type: getMimeType(extension) });
    const url = URL.createObjectURL(blob);
    setObjectUrl(url);
    return () => {
      URL.revokeObjectURL(url);
    };
  }, [buffer, extension]);

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 sm:px-6 py-2.5 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] flex items-center justify-between gap-3 text-xs shrink-0">
        <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
          {extension} Image {dims ? `· ${dims.w} × ${dims.h}px` : ''}
        </span>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setZoom(1)}
            className="px-2.5 py-1 rounded-md border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            Reset 100%
          </button>
          <button
            type="button"
            onClick={() =>
              setZoom((z) => Math.max(0.4, Number((z - 0.15).toFixed(2))))
            }
            aria-label="Zoom out"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 cursor-pointer"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono w-10 text-center tabular-nums">
            {Math.round(zoom * 100)}%
          </span>
          <button
            type="button"
            onClick={() =>
              setZoom((z) => Math.min(2.5, Number((z + 0.15).toFixed(2))))
            }
            aria-label="Zoom in"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 cursor-pointer"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 sm:p-10 bg-zinc-100 dark:bg-zinc-950 flex items-center justify-center">
        {objectUrl && (
          <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-4 shadow-sm overflow-auto max-w-full">
            <img
              src={objectUrl}
              alt={filename}
              referrerPolicy="no-referrer"
              onLoad={(e) => {
                const img = e.currentTarget;
                setDims({ w: img.naturalWidth, h: img.naturalHeight });
              }}
              style={{ transform: `scale(${zoom})`, transformOrigin: 'center' }}
              className="max-w-full h-auto rounded-lg transition-transform duration-150"
            />
          </div>
        )}
      </div>
    </div>
  );
};
