import { INITIAL_NFS_NODES, INITIAL_NFS_SOURCES } from '../mockData';
import {
  DateFilter,
  DocFormat,
  NfsActivityEntry,
  NfsNavSection,
  NfsNode,
  NfsSortField,
  NfsSortOrder,
  NfsSource,
  NfsViewMode,
  RecentFileEntry,
  SizeFilter,
  TypeFilterGroup,
} from '../types';

const SOURCES_KEY = 'mk-nfs-sources-v2';
const STARRED_KEY = 'mk-nfs-starred-v2';
const RECENT_KEY = 'mk-nfs-recent-v2';
const ACTIVITY_KEY = 'mk-nfs-activity-v2';
const EXPLORER_STATE_KEY = 'mk-nfs-explorer-state-v2';

// Ephemeral in-memory registry for browser-mounted Local Folder files
const localNodesRegistry = new Map<string, NfsNode[]>();

export function detectDocFormat(filename: string): DocFormat {
  const ext = filename.split('.').pop()?.toUpperCase() || '';
  switch (ext) {
    case 'PDF':
    case 'DOCX':
    case 'DOC':
    case 'XLSX':
    case 'XLS':
    case 'PPTX':
    case 'PPT':
    case 'CSV':
    case 'TSV':
    case 'TXT':
    case 'JSON':
    case 'XML':
    case 'MD':
    case 'PNG':
    case 'SVG':
    case 'ZIP':
      return ext;
    case 'YML':
    case 'YAML':
      return 'YAML';
    case 'JPEG':
    case 'JPG':
      return 'JPG';
    case 'WEBP':
      return 'PNG';
    default:
      return 'OTHER';
  }
}

export function registerLocalNodes(sourceId: string, nodes: NfsNode[]) {
  localNodesRegistry.set(sourceId, nodes);
}

export function unregisterLocalNodes(sourceId: string) {
  localNodesRegistry.delete(sourceId);
}

export function loadSources(): NfsSource[] {
  try {
    const raw = localStorage.getItem(SOURCES_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.map((src: NfsSource) => {
          // Security & Honesty guarantee: local_folder without active in-memory File handles cannot claim Connected after reload
          if (src.type === 'local_folder' && !localNodesRegistry.has(src.id)) {
            return { ...src, status: 'Disconnected' };
          }
          return src;
        });
      }
    }
  } catch {
    // Fallback to initial sources
  }
  return INITIAL_NFS_SOURCES;
}

export function saveSources(sources: NfsSource[]) {
  try {
    localStorage.setItem(SOURCES_KEY, JSON.stringify(sources));
  } catch {
    // Ignore storage errors
  }
}

export function loadStarredIds(): Set<string> {
  try {
    const raw = localStorage.getItem(STARRED_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return new Set(parsed);
    }
  } catch {
    // Ignore
  }
  return new Set(INITIAL_NFS_NODES.filter((n) => n.starred).map((n) => n.id));
}

export function saveStarredIds(ids: Set<string>) {
  try {
    localStorage.setItem(STARRED_KEY, JSON.stringify(Array.from(ids)));
  } catch {
    // Ignore
  }
}

export function loadRecentEntries(): RecentFileEntry[] {
  try {
    const raw = localStorage.getItem(RECENT_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // Ignore
  }
  return [
    {
      nodeId: 'file-q4-liquidity-pdf',
      sourceId: 'src-win-finance',
      name: 'Q4-Treasury-Liquidity-Report.pdf',
      path: '\\\\corp-fs01.internal\\finance\\documents\\Q4 Financial Reports\\Q4-Treasury-Liquidity-Report.pdf',
      extension: 'PDF',
      lastOpenedAt: Date.now() - 3600 * 1000 * 2,
      lastOpenedLabel: 'Today · 12:10',
    },
    {
      nodeId: 'file-nfs-tokens-json',
      sourceId: 'src-nfs-workspace',
      name: 'tokens.semantic.json',
      path: '10.0.4.12:/exports/workspace/configs/tokens.semantic.json',
      extension: 'JSON',
      lastOpenedAt: Date.now() - 3600 * 1000 * 5,
      lastOpenedLabel: 'Today · 09:40',
    },
  ];
}

export function recordRecentFile(node: NfsNode): RecentFileEntry[] {
  if (node.kind !== 'file') return loadRecentEntries();
  const existing = loadRecentEntries().filter((r) => r.nodeId !== node.id);
  const now = Date.now();
  const label = new Date(now).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
  const updated: RecentFileEntry[] = [
    {
      nodeId: node.id,
      sourceId: node.sourceId,
      name: node.name,
      path: node.path,
      extension: node.extension,
      lastOpenedAt: now,
      lastOpenedLabel: `Today · ${label}`,
    },
    ...existing,
  ].slice(0, 20);
  try {
    localStorage.setItem(RECENT_KEY, JSON.stringify(updated));
  } catch {
    // Ignore
  }
  return updated;
}

export function loadActivityLog(): NfsActivityEntry[] {
  try {
    const raw = localStorage.getItem(ACTIVITY_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // Ignore
  }
  return [
    {
      id: 'act-init-1',
      timestamp: 'Today · 13:10',
      action: 'Sources Indexed',
      target: '4 storage providers loaded (Demo & Auth-Gated)',
      status: 'info',
    },
  ];
}

export function appendActivityLog(
  action: string,
  target: string,
  status: NfsActivityEntry['status'] = 'ok'
): NfsActivityEntry[] {
  const stamp = new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
  const entry: NfsActivityEntry = {
    id: `act-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: `Today · ${stamp}`,
    action,
    target,
    status,
  };
  const next = [entry, ...loadActivityLog()].slice(0, 30);
  try {
    localStorage.setItem(ACTIVITY_KEY, JSON.stringify(next));
  } catch {
    // Ignore
  }
  return next;
}

export function loadAllNodes(): NfsNode[] {
  const starred = loadStarredIds();
  const combined = [...INITIAL_NFS_NODES];
  localNodesRegistry.forEach((nodes) => {
    combined.push(...nodes);
  });
  return combined.map((n) => ({
    ...n,
    starred: starred.has(n.id),
  }));
}

export function findNodeByRouteParams(
  sourceId: string,
  fileId: string
): { source: NfsSource | undefined; node: NfsNode | undefined } {
  const sources = loadSources();
  const source = sources.find((s) => s.id === sourceId);
  const allNodes = loadAllNodes();
  const node = allNodes.find((n) => n.id === fileId && n.sourceId === sourceId);
  return { source, node };
}

export interface PersistedExplorerState {
  navSection: NfsNavSection;
  activeSourceId: string | null;
  activeFolderId: string | null;
  searchQuery: string;
  typeFilter: TypeFilterGroup;
  dateFilter: DateFilter;
  sizeFilter: SizeFilter;
  sortField: NfsSortField;
  sortOrder: NfsSortOrder;
  viewMode: NfsViewMode;
}

export const DEFAULT_EXPLORER_STATE: PersistedExplorerState = {
  navSection: 'all',
  activeSourceId: null,
  activeFolderId: null,
  searchQuery: '',
  typeFilter: 'All',
  dateFilter: 'all',
  sizeFilter: 'all',
  sortField: 'name',
  sortOrder: 'asc',
  viewMode: 'list',
};

export function saveExplorerState(state: PersistedExplorerState) {
  try {
    sessionStorage.setItem(EXPLORER_STATE_KEY, JSON.stringify(state));
  } catch {
    // Ignore
  }
}

export function loadExplorerState(): PersistedExplorerState {
  try {
    const raw = sessionStorage.getItem(EXPLORER_STATE_KEY);
    if (raw) {
      return { ...DEFAULT_EXPLORER_STATE, ...JSON.parse(raw) };
    }
  } catch {
    // Ignore
  }
  return DEFAULT_EXPLORER_STATE;
}
