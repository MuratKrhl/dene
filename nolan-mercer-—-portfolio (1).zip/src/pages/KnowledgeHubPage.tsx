import React, { useEffect, useState } from 'react';
import { KnowledgeOneNoteTab } from '../components/KnowledgeOneNoteTab';
import { KnowledgeUserManagementTab } from '../components/KnowledgeUserManagementTab';
import { TechKnowledgeHubView } from '../components/technology/TechKnowledgeHubView';
import { TechnologyCenter } from '../components/technology/TechnologyCenter';
import { GitHubExplorer } from '../github/components/GitHubExplorer';
import { GitHubExplorerSubTab } from '../github/types';
import { TechSubTab } from '../types/technology';

export type KnowledgeHubTabKey =
  | 'onenote'
  | 'blog'
  | 'technology'
  | 'github'
  | 'user-management';

interface KnowledgeHubPageProps {
  onNavigate: (path: string) => void;
  initialTab?: KnowledgeHubTabKey;
  githubSubTab?: GitHubExplorerSubTab;
  technologySubTab?: TechSubTab;
  hubSection?: 'articles' | 'favorites' | 'archive' | 'sources' | 'history' | 'article';
  hubArticleId?: string;
  podcastSeriesId?: string;
  legacyTechPreset?: string;
  showTechSyncHistory?: boolean;
}

const KH_TABS: Array<{ key: KnowledgeHubTabKey; label: string }> = [
  { key: 'onenote', label: 'OneNote' },
  { key: 'blog', label: 'Blog' },
  { key: 'technology', label: 'Technology' },
  { key: 'github', label: 'Github' },
  { key: 'user-management', label: 'User Management' },
];

export const KnowledgeHubPage: React.FC<KnowledgeHubPageProps> = ({
  onNavigate,
  initialTab = 'onenote',
  githubSubTab,
  technologySubTab,
  hubSection,
  hubArticleId,
  podcastSeriesId,
  legacyTechPreset,
  showTechSyncHistory,
}) => {
  const [activeTab, setActiveTab] = useState<KnowledgeHubTabKey>(initialTab);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  const handleSelectTab = (tab: KnowledgeHubTabKey) => {
    setActiveTab(tab);
    if (tab === 'onenote') {
      onNavigate('/knowledge-hub');
    } else if (tab === 'blog') {
      onNavigate('/workspace/blog');
    } else {
      onNavigate(`/knowledge-hub/${tab}`);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-10 space-y-6">
      <header className="text-center max-w-2xl mx-auto space-y-2">
        <p className="text-xs font-medium text-[#2563EB] dark:text-blue-400">
          Knowledge Hub
        </p>
        <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] [text-wrap:balance]">
          OneNote, Blog, Technology, GitHub &amp; Personal Credentials
        </h1>
        <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400 leading-relaxed">
          Structured engineering notebooks, technical articles, multi-source technology intelligence, live GitHub explorer, and personal credentials.
        </p>
      </header>

      {/* Centered Segmented Tabs (Matching Bookmarks tab structure) */}
      <div className="flex justify-center">
        <div
          role="tablist"
          aria-label="Knowledge Hub sections"
          className="inline-flex flex-wrap justify-center items-center gap-1 p-1 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
        >
          {KH_TABS.map((tab) => {
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => handleSelectTab(tab.key)}
                className={`px-5 py-2 text-xs font-medium rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB] ${
                  isActive
                    ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'onenote' && (
        <section aria-label="OneNote Workspace">
          <KnowledgeOneNoteTab onNavigate={onNavigate} />
        </section>
      )}

      {activeTab === 'blog' && (
        <section aria-label="Blog ve Technology Knowledge Hub">
          <TechKnowledgeHubView
            section={hubSection || 'articles'}
            articleId={hubArticleId}
            onNavigate={onNavigate}
          />
        </section>
      )}

      {activeTab === 'technology' && (
        <section aria-label="Technology Intelligence Center">
          <TechnologyCenter
            onNavigate={onNavigate}
            initialSubTab={technologySubTab || 'overview'}
            hubSection={hubSection}
            hubArticleId={hubArticleId}
            initialPodcastSeriesId={podcastSeriesId || null}
            initialLegacyPreset={legacyTechPreset}
            initialShowSyncHistory={showTechSyncHistory}
          />
        </section>
      )}

      {activeTab === 'github' && (
        <section aria-label="GitHub Explorer">
          <GitHubExplorer
            onNavigate={onNavigate}
            initialSubTab={githubSubTab}
          />
        </section>
      )}

      {activeTab === 'user-management' && (
        <section aria-label="User Management Personal Credentials">
          <KnowledgeUserManagementTab />
        </section>
      )}
    </div>
  );
};
