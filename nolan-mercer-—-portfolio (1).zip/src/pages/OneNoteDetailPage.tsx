import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  Check,
  CheckSquare,
  Clock,
  Code2,
  Copy,
  Download,
  ExternalLink,
  Eye,
  FileCode2,
  Globe,
  Heading2,
  Monitor,
  PencilLine,
  Save,
  Star,
} from 'lucide-react';
import {
  OneNoteFileItem,
  OneNoteSource,
  detectOneNoteFileFormat,
  formatOneNoteDate,
  formatOneNoteTimestamp,
  loadOneNoteFiles,
  loadOneNoteSources,
  saveOneNoteFiles,
  saveOneNoteSources,
} from '../services/oneNoteStore';

export const ONENOTE_NEW_CONTEXT_KEY = 'mk-onenote-new-context-v1';

interface OneNoteDetailPageProps {
  fileId?: string;
  onNavigate: (path: string) => void;
}

export const OneNoteDetailPage: React.FC<OneNoteDetailPageProps> = ({
  fileId,
  onNavigate,
}) => {
  const [sources, setSources] = useState<OneNoteSource[]>(() =>
    loadOneNoteSources().filter((s) => s.enabled)
  );
  const [files, setFiles] = useState<OneNoteFileItem[]>(() =>
    loadOneNoteFiles()
  );

  const existingFile = useMemo(
    () => (fileId ? files.find((f) => f.id === fileId) || null : null),
    [files, fileId]
  );

  const initialNewContext = useMemo(() => {
    if (fileId) return null;
    try {
      const raw = sessionStorage.getItem(ONENOTE_NEW_CONTEXT_KEY);
      if (raw) {
        return JSON.parse(raw) as { sourceId?: string; section?: string };
      }
    } catch {
      // Ignore storage error
    }
    return null;
  }, [fileId]);

  const [selectedSourceId, setSelectedSourceId] = useState<string>(() => {
    if (existingFile) return existingFile.sourceId;
    if (
      initialNewContext?.sourceId &&
      sources.some((s) => s.id === initialNewContext.sourceId)
    ) {
      return initialNewContext.sourceId;
    }
    return sources[0]?.id || '';
  });

  const [section, setSection] = useState<string>(() => {
    if (existingFile) return existingFile.section;
    return initialNewContext?.section || 'General Notes';
  });
  const [isCustomSection, setIsCustomSection] = useState<boolean>(false);

  const [title, setTitle] = useState<string>(() =>
    existingFile ? existingFile.title : ''
  );

  const [fileName, setFileName] = useState<string>(() =>
    existingFile ? existingFile.fileName : ''
  );

  const [tagsText, setTagsText] = useState<string>(() =>
    existingFile ? existingFile.tags.join(', ') : ''
  );

  const [content, setContent] = useState<string>(() =>
    existingFile
      ? existingFile.content
      : `# New Engineering Note\n\n- [ ] Add runbook details, commands, or verification steps.\n`
  );

  const [starred, setStarred] = useState<boolean>(() =>
    Boolean(existingFile?.starred)
  );

  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('edit');
  const [savedNotice, setSavedNotice] = useState('');
  const [error, setError] = useState('');
  const [copiedPath, setCopiedPath] = useState(false);

  useEffect(() => {
    if (existingFile) {
      setSelectedSourceId(existingFile.sourceId);
      setSection(existingFile.section);
      setIsCustomSection(false);
      setTitle(existingFile.title);
      setFileName(existingFile.fileName);
      setTagsText(existingFile.tags.join(', '));
      setContent(existingFile.content);
      setStarred(Boolean(existingFile.starred));
    }
  }, [existingFile]);

  const activeSource = useMemo(
    () => sources.find((s) => s.id === selectedSourceId) || sources[0] || null,
    [sources, selectedSourceId]
  );

  const availableSections = useMemo(() => {
    const set = new Set<string>();
    if (activeSource) {
      files
        .filter((f) => f.sourceId === activeSource.id)
        .forEach((f) => {
          if (f.section.trim()) set.add(f.section.trim());
        });
    }
    if (section.trim() && !isCustomSection) {
      set.add(section.trim());
    }
    if (set.size === 0) {
      set.add('General Notes');
    }
    return Array.from(set);
  }, [activeSource, files, section, isCustomSection]);

  const resolvedFileName = useMemo(() => {
    if (fileName.trim()) {
      return fileName.trim().includes('.')
        ? fileName.trim()
        : `${fileName.trim()}.one`;
    }
    const slug = title
      .trim()
      .replace(/[^a-zA-Z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
    return `${slug || 'New-OneNote-Page'}.one`;
  }, [fileName, title]);

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!activeSource) {
      setError('No active OneNote source configured. Add one in Admin > OneNote.');
      return;
    }
    const cleanTitle = title.trim();
    if (!cleanTitle) {
      setError('Please enter a page title.');
      return;
    }

    setError('');
    const cleanSection = section.trim() || 'General Notes';
    const cleanTags = tagsText
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);
    const sep = activeSource.type === 'windows' ? '\\' : '/';
    const today = formatOneNoteDate();

    if (existingFile) {
      const nextVersion = (existingFile.version || 1) + 1;
      const updatedFiles = files.map((f) =>
        f.id === existingFile.id
          ? {
              ...f,
              sourceId: activeSource.id,
              section: cleanSection,
              fileName: resolvedFileName,
              title: cleanTitle,
              relativePath: `${activeSource.name}${sep}${cleanSection}${sep}${resolvedFileName}`,
              fileFormat: detectOneNoteFileFormat(resolvedFileName),
              tags: cleanTags,
              starred,
              content,
              updatedAt: today,
              updatedBy: 'Admin',
              version: nextVersion,
            }
          : f
      );
      setFiles(updatedFiles);
      saveOneNoteFiles(updatedFiles);

      const nextSources = loadOneNoteSources().map((s) =>
        s.id === activeSource.id
          ? { ...s, lastSynced: formatOneNoteTimestamp() }
          : s
      );
      saveOneNoteSources(nextSources);
      setSources(nextSources.filter((s) => s.enabled));
      setSection(cleanSection);
      setIsCustomSection(false);

      setSavedNotice(`Saved v${nextVersion} · ${formatOneNoteTimestamp()}`);
    } else {
      const newId = `on-file-${Date.now()}`;
      const created: OneNoteFileItem = {
        id: newId,
        sourceId: activeSource.id,
        section: cleanSection,
        fileName: resolvedFileName,
        title: cleanTitle,
        relativePath: `${activeSource.name}${sep}${cleanSection}${sep}${resolvedFileName}`,
        fileFormat: detectOneNoteFileFormat(resolvedFileName),
        tags:
          cleanTags.length > 0
            ? cleanTags
            : [activeSource.type === 'windows' ? 'Windows' : 'HTTPS', cleanSection],
        starred,
        content,
        updatedAt: today,
        updatedBy: 'Admin',
        version: 1,
      };

      const nextFiles = [created, ...files];
      setFiles(nextFiles);
      saveOneNoteFiles(nextFiles);

      const nextSources = loadOneNoteSources().map((s) =>
        s.id === activeSource.id
          ? { ...s, lastSynced: formatOneNoteTimestamp() }
          : s
      );
      saveOneNoteSources(nextSources);
      setSources(nextSources.filter((s) => s.enabled));

      try {
        sessionStorage.removeItem(ONENOTE_NEW_CONTEXT_KEY);
      } catch {
        // Ignore
      }

      setSavedNotice(`Page created · ${formatOneNoteTimestamp()}`);
      onNavigate(`/knowledge-hub/onenote/page/${encodeURIComponent(newId)}`);
    }
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  const appendSnippet = (snippet: string) => {
    setViewMode('edit');
    setContent((prev) =>
      prev.endsWith('\n') || prev === '' ? `${prev}${snippet}` : `${prev}\n${snippet}`
    );
  };

  const handleCopyPath = async () => {
    if (!activeSource) return;
    try {
      await navigator.clipboard.writeText(activeSource.location);
      setCopiedPath(true);
      window.setTimeout(() => setCopiedPath(false), 1500);
    } catch {
      setCopiedPath(false);
    }
  };

  const handleExportMarkdown = () => {
    const body = `# ${title || 'Untitled Page'}\nSection: ${section}\nSource: ${
      activeSource?.location || ''
    }\n\n${content}`;
    const blob = new Blob([body], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${resolvedFileName.replace(/\.[^.]+$/, '')}.md`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const handleTogglePreviewCheckbox = (lineIndex: number) => {
    const lines = content.split('\n');
    const line = lines[lineIndex];
    if (!line) return;
    if (line.trimStart().startsWith('- [ ] ')) {
      lines[lineIndex] = line.replace('- [ ] ', '- [x] ');
    } else if (line.trimStart().startsWith('- [x] ')) {
      lines[lineIndex] = line.replace('- [x] ', '- [ ] ');
    } else {
      return;
    }
    setContent(lines.join('\n'));
  };

  return (
    <div className="max-w-[1160px] mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-10 space-y-6">
      {/* Top Breadcrumb & Back Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onNavigate('/knowledge-hub/onenote')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:text-[#09090B] hover:border-zinc-300 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Back to OneNote</span>
          </button>

          <div className="hidden sm:flex items-center gap-2 text-xs text-zinc-500">
            <span>Knowledge Hub</span>
            <span>/</span>
            <span>OneNote</span>
            <span>/</span>
            <span className="font-medium text-[#09090B]">
              {existingFile ? existingFile.fileName : 'New Page'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {activeSource && (
            <button
              type="button"
              onClick={handleCopyPath}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:border-zinc-300 cursor-pointer"
            >
              {copiedPath ? (
                <Check className="w-3.5 h-3.5 text-[#2563EB]" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>{copiedPath ? 'Path Copied' : 'Copy Address'}</span>
            </button>
          )}

          {activeSource?.type === 'https' && (
            <a
              href={activeSource.location}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-[#2563EB] hover:border-[#2563EB]"
            >
              <span>Open HTTPS</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}

          <button
            type="button"
            onClick={handleExportMarkdown}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:border-zinc-300 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export .md</span>
          </button>
        </div>
      </div>

      {/* Main Dedicated Full-Page OneNote Editor Card */}
      <form
        onSubmit={handleSave}
        className="rounded-2xl bg-white border border-zinc-200 overflow-hidden"
      >
        {/* Header Metadata Bar */}
        <div className="p-5 sm:p-6 bg-[#FAFAFA] border-b border-zinc-200 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-white border border-zinc-200 flex items-center justify-center text-[#2563EB]">
                <BookOpen className="w-4 h-4" aria-hidden="true" />
              </div>
              <div>
                <h1 className="font-display text-lg font-bold text-[#09090B]">
                  {existingFile ? 'Edit OneNote Page' : 'Create New OneNote Page'}
                </h1>
                <p className="text-[11px] text-zinc-500">
                  {activeSource
                    ? `${
                        activeSource.type === 'windows' ? 'Windows Path' : 'HTTPS Source'
                      }: ${activeSource.location}`
                    : 'Select a target Windows or HTTPS notebook'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {savedNotice && (
                <span className="text-xs font-mono text-emerald-700">
                  {savedNotice}
                </span>
              )}

              <button
                type="button"
                onClick={() => setStarred((s) => !s)}
                aria-label={starred ? 'Unstar page' : 'Star page'}
                className={`inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                  starred
                    ? 'border-[#2563EB]/30 bg-[#2563EB]/10 text-[#2563EB]'
                    : 'border-zinc-200 bg-white text-zinc-600 hover:text-[#09090B]'
                }`}
              >
                <Star className={`w-3.5 h-3.5 ${starred ? 'fill-current' : ''}`} />
                <span>{starred ? 'Starred' : 'Star'}</span>
              </button>

              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{existingFile ? 'Save Update' : 'Create & Save Page'}</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 text-xs">
            <div className="sm:col-span-4 space-y-1">
              <label
                htmlFor="on-page-source"
                className="block text-[11px] font-medium text-zinc-600"
              >
                Notebook Source (Windows / HTTPS) *
              </label>
              <div className="relative">
                <select
                  id="on-page-source"
                  value={selectedSourceId}
                  onChange={(e) => {
                    const nextSourceId = e.target.value;
                    setSelectedSourceId(nextSourceId);
                    const nextSections = Array.from(
                      new Set(
                        files
                          .filter((f) => f.sourceId === nextSourceId)
                          .map((f) => f.section.trim())
                          .filter(Boolean)
                      )
                    );
                    if (!isCustomSection) {
                      setSection(nextSections[0] || 'General Notes');
                    }
                  }}
                  className="w-full px-3 py-2 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
                >
                  {sources.map((src) => (
                    <option key={src.id} value={src.id}>
                      [{src.type.toUpperCase()}] {src.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="sm:col-span-3 space-y-1">
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="on-page-section"
                  className="block text-[11px] font-medium text-zinc-600"
                >
                  Section *
                </label>
                {isCustomSection && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsCustomSection(false);
                      setSection(availableSections[0] || 'General Notes');
                    }}
                    className="text-[10px] font-medium text-[#2563EB] hover:underline cursor-pointer"
                  >
                    Select existing
                  </button>
                )}
              </div>
              {isCustomSection ? (
                <input
                  id="on-page-section"
                  type="text"
                  required
                  autoFocus
                  value={section}
                  onChange={(e) => setSection(e.target.value)}
                  placeholder="Enter new section name..."
                  className="w-full px-3 py-2 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B] focus:outline-none focus:border-[#2563EB]"
                />
              ) : (
                <select
                  id="on-page-section"
                  value={section}
                  onChange={(e) => {
                    if (e.target.value === '__new_section__') {
                      setIsCustomSection(true);
                      setSection('');
                    } else {
                      setSection(e.target.value);
                    }
                  }}
                  className="w-full px-3 py-2 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B] focus:outline-none focus:border-[#2563EB]"
                >
                  {availableSections.map((sec) => (
                    <option key={sec} value={sec}>
                      {sec}
                    </option>
                  ))}
                  <option value="__new_section__">+ New Section...</option>
                </select>
              )}
            </div>

            <div className="sm:col-span-3 space-y-1">
              <label
                htmlFor="on-page-filename"
                className="block text-[11px] font-medium text-zinc-600"
              >
                File Name (.one / .md)
              </label>
              <input
                id="on-page-filename"
                type="text"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                placeholder="Auto-generated from title (.one)"
                className="w-full px-3 py-2 text-xs font-mono rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>

            <div className="sm:col-span-2 space-y-1">
              <label
                htmlFor="on-page-tags"
                className="block text-[11px] font-medium text-zinc-600"
              >
                Tags
              </label>
              <input
                id="on-page-tags"
                type="text"
                value={tagsText}
                onChange={(e) => setTagsText(e.target.value)}
                placeholder="Prod, Runbook"
                className="w-full px-3 py-2 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
          </div>

          {error && (
            <p role="alert" className="text-xs font-medium text-red-600">
              {error}
            </p>
          )}
        </div>

        {/* Formatting & View Mode Toolbar */}
        <div className="px-5 sm:px-6 py-3 border-b border-zinc-200 flex flex-wrap items-center justify-between gap-3 bg-white">
          <div className="flex items-center gap-2">
            <div className="inline-flex p-0.5 rounded-lg bg-zinc-100 border border-zinc-200 text-xs">
              <button
                type="button"
                onClick={() => setViewMode('edit')}
                className={`inline-flex items-center gap-1 px-3 py-1 rounded-md font-medium cursor-pointer ${
                  viewMode === 'edit'
                    ? 'bg-white text-[#09090B] shadow-2xs'
                    : 'text-zinc-600'
                }`}
              >
                <PencilLine className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('preview')}
                className={`inline-flex items-center gap-1 px-3 py-1 rounded-md font-medium cursor-pointer ${
                  viewMode === 'preview'
                    ? 'bg-white text-[#09090B] shadow-2xs'
                    : 'text-zinc-600'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Preview</span>
              </button>
            </div>

            <div className="inline-flex items-center gap-1 pl-1">
              <button
                type="button"
                onClick={() => appendSnippet('## Section Heading\n')}
                title="Insert heading"
                className="p-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:text-[#09090B] cursor-pointer"
              >
                <Heading2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => appendSnippet('- [ ] Checklist item')}
                title="Insert checklist item"
                className="p-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:text-[#09090B] cursor-pointer"
              >
                <CheckSquare className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => appendSnippet('```\n# command\n```')}
                title="Insert code snippet"
                className="p-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:text-[#09090B] cursor-pointer"
              >
                <Code2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() =>
                  appendSnippet(`> Updated: ${formatOneNoteTimestamp()}`)
                }
                title="Insert timestamp"
                className="p-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:text-[#09090B] cursor-pointer"
              >
                <Clock className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {activeSource && (
            <div className="inline-flex items-center gap-1.5 text-[11px] font-mono text-zinc-500">
              {activeSource.type === 'windows' ? (
                <Monitor className="w-3.5 h-3.5 text-[#2563EB]" />
              ) : (
                <Globe className="w-3.5 h-3.5 text-emerald-600" />
              )}
              <span>{resolvedFileName}</span>
            </div>
          )}
        </div>

        {/* Document Title & Body */}
        <div className="p-5 sm:p-8 space-y-5">
          <input
            type="text"
            required
            autoFocus={!existingFile}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter OneNote page title..."
            aria-label="OneNote page title"
            className="w-full font-display text-2xl sm:text-3xl font-bold text-[#09090B] placeholder:text-zinc-300 bg-transparent border-b border-zinc-200 pb-3 focus:outline-none focus:border-[#2563EB]"
          />

          {viewMode === 'edit' ? (
            <textarea
              rows={18}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              aria-label="OneNote page content"
              className="w-full p-5 text-sm font-mono leading-relaxed rounded-xl bg-[#FAFAFA] border border-zinc-200 text-[#09090B] focus:outline-none focus:border-[#2563EB]"
            />
          ) : (
            <div className="p-6 rounded-xl bg-[#FAFAFA] border border-zinc-200 space-y-3 text-sm leading-relaxed text-[#09090B] min-h-[380px]">
              {content.split('\n').map((line, idx) => {
                const trimmed = line.trim();
                if (!trimmed) return <div key={idx} className="h-2" />;
                if (trimmed.startsWith('# ')) {
                  return (
                    <h2
                      key={idx}
                      className="font-display text-xl font-bold text-[#09090B] pt-1"
                    >
                      {trimmed.slice(2)}
                    </h2>
                  );
                }
                if (trimmed.startsWith('## ')) {
                  return (
                    <h3
                      key={idx}
                      className="font-display text-base font-semibold text-[#09090B] pt-1"
                    >
                      {trimmed.slice(3)}
                    </h3>
                  );
                }
                if (
                  trimmed.startsWith('- [ ] ') ||
                  trimmed.startsWith('- [x] ')
                ) {
                  const checked = trimmed.startsWith('- [x] ');
                  return (
                    <label
                      key={idx}
                      className="flex items-start gap-2.5 cursor-pointer py-0.5"
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => handleTogglePreviewCheckbox(idx)}
                        className="mt-1 rounded border-zinc-300 cursor-pointer"
                      />
                      <span
                        className={
                          checked
                            ? 'line-through text-zinc-400'
                            : 'text-[#09090B]'
                        }
                      >
                        {trimmed.slice(6)}
                      </span>
                    </label>
                  );
                }
                if (trimmed.startsWith('> ')) {
                  return (
                    <blockquote
                      key={idx}
                      className="pl-3 border-l-2 border-[#2563EB] text-xs font-mono text-zinc-600"
                    >
                      {trimmed.slice(2)}
                    </blockquote>
                  );
                }
                return (
                  <p key={idx} className="text-zinc-800 whitespace-pre-wrap">
                    {line}
                  </p>
                );
              })}
            </div>
          )}

          <div className="pt-3 border-t border-zinc-200 flex flex-wrap items-center justify-between gap-2 text-[11px] text-zinc-500">
            <div className="inline-flex items-center gap-2 font-mono">
              <FileCode2 className="w-3.5 h-3.5 text-zinc-400" />
              <span>
                {activeSource?.name} / {section} / {resolvedFileName}
              </span>
            </div>
            <span className="font-mono">
              {existingFile ? `v${existingFile.version} · ${existingFile.updatedAt}` : 'Draft · Ctrl+S to save'}
            </span>
          </div>
        </div>
      </form>
    </div>
  );
};
