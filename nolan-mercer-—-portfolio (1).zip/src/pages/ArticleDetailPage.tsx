import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ExternalLink,
  ShieldAlert,
  Star,
  Trash2,
} from 'lucide-react';
import { ResilientImage } from '../components/ResilientImage';
import { JOURNAL_ARTICLES } from '../data/portfolioData';
import {
  deleteAggregatedArticleById,
  findAggregatedArticleById,
  formatArticlePublishedDate,
  getAggregatedArticlesSync,
  initializeArticleAggregation,
  setAggregatedArticleRead,
  toggleAggregatedArticleFavorite,
} from '../services/articles/articleAggregator';
import { shouldArchiveAggregatedArticle } from '../services/articles/articleNormalizer';
import { AggregatedArticle } from '../types/article';

interface ArticleDetailPageProps {
  slug: string;
  onNavigate: (path: string) => void;
}

export const ArticleDetailPage: React.FC<ArticleDetailPageProps> = ({
  slug,
  onNavigate,
}) => {
  const decodedSlug = decodeURIComponent(slug);
  const workspaceIndex = JOURNAL_ARTICLES.findIndex(
    (a) => a.slug === decodedSlug || a.slug === slug
  );
  const workspaceArticle =
    workspaceIndex >= 0 ? JOURNAL_ARTICLES[workspaceIndex] : null;

  const [aggregatedArticle, setAggregatedArticle] =
    useState<AggregatedArticle | null>(null);
  const [isLoadingAggregated, setIsLoadingAggregated] = useState(
    !workspaceArticle
  );
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    let active = true;
    setConfirmDelete(false);

    if (workspaceArticle) {
      setAggregatedArticle(null);
      setIsLoadingAggregated(false);
      return;
    }

    setIsLoadingAggregated(true);
    (async () => {
      await initializeArticleAggregation();
      const found = await findAggregatedArticleById(decodedSlug);
      if (!active) return;
      if (found && !found.isRead) {
        const updated = await setAggregatedArticleRead(found.id, true);
        if (!active) return;
        setAggregatedArticle(
          updated.find((a) => a.id === found.id) || { ...found, isRead: true }
        );
      } else {
        setAggregatedArticle(found);
      }
      setIsLoadingAggregated(false);
    })();

    return () => {
      active = false;
    };
  }, [decodedSlug, workspaceArticle]);

  const handleLink = (e: React.MouseEvent, path: string) => {
    e.preventDefault();
    onNavigate(path);
  };

  if (!workspaceArticle && isLoadingAggregated) {
    return (
      <div className="max-w-[760px] mx-auto px-6 py-16 text-center text-sm text-zinc-500">
        Loading article...
      </div>
    );
  }

  // Render aggregated multi-source article detail (Medium, Red Hat, K8s, Security, AI, Dev, etc.)
  if (!workspaceArticle && aggregatedArticle) {
    const allStored = getAggregatedArticlesSync();
    const idx = allStored.findIndex((a) => a.id === aggregatedArticle.id);
    const nextArticle =
      allStored.length > 1
        ? allStored[(Math.max(0, idx) + 1) % allStored.length]
        : null;

    const isArchived =
      aggregatedArticle.isArchived ||
      shouldArchiveAggregatedArticle(aggregatedArticle.publishedAt);

    const categories =
      aggregatedArticle.categories && aggregatedArticle.categories.length > 0
        ? aggregatedArticle.categories
        : [aggregatedArticle.category];

    const sourceNames =
      aggregatedArticle.matchedSourceNames &&
      aggregatedArticle.matchedSourceNames.length > 0
        ? aggregatedArticle.matchedSourceNames.join(' · ')
        : aggregatedArticle.sourceName;

    const paragraphs =
      aggregatedArticle.paragraphs && aggregatedArticle.paragraphs.length > 0
        ? aggregatedArticle.paragraphs
        : aggregatedArticle.contentSnippet
          ? [aggregatedArticle.contentSnippet]
          : [];

    const hasFullContent = Boolean(aggregatedArticle.content);
    const isAdvisory = aggregatedArticle.contentType === 'security-advisory';

    const handleToggleRead = async () => {
      const updated = await setAggregatedArticleRead(
        aggregatedArticle.id,
        !aggregatedArticle.isRead
      );
      setAggregatedArticle(
        updated.find((a) => a.id === aggregatedArticle.id) || aggregatedArticle
      );
    };

    const handleToggleFavorite = async () => {
      const updated = await toggleAggregatedArticleFavorite(
        aggregatedArticle.id
      );
      setAggregatedArticle(
        updated.find((a) => a.id === aggregatedArticle.id) || aggregatedArticle
      );
    };

    const handleExplicitDelete = async () => {
      await deleteAggregatedArticleById(aggregatedArticle.id);
      onNavigate('/knowledge-hub/blog');
    };

    return (
      <article className="max-w-[900px] mx-auto px-6 py-12 lg:py-16">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-3">
          <a
            href="/knowledge-hub/blog"
            onClick={(e) => handleLink(e, '/knowledge-hub/blog')}
            className="inline-flex items-center gap-2 text-xs font-medium text-zinc-600 hover:text-[#09090B] transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Back to Blog</span>
          </a>

          <div className="flex flex-wrap items-center gap-2">
            {isArchived && (
              <span className="px-2.5 py-1 text-[11px] font-medium rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600">
                Archived (&gt;30d)
              </span>
            )}

            <button
              type="button"
              onClick={() => void handleToggleFavorite()}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                aggregatedArticle.isFavorite
                  ? 'border-[#2563EB]/30 bg-[#2563EB]/10 text-[#2563EB]'
                  : 'border-zinc-200 bg-white text-zinc-600 hover:text-[#09090B]'
              }`}
            >
              <Star
                className={`w-3.5 h-3.5 ${
                  aggregatedArticle.isFavorite ? 'fill-current' : ''
                }`}
              />
              <span>
                {aggregatedArticle.isFavorite ? 'Favorited' : 'Favorite'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => void handleToggleRead()}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                aggregatedArticle.isRead
                  ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                  : 'border-zinc-200 bg-white text-zinc-600 hover:text-[#09090B]'
              }`}
            >
              <Check className="w-3.5 h-3.5" />
              <span>{aggregatedArticle.isRead ? 'Read' : 'Mark as Read'}</span>
            </button>

            {confirmDelete ? (
              <div className="inline-flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => void handleExplicitDelete()}
                  className="px-2.5 py-1.5 text-xs font-medium rounded-lg bg-red-600 hover:bg-red-700 text-white transition-colors cursor-pointer"
                >
                  Confirm Delete
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="px-2.5 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-600 hover:text-[#09090B] transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-600 hover:text-red-600 hover:border-red-200 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            )}

            <a
              href={aggregatedArticle.articleUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors"
            >
              <span>Open Original Article</span>
              <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
            </a>
          </div>
        </div>

        <header className="space-y-4 pb-8 border-b border-zinc-200">
          <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
            {isAdvisory && (
              <span className="inline-flex items-center gap-1 font-semibold text-amber-700">
                <ShieldAlert className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Security Advisory</span>
              </span>
            )}
            {isAdvisory && <span aria-hidden="true">·</span>}
            <span className="font-semibold text-[#2563EB]">{sourceNames}</span>
            <span aria-hidden="true">·</span>
            <span className="font-medium text-[#09090B]">
              {categories.join(', ')}
            </span>
            <span aria-hidden="true">·</span>
            <span>
              {aggregatedArticle.publishedAt
                ? formatArticlePublishedDate(aggregatedArticle.publishedAt)
                : 'Publication date not provided'}
            </span>
            {aggregatedArticle.readingTime && (
              <>
                <span aria-hidden="true">·</span>
                <span>{aggregatedArticle.readingTime}</span>
              </>
            )}
          </div>

          <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#09090B] [text-wrap:balance]">
            {aggregatedArticle.title}
          </h1>

          {aggregatedArticle.author && (
            <div className="text-xs font-medium text-zinc-700">
              By{' '}
              <span className="text-[#09090B]">{aggregatedArticle.author}</span>
            </div>
          )}

          {aggregatedArticle.summary && (
            <p className="text-base sm:text-lg text-zinc-600 leading-relaxed max-w-[65ch]">
              {aggregatedArticle.summary}
            </p>
          )}
        </header>

        {aggregatedArticle.imageUrl && (
          <div className="my-10 aspect-[16/9] w-full rounded-2xl overflow-hidden border border-zinc-200 bg-zinc-100">
            <ResilientImage
              src={aggregatedArticle.imageUrl}
              alt={aggregatedArticle.title}
              fallbackTitle={aggregatedArticle.title}
            />
          </div>
        )}

        <div className="my-10 space-y-6 max-w-[65ch]">
          {paragraphs.length > 0 && (
            <div className="space-y-4">
              {paragraphs.map((para, idx) => (
                <p
                  key={idx}
                  className="text-base text-zinc-700 leading-[1.7] tracking-[0.005em]"
                >
                  {para}
                </p>
              ))}
            </div>
          )}

          {/* Honest feed-extent disclosure & external link */}
          <div className="p-6 rounded-2xl bg-white border border-zinc-200 space-y-3">
            <div className="text-sm font-semibold text-[#09090B]">
              {hasFullContent
                ? `Read original publication on ${aggregatedArticle.sourceName}`
                : `Read the complete post on ${aggregatedArticle.sourceName}`}
            </div>
            <p className="text-xs sm:text-sm text-zinc-600 leading-relaxed">
              {hasFullContent
                ? 'Sanitized text extracted from the official feed is shown above. Open the original source for formatting, interactive figures, code listings, and latest updates.'
                : 'This source feed only publishes a headline or brief summary rather than the full article body. Open the original link to read the complete text.'}
            </p>
            <div className="pt-1 flex flex-wrap items-center justify-between gap-3">
              <a
                href={aggregatedArticle.articleUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors"
              >
                <span>Open Original Article</span>
                <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
              </a>

              {aggregatedArticle.tags.length > 0 && (
                <div className="text-[11px] font-mono text-zinc-500">
                  Tags: {aggregatedArticle.tags.join(' · ')}
                </div>
              )}
            </div>
          </div>
        </div>

        {nextArticle && (
          <footer className="mt-14 pt-8 border-t border-zinc-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-xs text-zinc-500">Next Article</span>
              <div className="font-display text-lg font-semibold text-[#09090B]">
                {nextArticle.title}
              </div>
            </div>
            <a
              href={`/journal/${encodeURIComponent(nextArticle.id)}`}
              onClick={(e) =>
                handleLink(e, `/journal/${encodeURIComponent(nextArticle.id)}`)
              }
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
            >
              <span>Next Article</span>
              <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
            </a>
          </footer>
        )}
      </article>
    );
  }

  // Fallback if neither workspace article nor stored aggregated article matches
  if (!workspaceArticle && !aggregatedArticle) {
    return (
      <div className="max-w-[760px] mx-auto px-6 py-16 text-center space-y-4">
        <h1 className="font-display text-2xl font-bold text-[#09090B]">
          Article not found in local store
        </h1>
        <p className="text-sm text-zinc-600">
          This article could not be located. Return to the Knowledge Hub Blog tab
          to refresh sources or browse available articles.
        </p>
        <a
          href="/knowledge-hub/blog"
          onClick={(e) => handleLink(e, '/knowledge-hub/blog')}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Back to Blog</span>
        </a>
      </div>
    );
  }

  // Render existing Workspace JOURNAL_ARTICLES entry (100% preserved)
  const article = workspaceArticle!;
  const nextArticle =
    JOURNAL_ARTICLES[(workspaceIndex + 1) % JOURNAL_ARTICLES.length];

  return (
    <article className="max-w-[900px] mx-auto px-6 py-12 lg:py-16">
      <div className="mb-8">
        <a
          href="/knowledge-hub/blog"
          onClick={(e) => handleLink(e, '/knowledge-hub/blog')}
          className="inline-flex items-center gap-2 text-xs font-medium text-zinc-600 hover:text-[#09090B] transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Back to Blog</span>
        </a>
      </div>

      <header className="space-y-4 pb-8 border-b border-zinc-200">
        <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
          <span>{article.category}</span>
          <span aria-hidden="true">·</span>
          <span>{article.publishedAt}</span>
          <span aria-hidden="true">·</span>
          <span>{article.readTime}</span>
        </div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#09090B] [text-wrap:balance]">
          {article.title}
        </h1>
        <p className="text-base sm:text-lg text-zinc-600 leading-relaxed max-w-[65ch]">
          {article.excerpt}
        </p>
      </header>

      {article.coverImage && (
        <div className="my-10 aspect-[16/9] w-full rounded-2xl overflow-hidden border border-zinc-200 bg-zinc-100">
          <ResilientImage
            src={article.coverImage}
            alt={article.coverAlt || article.title}
            fallbackTitle={article.title}
          />
        </div>
      )}

      <div className="my-10 space-y-6 max-w-[65ch]">
        {article.blocks.map((block, i) => {
          if (block.type === 'heading') {
            return (
              <h2
                key={i}
                className="font-display text-xl sm:text-2xl font-semibold tracking-tight text-[#09090B] pt-4"
              >
                {block.content}
              </h2>
            );
          }

          if (block.type === 'quote') {
            return (
              <blockquote
                key={i}
                className="p-6 rounded-2xl bg-white border border-zinc-200 text-base font-medium text-[#09090B] leading-relaxed"
              >
                “{block.content}”
              </blockquote>
            );
          }

          if (block.type === 'code') {
            return (
              <pre
                key={i}
                className="p-5 rounded-xl bg-zinc-950 text-zinc-100 border border-zinc-800 overflow-x-auto text-xs font-mono leading-relaxed"
              >
                <code>{block.content}</code>
              </pre>
            );
          }

          return (
            <p
              key={i}
              className="text-base text-zinc-700 leading-[1.7] tracking-[0.005em]"
            >
              {block.content}
            </p>
          );
        })}
      </div>

      {/* Next Essay */}
      <footer className="mt-14 pt-8 border-t border-zinc-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <span className="text-xs text-zinc-500">Continue Reading</span>
          <div className="font-display text-lg font-semibold text-[#09090B]">
            {nextArticle.title}
          </div>
        </div>
        <a
          href={`/journal/${nextArticle.slug}`}
          onClick={(e) => handleLink(e, `/journal/${nextArticle.slug}`)}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <span>Next Essay</span>
          <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
        </a>
      </footer>
    </article>
  );
};
