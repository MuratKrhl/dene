import React from 'react';
import { ArrowRight, ArrowUpRight } from 'lucide-react';
import {
  CAPABILITIES,
  JOURNAL_ARTICLES,
  PROJECTS,
  STUDIO_PROFILE,
  TESTIMONIALS,
} from '../data/portfolioData';
import { ResilientImage } from '../components/ResilientImage';
import { WorkspaceHeroVisual } from '../components/WorkspaceHeroVisual';
import { SocialLinks } from '../components/SocialLinks';

interface HomePageProps {
  onNavigate: (path: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const featuredProjects = PROJECTS.filter((p) => p.featured).slice(0, 4);
  const latestArticles = JOURNAL_ARTICLES.slice(0, 3);

  const handleLink = (e: React.MouseEvent, path: string) => {
    e.preventDefault();
    onNavigate(path);
  };

  return (
    <div>
      {/* Split-Screen Murat Krhl's WorkSpace Hero */}
      <section className="max-w-[1200px] mx-auto px-6 pt-10 pb-10 lg:pt-14 lg:pb-14">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
          <div className="lg:col-span-6 space-y-5 py-2">
            <h1 className="font-display font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] text-[clamp(1.6rem,2.9vw,2.65rem)] leading-[1.1] sm:whitespace-nowrap">
              {STUDIO_PROFILE.workspaceTitle}
            </h1>

            <p className="text-base sm:text-lg text-zinc-600 dark:text-zinc-400 leading-relaxed max-w-[48ch]">
              {STUDIO_PROFILE.tagline}
            </p>

            {/* Icon-Only Social Workspace Links */}
            <div className="pt-1">
              <SocialLinks />
            </div>
          </div>

          <div className="lg:col-span-6">
            <WorkspaceHeroVisual />
          </div>
        </div>

        {/* Full-Width 4-Column Metrics Row Below Split */}
        <div className="mt-10 pt-8 border-t border-zinc-200 dark:border-zinc-800 grid grid-cols-2 lg:grid-cols-4 gap-6">
          {STUDIO_PROFILE.careerMetrics.map((metric) => (
            <div key={metric.label} className="space-y-1">
              <div className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                {metric.value}
              </div>
              <div className="text-xs text-zinc-600 dark:text-zinc-400">
                {metric.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Selected Works Bento Grid */}
      <section className="max-w-[1200px] mx-auto px-6 py-16 lg:py-20">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div className="space-y-2">
            <p className="text-xs font-medium text-[#2563EB] dark:text-blue-400">
              Selected Works
            </p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] [text-wrap:balance]">
              Recent client engagements and shipped platforms
            </h2>
          </div>
          <a
            href="/quick-access"
            onClick={(e) => handleLink(e, '/quick-access')}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-[#09090B] dark:text-[#FAFAFA] hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors whitespace-nowrap shrink-0"
          >
            <span>Open Quick Access</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </a>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {featuredProjects.map((project, idx) => {
            const spanClass =
              idx === 0 || idx === 3 ? 'lg:col-span-7' : 'lg:col-span-5';
            return (
              <article
                key={project.slug}
                className={`${spanClass} group rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-hidden flex flex-col transition-colors duration-150 hover:border-zinc-300 dark:hover:border-zinc-700`}
              >
                <a
                  href={`/work/${project.slug}`}
                  onClick={(e) => handleLink(e, `/work/${project.slug}`)}
                  className="block aspect-[4/3] w-full overflow-hidden bg-zinc-100 dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800"
                >
                  <ResilientImage
                    src={project.image}
                    alt={project.imageAlt || project.title}
                    fallbackTitle={project.title}
                    specimenType={project.specimenType}
                    className="transition-transform duration-300 group-hover:scale-[1.02]"
                  />
                </a>
                <div className="p-6 flex-1 flex flex-col justify-between gap-4">
                  <div className="space-y-2.5">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                      <span>{project.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.client}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{project.year}</span>
                    </div>
                    <h3 className="font-display text-xl font-semibold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
                      <a
                        href={`/work/${project.slug}`}
                        onClick={(e) => handleLink(e, `/work/${project.slug}`)}
                        className="hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors focus-visible:outline-2 focus-visible:outline-[#2563EB] rounded-sm"
                      >
                        {project.title}
                      </a>
                    </h3>
                    <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed">
                      {project.summary}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between gap-4">
                    <span className="text-xs font-mono text-zinc-700 dark:text-zinc-300 tabular-nums">
                      {project.metrics[0].value} {project.metrics[0].label}
                    </span>
                    <a
                      href={`/work/${project.slug}`}
                      onClick={(e) => handleLink(e, `/work/${project.slug}`)}
                      className="inline-flex items-center gap-1 text-xs font-medium text-[#2563EB] dark:text-blue-400 hover:underline whitespace-nowrap shrink-0"
                    >
                      <span>Read Case Study</span>
                      <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </a>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Client Proof Adjacent to Selected Works */}
      <section className="border-y border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#0E0E12]">
        <div className="max-w-[1200px] mx-auto px-6 py-16">
          <div className="space-y-2 mb-10">
            <p className="text-xs font-medium text-[#2563EB] dark:text-blue-400">
              Client Outcomes
            </p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
              Verified impact from product and engineering partners
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {TESTIMONIALS.map((item) => (
              <figure
                key={item.author}
                className="p-7 rounded-2xl bg-[#FAFAFA] dark:bg-[#141418] border border-zinc-200 dark:border-zinc-800 flex flex-col justify-between gap-6"
              >
                <blockquote className="text-sm sm:text-base text-zinc-800 dark:text-zinc-200 leading-relaxed">
                  “{item.quote}”
                </blockquote>
                <figcaption className="pt-4 border-t border-zinc-200 dark:border-zinc-800 space-y-1">
                  <div className="text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                    {item.author}
                  </div>
                  <div className="text-xs text-zinc-600 dark:text-zinc-400">
                    {item.role} · {item.company}
                  </div>
                  <div className="text-xs font-mono text-[#2563EB] dark:text-blue-400 pt-1">
                    {item.outcome}
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* Capabilities */}
      <section className="max-w-[1200px] mx-auto px-6 py-16 lg:py-20">
        <div className="space-y-2 mb-10">
          <p className="text-xs font-medium text-[#2563EB] dark:text-blue-400">
            Capabilities
          </p>
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
            From structural systems to production deployment
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {CAPABILITIES.map((cap) => (
            <div
              key={cap.index}
              className="pt-6 border-t border-zinc-200 dark:border-zinc-800 space-y-4"
            >
              <h3 className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                <span className="font-mono text-sm text-[#2563EB] dark:text-blue-400 mr-2">
                  {cap.index}
                </span>
                {cap.title}
              </h3>
              <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed">
                {cap.description}
              </p>
              <ul className="space-y-1.5 pt-2 text-xs text-zinc-700 dark:text-zinc-300">
                {cap.deliverables.map((del) => (
                  <li key={del} className="flex items-center gap-2">
                    <span className="text-zinc-400 dark:text-zinc-600" aria-hidden="true">
                      —
                    </span>
                    <span>{del}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Latest Journal Articles */}
      <section className="border-t border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#0E0E12]">
        <div className="max-w-[1200px] mx-auto px-6 py-16">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div className="space-y-2">
              <p className="text-xs font-medium text-[#2563EB] dark:text-blue-400">
                Journal
              </p>
              <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
                Notes on interface craft and frontend architecture
              </h2>
            </div>
            <a
              href="/project-management"
              onClick={(e) => handleLink(e, '/project-management')}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-[#09090B] dark:text-[#FAFAFA] hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors whitespace-nowrap shrink-0"
            >
              <span>Project Management &amp; Notes</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </a>
          </div>

          <div className="divide-y divide-zinc-200 dark:divide-zinc-800 border-y border-zinc-200 dark:border-zinc-800">
            {latestArticles.map((article) => (
              <article
                key={article.slug}
                className="py-6 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1.5 max-w-2xl">
                  <div className="flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                    <span>{article.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{article.publishedAt}</span>
                    <span aria-hidden="true">·</span>
                    <span>{article.readTime}</span>
                  </div>
                  <h3 className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                    <a
                      href={`/journal/${article.slug}`}
                      onClick={(e) => handleLink(e, `/journal/${article.slug}`)}
                      className="hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors"
                    >
                      {article.title}
                    </a>
                  </h3>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400">
                    {article.excerpt}
                  </p>
                </div>
                <a
                  href={`/journal/${article.slug}`}
                  onClick={(e) => handleLink(e, `/journal/${article.slug}`)}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-[#2563EB] dark:text-blue-400 hover:underline whitespace-nowrap shrink-0"
                >
                  <span>Read Essay</span>
                  <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Closing CTA */}
      <section className="max-w-[1200px] mx-auto px-6 py-16 lg:py-20">
        <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-8 sm:p-12 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          <div className="space-y-3 max-w-xl">
            <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
              {STUDIO_PROFILE.availability}
            </p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] [text-wrap:balance]">
              Planning a new product architecture or design system?
            </h2>
            <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400">
              Share your scope, timeline, and engineering context. Expect a thoughtful
              response within one business day.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <a
              href="/contact"
              onClick={(e) => handleLink(e, '/contact')}
              className="inline-flex items-center gap-2 px-5 py-3 text-sm font-medium text-white bg-[#2563EB] hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <span>Start a Project</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
