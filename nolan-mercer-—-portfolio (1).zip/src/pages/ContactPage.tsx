import React, { useState } from 'react';
import { Check, Copy, Mail, MapPin, Send } from 'lucide-react';
import { STUDIO_PROFILE } from '../data/portfolioData';

const SCOPES = [
  'Product Design',
  'Design System',
  'Frontend Architecture',
  'Full End-to-End Build',
] as const;

const BUDGETS = [
  '$10k – $20k',
  '$20k – $40k',
  '$40k+',
  'Advisory / Retainer',
] as const;

export const ContactPage: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [scope, setScope] = useState<string>(SCOPES[0]);
  const [budget, setBudget] = useState<string>(BUDGETS[1]);
  const [timeline, setTimeline] = useState('Within 1–2 months');
  const [brief, setBrief] = useState('');
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(STUDIO_PROFILE.email);
      setCopiedEmail(true);
      window.setTimeout(() => setCopiedEmail(false), 2200);
    } catch {
      setCopiedEmail(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const trimmedBrief = brief.trim();

    if (!trimmedName) {
      setError('Please enter your name so I know who to reply to.');
      return;
    }
    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (trimmedBrief.length < 15) {
      setError('Please share a brief overview of your project goals (at least 15 characters).');
      return;
    }

    setError('');
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    setName('');
    setEmail('');
    setCompany('');
    setBrief('');
  };

  return (
    <div className="max-w-[1200px] mx-auto px-6 py-12 lg:py-16">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Left Info Column */}
        <div className="lg:col-span-5 space-y-8">
          <div className="space-y-4">
            <p className="text-xs font-medium text-[#2563EB] dark:text-blue-400">
              Start a Conversation
            </p>
            <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] [text-wrap:balance]">
              Tell me about what your team is building next
            </h1>
            <p className="text-base text-zinc-600 dark:text-zinc-400 leading-relaxed">
              {STUDIO_PROFILE.availability}. I respond directly to every inquiry within
              one business day with initial questions or a proposed intro call slot.
            </p>
          </div>

          <div className="pt-6 border-t border-zinc-200 dark:border-zinc-800 space-y-5">
            <div className="space-y-1.5">
              <div className="text-xs text-zinc-500 dark:text-zinc-400">
                Direct Email
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <a
                  href={`mailto:${STUDIO_PROFILE.email}`}
                  className="inline-flex items-center gap-2 text-sm font-medium text-[#09090B] dark:text-[#FAFAFA] hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors"
                >
                  <Mail className="w-4 h-4 text-zinc-400" aria-hidden="true" />
                  <span>{STUDIO_PROFILE.email}</span>
                </a>
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors cursor-pointer whitespace-nowrap"
                >
                  {copiedEmail ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-zinc-400" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-xs text-zinc-500 dark:text-zinc-400">
                Studio Base
              </div>
              <div className="inline-flex items-center gap-2 text-sm text-[#09090B] dark:text-[#FAFAFA]">
                <MapPin className="w-4 h-4 text-zinc-400" aria-hidden="true" />
                <span>
                  {STUDIO_PROFILE.location} · {STUDIO_PROFILE.timezone}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Form Column */}
        <div className="lg:col-span-7">
          {submitted ? (
            <div className="p-8 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-6">
              <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-[#2563EB]/10 text-[#2563EB] dark:text-blue-400">
                <Check className="w-5 h-5" />
              </div>
              <div className="space-y-2">
                <h2 className="font-display text-2xl font-bold text-[#09090B] dark:text-[#FAFAFA]">
                  Inquiry prepared for {name}
                </h2>
                <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed">
                  Thank you for sharing the context. Your inquiry summary is captured
                  below—I will reply to{' '}
                  <span className="font-medium text-[#09090B] dark:text-[#FAFAFA]">
                    {email}
                  </span>{' '}
                  within 24 hours.
                </p>
              </div>

              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-5 border-y border-zinc-200 dark:border-zinc-800 text-sm">
                <div>
                  <dt className="text-xs text-zinc-500 dark:text-zinc-400">Scope</dt>
                  <dd className="font-medium text-[#09090B] dark:text-[#FAFAFA] mt-0.5">
                    {scope}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-zinc-500 dark:text-zinc-400">
                    Estimated Budget
                  </dt>
                  <dd className="font-medium text-[#09090B] dark:text-[#FAFAFA] mt-0.5 tabular-nums">
                    {budget}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-zinc-500 dark:text-zinc-400">Timeline</dt>
                  <dd className="font-medium text-[#09090B] dark:text-[#FAFAFA] mt-0.5">
                    {timeline}
                  </dd>
                </div>
                {company.trim() && (
                  <div>
                    <dt className="text-xs text-zinc-500 dark:text-zinc-400">
                      Organization
                    </dt>
                    <dd className="font-medium text-[#09090B] dark:text-[#FAFAFA] mt-0.5">
                      {company}
                    </dd>
                  </div>
                )}
              </dl>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-4 py-2.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] hover:bg-zinc-100 dark:hover:bg-zinc-900 transition-colors cursor-pointer"
                >
                  Send Another Inquiry
                </button>
              </div>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              noValidate
              className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-6"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="space-y-1.5">
                  <label
                    htmlFor="contact-name"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Your Name *
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Astrid Lindqvist"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB] dark:focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="contact-email"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Work Email *
                  </label>
                  <input
                    id="contact-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="astrid@company.com"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB] dark:focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="space-y-1.5">
                  <label
                    htmlFor="contact-company"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Company / Organization
                  </label>
                  <input
                    id="contact-company"
                    type="text"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="Optional"
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB] dark:focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="contact-timeline"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Target Kickoff
                  </label>
                  <select
                    id="contact-timeline"
                    value={timeline}
                    onChange={(e) => setTimeline(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] focus:outline-none focus:border-[#2563EB] dark:focus:border-blue-500"
                  >
                    <option value="Immediately">Immediately</option>
                    <option value="Within 1–2 months">Within 1–2 months</option>
                    <option value="Next quarter">Next quarter</option>
                    <option value="Exploratory">Exploratory</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <span className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
                  Primary Engagement Scope
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {SCOPES.map((item) => {
                    const selected = scope === item;
                    return (
                      <button
                        key={item}
                        type="button"
                        onClick={() => setScope(item)}
                        aria-pressed={selected}
                        className={`px-3.5 py-2.5 text-xs font-medium rounded-lg border text-left transition-colors cursor-pointer ${
                          selected
                            ? 'bg-[#2563EB] border-[#2563EB] text-white'
                            : 'bg-[#FAFAFA] dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700'
                        }`}
                      >
                        {item}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-2">
                <span className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
                  Estimated Budget
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {BUDGETS.map((tier) => {
                    const selected = budget === tier;
                    return (
                      <button
                        key={tier}
                        type="button"
                        onClick={() => setBudget(tier)}
                        aria-pressed={selected}
                        className={`px-3 py-2 text-xs font-medium rounded-lg border text-center transition-colors cursor-pointer tabular-nums whitespace-nowrap ${
                          selected
                            ? 'bg-[#09090B] dark:bg-white border-[#09090B] dark:border-white text-white dark:text-[#09090B]'
                            : 'bg-[#FAFAFA] dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700'
                        }`}
                      >
                        {tier}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="contact-brief"
                  className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                >
                  Project Overview *
                </label>
                <textarea
                  id="contact-brief"
                  rows={4}
                  required
                  value={brief}
                  onChange={(e) => setBrief(e.target.value)}
                  placeholder="Share context on your product, current team setup, and what success looks like..."
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB] dark:focus:border-blue-500 resize-y"
                />
              </div>

              {error && (
                <p
                  role="alert"
                  className="text-xs font-medium text-red-600 dark:text-red-400"
                >
                  {error}
                </p>
              )}

              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 w-full sm:w-auto px-6 py-3 text-sm font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-500 text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                <Send className="w-4 h-4" aria-hidden="true" />
                <span>Send Project Inquiry</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
