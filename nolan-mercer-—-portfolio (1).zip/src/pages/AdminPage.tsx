import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  ArrowUpRight,
  Bookmark,
  Check,
  FolderUp,
  Globe,
  HardDrive,
  Network,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Server,
  Trash2,
  X,
} from 'lucide-react';
import {
  BOOKMARK_COLLECTIONS,
  BookmarkIconKey,
  RaindropBookmark,
} from '../data/portfolioData';
import {
  BOOKMARK_ICON_OPTIONS,
  BookmarkIcon,
  BookmarkInlineFavicon,
} from '../components/BookmarkIcon';
import { loadBookmarks, saveBookmarks } from '../services/bookmarksStore';
import {
  ConnectionStatus,
  NfsActivityEntry,
  NfsNode,
  NfsSource,
  NfsVersion,
  SourceType,
} from '../nfs/types';
import { getAdapterForSource } from '../nfs/providers/storageAdapters';
import {
  appendActivityLog,
  detectDocFormat,
  loadActivityLog,
  loadSources,
  registerLocalNodes,
  saveSources,
  unregisterLocalNodes,
} from '../nfs/services/nfsStore';
import { AdminDataImportsPanel } from '../components/AdminDataImportsPanel';
import { AdminOneNotePanel } from '../components/AdminOneNotePanel';

export type AdminTabKey =
  | 'bookmarks'
  | 'nfs'
  | 'environment'
  | 'project-management'
  | 'onenote';

interface AdminPageProps {
  onNavigate: (path: string) => void;
  initialTab?: AdminTabKey;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export const AdminPage: React.FC<AdminPageProps> = ({
  onNavigate,
  initialTab = 'bookmarks',
}) => {
  const [activeTab, setActiveTab] = useState<AdminTabKey>(initialTab);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  const handleSelectTab = (tab: AdminTabKey) => {
    setActiveTab(tab);
    if (tab === 'nfs') {
      onNavigate('/admin/nfs');
    } else if (tab === 'environment') {
      onNavigate('/admin/environment');
    } else if (tab === 'project-management') {
      onNavigate('/admin/project-management');
    } else if (tab === 'onenote') {
      onNavigate('/admin/onenote');
    } else {
      onNavigate('/admin/bookmarks');
    }
  };

  return (
    <div className="max-w-[1200px] mx-auto px-6 py-10 lg:py-12 space-y-8">
      <header className="text-center max-w-2xl mx-auto space-y-2.5">
        <p className="text-xs font-medium text-[#2563EB]">Admin Console</p>
        <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#09090B] [text-wrap:balance]">
          Workspace Parameters, Sources &amp; Imports
        </h1>
        <p className="text-sm sm:text-base text-zinc-600 leading-relaxed">
          Manage Bookmarks, Network File System storage sources, Environment
          inventories, Project Management tracking, and OneNote Windows/HTTPS
          notebooks.
        </p>
      </header>

      {/* Centered Segmented Tabs (Matching Quick Access tab structure) */}
      <div className="flex justify-center">
        <div
          role="tablist"
          aria-label="Admin management sections"
          className="inline-flex flex-wrap justify-center items-center gap-1 p-1 rounded-lg bg-zinc-100 border border-zinc-200"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'bookmarks'}
            onClick={() => handleSelectTab('bookmarks')}
            className={`px-5 py-2 text-xs font-medium rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB] ${
              activeTab === 'bookmarks'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            Bookmarks
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'nfs'}
            onClick={() => handleSelectTab('nfs')}
            className={`px-5 py-2 text-xs font-medium rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB] ${
              activeTab === 'nfs'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            Network File System
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'environment'}
            onClick={() => handleSelectTab('environment')}
            className={`px-5 py-2 text-xs font-medium rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB] ${
              activeTab === 'environment'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            Environment
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'project-management'}
            onClick={() => handleSelectTab('project-management')}
            className={`px-5 py-2 text-xs font-medium rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB] ${
              activeTab === 'project-management'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            Project Management
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'onenote'}
            onClick={() => handleSelectTab('onenote')}
            className={`px-5 py-2 text-xs font-medium rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB] ${
              activeTab === 'onenote'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            OneNote
          </button>
        </div>
      </div>

      {activeTab === 'bookmarks' && (
        <AdminBookmarksPanel onNavigate={onNavigate} />
      )}

      {activeTab === 'nfs' && <AdminNfsPanel onNavigate={onNavigate} />}

      {activeTab === 'environment' && (
        <AdminDataImportsPanel
          key="admin-environment"
          domain="environment"
          onNavigate={onNavigate}
        />
      )}

      {activeTab === 'project-management' && (
        <AdminDataImportsPanel
          key="admin-pm"
          domain="pm"
          onNavigate={onNavigate}
        />
      )}

      {activeTab === 'onenote' && <AdminOneNotePanel onNavigate={onNavigate} />}
    </div>
  );
};

/* ============================================================================
 * TAB 1: BOOKMARKS MANAGEMENT (Moved from Quick Access > Bookmarks)
 * ========================================================================== */

const AdminBookmarksPanel: React.FC<{ onNavigate: (path: string) => void }> = ({
  onNavigate,
}) => {
  const [bookmarks, setBookmarks] = useState<RaindropBookmark[]>(() =>
    loadBookmarks()
  );
  const [search, setSearch] = useState('');
  const [collectionFilter, setCollectionFilter] = useState('All');
  const [showAddForm, setShowAddForm] = useState(false);

  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newCollectionPath, setNewCollectionPath] = useState(
    'Engineering::Frontend'
  );
  const [newDesc, setNewDesc] = useState('');
  const [newIconKey, setNewIconKey] = useState<BookmarkIconKey>('auto');
  const [newIconUrl, setNewIconUrl] = useState('');

  const persist = (next: RaindropBookmark[]) => {
    setBookmarks(next);
    saveBookmarks(next);
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return bookmarks.filter((item) => {
      if (collectionFilter !== 'All' && item.collection !== collectionFilter) {
        return false;
      }
      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.domain.toLowerCase().includes(q) ||
        item.url.toLowerCase().includes(q) ||
        item.collection.toLowerCase().includes(q) ||
        item.subCollection.toLowerCase().includes(q)
      );
    });
  }, [bookmarks, search, collectionFilter]);

  const handleAddBookmark = (e: React.FormEvent) => {
    e.preventDefault();
    const title = newTitle.trim();
    const rawUrl = newUrl.trim();
    if (!title || !rawUrl) return;

    const normalizedUrl =
      rawUrl.startsWith('http://') ||
      rawUrl.startsWith('https://') ||
      rawUrl.startsWith('/')
        ? rawUrl
        : `https://${rawUrl}`;

    let domain = 'workspace.local';
    if (!normalizedUrl.startsWith('/')) {
      try {
        domain = new URL(normalizedUrl).hostname.replace(/^www\./, '');
      } catch {
        domain = 'external.link';
      }
    }

    const [collection, subCollection] = newCollectionPath.split('::');
    const today = new Date().toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
    });

    const newItem: RaindropBookmark = {
      id: `custom-${Date.now()}`,
      title,
      description:
        newDesc.trim() || `Saved in ${collection} / ${subCollection}.`,
      url: normalizedUrl,
      domain,
      date: today,
      collection,
      subCollection,
      monogram: title.slice(0, 2).toUpperCase(),
      tone: 'cobalt',
      iconKey: newIconKey,
      iconUrl: newIconUrl.trim() || undefined,
      favorite: false,
      internalPath: normalizedUrl.startsWith('/') ? normalizedUrl : undefined,
    };

    persist([newItem, ...bookmarks]);
    setNewTitle('');
    setNewUrl('');
    setNewDesc('');
    setNewIconKey('auto');
    setNewIconUrl('');
    setShowAddForm(false);
  };

  const handleDeleteBookmark = (id: string) => {
    persist(bookmarks.filter((b) => b.id !== id));
  };

  return (
    <section aria-label="Bookmarks Admin Management" className="space-y-5">
      {/* Toolbar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white border border-zinc-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Bookmark className="w-4 h-4 text-[#2563EB]" aria-hidden="true" />
            <h2 className="font-display text-lg font-semibold text-[#09090B]">
              Bookmarks Inventory
            </h2>
            <span className="text-xs font-mono text-zinc-500 tabular-nums">
              · {bookmarks.length} total
            </span>
          </div>
          <p className="text-xs text-zinc-600">
            Changes sync immediately to Quick Access &gt; Bookmarks.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="relative w-full sm:w-52">
            <Search
              className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search bookmarks..."
              aria-label="Search bookmarks"
              className="w-full pl-8 pr-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
            />
          </div>

          <select
            value={collectionFilter}
            onChange={(e) => setCollectionFilter(e.target.value)}
            aria-label="Filter by collection"
            className="px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B] cursor-pointer"
          >
            <option value="All">Collection: All</option>
            {BOOKMARK_COLLECTIONS.map((g) => (
              <option key={g.id} value={g.label}>
                {g.label}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => onNavigate('/quick-access')}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 bg-[#FAFAFA] text-zinc-700 hover:border-zinc-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <span>View in Quick Access</span>
            <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={() => setShowAddForm((prev) => !prev)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Add Bookmark</span>
          </button>
        </div>
      </div>

      {/* Add Bookmark Form */}
      {showAddForm && (
        <form
          onSubmit={handleAddBookmark}
          className="p-5 rounded-2xl bg-white border border-zinc-200 grid grid-cols-1 sm:grid-cols-12 gap-4 items-end"
        >
          <div className="sm:col-span-12 flex items-center justify-between">
            <h3 className="font-display text-sm font-semibold text-[#09090B]">
              Add New Bookmark
            </h3>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              aria-label="Close form"
              className="p-1 text-zinc-400 hover:text-[#09090B] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="sm:col-span-4 space-y-1">
            <label
              htmlFor="admin-bm-title"
              className="block text-xs font-medium text-zinc-700"
            >
              Title *
            </label>
            <input
              id="admin-bm-title"
              type="text"
              required
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="MDN Web Docs"
              className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
            />
          </div>

          <div className="sm:col-span-4 space-y-1">
            <label
              htmlFor="admin-bm-url"
              className="block text-xs font-medium text-zinc-700"
            >
              URL *
            </label>
            <input
              id="admin-bm-url"
              type="text"
              required
              value={newUrl}
              onChange={(e) => setNewUrl(e.target.value)}
              placeholder="https://developer.mozilla.org"
              className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
            />
          </div>

          <div className="sm:col-span-4 space-y-1">
            <label
              htmlFor="admin-bm-col"
              className="block text-xs font-medium text-zinc-700"
            >
              Collection
            </label>
            <select
              id="admin-bm-col"
              value={newCollectionPath}
              onChange={(e) => setNewCollectionPath(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
            >
              {BOOKMARK_COLLECTIONS.map((g) =>
                g.children.map((c) => (
                  <option key={`${g.id}-${c.id}`} value={`${g.label}::${c.label}`}>
                    {g.label} &gt; {c.label}
                  </option>
                ))
              )}
            </select>
          </div>

          <div className="sm:col-span-4 space-y-1">
            <label
              htmlFor="admin-bm-icon"
              className="block text-xs font-medium text-zinc-700"
            >
              Icon Style
            </label>
            <div className="flex items-center gap-2">
              <BookmarkIcon
                title={newTitle || 'Preview'}
                domain={
                  newUrl.trim() && !newUrl.trim().startsWith('/')
                    ? (() => {
                        try {
                          const normalized = newUrl.trim().startsWith('http')
                            ? newUrl.trim()
                            : `https://${newUrl.trim()}`;
                          return new URL(normalized).hostname.replace(/^www\./, '');
                        } catch {
                          return 'workspace.local';
                        }
                      })()
                    : 'workspace.local'
                }
                url={newUrl.trim() || '/'}
                iconKey={newIconKey}
                iconUrl={newIconUrl.trim() || undefined}
                tone="cobalt"
                size="sm"
              />
              <select
                id="admin-bm-icon"
                value={newIconKey}
                onChange={(e) => setNewIconKey(e.target.value as BookmarkIconKey)}
                className="flex-1 min-w-0 px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
              >
                {BOOKMARK_ICON_OPTIONS.map((opt) => (
                  <option key={opt.key} value={opt.key}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="sm:col-span-4 space-y-1">
            <label
              htmlFor="admin-bm-icon-url"
              className="block text-xs font-medium text-zinc-700"
            >
              Custom Icon URL (optional)
            </label>
            <input
              id="admin-bm-icon-url"
              type="text"
              value={newIconUrl}
              onChange={(e) => setNewIconUrl(e.target.value)}
              placeholder="https://example.com/favicon.svg"
              className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
            />
          </div>

          <div className="sm:col-span-4 space-y-1">
            <label
              htmlFor="admin-bm-desc"
              className="block text-xs font-medium text-zinc-700"
            >
              Description
            </label>
            <input
              id="admin-bm-desc"
              type="text"
              value={newDesc}
              onChange={(e) => setNewDesc(e.target.value)}
              placeholder="Concise summary for this bookmark..."
              className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
            />
          </div>

          <div className="sm:col-span-12 flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 text-xs font-medium rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer"
            >
              Save Bookmark
            </button>
          </div>
        </form>
      )}

      {/* Bookmarks Table */}
      <div className="rounded-2xl bg-white border border-zinc-200 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-12 text-center space-y-2 text-xs text-zinc-500">
            <p className="text-sm font-medium text-[#09090B]">
              No bookmarks found
            </p>
            <p>Adjust your search filters or add a new bookmark above.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#FAFAFA] border-b border-zinc-200 text-[11px] font-medium text-zinc-500">
                  <th className="px-4 py-3">Bookmark</th>
                  <th className="px-3 py-3">URL / Domain</th>
                  <th className="px-3 py-3">Collection</th>
                  <th className="px-3 py-3">Added</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200">
                {filtered.map((item) => (
                  <tr
                    key={item.id}
                    className="hover:bg-zinc-50/80 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <BookmarkIcon
                          title={item.title}
                          domain={item.domain}
                          url={item.url}
                          iconKey={item.iconKey}
                          iconUrl={item.iconUrl}
                          tone={item.tone}
                          size="sm"
                        />
                        <div className="min-w-0">
                          <div className="font-semibold text-[#09090B] truncate">
                            {item.title}
                          </div>
                          <div className="text-[11px] text-zinc-500 truncate max-w-[300px]">
                            {item.description}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3 font-mono text-[11px] text-zinc-600 max-w-[220px] truncate">
                      <span className="inline-flex items-center gap-1.5">
                        <BookmarkInlineFavicon
                          domain={item.domain}
                          url={item.url}
                          iconKey={item.iconKey}
                          iconUrl={item.iconUrl}
                        />
                        <span className="truncate">{item.domain}</span>
                      </span>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap text-zinc-600">
                      {item.collection} / {item.subCollection}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap font-mono text-[11px] text-zinc-500 tabular-nums">
                      {item.date}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => handleDeleteBookmark(item.id)}
                        aria-label={`Delete ${item.title}`}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:border-red-500 hover:text-red-600 text-[11px] font-medium transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" aria-hidden="true" />
                        <span>Delete</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
};

/* ============================================================================
 * TAB 2: NETWORK FILE SYSTEM MANAGEMENT (Moved from Quick Access > NFS)
 * ========================================================================== */

const AdminNfsPanel: React.FC<{ onNavigate: (path: string) => void }> = ({
  onNavigate,
}) => {
  const [sources, setSources] = useState<NfsSource[]>(() => loadSources());
  const [activity, setActivity] = useState<NfsActivityEntry[]>(() =>
    loadActivityLog()
  );
  const [subView, setSubView] = useState<'sources' | 'diagnostics'>('sources');
  const [showForm, setShowForm] = useState(false);
  const [activeEdit, setActiveEdit] = useState<NfsSource | null>(null);

  const [name, setName] = useState('');
  const [type, setType] = useState<SourceType>('windows_share');
  const [path, setPath] = useState('');
  const [serverAddress, setServerAddress] = useState('10.0.4.12');
  const [exportPath, setExportPath] = useState('/exports/workspace');
  const [nfsVersion, setNfsVersion] = useState<NfsVersion>('v4');
  const [documentLibrary, setDocumentLibrary] = useState('Shared Documents');
  const [description, setDescription] = useState('');
  const [mountedFiles, setMountedFiles] = useState<File[]>([]);
  const [testResult, setTestResult] = useState<{
    status: ConnectionStatus;
    message: string;
    protocolDetail: string;
  } | null>(null);
  const [error, setError] = useState('');
  const folderInputRef = useRef<HTMLInputElement | null>(null);

  const resetForm = (editTarget: NfsSource | null = null) => {
    setActiveEdit(editTarget);
    setName(editTarget?.name || '');
    setType(editTarget?.type || 'windows_share');
    setPath(editTarget?.path || '');
    setServerAddress(editTarget?.serverAddress || '10.0.4.12');
    setExportPath(editTarget?.exportPath || '/exports/workspace');
    setNfsVersion(editTarget?.nfsVersion || 'v4');
    setDocumentLibrary(editTarget?.documentLibrary || 'Shared Documents');
    setDescription(editTarget?.description || '');
    setMountedFiles([]);
    setTestResult(null);
    setError('');
  };

  const openAddForm = () => {
    resetForm(null);
    setShowForm(true);
    setSubView('sources');
  };

  const openEditForm = (src: NfsSource) => {
    resetForm(src);
    setShowForm(true);
    setSubView('sources');
  };

  const placeholderForType = (t: SourceType) => {
    switch (t) {
      case 'windows_share':
        return '\\\\server\\department\\documents';
      case 'mapped_drive':
        return 'Z:\\Operations\\Documents';
      case 'nfs_share':
        return '10.0.4.12:/exports/workspace';
      case 'sharepoint':
        return 'https://company.sharepoint.com/sites/Engineering/Shared%20Documents';
      case 'local_folder':
        return 'Local Directory (Pick folder below)';
    }
  };

  const resolvedPath =
    type === 'nfs_share'
      ? path.trim() || `${serverAddress.trim()}:${exportPath.trim()}`
      : path.trim();

  const handleLocalFolderPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const files = Array.from(fileList);
    setMountedFiles(files);
    const firstRel = (files[0] as File & { webkitRelativePath?: string })
      .webkitRelativePath;
    const rootFolderName = firstRel ? firstRel.split('/')[0] : 'Local Folder';
    if (!name.trim()) setName(rootFolderName);
    setPath(`local://${rootFolderName}`);
    setError('');
    setTestResult({
      status: 'Connected',
      protocolDetail: 'Browser File System API',
      message: `Local folder ready: ${files.length} files scanned directly from disk.`,
    });
  };

  const handleTestConnection = () => {
    const draft: NfsSource = {
      id: activeEdit?.id || 'draft',
      name: name.trim() || 'Draft Source',
      type,
      path: resolvedPath,
      serverAddress,
      exportPath,
      nfsVersion,
      documentLibrary,
      description,
      status: 'Disconnected',
      lastAccessed: '',
      lastSynced: '',
      enabled: true,
    };
    const adapter = getAdapterForSource(draft);
    const res = adapter.testConnection(draft, mountedFiles.length);
    setTestResult({
      status: res.status,
      message: res.message,
      protocolDetail: res.protocolDetail,
    });
    setActivity(
      appendActivityLog(
        'Tested Connection',
        `${draft.name} (${res.status})`,
        res.ok ? 'ok' : res.status === 'Error' ? 'error' : 'info'
      )
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter a source name.');
      return;
    }
    if (!resolvedPath && type !== 'local_folder') {
      setError('Please enter a network path, NFS export, or SharePoint URL.');
      return;
    }
    if (type === 'local_folder' && mountedFiles.length === 0 && !activeEdit) {
      setError('Please select a local folder from your computer.');
      return;
    }

    const sourceId = activeEdit?.id || `src-${Date.now()}`;
    const draft: NfsSource = {
      id: sourceId,
      name: name.trim(),
      type,
      path: resolvedPath || `local://${name.trim()}`,
      serverAddress: type === 'nfs_share' ? serverAddress.trim() : undefined,
      exportPath: type === 'nfs_share' ? exportPath.trim() : undefined,
      nfsVersion: type === 'nfs_share' ? nfsVersion : undefined,
      documentLibrary:
        type === 'sharepoint' ? documentLibrary.trim() : undefined,
      description:
        description.trim() ||
        `${type.replace('_', ' ')} storage source configured in Workspace NFS.`,
      status:
        type === 'local_folder' && mountedFiles.length > 0
          ? 'Connected'
          : activeEdit?.status || 'Disconnected',
      lastAccessed: 'Just now',
      lastSynced: 'Just now',
      enabled: activeEdit ? activeEdit.enabled : true,
      isDemo: type !== 'local_folder',
    };

    const adapter = getAdapterForSource(draft);
    const test = adapter.testConnection(draft, mountedFiles.length);
    draft.status = test.status;

    if (type === 'local_folder' && mountedFiles.length > 0) {
      const folderMap = new Map<string, NfsNode>();
      const nodes: NfsNode[] = [];
      const nowLabel = new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: '2-digit',
        year: 'numeric',
      });

      mountedFiles.forEach((file, idx) => {
        const ext = detectDocFormat(file.name);
        const relPath =
          (file as File & { webkitRelativePath?: string }).webkitRelativePath ||
          file.name;
        const parts = relPath.split('/');
        let parentId: string | null = null;
        for (let i = 1; i < parts.length - 1; i++) {
          const folderKey = parts.slice(0, i + 1).join('/');
          if (!folderMap.has(folderKey)) {
            const folderNode: NfsNode = {
              id: `loc-fld-${sourceId}-${folderMap.size}`,
              sourceId,
              parentId,
              name: parts[i],
              kind: 'folder',
              sizeBytes: 0,
              sizeLabel: 'Folder',
              modifiedAt: nowLabel,
              modifiedTimestamp: Date.now(),
              path: folderKey,
              owner: 'Local User',
              permissions: 'Browser Read-Only',
            };
            folderMap.set(folderKey, folderNode);
            nodes.push(folderNode);
          }
          parentId = folderMap.get(folderKey)!.id;
        }

        nodes.push({
          id: `loc-file-${sourceId}-${idx}`,
          sourceId,
          parentId,
          name: file.name,
          kind: 'file',
          extension: ext,
          sizeBytes: file.size,
          sizeLabel: formatBytes(file.size),
          modifiedAt: new Date(file.lastModified).toLocaleDateString('en-US', {
            month: 'short',
            day: '2-digit',
            year: 'numeric',
          }),
          modifiedTimestamp: file.lastModified,
          path: relPath,
          fileObject: file,
          author: 'Local Disk',
          owner: 'Local User',
          permissions: 'Browser Read-Only',
        });
      });

      registerLocalNodes(draft.id, nodes);
    }

    const exists = sources.some((s) => s.id === draft.id);
    const nextSources = exists
      ? sources.map((s) => (s.id === draft.id ? draft : s))
      : [...sources, draft];
    setSources(nextSources);
    saveSources(nextSources);

    setActivity(
      appendActivityLog(
        activeEdit ? 'Updated Source' : 'Added Source',
        `${draft.name} (${draft.status})`,
        test.ok ? 'ok' : 'info'
      )
    );
    setShowForm(false);
    resetForm(null);
  };

  const handleDeleteSource = (sourceId: string) => {
    const target = sources.find((s) => s.id === sourceId);
    const next = sources.filter((s) => s.id !== sourceId);
    setSources(next);
    saveSources(next);
    unregisterLocalNodes(sourceId);
    if (activeEdit?.id === sourceId) {
      setShowForm(false);
      resetForm(null);
    }
    if (target) {
      setActivity(appendActivityLog('Removed Source', target.name, 'warn'));
    }
  };

  const handleToggleEnabled = (sourceId: string) => {
    const next = sources.map((s) =>
      s.id === sourceId ? { ...s, enabled: !s.enabled } : s
    );
    setSources(next);
    saveSources(next);
  };

  const handleRefreshSingle = (sourceId: string) => {
    const stamp = new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
    const updated = sources.map((s) => {
      if (s.id !== sourceId) return s;
      const res = getAdapterForSource(s).refresh(s);
      return { ...s, status: res.status, lastSynced: `Today · ${stamp}` };
    });
    setSources(updated);
    saveSources(updated);
    const src = updated.find((s) => s.id === sourceId);
    if (src) {
      setActivity(
        appendActivityLog(
          'Refreshed Source',
          `${src.name} (${src.status})`,
          'info'
        )
      );
    }
  };

  const statusBadgeClass = (status: ConnectionStatus) => {
    switch (status) {
      case 'Connected':
        return 'text-emerald-700';
      case 'Authentication Required':
        return 'text-amber-700';
      case 'Error':
        return 'text-red-600';
      default:
        return 'text-zinc-600';
    }
  };

  return (
    <section aria-label="Network File System Admin Management" className="space-y-5">
      {/* Toolbar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white border border-zinc-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Network className="w-4 h-4 text-[#2563EB]" aria-hidden="true" />
            <h2 className="font-display text-lg font-semibold text-[#09090B]">
              Storage Sources &amp; Mounts
            </h2>
            <span className="text-xs font-mono text-zinc-500 tabular-nums">
              · {sources.length} registered
            </span>
          </div>
          <p className="text-xs text-zinc-600">
            Configure Windows SMB shares, mapped drives, NFS exports, SharePoint,
            or local folders shown in Quick Access &gt; NFS.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex p-0.5 rounded-lg bg-zinc-100 border border-zinc-200 text-xs">
            <button
              type="button"
              onClick={() => setSubView('sources')}
              className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                subView === 'sources'
                  ? 'bg-white text-[#09090B] shadow-xs'
                  : 'text-zinc-600'
              }`}
            >
              Sources
            </button>
            <button
              type="button"
              onClick={() => setSubView('diagnostics')}
              className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                subView === 'diagnostics'
                  ? 'bg-white text-[#09090B] shadow-xs'
                  : 'text-zinc-600'
              }`}
            >
              Diagnostics &amp; Log
            </button>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('/quick-access/nfs')}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 bg-[#FAFAFA] text-zinc-700 hover:border-zinc-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <span>Open Explorer</span>
            <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={openAddForm}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Add Source</span>
          </button>
        </div>
      </div>

      {subView === 'sources' ? (
        <>
          {/* Add / Edit Source Form */}
          {showForm && (
            <form
              onSubmit={handleSubmit}
              className="p-6 rounded-2xl bg-white border border-zinc-200 space-y-5"
            >
              <div className="flex items-center justify-between border-b border-zinc-200 pb-3">
                <h3 className="font-display text-sm font-semibold text-[#09090B]">
                  {activeEdit
                    ? `Edit Source — ${activeEdit.name}`
                    : 'Register Storage Source'}
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    resetForm(null);
                  }}
                  aria-label="Close source form"
                  className="p-1 text-zinc-400 hover:text-[#09090B] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {[
                  { id: 'windows_share', label: 'Windows UNC', icon: Server },
                  { id: 'mapped_drive', label: 'Mapped Drive', icon: HardDrive },
                  { id: 'nfs_share', label: 'NFS Share', icon: Network },
                  { id: 'sharepoint', label: 'SharePoint', icon: Globe },
                  { id: 'local_folder', label: 'Local Folder', icon: FolderUp },
                ].map((opt) => {
                  const Icon = opt.icon;
                  const active = type === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        setType(opt.id as SourceType);
                        setTestResult(null);
                        setError('');
                      }}
                      className={`p-2.5 rounded-xl border text-left transition-colors cursor-pointer flex items-center gap-2 text-xs font-medium ${
                        active
                          ? 'bg-[#2563EB]/10 border-[#2563EB] text-[#2563EB]'
                          : 'bg-[#FAFAFA] border-zinc-200 text-zinc-700 hover:border-zinc-300'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{opt.label}</span>
                    </button>
                  );
                })}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label
                    htmlFor="admin-src-name"
                    className="block text-xs font-medium text-zinc-700"
                  >
                    Display Name *
                  </label>
                  <input
                    id="admin-src-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Engineering NFSv4"
                    className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="admin-src-path"
                    className="block text-xs font-medium text-zinc-700"
                  >
                    {type === 'sharepoint'
                      ? 'Site / Folder URL *'
                      : type === 'local_folder'
                        ? 'Selected Local Folder'
                        : type === 'nfs_share'
                          ? 'Export Target (host:/path) *'
                          : 'Network / Drive Path *'}
                  </label>
                  {type === 'local_folder' ? (
                    <div>
                      <input
                        ref={folderInputRef}
                        type="file"
                        // @ts-expect-error webkitdirectory is supported across modern browsers
                        webkitdirectory=""
                        multiple
                        onChange={handleLocalFolderPick}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => folderInputRef.current?.click()}
                        className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 bg-[#FAFAFA] text-[#09090B] hover:border-[#2563EB] transition-colors cursor-pointer text-left truncate"
                      >
                        {mountedFiles.length > 0
                          ? `${path} (${mountedFiles.length} files)`
                          : 'Choose Local Directory...'}
                      </button>
                    </div>
                  ) : (
                    <input
                      id="admin-src-path"
                      type="text"
                      value={path}
                      onChange={(e) => setPath(e.target.value)}
                      placeholder={placeholderForType(type)}
                      className="w-full px-3 py-2 text-xs font-mono rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
                    />
                  )}
                </div>
              </div>

              {type === 'nfs_share' && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-[#FAFAFA] border border-zinc-200">
                  <div className="space-y-1">
                    <label
                      htmlFor="admin-nfs-host"
                      className="block text-[11px] font-medium text-zinc-600"
                    >
                      Server Address
                    </label>
                    <input
                      id="admin-nfs-host"
                      type="text"
                      value={serverAddress}
                      onChange={(e) => {
                        setServerAddress(e.target.value);
                        setPath(`${e.target.value}:${exportPath}`);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs font-mono rounded-md bg-white border border-zinc-200"
                    />
                  </div>
                  <div className="space-y-1">
                    <label
                      htmlFor="admin-nfs-export"
                      className="block text-[11px] font-medium text-zinc-600"
                    >
                      Export Path
                    </label>
                    <input
                      id="admin-nfs-export"
                      type="text"
                      value={exportPath}
                      onChange={(e) => {
                        setExportPath(e.target.value);
                        setPath(`${serverAddress}:${e.target.value}`);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs font-mono rounded-md bg-white border border-zinc-200"
                    />
                  </div>
                  <div className="space-y-1">
                    <label
                      htmlFor="admin-nfs-ver"
                      className="block text-[11px] font-medium text-zinc-600"
                    >
                      NFS Version
                    </label>
                    <select
                      id="admin-nfs-ver"
                      value={nfsVersion}
                      onChange={(e) => setNfsVersion(e.target.value as NfsVersion)}
                      className="w-full px-2.5 py-1.5 text-xs rounded-md bg-white border border-zinc-200"
                    >
                      <option value="v4">NFSv4 / v4.1 (Recommended)</option>
                      <option value="v3">NFSv3</option>
                      <option value="v2">NFSv2 (Legacy)</option>
                    </select>
                  </div>
                </div>
              )}

              {type === 'sharepoint' && (
                <div className="p-4 rounded-xl bg-[#FAFAFA] border border-zinc-200 space-y-2 text-xs">
                  <div className="space-y-1">
                    <label
                      htmlFor="admin-sp-lib"
                      className="block text-[11px] font-medium text-zinc-600"
                    >
                      Document Library Name
                    </label>
                    <input
                      id="admin-sp-lib"
                      type="text"
                      value={documentLibrary}
                      onChange={(e) => setDocumentLibrary(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs rounded-md bg-white border border-zinc-200"
                    />
                  </div>
                  <p className="text-[11px] text-zinc-500">
                    Microsoft Graph OAuth tokens are never stored in browser
                    localStorage. Unauthenticated libraries remain in Authentication
                    Required state.
                  </p>
                </div>
              )}

              <div className="space-y-1.5">
                <label
                  htmlFor="admin-src-desc"
                  className="block text-xs font-medium text-zinc-700"
                >
                  Description
                </label>
                <input
                  id="admin-src-desc"
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Optional description of documents stored in this location"
                  className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
                />
              </div>

              {testResult && (
                <div className="p-3.5 rounded-xl bg-[#FAFAFA] border border-zinc-200 text-xs space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`font-semibold ${statusBadgeClass(testResult.status)}`}
                    >
                      Status: {testResult.status}
                    </span>
                    <span className="font-mono text-[11px] text-zinc-400">
                      {testResult.protocolDetail}
                    </span>
                  </div>
                  <p className="text-zinc-600">{testResult.message}</p>
                </div>
              )}

              {error && (
                <p role="alert" className="text-xs font-medium text-red-600">
                  {error}
                </p>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                <button
                  type="button"
                  onClick={handleTestConnection}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 text-[#09090B] hover:bg-zinc-100 transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Test Connection</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowForm(false);
                      resetForm(null);
                    }}
                    className="px-4 py-2 text-xs font-medium rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-100 transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{activeEdit ? 'Update Source' : 'Register Source'}</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Registered Sources Inventory */}
          <div className="rounded-2xl bg-white border border-zinc-200 overflow-hidden">
            {sources.length === 0 ? (
              <div className="py-12 text-center space-y-2 text-xs text-zinc-500">
                <p className="text-sm font-medium text-[#09090B]">
                  No storage sources configured
                </p>
                <p>Click Add Source above to register a storage mount.</p>
              </div>
            ) : (
              <div className="divide-y divide-zinc-200">
                {sources.map((src) => (
                  <div
                    key={src.id}
                    className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-zinc-50/70 transition-colors"
                  >
                    <div className="min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-semibold text-[#09090B]">
                          {src.name}
                        </span>
                        <span className="text-zinc-400">·</span>
                        <span
                          className={`font-medium ${statusBadgeClass(src.status)}`}
                        >
                          {src.status}
                        </span>
                        {src.nfsVersion && (
                          <>
                            <span className="text-zinc-400">·</span>
                            <span className="font-mono text-[11px] text-zinc-500">
                              NFS{src.nfsVersion}
                            </span>
                          </>
                        )}
                      </div>
                      <div className="text-[11px] font-mono text-zinc-500 truncate">
                        {src.path}
                      </div>
                      <div className="text-[11px] text-zinc-500 tabular-nums">
                        Last sync: {src.lastSynced}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleRefreshSingle(src.id)}
                        aria-label={`Refresh ${src.name}`}
                        className="p-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:bg-white cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleEnabled(src.id)}
                        className="px-2.5 py-1.5 text-[11px] font-medium rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-700 hover:bg-white cursor-pointer"
                      >
                        {src.enabled ? 'Enabled' : 'Disabled'}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onNavigate(
                            `/quick-access/nfs/source/${encodeURIComponent(src.id)}`
                          )
                        }
                        className="px-2.5 py-1.5 text-[11px] font-medium rounded-md bg-white border border-zinc-200 text-[#2563EB] hover:border-[#2563EB] cursor-pointer"
                      >
                        Browse
                      </button>
                      <button
                        type="button"
                        onClick={() => openEditForm(src)}
                        aria-label={`Edit ${src.name}`}
                        className="p-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:border-[#2563EB] hover:text-[#2563EB] cursor-pointer"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteSource(src.id)}
                        aria-label={`Delete ${src.name}`}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:border-red-500 hover:text-red-600 text-[11px] font-medium cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" aria-hidden="true" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="rounded-2xl bg-white border border-zinc-200 p-6 space-y-6 text-xs">
          <div className="p-4 rounded-xl bg-[#FAFAFA] border border-zinc-200 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-[#09090B]">
              <Activity className="w-4 h-4 text-[#2563EB]" />
              <span>Browser Connectivity &amp; Security Boundary</span>
            </div>
            <p className="text-zinc-600 leading-relaxed">
              Windows UNC paths, mapped drive letters, and kernel NFS exports
              require a server-side RPC/SMB proxy to access live network storage.
              SharePoint requires delegated Microsoft Graph OAuth without
              persisting access tokens in localStorage. Only Local Folder mounts
              with active browser directory handles report Connected.
            </p>
          </div>

          <div className="space-y-2">
            <h3 className="text-xs font-medium text-zinc-500">
              Activity Log ({activity.length})
            </h3>
            <div className="divide-y divide-zinc-200 rounded-xl border border-zinc-200 overflow-hidden">
              {activity.map((entry) => (
                <div
                  key={entry.id}
                  className="px-4 py-3 flex items-center justify-between gap-3 bg-[#FAFAFA]"
                >
                  <div className="min-w-0">
                    <span className="font-medium text-[#09090B] mr-2">
                      {entry.action}
                    </span>
                    <span className="text-zinc-500 truncate">{entry.target}</span>
                  </div>
                  <span className="font-mono text-[11px] text-zinc-400 tabular-nums shrink-0">
                    {entry.timestamp}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
