import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  Braces,
  ChevronDown,
  ChevronRight,
  Cpu,
  Globe,
  Layers,
  Search,
  Server,
  ShieldCheck,
} from 'lucide-react';
import {
  TOOL_CATEGORIES,
  ToolCategoryConfig,
  ToolCategoryIconKey,
} from '../data/toolsData';
import { ToolWorkbench } from '../components/ToolWorkbench';

interface ToolsPageProps {
  onNavigate?: (path: string) => void;
}

type LeftSidebarSelection =
  | { type: 'category'; categoryId: string }
  | { type: 'tool'; categoryId: string; toolId: string };

function renderCategoryIcon(
  icon: ToolCategoryIconKey,
  className = 'w-4 h-4'
): React.ReactNode {
  switch (icon) {
    case 'network':
      return <Globe className={className} aria-hidden="true" />;
    case 'openshift':
      return <Layers className={className} aria-hidden="true" />;
    case 'middleware':
      return <Server className={className} aria-hidden="true" />;
    case 'decision':
      return <Cpu className={className} aria-hidden="true" />;
    case 'security':
      return <ShieldCheck className={className} aria-hidden="true" />;
    case 'data':
    default:
      return <Braces className={className} aria-hidden="true" />;
  }
}

export const ToolsPage: React.FC<ToolsPageProps> = () => {
  const defaultCategory = TOOL_CATEGORIES[0];

  const [selection, setSelection] = useState<LeftSidebarSelection>({
    type: 'category',
    categoryId: defaultCategory?.id || 'reverse-proxy-network',
  });

  const [expandedCategories, setExpandedCategories] = useState<
    Record<string, boolean>
  >(() => {
    const initial: Record<string, boolean> = {};
    TOOL_CATEGORIES.forEach((cat, idx) => {
      initial[cat.id] = idx === 0;
    });
    return initial;
  });

  const [searchQuery, setSearchQuery] = useState('');

  const filteredSidebarCategories: ToolCategoryConfig[] = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return TOOL_CATEGORIES;

    return TOOL_CATEGORIES.map((cat) => {
      const catMatches =
        cat.label.toLowerCase().includes(q) ||
        cat.description.toLowerCase().includes(q);
      if (catMatches) return cat;

      const matchingTools = cat.tools.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.scope.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q)
      );
      return { ...cat, tools: matchingTools };
    }).filter((cat) => cat.tools.length > 0);
  }, [searchQuery]);

  const activeCategory = useMemo(
    () =>
      TOOL_CATEGORIES.find((c) => c.id === selection.categoryId) ||
      TOOL_CATEGORIES[0],
    [selection.categoryId]
  );

  const activeTool = useMemo(() => {
    if (selection.type !== 'tool') return null;
    return (
      activeCategory.tools.find((t) => t.id === selection.toolId) ||
      activeCategory.tools[0] ||
      null
    );
  }, [selection, activeCategory]);

  const handleCategoryClick = (categoryId: string) => {
    const isCurrentlySelectedCategory =
      selection.type === 'category' && selection.categoryId === categoryId;

    setExpandedCategories((prev) => ({
      ...prev,
      [categoryId]: isCurrentlySelectedCategory ? !prev[categoryId] : true,
    }));

    setSelection({ type: 'category', categoryId });
  };

  const handleToolClick = (categoryId: string, toolId: string) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [categoryId]: true,
    }));
    setSelection({ type: 'tool', categoryId, toolId });
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-10 space-y-8">
      {/* Page Header */}
      <header className="pb-6 border-b border-zinc-200 dark:border-zinc-800 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div className="max-w-2xl space-y-2">
          <p className="text-xs font-medium text-[#2563EB] dark:text-blue-400">
            Tools
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] [text-wrap:balance]">
            Engineering Utilities &amp; Diagnostic Directory
          </h1>
          <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400 leading-relaxed">
            Select a category or tool from the left dropdown tree to launch its
            interactive workspace on the right.
          </p>
        </div>

        <div className="relative w-full sm:w-72 shrink-0">
          <Search
            className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search categories or tools..."
            aria-label="Search categories or tools"
            className="w-full pl-8 pr-3 py-2 text-xs rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB] dark:focus:border-blue-500"
          />
        </div>
      </header>

      {/* Mobile & Tablet Category + Tool Selector */}
      <div className="lg:hidden space-y-3">
        <div className="flex flex-wrap gap-1.5">
          {TOOL_CATEGORIES.map((cat) => {
            const isCatSelected =
              selection.type === 'category' && selection.categoryId === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleCategoryClick(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                  isCatSelected
                    ? 'bg-[#2563EB] border-[#2563EB] text-white'
                    : 'bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                }`}
              >
                {cat.label} ({cat.tools.length})
              </button>
            );
          })}
        </div>

        {activeCategory && (
          <div className="flex flex-wrap gap-1.5 pt-1">
            {activeCategory.tools.map((tool) => {
              const isToolSelected =
                selection.type === 'tool' && selection.toolId === tool.id;
              return (
                <button
                  key={tool.id}
                  type="button"
                  onClick={() => handleToolClick(activeCategory.id, tool.id)}
                  className={`px-2.5 py-1.5 text-[11px] font-medium rounded-md border transition-colors cursor-pointer ${
                    isToolSelected
                      ? 'bg-[#2563EB]/10 border-[#2563EB] text-[#2563EB] dark:text-blue-400'
                      : 'bg-[#FAFAFA] dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                  }`}
                >
                  {tool.name}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Two-Column AstroDeck Layout: Left Dropdown Categories & Tools + Right Active Screen */}
      <div className="flex flex-col lg:flex-row gap-8 lg:gap-10 items-start">
        <aside className="hidden lg:block lg:w-72 lg:shrink-0 lg:sticky lg:top-24">
          <nav
            id="tools-categories-nav"
            aria-label="Tool categories and tools"
            className="space-y-1.5"
          >
            <p className="px-3 mb-3 text-xs font-semibold text-zinc-500 dark:text-zinc-400">
              Categories
            </p>

            {filteredSidebarCategories.length === 0 ? (
              <p className="px-3 py-4 text-xs text-zinc-500 dark:text-zinc-400">
                No matching categories or tools.
              </p>
            ) : (
              filteredSidebarCategories.map((cat) => {
                const isExpanded =
                  searchQuery.trim().length > 0
                    ? true
                    : Boolean(expandedCategories[cat.id]);

                // Strictly highlight ONLY the category when the category itself is the selected item
                const isCategorySelected =
                  selection.type === 'category' &&
                  selection.categoryId === cat.id;

                return (
                  <div key={cat.id} className="space-y-0.5">
                    <button
                      type="button"
                      aria-expanded={isExpanded}
                      onClick={() => handleCategoryClick(cat.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-lg transition-colors duration-150 cursor-pointer text-left ${
                        isCategorySelected
                          ? 'bg-[#2563EB]/10 dark:bg-blue-500/15 text-[#2563EB] dark:text-blue-400 font-medium'
                          : 'text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-900 hover:text-[#09090B] dark:hover:text-zinc-100'
                      }`}
                    >
                      <span className="inline-flex items-center gap-2 min-w-0">
                        {isExpanded ? (
                          <ChevronDown
                            className={`w-3.5 h-3.5 shrink-0 ${
                              isCategorySelected
                                ? 'text-[#2563EB] dark:text-blue-400'
                                : 'text-zinc-400'
                            }`}
                            aria-hidden="true"
                          />
                        ) : (
                          <ChevronRight
                            className={`w-3.5 h-3.5 shrink-0 ${
                              isCategorySelected
                                ? 'text-[#2563EB] dark:text-blue-400'
                                : 'text-zinc-400'
                            }`}
                            aria-hidden="true"
                          />
                        )}
                        {renderCategoryIcon(
                          cat.icon,
                          `w-3.5 h-3.5 shrink-0 ${
                            isCategorySelected
                              ? 'text-[#2563EB] dark:text-blue-400'
                              : 'text-zinc-500 dark:text-zinc-400'
                          }`
                        )}
                        <span className="truncate">{cat.label}</span>
                      </span>

                      <span
                        className={`font-mono text-[11px] tabular-nums ml-2 shrink-0 ${
                          isCategorySelected
                            ? 'text-[#2563EB] dark:text-blue-400'
                            : 'text-zinc-500 dark:text-zinc-400'
                        }`}
                      >
                        ({cat.tools.length})
                      </span>
                    </button>

                    {/* Dropdown Nested Tools List */}
                    {isExpanded && (
                      <div className="pl-7 pr-1 py-1 space-y-0.5">
                        {cat.tools.map((tool) => {
                          const isToolSelected =
                            selection.type === 'tool' &&
                            selection.categoryId === cat.id &&
                            selection.toolId === tool.id;

                          return (
                            <button
                              key={tool.id}
                              type="button"
                              onClick={() => handleToolClick(cat.id, tool.id)}
                              className={`w-full px-2.5 py-1.5 text-xs rounded-md transition-colors duration-150 cursor-pointer text-left truncate block ${
                                isToolSelected
                                  ? 'bg-[#2563EB]/10 dark:bg-blue-500/15 text-[#2563EB] dark:text-blue-400 font-medium'
                                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-900 hover:text-[#09090B] dark:hover:text-zinc-200'
                              }`}
                            >
                              {tool.name}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </nav>
        </aside>

        {/* Right Main Display Area */}
        <div className="flex-1 min-w-0 w-full">
          {activeTool ? (
            <ToolWorkbench
              category={activeCategory}
              tool={activeTool}
              onBackToCategory={() =>
                setSelection({
                  type: 'category',
                  categoryId: activeCategory.id,
                })
              }
            />
          ) : (
            <section
              aria-label={`${activeCategory.label} tools`}
              className="space-y-6"
            >
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 pb-4 border-b border-zinc-200 dark:border-zinc-800">
                <div className="space-y-1">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-lg bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 flex items-center justify-center text-[#2563EB] dark:text-blue-400">
                      {renderCategoryIcon(activeCategory.icon, 'w-3.5 h-3.5')}
                    </span>
                    <h2 className="font-display text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
                      {activeCategory.label}
                    </h2>
                  </div>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed">
                    {activeCategory.description}
                  </p>
                </div>

                <span className="font-mono text-xs text-zinc-500 dark:text-zinc-400 tabular-nums whitespace-nowrap shrink-0">
                  {activeCategory.tools.length} tools
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {activeCategory.tools.map((tool, index) => (
                  <button
                    key={tool.id}
                    type="button"
                    onClick={() => handleToolClick(activeCategory.id, tool.id)}
                    className="text-left p-5 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 hover:border-[#2563EB] dark:hover:border-blue-500 transition-colors flex flex-col justify-between gap-4 cursor-pointer group"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                        <span>
                          {String(index + 1).padStart(2, '0')} · {tool.scope}
                        </span>
                        <ArrowRight
                          className="w-3.5 h-3.5 text-zinc-400 group-hover:text-[#2563EB] dark:group-hover:text-blue-400 transition-colors"
                          aria-hidden="true"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <h3 className="font-display text-base font-semibold text-[#09090B] dark:text-[#FAFAFA] group-hover:text-[#2563EB] dark:group-hover:text-blue-400 transition-colors">
                          {tool.name}
                        </h3>
                        <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
                          {tool.description}
                        </p>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between gap-2 text-[11px] font-mono text-zinc-500 dark:text-zinc-400">
                      <span className="truncate">{tool.ioSpec}</span>
                      <span className="text-[#2563EB] dark:text-blue-400 whitespace-nowrap shrink-0">
                        Open Tool
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
};
