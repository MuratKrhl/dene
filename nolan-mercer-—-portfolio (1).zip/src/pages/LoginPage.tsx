import React, { useState } from 'react';
import { AlertCircle, Eye, EyeOff } from 'lucide-react';

interface LoginPageProps {
  onLoginSuccess: (username: string) => void;
}

const VALID_USERNAME = 'Admin';
const VALID_PASSWORD = 'Admin';

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorField, setErrorField] = useState<'both' | 'password' | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedUser = username.trim();

    if (!trimmedUser || !password) {
      setErrorField('both');
      setErrorMessage('Please enter both username and password.');
      return;
    }

    if (trimmedUser !== VALID_USERNAME) {
      setErrorField('both');
      setErrorMessage('Incorrect username or password. Please check and try again');
      return;
    }

    if (password !== VALID_PASSWORD) {
      setErrorField('password');
      setErrorMessage('Incorrect password. Please check and try again');
      return;
    }

    setErrorField(null);
    setErrorMessage(null);
    onLoginSuccess(VALID_USERNAME);
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#FAFAFA] text-[#09090B]">
      {/* Top Bar */}
      <header className="w-full border-b border-zinc-200 bg-[#FAFAFA]/90 backdrop-blur-md">
        <div className="max-w-[1200px] mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <span className="font-display text-lg font-semibold tracking-tight text-[#09090B] whitespace-nowrap shrink-0">
            Murat Krhl's
          </span>
        </div>
      </header>

      {/* Centered Login Surface */}
      <main className="flex-1 flex items-center justify-center px-4 sm:px-6 py-12">
        <div className="w-full max-w-[440px] rounded-2xl bg-white border border-zinc-200 p-8 sm:p-10 shadow-xs">
          <div className="text-center space-y-2">
            <h1 className="font-display text-3xl font-bold tracking-tight text-[#09090B] [text-wrap:balance]">
              Welcome back!
            </h1>
            <p className="text-sm text-zinc-500">
              Log in to your{' '}
              <span className="font-semibold text-zinc-700">WorkSpace</span> account
            </p>
          </div>

          {errorMessage && (
            <div
              role="alert"
              className="mt-5 flex items-center justify-center gap-2 text-xs sm:text-sm font-medium text-red-600 text-center"
            >
              <AlertCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-7 space-y-5" noValidate>
            <div className="space-y-1.5">
              <label
                htmlFor="login-username"
                className="block text-sm font-medium text-[#09090B]"
              >
                Username
              </label>
              <input
                id="login-username"
                type="text"
                autoComplete="username"
                autoFocus
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  if (errorMessage) {
                    setErrorMessage(null);
                    setErrorField(null);
                  }
                }}
                placeholder="Enter username"
                className={`w-full px-4 py-3 text-sm rounded-xl bg-white text-[#09090B] placeholder:text-zinc-400 border transition-colors focus:outline-none ${
                  errorField === 'both'
                    ? 'border-red-300 focus:border-red-500'
                    : 'border-zinc-200 focus:border-[#2563EB]'
                }`}
              />
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="login-password"
                className="block text-sm font-medium text-[#09090B]"
              >
                Password
              </label>
              <div className="relative">
                <input
                  id="login-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errorMessage) {
                      setErrorMessage(null);
                      setErrorField(null);
                    }
                  }}
                  placeholder="Enter password"
                  className={`w-full pl-4 pr-11 py-3 text-sm rounded-xl bg-white text-[#09090B] placeholder:text-zinc-400 border transition-colors focus:outline-none ${
                    errorField !== null
                      ? 'border-red-300 focus:border-red-500'
                      : 'border-zinc-200 focus:border-[#2563EB]'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-zinc-400 hover:text-[#09090B] transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#2563EB] rounded-md"
                >
                  {showPassword ? (
                    <Eye className="w-4 h-4" aria-hidden="true" />
                  ) : (
                    <EyeOff className="w-4 h-4" aria-hidden="true" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-white bg-[#2563EB] hover:bg-blue-700 transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB]"
            >
              Log in
            </button>
          </form>
        </div>
      </main>

      <footer className="py-6 px-6 text-center text-xs text-zinc-500">
        © 2026 Murat Krhl's WorkSpace. All rights reserved.
      </footer>
    </div>
  );
};
