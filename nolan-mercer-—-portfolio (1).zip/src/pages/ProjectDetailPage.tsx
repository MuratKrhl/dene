import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Maximize2 } from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { ResilientImage } from '../components/ResilientImage';
import { Lightbox } from '../components/Lightbox';

interface ProjectDetailPageProps {
  slug: string;
  onNavigate: (path: string) => void;
}

export const ProjectDetailPage: React.FC<ProjectDetailPageProps> = ({
  slug,
  onNavigate,
}) => {
  const [lightboxOpen, setLightboxOpen] = useState(false);

  const index = PROJECTS.findIndex((p) => p.slug === slug);
  const project = index >= 0 ? PROJECTS[index] : PROJECTS[0];
  const prevProject = PROJECTS[(index - 1 + PROJECTS.length) % PROJECTS.length];
  const nextProject = PROJECTS[(index + 1) % PROJECTS.length];

  const handleLink = (e: React.MouseEvent, path: string) => {
    e.preventDefault();
    onNavigate(path);
  };

  return (
    <article className="max-w-[1200px] mx-auto px-6 py-12 lg:py-16">
      <div className="mb-8">
        <a
          href="/quick-access"
          onClick={(e) => handleLink(e, '/quick-access')}
          className="inline-flex items-center gap-2 text-xs font-medium text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-[#FAFAFA] transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Back to Quick Access</span>
        </a>
      </div>

      {/* Header */}
      <header className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-10 border-b border-zinc-200 dark:border-zinc-800">
        <div className="lg:col-span-8 space-y-4">
          <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
            <span>{project.category}</span>
            <span aria-hidden="true">·</span>
            <span>{project.client}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{project.year}</span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] [text-wrap:balance]">
            {project.title}
          </h1>
          <p className="text-base sm:text-lg text-zinc-600 dark:text-zinc-400 leading-relaxed max-w-2xl">
            {project.summary}
          </p>
        </div>

        <div className="lg:col-span-4 flex flex-col justify-end space-y-3 text-sm">
          <div className="flex items-center justify-between py-2 border-b border-zinc-200 dark:border-zinc-800">
            <span className="text-zinc-500 dark:text-zinc-400">Role</span>
            <span className="font-medium text-[#09090B] dark:text-[#FAFAFA] text-right">
              {project.role}
            </span>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-zinc-200 dark:border-zinc-800">
            <span className="text-zinc-500 dark:text-zinc-400">Timeline</span>
            <span className="font-medium text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
              {project.timeline}
            </span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-zinc-500 dark:text-zinc-400">Client</span>
            <span className="font-medium text-[#09090B] dark:text-[#FAFAFA]">
              {project.client}
            </span>
          </div>
        </div>
      </header>

      {/* Hero Visual */}
      <div className="relative my-10 aspect-[16/9] max-h-[560px] w-full rounded-2xl overflow-hidden border border-zinc-200 dark:border-zinc-800 bg-zinc-100 dark:bg-zinc-900">
        <ResilientImage
          src={project.image}
          alt={project.imageAlt || project.title}
          fallbackTitle={project.title}
          specimenType={project.specimenType}
        />
        {project.image && (
          <button
            type="button"
            onClick={() => setLightboxOpen(true)}
            className="absolute bottom-4 right-4 inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium bg-zinc-950/80 text-white border border-white/15 hover:bg-zinc-950 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Maximize2 className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Expand Preview</span>
          </button>
        )}
      </div>

      {/* Measured Outcomes Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 py-8 px-6 sm:px-8 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 mb-12">
        {project.metrics.map((metric) => (
          <div key={metric.label} className="space-y-1">
            <div className="font-display text-2xl sm:text-3xl font-bold text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
              {metric.value}
            </div>
            <div className="text-xs text-zinc-600 dark:text-zinc-400">
              {metric.label}
            </div>
          </div>
        ))}
      </div>

      {/* Narrative + Deliverables */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 pb-16 border-b border-zinc-200 dark:border-zinc-800">
        <div className="lg:col-span-8 space-y-10">
          <section className="space-y-3">
            <h2 className="font-display text-xl font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              01. The Challenge
            </h2>
            <p className="text-base text-zinc-600 dark:text-zinc-400 leading-relaxed max-w-[68ch]">
              {project.challenge}
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="font-display text-xl font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              02. Design Approach
            </h2>
            <p className="text-base text-zinc-600 dark:text-zinc-400 leading-relaxed max-w-[68ch]">
              {project.approach}
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="font-display text-xl font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              03. Frontend Architecture
            </h2>
            <p className="text-base text-zinc-600 dark:text-zinc-400 leading-relaxed max-w-[68ch]">
              {project.architecture}
            </p>
          </section>
        </div>

        <aside className="lg:col-span-4 space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-4">
            <h2 className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
              Shipped Deliverables
            </h2>
            <ul className="space-y-2.5 text-sm text-[#09090B] dark:text-[#FAFAFA]">
              {project.deliverables.map((item) => (
                <li
                  key={item}
                  className="py-1.5 border-b last:border-b-0 border-zinc-100 dark:border-zinc-800/80"
                >
                  {item}
                </li>
              ))}
            </ul>
            <div className="pt-2">
              <a
                href="/contact"
                onClick={(e) => handleLink(e, '/contact')}
                className="flex items-center justify-center gap-2 w-full px-4 py-2.5 text-xs font-medium text-white bg-[#2563EB] hover:bg-blue-700 rounded-lg transition-colors"
              >
                <span>Discuss a Similar Scope</span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </a>
            </div>
          </div>
        </aside>
      </div>

      {/* Previous / Next Case Study */}
      <nav
        aria-label="Case study pagination"
        className="pt-10 grid grid-cols-1 sm:grid-cols-2 gap-6"
      >
        <a
          href={`/work/${prevProject.slug}`}
          onClick={(e) => handleLink(e, `/work/${prevProject.slug}`)}
          className="p-6 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors space-y-1"
        >
          <span className="inline-flex items-center gap-1.5 text-xs text-zinc-500 dark:text-zinc-400">
            <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Previous Case Study</span>
          </span>
          <div className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA]">
            {prevProject.title}
          </div>
        </a>

        <a
          href={`/work/${nextProject.slug}`}
          onClick={(e) => handleLink(e, `/work/${nextProject.slug}`)}
          className="p-6 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors space-y-1 sm:text-right"
        >
          <span className="inline-flex items-center gap-1.5 text-xs text-zinc-500 dark:text-zinc-400 sm:justify-end">
            <span>Next Case Study</span>
            <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
          </span>
          <div className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA]">
            {nextProject.title}
          </div>
        </a>
      </nav>

      <Lightbox
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        title={project.title}
        subtitle={`${project.client} · ${project.year}`}
        image={project.image}
        alt={project.imageAlt || project.title}
      />
    </article>
  );
};
