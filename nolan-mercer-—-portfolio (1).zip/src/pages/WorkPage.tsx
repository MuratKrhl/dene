import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowUpRight,
  Bookmark,
  Check,
  ChevronDown,
  ChevronRight,
  Copy,
  Folder,
  FolderOpen,
  Search,
  Star,
} from 'lucide-react';
import {
  BOOKMARK_COLLECTIONS,
  RaindropBookmark,
} from '../data/portfolioData';
import {
  BookmarkIcon,
  BookmarkInlineFavicon,
} from '../components/BookmarkIcon';
import { loadBookmarks, saveBookmarks } from '../services/bookmarksStore';
import { NfsExplorer } from '../nfs/components/NfsExplorer';

interface WorkPageProps {
  onNavigate: (path: string) => void;
  initialTab?: 'bookmarks' | 'nfs';
  nfsSourceId?: string;
}

type QuickAccessTab = 'bookmarks' | 'nfs';
type CollectionSelection =
  | { type: 'all' }
  | { type: 'favorites' }
  | { type: 'collection'; collection: string }
  | { type: 'subcollection'; collection: string; subCollection: string };

export const WorkPage: React.FC<WorkPageProps> = ({
  onNavigate,
  initialTab = 'bookmarks',
  nfsSourceId,
}) => {
  const [activeTab, setActiveTab] = useState<QuickAccessTab>(initialTab);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  // Raindrop-style Bookmarks State (managed from Admin > Bookmarks)
  const [bookmarks, setBookmarks] = useState<RaindropBookmark[]>(() =>
    loadBookmarks()
  );
  const [selection, setSelection] = useState<CollectionSelection>({ type: 'all' });
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({
    engineering: true,
    design: true,
    infrastructure: true,
    reading: true,
  });
  const [bookmarkSearch, setBookmarkSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const persistBookmarks = (next: RaindropBookmark[]) => {
    setBookmarks(next);
    saveBookmarks(next);
  };

  const filteredBookmarks = useMemo(() => {
    const q = bookmarkSearch.trim().toLowerCase();
    return bookmarks.filter((item) => {
      let matchesSel = true;
      if (selection.type === 'favorites') {
        matchesSel = Boolean(item.favorite);
      } else if (selection.type === 'collection') {
        matchesSel = item.collection === selection.collection;
      } else if (selection.type === 'subcollection') {
        matchesSel =
          item.collection === selection.collection &&
          item.subCollection === selection.subCollection;
      }

      const matchesQuery =
        !q ||
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.domain.toLowerCase().includes(q) ||
        item.collection.toLowerCase().includes(q) ||
        item.subCollection.toLowerCase().includes(q);

      return matchesSel && matchesQuery;
    });
  }, [bookmarks, selection, bookmarkSearch]);

  const activeHeading = useMemo(() => {
    if (selection.type === 'all') return 'All Bookmarks';
    if (selection.type === 'favorites') return 'Favorites';
    if (selection.type === 'collection') return selection.collection;
    return `${selection.collection} / ${selection.subCollection}`;
  }, [selection]);

  const countForCollection = (col: string) =>
    bookmarks.filter((b) => b.collection === col).length;

  const countForSubCollection = (col: string, sub: string) =>
    bookmarks.filter((b) => b.collection === col && b.subCollection === sub).length;

  const favoritesCount = useMemo(
    () => bookmarks.filter((b) => b.favorite).length,
    [bookmarks]
  );

  const toggleGroup = (id: string) => {
    setExpandedGroups((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleToggleFavorite = (id: string) => {
    persistBookmarks(
      bookmarks.map((b) => (b.id === id ? { ...b, favorite: !b.favorite } : b))
    );
  };

  const handleCopyBookmarkUrl = async (item: RaindropBookmark) => {
    try {
      await navigator.clipboard.writeText(item.url);
      setCopiedId(item.id);
      window.setTimeout(() => setCopiedId(null), 1600);
    } catch {
      setCopiedId(null);
    }
  };

  const handleLink = (e: React.MouseEvent, path: string) => {
    e.preventDefault();
    onNavigate(path);
  };

  const handleSelectTab = (tab: QuickAccessTab) => {
    setActiveTab(tab);
    onNavigate(tab === 'nfs' ? '/quick-access/nfs' : '/quick-access');
  };

  return (
    <div
      className={`mx-auto transition-[max-width] duration-150 ${
        activeTab === 'nfs'
          ? 'max-w-[1440px] px-4 sm:px-6 lg:px-8 py-6 lg:py-8 space-y-5'
          : 'max-w-[1200px] px-6 py-12 lg:py-16 space-y-10'
      }`}
    >
      <header className={`text-center max-w-2xl mx-auto ${activeTab === 'nfs' ? 'space-y-1.5' : 'space-y-3'}`}>
        <p className="text-xs font-medium text-[#2563EB] dark:text-blue-400">
          Quick Access
        </p>
        <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] [text-wrap:balance]">
          Bookmarks &amp; Network File System
        </h1>
        {activeTab !== 'nfs' && (
          <p className="text-base text-zinc-600 dark:text-zinc-400 leading-relaxed">
            Organized collections for engineering bookmarks and enterprise document
            sources across network shares, SharePoint, and local folders.
          </p>
        )}
      </header>

      {/* Centered Segmented Tabs */}
      <div className="flex justify-center">
        <div
          role="tablist"
          aria-label="Quick Access sections"
          className="inline-flex items-center gap-1 p-1 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'bookmarks'}
            onClick={() => handleSelectTab('bookmarks')}
            className={`px-5 py-2 text-xs font-medium rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB] ${
              activeTab === 'bookmarks'
                ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
            }`}
          >
            Bookmarks
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'nfs'}
            onClick={() => handleSelectTab('nfs')}
            className={`px-5 py-2 text-xs font-medium rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB] ${
              activeTab === 'nfs'
                ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
            }`}
          >
            NFS (Network File System)
          </button>
        </div>
      </div>

      {/* TAB 1: ASTRODECK SIDEBAR + RAINDROP-STYLE BOOKMARKS */}
      {activeTab === 'bookmarks' && (
        <section
          aria-label="Bookmarks collections and items"
          className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
        >
          {/* Left Sticky Categories Sidebar (AstroDeck / Raindrop structure) */}
          <aside className="lg:col-span-3 lg:sticky lg:top-24 space-y-6">
            {/* System Filters */}
            <div className="space-y-1">
              <button
                type="button"
                onClick={() => setSelection({ type: 'all' })}
                className={`w-full px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between transition-colors cursor-pointer ${
                  selection.type === 'all'
                    ? 'bg-zinc-200/70 dark:bg-zinc-800 text-[#09090B] dark:text-[#FAFAFA]'
                    : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-900 hover:text-[#09090B] dark:hover:text-zinc-200'
                }`}
              >
                <span className="inline-flex items-center gap-2.5">
                  <Bookmark className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400" />
                  <span>All Bookmarks</span>
                </span>
                <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                  {bookmarks.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setSelection({ type: 'favorites' })}
                className={`w-full px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between transition-colors cursor-pointer ${
                  selection.type === 'favorites'
                    ? 'bg-zinc-200/70 dark:bg-zinc-800 text-[#09090B] dark:text-[#FAFAFA]'
                    : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-900 hover:text-[#09090B] dark:hover:text-zinc-200'
                }`}
              >
                <span className="inline-flex items-center gap-2.5">
                  <Star className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400" />
                  <span>Favorites</span>
                </span>
                <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                  {favoritesCount}
                </span>
              </button>
            </div>

            {/* Collections Tree */}
            <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 space-y-2">
              <div className="px-3 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                Collections
              </div>

              <div className="space-y-1">
                {BOOKMARK_COLLECTIONS.map((group) => {
                  const isExpanded = expandedGroups[group.id] ?? true;
                  const isGroupSelected =
                    selection.type === 'collection' &&
                    selection.collection === group.label;

                  return (
                    <div key={group.id} className="space-y-0.5">
                      <div className="flex items-center">
                        <button
                          type="button"
                          onClick={() => toggleGroup(group.id)}
                          aria-label={`Toggle ${group.label} subcollections`}
                          className="p-1.5 rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
                        >
                          {isExpanded ? (
                            <ChevronDown className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronRight className="w-3.5 h-3.5" />
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            setSelection({
                              type: 'collection',
                              collection: group.label,
                            })
                          }
                          className={`flex-1 px-2 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between transition-colors cursor-pointer ${
                            isGroupSelected
                              ? 'bg-zinc-200/70 dark:bg-zinc-800 text-[#09090B] dark:text-[#FAFAFA]'
                              : 'text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-900'
                          }`}
                        >
                          <span className="inline-flex items-center gap-2 truncate">
                            {isExpanded ? (
                              <FolderOpen className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400 shrink-0" />
                            ) : (
                              <Folder className="w-3.5 h-3.5 text-zinc-500 dark:text-zinc-400 shrink-0" />
                            )}
                            <span className="truncate">{group.label}</span>
                          </span>
                          <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums ml-2">
                            {countForCollection(group.label)}
                          </span>
                        </button>
                      </div>

                      {isExpanded && (
                        <div className="pl-7 space-y-0.5">
                          {group.children.map((sub) => {
                            const isSubSelected =
                              selection.type === 'subcollection' &&
                              selection.collection === group.label &&
                              selection.subCollection === sub.label;

                            return (
                              <button
                                key={sub.id}
                                type="button"
                                onClick={() =>
                                  setSelection({
                                    type: 'subcollection',
                                    collection: group.label,
                                    subCollection: sub.label,
                                  })
                                }
                                className={`w-full px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors cursor-pointer ${
                                  isSubSelected
                                    ? 'bg-[#2563EB]/10 dark:bg-blue-500/15 text-[#2563EB] dark:text-blue-400 font-medium'
                                    : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-900 hover:text-[#09090B] dark:hover:text-zinc-200'
                                }`}
                              >
                                <span className="truncate">{sub.label}</span>
                                <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums ml-2">
                                  {countForSubCollection(group.label, sub.label)}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </aside>

          {/* Right Main Bookmarks Pane */}
          <div className="lg:col-span-9 space-y-5">
            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-baseline gap-2.5">
                <h2 className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                  {activeHeading}
                </h2>
                <span className="text-xs font-mono text-zinc-500 dark:text-zinc-400 tabular-nums">
                  {filteredBookmarks.length} items
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <div className="relative w-full sm:w-56">
                  <Search
                    className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    type="search"
                    value={bookmarkSearch}
                    onChange={(e) => setBookmarkSearch(e.target.value)}
                    placeholder="Filter bookmarks..."
                    aria-label="Filter bookmarks"
                    className="w-full pl-8 pr-3 py-2 text-xs rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
                  />
                </div>
              </div>
            </div>

            {/* Raindrop.io-style Hairline-Divided Bookmark Rows */}
            {filteredBookmarks.length === 0 ? (
              <div className="py-14 text-center rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#111114] space-y-3">
                <p className="text-sm font-medium text-[#09090B] dark:text-[#FAFAFA]">
                  No bookmarks found in {activeHeading}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSelection({ type: 'all' });
                    setBookmarkSearch('');
                  }}
                  className="px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] text-white hover:bg-blue-700 transition-colors cursor-pointer"
                >
                  Show All Bookmarks
                </button>
              </div>
            ) : (
              <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 divide-y divide-zinc-200 dark:divide-zinc-800 overflow-hidden">
                {filteredBookmarks.map((item) => {
                  const isInternal = Boolean(item.internalPath);

                  return (
                    <article
                      key={item.id}
                      className="p-5 flex items-start gap-4 hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40 transition-colors duration-150"
                    >
                      {/* KiwiBookmark-style Favicon / Preset Icon Tile */}
                      <BookmarkIcon
                        title={item.title}
                        domain={item.domain}
                        url={item.url}
                        iconKey={item.iconKey}
                        iconUrl={item.iconUrl}
                        tone={item.tone}
                        size="md"
                      />

                      {/* Content & Breadcrumb Metadata */}
                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex items-start justify-between gap-4">
                          <div className="min-w-0 space-y-1">
                            <h3 className="font-display text-base font-semibold text-[#09090B] dark:text-[#FAFAFA] truncate">
                              <a
                                href={item.url}
                                target={isInternal ? undefined : '_blank'}
                                rel={isInternal ? undefined : 'noopener noreferrer'}
                                onClick={
                                  isInternal && item.internalPath
                                    ? (e) => handleLink(e, item.internalPath!)
                                    : undefined
                                }
                                className="hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors"
                              >
                                {item.title}
                              </a>
                            </h3>
                            <p className="text-sm text-zinc-600 dark:text-zinc-400 line-clamp-1">
                              {item.description}
                            </p>
                          </div>

                          {/* Row Actions */}
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => handleToggleFavorite(item.id)}
                              aria-label={
                                item.favorite
                                  ? `Remove ${item.title} from favorites`
                                  : `Add ${item.title} to favorites`
                              }
                              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                                item.favorite
                                  ? 'text-[#2563EB] dark:text-blue-400'
                                  : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
                              }`}
                            >
                              <Star
                                className={`w-4 h-4 ${
                                  item.favorite ? 'fill-current' : ''
                                }`}
                              />
                            </button>

                            <button
                              type="button"
                              onClick={() => handleCopyBookmarkUrl(item)}
                              aria-label={`Copy URL for ${item.title}`}
                              className="p-1.5 rounded-md text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors cursor-pointer"
                            >
                              {copiedId === item.id ? (
                                <Check className="w-4 h-4 text-[#2563EB] dark:text-blue-400" />
                              ) : (
                                <Copy className="w-4 h-4" />
                              )}
                            </button>

                            <a
                              href={item.url}
                              target={isInternal ? undefined : '_blank'}
                              rel={isInternal ? undefined : 'noopener noreferrer'}
                              onClick={
                                isInternal && item.internalPath
                                  ? (e) => handleLink(e, item.internalPath!)
                                  : undefined
                              }
                              aria-label={`Open ${item.title}`}
                              className="p-1.5 rounded-md text-zinc-400 hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors"
                            >
                              <ArrowUpRight className="w-4 h-4" />
                            </a>
                          </div>
                        </div>

                        {/* Raindrop Metadata + Collection Hierarchy Row */}
                        <div className="flex flex-wrap items-center gap-x-5 gap-y-1 pt-1 text-xs text-zinc-500 dark:text-zinc-400">
                          <div className="flex items-center gap-2 tabular-nums">
                            <span>{item.date}</span>
                            <span aria-hidden="true">·</span>
                            <span className="inline-flex items-center gap-1.5 font-mono text-[11px] text-zinc-600 dark:text-zinc-300">
                              <BookmarkInlineFavicon
                                domain={item.domain}
                                url={item.url}
                                iconKey={item.iconKey}
                                iconUrl={item.iconUrl}
                              />
                              <span>{item.domain}</span>
                            </span>
                          </div>

                          <div className="inline-flex items-center gap-1.5 text-zinc-600 dark:text-zinc-300">
                            <Folder
                              className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400"
                              aria-hidden="true"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                setSelection({
                                  type: 'collection',
                                  collection: item.collection,
                                })
                              }
                              className="hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors cursor-pointer"
                            >
                              {item.collection}
                            </button>
                            <ChevronRight
                              className="w-3 h-3 text-zinc-400"
                              aria-hidden="true"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                setSelection({
                                  type: 'subcollection',
                                  collection: item.collection,
                                  subCollection: item.subCollection,
                                })
                              }
                              className="font-medium hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors cursor-pointer"
                            >
                              {item.subCollection}
                            </button>
                          </div>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      )}

      {/* TAB 2: NFS (NETWORK FILE SYSTEM) */}
      {activeTab === 'nfs' && (
        <section aria-label="NFS Enterprise File Explorer">
          <NfsExplorer
            onNavigate={onNavigate}
            initialSourceId={nfsSourceId}
          />
        </section>
      )}
    </div>
  );
};
