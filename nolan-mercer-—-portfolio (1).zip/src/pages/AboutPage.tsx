import React, { useEffect, useState } from 'react';
import {
  ENVIRONMENT_TABS,
  EnvironmentTabKey,
} from '../data/environmentData';
import { EnvironmentTable } from '../components/EnvironmentTable';

interface AboutPageProps {
  onNavigate: (path: string) => void;
  initialTab?: EnvironmentTabKey;
}

export const AboutPage: React.FC<AboutPageProps> = ({
  onNavigate,
  initialTab = 'sunucu',
}) => {
  const [activeTab, setActiveTab] = useState<EnvironmentTabKey>(initialTab);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  const handleSelectTab = (tab: EnvironmentTabKey) => {
    setActiveTab(tab);
    onNavigate(tab === 'sunucu' ? '/environment' : `/environment/${tab}`);
  };

  const activeConfig =
    ENVIRONMENT_TABS.find((t) => t.key === activeTab) || ENVIRONMENT_TABS[0];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-10 space-y-6">
      <header className="text-center max-w-2xl mx-auto space-y-2">
        <p className="text-xs font-medium text-[#2563EB] dark:text-blue-400">
          Environment
        </p>
        <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] [text-wrap:balance]">
          Infrastructure &amp; Platform Inventory
        </h1>
        <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400 leading-relaxed">
          {activeConfig.description}
        </p>
      </header>

      {/* Centered Segmented Tabs (Matching Bookmarks & NFS structure) */}
      <div className="flex justify-center">
        <div
          role="tablist"
          aria-label="Environment categories"
          className="inline-flex flex-wrap justify-center items-center gap-1 p-1 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
        >
          {ENVIRONMENT_TABS.map((tab) => {
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => handleSelectTab(tab.key)}
                className={`px-4 py-2 text-xs font-medium rounded-md transition-colors duration-150 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB] ${
                  isActive
                    ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Tab Enterprise Inventory Table */}
      <section aria-label={`${activeConfig.label} environment inventory`}>
        <EnvironmentTable tabConfig={activeConfig} onNavigate={onNavigate} />
      </section>
    </div>
  );
};
