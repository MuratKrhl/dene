import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Check,
  ChevronDown,
  ChevronRight,
  Copy,
  Cpu,
  Download,
  Edit3,
  FileCode2,
  Globe,
  Layers,
  MoreHorizontal,
  Network,
  RefreshCw,
  Server,
  ShieldCheck,
  Workflow,
  Zap,
} from 'lucide-react';
import {
  ActivityEventItem,
  buildEnvironmentDetailProfile,
  ENVIRONMENT_TABS,
  EnvironmentEntry,
  EnvironmentTabKey,
  findEnvironmentEntryByRoute,
  loadEnvironmentEntries,
  saveEnvironmentEntries,
  toEntrySlug,
} from '../data/environmentData';

type DetailTab = 'overview' | 'upstreams' | 'tls' | 'configuration' | 'activity';

interface EnvironmentDetailPageProps {
  tab: EnvironmentTabKey;
  slug: string;
  onNavigate: (path: string) => void;
}

function getTabIcon(tab: EnvironmentTabKey) {
  switch (tab) {
    case 'sunucu':
      return Server;
    case 'uygulama':
      return Layers;
    case 'openshift':
      return Cpu;
    case 'reverse-proxy':
      return ShieldCheck;
    case 'provenir':
      return Workflow;
    case 'evam':
      return Zap;
    case 'powercurve':
      return Network;
    default:
      return Globe;
  }
}

function getBackLabel(tab: EnvironmentTabKey, label: string): string {
  if (tab === 'reverse-proxy') return 'Back to Reverse Proxies';
  if (tab === 'sunucu') return 'Back to Servers';
  if (tab === 'uygulama') return 'Back to Applications';
  return `Back to ${label}`;
}

function getEnvFullName(env: EnvironmentEntry['env']): string {
  if (env === 'Prod') return 'Production';
  if (env === 'Pre-Prod') return 'Pre-Production';
  if (env === 'DR') return 'Disaster Recovery';
  return env;
}

function getStatusDotClass(status: EnvironmentEntry['status']): string {
  switch (status) {
    case 'Online':
    case 'Healthy':
    case 'Active':
      return 'bg-emerald-500';
    case 'Degraded':
      return 'bg-red-500';
    case 'Maintenance':
      return 'bg-amber-500';
    case 'Standby':
    default:
      return 'bg-zinc-400';
  }
}

function getStatusPillClass(status: EnvironmentEntry['status']): string {
  switch (status) {
    case 'Online':
    case 'Healthy':
    case 'Active':
      return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-900/60';
    case 'Degraded':
      return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950/50 dark:text-red-300 dark:border-red-900/60';
    case 'Maintenance':
      return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-900/60';
    case 'Standby':
    default:
      return 'bg-zinc-100 text-zinc-700 border-zinc-200 dark:bg-zinc-800 dark:text-zinc-300 dark:border-zinc-700';
  }
}

export const EnvironmentDetailPage: React.FC<EnvironmentDetailPageProps> = ({
  tab,
  slug,
  onNavigate,
}) => {
  const tabConfig =
    ENVIRONMENT_TABS.find((t) => t.key === tab) || ENVIRONMENT_TABS[0];

  const [entry, setEntry] = useState<EnvironmentEntry | null>(() =>
    findEnvironmentEntryByRoute(tab, slug)
  );
  const [activeTab, setActiveTab] = useState<DetailTab>('overview');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [upstreamHealthFilter, setUpstreamHealthFilter] = useState<
    'all' | 'Healthy' | 'Degraded' | 'Unhealthy'
  >('all');
  const [hoveredPointIdx, setHoveredPointIdx] = useState<number | null>(null);
  const [sessionEvents, setSessionEvents] = useState<ActivityEventItem[]>([]);

  // Edit form state
  const [editName, setEditName] = useState('');
  const [editSubtitle, setEditSubtitle] = useState('');
  const [editEndpoint, setEditEndpoint] = useState('');
  const [editEnv, setEditEnv] = useState<EnvironmentEntry['env']>('Prod');
  const [editStatus, setEditStatus] =
    useState<EnvironmentEntry['status']>('Active');
  const [editOwner, setEditOwner] = useState('');
  const [editZone, setEditZone] = useState('');
  const [editNotes, setEditNotes] = useState('');

  useEffect(() => {
    const resolved = findEnvironmentEntryByRoute(tab, slug);
    setEntry(resolved);
    setActiveTab('overview');
    setIsEditing(false);
    setMoreMenuOpen(false);
    setSessionEvents([]);
  }, [tab, slug]);

  useEffect(() => {
    if (!entry) return;
    setEditName(entry.name);
    setEditSubtitle(entry.subtitle);
    setEditEndpoint(entry.endpoint);
    setEditEnv(entry.env);
    setEditStatus(entry.status);
    setEditOwner(entry.owner);
    setEditZone(entry.regionOrCluster);
    setEditNotes(entry.notes || '');
  }, [entry]);

  const profile = useMemo(
    () => (entry ? buildEnvironmentDetailProfile(entry) : null),
    [entry]
  );

  const listPath =
    tab === 'sunucu' ? '/environment' : `/environment/${tab}`;

  const handleBackToList = () => {
    if (
      window.history.state &&
      (window.history.state as { fromWorkspaceApp?: boolean }).fromWorkspaceApp
    ) {
      window.history.back();
    } else {
      onNavigate(listPath);
    }
  };

  const handleCopyText = async (key: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedKey(key);
      window.setTimeout(() => setCopiedKey(null), 1500);
    } catch {
      setCopiedKey(null);
    }
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!entry || !editName.trim() || !editEndpoint.trim()) return;

    const today = new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: '2-digit',
      year: 'numeric',
    });

    const updated: EnvironmentEntry = {
      ...entry,
      name: editName.trim(),
      subtitle: editSubtitle.trim() || entry.subtitle,
      endpoint: editEndpoint.trim(),
      env: editEnv,
      status: editStatus,
      owner: editOwner.trim() || entry.owner,
      regionOrCluster: editZone.trim() || entry.regionOrCluster,
      notes: editNotes.trim(),
      updatedAt: today,
    };

    const all = loadEnvironmentEntries();
    const next = all.map((item) => (item.id === entry.id ? updated : item));
    saveEnvironmentEntries(next);
    setEntry(updated);
    setIsEditing(false);

    setSessionEvents((prev) => [
      {
        id: `local-${Date.now()}`,
        timestamp: `${today} · Just now`,
        actor: 'murat.krhl',
        action: 'Updated Configuration Metadata',
        target: `${updated.name} (${updated.env} · ${updated.status})`,
        severity: 'info',
      },
      ...prev,
    ]);

    const nextSlug = toEntrySlug(updated);
    if (nextSlug !== slug) {
      onNavigate(`/environment/${tab}/${encodeURIComponent(nextSlug)}`);
    }
  };

  const handleRunHealthCheck = () => {
    if (!entry) return;
    const nowLabel = new Date().toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
    });
    setSessionEvents((prev) => [
      {
        id: `probe-${Date.now()}`,
        timestamp: `Nov 16, 2026 · ${nowLabel}`,
        actor: 'Manual Health Probe',
        action: 'Verified Endpoint Reachability',
        target: `${entry.endpoint} responded (${entry.status})`,
        severity:
          entry.status === 'Degraded'
            ? 'critical'
            : entry.status === 'Maintenance'
            ? 'warning'
            : 'ok',
      },
      ...prev,
    ]);
    setMoreMenuOpen(false);
  };

  const handleExportJson = () => {
    if (!entry || !profile) return;
    const payload = JSON.stringify({ entry, profile }, null, 2);
    const blob = new Blob([payload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${toEntrySlug(entry)}-spec.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    setMoreMenuOpen(false);
  };

  const handleDownloadConfig = () => {
    if (!profile) return;
    const blob = new Blob([profile.configSnippet], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = profile.configFilename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const TabIcon = getTabIcon(tab);

  if (!entry || !profile) {
    return (
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-lg mx-auto p-8 rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 text-center space-y-4">
          <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto" />
          <div className="space-y-1">
            <h1 className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              Environment record not found
            </h1>
            <p className="text-xs text-zinc-600 dark:text-zinc-400">
              No entry matching “{slug}” was found under {tabConfig.label}.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate(listPath)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{getBackLabel(tab, tabConfig.label)}</span>
          </button>
        </div>
      </div>
    );
  }

  // SVG Chart Geometry (24h Traffic Trend)
  const chartW = 520;
  const chartH = 148;
  const padX = 10;
  const padY = 14;
  const maxRps = Math.max(...profile.trafficSeries.map((p) => p.rps), 10);
  const minRps = Math.min(...profile.trafficSeries.map((p) => p.rps));
  const rangeRps = Math.max(maxRps - minRps, 1);

  const coords = profile.trafficSeries.map((pt, idx) => {
    const x =
      padX +
      (idx / (profile.trafficSeries.length - 1)) * (chartW - padX * 2);
    const y =
      chartH -
      padY -
      ((pt.rps - minRps) / rangeRps) * (chartH - padY * 2);
    return { x, y, ...pt };
  });

  const linePath = coords
    .map((c, idx) => `${idx === 0 ? 'M' : 'L'} ${c.x.toFixed(1)} ${c.y.toFixed(1)}`)
    .join(' ');
  const areaPath = `${linePath} L ${coords[coords.length - 1].x.toFixed(1)} ${(
    chartH - padY
  ).toFixed(1)} L ${coords[0].x.toFixed(1)} ${(chartH - padY).toFixed(1)} Z`;

  const activePoint =
    hoveredPointIdx !== null
      ? coords[hoveredPointIdx]
      : coords[coords.length - 1];

  const allActivities = [...sessionEvents, ...profile.activities];
  const filteredUpstreams =
    upstreamHealthFilter === 'all'
      ? profile.upstreams
      : profile.upstreams.filter((u) => u.health === upstreamHealthFilter);

  const detailTabs: Array<{ id: DetailTab; label: string }> = [
    { id: 'overview', label: 'Overview' },
    { id: 'upstreams', label: 'Upstreams' },
    { id: 'tls', label: 'TLS & Certificates' },
    { id: 'configuration', label: 'Configuration' },
    { id: 'activity', label: 'Activity' },
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8 space-y-6">
      {/* Detail Page Header */}
      <header className="bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
        <div className="p-5 sm:p-6 space-y-4">
          {/* Breadcrumb */}
          <nav
            aria-label="Breadcrumb"
            className="flex flex-wrap items-center gap-1.5 text-xs text-zinc-500 dark:text-zinc-400"
          >
            <a
              href="/environment"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('/environment');
              }}
              className="hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors"
            >
              Environment
            </a>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" aria-hidden="true" />
            <a
              href={listPath}
              onClick={(e) => {
                e.preventDefault();
                onNavigate(listPath);
              }}
              className="hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors"
            >
              {tabConfig.label}
            </a>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" aria-hidden="true" />
            <span className="font-mono text-[#09090B] dark:text-[#FAFAFA] font-medium">
              {entry.name}
            </span>
          </nav>

          {/* Title & Actions Row */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5 min-w-0">
              <div className="w-11 h-11 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-center text-[#2563EB] dark:text-blue-400 shrink-0">
                <TabIcon className="w-5 h-5" aria-hidden="true" />
              </div>

              <div className="min-w-0 space-y-1">
                <div className="flex flex-wrap items-center gap-2.5">
                  <h1 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
                    {entry.name}
                  </h1>
                  <span
                    className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border text-[11px] font-medium ${getStatusPillClass(
                      entry.status
                    )}`}
                  >
                    <span
                      aria-hidden="true"
                      className={`w-1.5 h-1.5 rounded-full ${getStatusDotClass(
                        entry.status
                      )}`}
                    />
                    <span>
                      {entry.env} · {entry.status}
                    </span>
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400">
                  {entry.subtitle}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0 relative">
              <button
                type="button"
                onClick={handleBackToList}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{getBackLabel(tab, tabConfig.label)}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsEditing((v) => !v)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{isEditing ? 'Close Edit' : 'Edit'}</span>
              </button>

              <div className="relative">
                <button
                  type="button"
                  onClick={() => setMoreMenuOpen((v) => !v)}
                  aria-expanded={moreMenuOpen}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors cursor-pointer"
                >
                  <MoreHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>More Actions</span>
                  <ChevronDown className="w-3 h-3 text-zinc-400" aria-hidden="true" />
                </button>

                {moreMenuOpen && (
                  <div className="absolute right-0 top-10 z-30 w-52 py-1.5 rounded-xl bg-white dark:bg-[#141418] border border-zinc-200 dark:border-zinc-800 shadow-lg text-xs">
                    <button
                      type="button"
                      onClick={() => {
                        handleCopyText('menu-ep', entry.endpoint);
                        setMoreMenuOpen(false);
                      }}
                      className="w-full px-3 py-2 text-left flex items-center gap-2 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Endpoint</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleCopyText('menu-url', window.location.href);
                        setMoreMenuOpen(false);
                      }}
                      className="w-full px-3 py-2 text-left flex items-center gap-2 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                    >
                      <Globe className="w-3.5 h-3.5" />
                      <span>Copy Detail Page URL</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleRunHealthCheck}
                      className="w-full px-3 py-2 text-left flex items-center gap-2 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Run Health Probe</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleExportJson}
                      className="w-full px-3 py-2 text-left flex items-center gap-2 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export JSON Spec</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Inline Edit Panel */}
          {isEditing && (
            <form
              onSubmit={handleSaveEdit}
              className="pt-4 border-t border-zinc-200 dark:border-zinc-800 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end"
            >
              <div className="sm:col-span-3 space-y-1">
                <label className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                  Name *
                </label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                />
              </div>

              <div className="sm:col-span-3 space-y-1">
                <label className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                  Endpoint *
                </label>
                <input
                  type="text"
                  required
                  value={editEndpoint}
                  onChange={(e) => setEditEndpoint(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs font-mono rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                />
              </div>

              <div className="sm:col-span-2 space-y-1">
                <label className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                  Environment
                </label>
                <select
                  value={editEnv}
                  onChange={(e) =>
                    setEditEnv(e.target.value as EnvironmentEntry['env'])
                  }
                  className="w-full px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                >
                  <option value="Prod">Prod</option>
                  <option value="UAT">UAT</option>
                  <option value="Pre-Prod">Pre-Prod</option>
                  <option value="DR">DR</option>
                  <option value="Test">Test</option>
                </select>
              </div>

              <div className="sm:col-span-2 space-y-1">
                <label className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                  Status
                </label>
                <select
                  value={editStatus}
                  onChange={(e) =>
                    setEditStatus(e.target.value as EnvironmentEntry['status'])
                  }
                  className="w-full px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                >
                  <option value="Active">Active</option>
                  <option value="Online">Online</option>
                  <option value="Healthy">Healthy</option>
                  <option value="Degraded">Degraded</option>
                  <option value="Maintenance">Maintenance</option>
                  <option value="Standby">Standby</option>
                </select>
              </div>

              <div className="sm:col-span-2 space-y-1">
                <label className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                  Owner
                </label>
                <input
                  type="text"
                  value={editOwner}
                  onChange={(e) => setEditOwner(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                />
              </div>

              <div className="sm:col-span-5 space-y-1">
                <label className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                  Description
                </label>
                <input
                  type="text"
                  value={editSubtitle}
                  onChange={(e) => setEditSubtitle(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                />
              </div>

              <div className="sm:col-span-4 space-y-1">
                <label className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400">
                  Zone / Cluster
                </label>
                <input
                  type="text"
                  value={editZone}
                  onChange={(e) => setEditZone(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA]"
                />
              </div>

              <div className="sm:col-span-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Horizontal Tab Navigation */}
        <div
          role="tablist"
          aria-label="Detail sections"
          className="px-5 sm:px-6 border-t border-zinc-200 dark:border-zinc-800 flex items-center gap-6 overflow-x-auto"
        >
          {detailTabs.map((t) => {
            const active = activeTab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActiveTab(t.id)}
                className={`relative py-3 text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  active
                    ? 'text-[#09090B] dark:text-[#FAFAFA]'
                    : 'text-zinc-500 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
                }`}
              >
                <span>{t.label}</span>
                {t.id === 'upstreams' && (
                  <span className="ml-1.5 font-mono text-[11px] text-zinc-400 tabular-nums">
                    ({profile.upstreams.length})
                  </span>
                )}
                {active && (
                  <span
                    aria-hidden="true"
                    className="absolute left-0 right-0 bottom-0 h-[2px] bg-[#2563EB] dark:bg-blue-400"
                  />
                )}
              </button>
            );
          })}
        </div>
      </header>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* A. Four Compact Summary Metrics (Unified Hairline Grid) */}
          <section
            aria-label="Summary metrics"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl divide-y sm:divide-y-0 sm:divide-x divide-zinc-200 dark:divide-zinc-800"
          >
            <div className="p-4 sm:p-5 space-y-1">
              <div className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                Upstreams
              </div>
              <div className="font-display text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                {profile.upstreamCount}
              </div>
              <div className="text-xs text-zinc-600 dark:text-zinc-400 tabular-nums">
                {profile.unhealthyCount > 0 ? (
                  <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{profile.unhealthyCount} unhealthy upstreams</span>
                  </span>
                ) : (
                  'All upstreams healthy'
                )}
              </div>
            </div>

            <div className="p-4 sm:p-5 space-y-1">
              <div className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                24h Request Rate
              </div>
              <div className="font-display text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                {profile.requestRate}
              </div>
              <div className="text-xs text-emerald-600 dark:text-emerald-400 tabular-nums">
                Traffic trend {profile.trafficDelta}
              </div>
            </div>

            <div className="p-4 sm:p-5 space-y-1">
              <div className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                Average Latency
              </div>
              <div className="font-display text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                {profile.avgLatencyMs} ms
              </div>
              <div className="text-xs text-zinc-600 dark:text-zinc-400 tabular-nums">
                P95 latency {profile.p95LatencyMs} ms
              </div>
            </div>

            <div className="p-4 sm:p-5 space-y-1">
              <div className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                TLS Certificate
              </div>
              <div className="font-display text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                {profile.tlsSummaryValue}
              </div>
              <div className="text-xs tabular-nums">
                {entry.alertLevel === 'critical' ? (
                  <span className="inline-flex items-center gap-1 text-red-600 dark:text-red-400 font-medium">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{profile.tlsSummaryNote}</span>
                  </span>
                ) : entry.alertLevel === 'warning' ? (
                  <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{profile.tlsSummaryNote}</span>
                  </span>
                ) : (
                  <span className="text-zinc-600 dark:text-zinc-400">
                    {profile.tlsSummaryNote}
                  </span>
                )}
              </div>
            </div>
          </section>

          {/* B. Proxy Information (Left) + C. Health & Traffic (Right) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* B. Two-Column Technical Information Table */}
            <section
              aria-label="Proxy Information"
              className="lg:col-span-6 bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden"
            >
              <div className="px-5 py-3.5 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
                <h2 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                  {tab === 'reverse-proxy'
                    ? 'Proxy Information'
                    : `${tabConfig.label} Information`}
                </h2>
                <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400">
                  {entry.code}
                </span>
              </div>

              <dl className="divide-y divide-zinc-200 dark:divide-zinc-800 text-xs">
                {[
                  { label: 'Name', value: entry.name },
                  { label: 'Code', value: entry.code, mono: true },
                  { label: 'Environment', value: getEnvFullName(entry.env) },
                  { label: 'Zone', value: entry.regionOrCluster },
                  {
                    label: 'Status',
                    value: `${entry.env} · ${entry.status}`,
                    statusDot: true,
                  },
                  {
                    label: 'Endpoint',
                    value: entry.endpoint,
                    mono: true,
                    copyable: true,
                  },
                  { label: 'Protocol', value: profile.protocol },
                  { label: 'Owner', value: entry.owner },
                  { label: 'Created', value: profile.createdAt },
                  { label: 'Last Updated', value: entry.updatedAt },
                ].map((row) => (
                  <div
                    key={row.label}
                    className="px-5 py-2.5 grid grid-cols-12 gap-3 items-center"
                  >
                    <dt className="col-span-4 text-zinc-500 dark:text-zinc-400 font-medium">
                      {row.label}
                    </dt>
                    <dd
                      className={`col-span-8 flex items-center justify-between gap-2 text-[#09090B] dark:text-[#FAFAFA] ${
                        row.mono ? 'font-mono text-[11px]' : ''
                      }`}
                    >
                      <span className="inline-flex items-center gap-1.5 truncate">
                        {row.statusDot && (
                          <span
                            aria-hidden="true"
                            className={`w-1.5 h-1.5 rounded-full shrink-0 ${getStatusDotClass(
                              entry.status
                            )}`}
                          />
                        )}
                        <span className="truncate tabular-nums">{row.value}</span>
                      </span>

                      {row.copyable && (
                        <button
                          type="button"
                          onClick={() => handleCopyText('info-ep', entry.endpoint)}
                          aria-label="Copy endpoint to clipboard"
                          className="p-1 rounded text-zinc-400 hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors cursor-pointer shrink-0"
                        >
                          {copiedKey === 'info-ep' ? (
                            <Check className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      )}
                    </dd>
                  </div>
                ))}
              </dl>
            </section>

            {/* C. Compact Health & Traffic Monitoring */}
            <section
              aria-label="Health and Traffic"
              className="lg:col-span-6 bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden"
            >
              <div className="px-5 py-3.5 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Activity
                    className="w-4 h-4 text-[#2563EB] dark:text-blue-400"
                    aria-hidden="true"
                  />
                  <h2 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                    Health &amp; Traffic
                  </h2>
                </div>
                <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span>
                    {entry.status === 'Degraded'
                      ? 'Degraded'
                      : entry.status === 'Maintenance'
                      ? 'Maintenance'
                      : 'Operational'}
                  </span>
                </span>
              </div>

              <div className="p-5 space-y-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-500 dark:text-zinc-400">
                    24h Traffic Trend
                  </span>
                  <span className="font-mono text-[11px] text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                    {activePoint.hour} · {activePoint.rps.toLocaleString()} req/s ·{' '}
                    {activePoint.p95Ms} ms P95
                  </span>
                </div>

                {/* Native Lightweight SVG Chart */}
                <div className="w-full">
                  <svg
                    viewBox={`0 0 ${chartW} ${chartH}`}
                    className="w-full h-36 overflow-visible"
                    role="img"
                    aria-label="24 hour traffic trend chart"
                    onMouseLeave={() => setHoveredPointIdx(null)}
                  >
                    <defs>
                      <linearGradient id="envTrafficFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#2563EB" stopOpacity="0.18" />
                        <stop offset="100%" stopColor="#2563EB" stopOpacity="0.01" />
                      </linearGradient>
                    </defs>

                    {[0.25, 0.5, 0.75].map((ratio) => {
                      const y = padY + ratio * (chartH - padY * 2);
                      return (
                        <line
                          key={ratio}
                          x1={padX}
                          x2={chartW - padX}
                          y1={y}
                          y2={y}
                          stroke="currentColor"
                          className="text-zinc-200 dark:text-zinc-800"
                          strokeDasharray="3 3"
                        />
                      );
                    })}

                    <path d={areaPath} fill="url(#envTrafficFill)" />
                    <path
                      d={linePath}
                      fill="none"
                      stroke="#2563EB"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />

                    {coords.map((c, idx) => (
                      <g key={c.hour}>
                        <rect
                          x={c.x - 10}
                          y={0}
                          width={20}
                          height={chartH}
                          fill="transparent"
                          className="cursor-crosshair"
                          onMouseEnter={() => setHoveredPointIdx(idx)}
                        />
                        {(hoveredPointIdx === idx ||
                          (hoveredPointIdx === null && idx === coords.length - 1)) && (
                          <circle
                            cx={c.x}
                            cy={c.y}
                            r="3.5"
                            fill="#2563EB"
                            stroke="#FFFFFF"
                            strokeWidth="1.5"
                          />
                        )}
                      </g>
                    ))}
                  </svg>
                  <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400 tabular-nums pt-1">
                    <span>00:00</span>
                    <span>06:00</span>
                    <span>12:00</span>
                    <span>18:00</span>
                    <span>23:00</span>
                  </div>
                </div>

                {/* Compact Monitoring Readouts */}
                <div className="pt-3 border-t border-zinc-200 dark:border-zinc-800 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                  <div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      Request Rate
                    </div>
                    <div className="font-mono font-semibold text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                      {profile.requestRate}
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      Availability
                    </div>
                    <div className="font-mono font-semibold text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                      {profile.availability}
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      Avg Latency
                    </div>
                    <div className="font-mono font-semibold text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                      {profile.avgLatencyMs} ms
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      P95 Latency
                    </div>
                    <div className="font-mono font-semibold text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                      {profile.p95LatencyMs} ms
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>

          {/* D. Upstream Services Mini Table */}
          <section
            aria-label="Upstream Services"
            className="bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden"
          >
            <div className="px-5 py-3.5 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <h2 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                  Upstream Services
                </h2>
                <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                  {profile.upstreams.length} connected
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('upstreams')}
                className="text-xs font-medium text-[#2563EB] dark:text-blue-400 hover:underline cursor-pointer"
              >
                Manage All Upstreams
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                    <th className="px-5 py-2.5">Service</th>
                    <th className="px-3 py-2.5">Endpoint</th>
                    <th className="px-3 py-2.5">Health</th>
                    <th className="px-3 py-2.5">Traffic</th>
                    <th className="px-3 py-2.5">Weight</th>
                    <th className="px-5 py-2.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                  {profile.upstreams.map((up) => (
                    <tr
                      key={up.id}
                      className="hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40 transition-colors"
                    >
                      <td className="px-5 py-2.5 font-medium text-[#09090B] dark:text-[#FAFAFA]">
                        {up.service}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-zinc-600 dark:text-zinc-400">
                        {up.endpoint}
                      </td>
                      <td className="px-3 py-2.5 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1.5 tabular-nums">
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              up.health === 'Healthy'
                                ? 'bg-emerald-500'
                                : up.health === 'Degraded'
                                ? 'bg-amber-500'
                                : 'bg-red-500'
                            }`}
                          />
                          <span
                            className={
                              up.health === 'Unhealthy'
                                ? 'text-red-600 dark:text-red-400 font-medium'
                                : up.health === 'Degraded'
                                ? 'text-amber-600 dark:text-amber-400 font-medium'
                                : 'text-zinc-700 dark:text-zinc-300'
                            }
                          >
                            {up.health}
                          </span>
                        </span>
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-zinc-700 dark:text-zinc-300 tabular-nums">
                        {up.traffic}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-zinc-600 dark:text-zinc-400 tabular-nums">
                        {up.weight}
                      </td>
                      <td className="px-5 py-2.5 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => handleCopyText(`up-${up.id}`, up.endpoint)}
                          aria-label={`Copy ${up.service} endpoint`}
                          className="p-1.5 rounded-md text-zinc-400 hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors cursor-pointer"
                        >
                          {copiedKey === `up-${up.id}` ? (
                            <Check className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      )}

      {/* TAB 2: UPSTREAMS */}
      {activeTab === 'upstreams' && (
        <section
          aria-label="Upstream pool table"
          className="bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden"
        >
          <div className="px-5 py-3.5 border-b border-zinc-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <h2 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                Upstream Pool &amp; Load Distribution
              </h2>
              <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                {filteredUpstreams.length} / {profile.upstreams.length}
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-xs">
              {(['all', 'Healthy', 'Degraded', 'Unhealthy'] as const).map(
                (st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setUpstreamHealthFilter(st)}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-medium cursor-pointer transition-colors ${
                      upstreamHealthFilter === st
                        ? 'bg-[#2563EB] text-white'
                        : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                    }`}
                  >
                    {st === 'all' ? 'All' : st}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                  <th className="px-5 py-2.5">Service</th>
                  <th className="px-3 py-2.5">Endpoint</th>
                  <th className="px-3 py-2.5">Health</th>
                  <th className="px-3 py-2.5">Traffic</th>
                  <th className="px-3 py-2.5">Latency</th>
                  <th className="px-3 py-2.5">Active Conns</th>
                  <th className="px-3 py-2.5">Weight</th>
                  <th className="px-5 py-2.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                {filteredUpstreams.map((up) => (
                  <tr
                    key={up.id}
                    className="hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40"
                  >
                    <td className="px-5 py-3 font-medium text-[#09090B] dark:text-[#FAFAFA]">
                      {up.service}
                    </td>
                    <td className="px-3 py-3 font-mono text-[11px] text-zinc-600 dark:text-zinc-400">
                      {up.endpoint}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5">
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            up.health === 'Healthy'
                              ? 'bg-emerald-500'
                              : up.health === 'Degraded'
                              ? 'bg-amber-500'
                              : 'bg-red-500'
                          }`}
                        />
                        <span>{up.health}</span>
                      </span>
                    </td>
                    <td className="px-3 py-3 font-mono text-[11px] tabular-nums">
                      {up.traffic}
                    </td>
                    <td className="px-3 py-3 font-mono text-[11px] tabular-nums">
                      {up.latencyMs > 0 ? `${up.latencyMs} ms` : '—'}
                    </td>
                    <td className="px-3 py-3 font-mono text-[11px] tabular-nums">
                      {up.activeConns}
                    </td>
                    <td className="px-3 py-3 font-mono text-[11px] tabular-nums">
                      {up.weight}
                    </td>
                    <td className="px-5 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => handleCopyText(`up-tab-${up.id}`, up.endpoint)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-zinc-200 dark:border-zinc-800 text-[11px] hover:border-[#2563EB] cursor-pointer"
                      >
                        {copiedKey === `up-tab-${up.id}` ? (
                          <>
                            <Check className="w-3 h-3 text-[#2563EB]" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* TAB 3: TLS & CERTIFICATES */}
      {activeTab === 'tls' && (
        <section
          aria-label="TLS and Certificates"
          className="bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden"
        >
          <div className="px-5 py-3.5 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
            <h2 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              TLS Certificate &amp; Transport Security
            </h2>
            {entry.alertLevel && entry.alertLevel !== 'none' && (
              <span
                className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                  entry.alertLevel === 'critical'
                    ? 'text-red-600 dark:text-red-400'
                    : 'text-amber-600 dark:text-amber-400'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{entry.alertNote || profile.tlsSummaryNote}</span>
              </span>
            )}
          </div>

          <dl className="divide-y divide-zinc-200 dark:divide-zinc-800 text-xs">
            {[
              { label: 'Common Name (CN)', value: profile.tls.commonName, mono: true },
              { label: 'Issuing Authority', value: profile.tls.issuer },
              { label: 'Serial Number', value: profile.tls.serialNumber, mono: true },
              { label: 'Valid From', value: profile.tls.validFrom },
              { label: 'Valid Until', value: profile.tls.validTo },
              {
                label: 'Remaining Validity',
                value: `${profile.tls.daysRemaining} days`,
              },
              { label: 'TLS Protocols', value: profile.tls.tlsVersions, mono: true },
              { label: 'Cipher Suite', value: profile.tls.cipherSuite, mono: true },
              { label: 'mTLS Policy', value: profile.tls.mtlsMode },
              { label: 'OCSP Stapling', value: profile.tls.ocspStapling },
              { label: 'HSTS Header', value: profile.tls.hsts, mono: true },
              {
                label: 'Subject Alternative Names',
                value: profile.tls.sans.join(', '),
                mono: true,
              },
            ].map((row) => (
              <div
                key={row.label}
                className="px-5 py-3 grid grid-cols-12 gap-3 items-center"
              >
                <dt className="col-span-4 sm:col-span-3 text-zinc-500 dark:text-zinc-400 font-medium">
                  {row.label}
                </dt>
                <dd
                  className={`col-span-8 sm:col-span-9 text-[#09090B] dark:text-[#FAFAFA] break-all ${
                    row.mono ? 'font-mono text-[11px]' : ''
                  }`}
                >
                  {row.value}
                </dd>
              </div>
            ))}
          </dl>
        </section>
      )}

      {/* TAB 4: CONFIGURATION */}
      {activeTab === 'configuration' && (
        <section
          aria-label="Runtime configuration"
          className="bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden"
        >
          <div className="px-5 py-3.5 border-b border-zinc-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <FileCode2
                className="w-4 h-4 text-[#2563EB] dark:text-blue-400"
                aria-hidden="true"
              />
              <span className="font-mono text-xs font-medium text-[#09090B] dark:text-[#FAFAFA]">
                {profile.configFilename}
              </span>
              <span className="text-[11px] text-zinc-500 dark:text-zinc-400">
                · {entry.version}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleCopyText('cfg', profile.configSnippet)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 hover:border-zinc-300 cursor-pointer"
              >
                {copiedKey === 'cfg' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#2563EB]" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Config</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleDownloadConfig}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </button>
            </div>
          </div>

          <pre className="p-5 overflow-x-auto bg-[#FAFAFA] dark:bg-[#09090B] font-mono text-xs leading-relaxed text-[#09090B] dark:text-zinc-200">
            <code>{profile.configSnippet}</code>
          </pre>
        </section>
      )}

      {/* TAB 5: ACTIVITY */}
      {activeTab === 'activity' && (
        <section
          aria-label="Operational activity log"
          className="bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden"
        >
          <div className="px-5 py-3.5 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
            <h2 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              Audit &amp; Operational Activity
            </h2>
            <button
              type="button"
              onClick={handleRunHealthCheck}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 hover:border-zinc-300 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Run Probe Now</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                  <th className="px-5 py-2.5">Timestamp</th>
                  <th className="px-3 py-2.5">Actor</th>
                  <th className="px-3 py-2.5">Event</th>
                  <th className="px-5 py-2.5">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                {allActivities.map((act) => (
                  <tr
                    key={act.id}
                    className="hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40"
                  >
                    <td className="px-5 py-3 font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums whitespace-nowrap">
                      {act.timestamp}
                    </td>
                    <td className="px-3 py-3 font-medium text-[#09090B] dark:text-[#FAFAFA] whitespace-nowrap">
                      {act.actor}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5">
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            act.severity === 'critical'
                              ? 'bg-red-500'
                              : act.severity === 'warning'
                              ? 'bg-amber-500'
                              : act.severity === 'ok'
                              ? 'bg-emerald-500'
                              : 'bg-[#2563EB]'
                          }`}
                        />
                        <span>{act.action}</span>
                      </span>
                    </td>
                    <td className="px-5 py-3 text-zinc-600 dark:text-zinc-300">
                      {act.target}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
};
