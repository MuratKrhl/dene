export type OneNoteSourceType = 'windows' | 'https';

export interface OneNoteSource {
  id: string;
  name: string;
  type: OneNoteSourceType;
  location: string;
  description: string;
  accent: 'cobalt' | 'emerald' | 'amber' | 'slate';
  status: 'Synced' | 'Connected' | 'Local Mounted';
  lastSynced: string;
  enabled: boolean;
}

export interface OneNoteFileItem {
  id: string;
  sourceId: string;
  section: string;
  fileName: string;
  title: string;
  content: string;
  relativePath: string;
  fileFormat: '.one' | '.onetoc2' | '.md' | '.txt';
  tags: string[];
  starred?: boolean;
  updatedAt: string;
  updatedBy: string;
  version: number;
}

const SOURCES_KEY = 'mk-onenote-sources-v1';
const FILES_KEY = 'mk-onenote-files-v1';

export const INITIAL_ONENOTE_SOURCES: OneNoteSource[] = [
  {
    id: 'on-src-win-middleware',
    name: 'Middleware Engineering Notebook',
    type: 'windows',
    location: '\\\\corp-fs01.internal\\engineering\\OneNote\\Middleware',
    description:
      'Windows UNC shared OneNote notebook for JBoss EAP 8, Reverse Proxy, and OpenShift runbooks.',
    accent: 'cobalt',
    status: 'Synced',
    lastSynced: '18 Nov 2026 · 09:30',
    enabled: true,
  },
  {
    id: 'on-src-https-architecture',
    name: 'Decisioning & Risk Architecture',
    type: 'https',
    location:
      'https://corp.sharepoint.com/sites/Engineering/SiteAssets/DecisioningNotebook',
    description:
      'HTTPS SharePoint-hosted OneNote notebook for Provenir 8.7, Evam CEP, and PowerCurve.',
    accent: 'emerald',
    status: 'Connected',
    lastSynced: '18 Nov 2026 · 09:15',
    enabled: true,
  },
];

export const INITIAL_ONENOTE_FILES: OneNoteFileItem[] = [
  {
    id: 'on-file-1',
    sourceId: 'on-src-win-middleware',
    section: 'JBoss EAP 8',
    fileName: 'JBoss-EAP8-Migration-Checklist.one',
    title: 'JBoss EAP 8 Elytron & Datasource Migration Checklist',
    relativePath: 'Middleware\\JBoss EAP 8\\JBoss-EAP8-Migration-Checklist.one',
    fileFormat: '.one',
    tags: ['JBoss', 'Jakarta EE 10', 'Elytron'],
    starred: true,
    updatedAt: '18 Nov 2026',
    updatedBy: 'Admin',
    version: 3,
    content: `# JBoss EAP 8 Migration Checklist

1. Verify Java 21 runtime & JBoss EAP 8 base image on OpenShift.
2. Execute JBoss Server Migration Tool against standalone-full.xml.
3. Replace legacy security-domain blocks with Elytron credential stores.
4. Validate PostgreSQL / Oracle XA datasource pool thresholds and blocking-timeout-millis.
5. Confirm /health/ready and /health/live probes before Canary cutover.`,
  },
  {
    id: 'on-file-2',
    sourceId: 'on-src-win-middleware',
    section: 'Reverse Proxy & TLS',
    fileName: 'Edge-Gateway-mTLS-Rotation.one',
    title: 'Edge Gateway mTLS Certificate Rotation SOP',
    relativePath: 'Middleware\\Reverse Proxy & TLS\\Edge-Gateway-mTLS-Rotation.one',
    fileFormat: '.one',
    tags: ['mTLS', 'Nginx', 'Certificates'],
    starred: false,
    updatedAt: '16 Nov 2026',
    updatedBy: 'Admin',
    version: 2,
    content: `# Edge Gateway mTLS Rotation SOP

- Verify certificate chain order: leaf -> intermediate CA -> root CA.
- Test handshake via: openssl s_client -connect gw.corp.internal:443 -servername gw.corp.internal
- Validate HSTS max-age=31536000 and OCSP stapling response.
- Perform graceful reload and monitor 5xx error budget for 15 minutes.`,
  },
  {
    id: 'on-file-3',
    sourceId: 'on-src-win-middleware',
    section: 'OpenShift Platform',
    fileName: 'Cluster-Drain-PDB-Guardrails.one',
    title: 'OpenShift Cluster Drain & PDB Guardrails',
    relativePath: 'Middleware\\OpenShift Platform\\Cluster-Drain-PDB-Guardrails.one',
    fileFormat: '.one',
    tags: ['OpenShift', 'SRE', 'PDB'],
    starred: false,
    updatedAt: '14 Nov 2026',
    updatedBy: 'Admin',
    version: 1,
    content: `# Cluster Drain Guardrails

- Ensure PodDisruptionBudget minAvailable >= 1 on stateful gateway workloads.
- Verify HPA minReplicas >= 2 distributed across worker zones.
- Run oc adm top nodes & oc adm top pods before node patch drain.`,
  },
  {
    id: 'on-file-4',
    sourceId: 'on-src-https-architecture',
    section: 'Provenir 8.7',
    fileName: 'Provenir-Shadow-Replay-Thresholds.one',
    title: 'Provenir 8.7 Shadow Replay Diff & Bureau Parity',
    relativePath:
      'DecisioningNotebook/Provenir 8.7/Provenir-Shadow-Replay-Thresholds.one',
    fileFormat: '.one',
    tags: ['Provenir', 'Decisioning', 'UAT'],
    starred: true,
    updatedAt: '17 Nov 2026',
    updatedBy: 'Admin',
    version: 4,
    content: `# Provenir 8.7 Shadow Replay Verification

- Replay target: 100,000 anonymized retail & SME credit applications.
- Acceptable decision variance threshold: < 0.01%.
- Validate KKB & Findeks mTLS adapter timeout (1800ms) and fallback circuit breaker.
- Compare P95 latency against 8.6.4 baseline before Blue/Green cutover.`,
  },
  {
    id: 'on-file-5',
    sourceId: 'on-src-https-architecture',
    section: 'Evam & Streaming',
    fileName: 'Evam-Kafka-Partition-Tuning.one',
    title: 'Evam CEP Kafka Consumer & Partition Tuning Notes',
    relativePath:
      'DecisioningNotebook/Evam & Streaming/Evam-Kafka-Partition-Tuning.one',
    fileFormat: '.one',
    tags: ['Evam', 'Kafka', 'CEP'],
    starred: false,
    updatedAt: '15 Nov 2026',
    updatedBy: 'Admin',
    version: 2,
    content: `# Evam CEP Kafka Consumer Tuning

- Monitor consumer group lag during 09:00-11:00 authorization burst window.
- Match Kafka topic partitions (36) to actor thread pool concurrency.
- Verify SASL_SSL truststore rotation schedule ahead of Nov 26 deadline.`,
  },
];

export function formatOneNoteDate(): string {
  return new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatOneNoteTimestamp(): string {
  const datePart = formatOneNoteDate();
  const timePart = new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
  return `${datePart} · ${timePart}`;
}

export function loadOneNoteSources(): OneNoteSource[] {
  try {
    const raw = localStorage.getItem(SOURCES_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // Fallback
  }
  return INITIAL_ONENOTE_SOURCES;
}

export function saveOneNoteSources(sources: OneNoteSource[]): void {
  try {
    localStorage.setItem(SOURCES_KEY, JSON.stringify(sources));
  } catch {
    // Ignore storage errors
  }
}

export function loadOneNoteFiles(): OneNoteFileItem[] {
  try {
    const raw = localStorage.getItem(FILES_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // Fallback
  }
  return INITIAL_ONENOTE_FILES;
}

export function saveOneNoteFiles(files: OneNoteFileItem[]): void {
  try {
    localStorage.setItem(FILES_KEY, JSON.stringify(files));
  } catch {
    // Ignore storage errors
  }
}

export function detectOneNoteFileFormat(
  filename: string
): OneNoteFileItem['fileFormat'] {
  const lower = filename.toLowerCase();
  if (lower.endsWith('.onetoc2')) return '.onetoc2';
  if (lower.endsWith('.md')) return '.md';
  if (lower.endsWith('.txt')) return '.txt';
  return '.one';
}
