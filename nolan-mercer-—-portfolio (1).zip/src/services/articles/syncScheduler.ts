import {
  AggregationSyncConfig,
  AggregationSyncSummary,
} from '../../types/articleSource';
import { syncAllArticleSources } from './articleAggregator';

export interface AggregationSyncSchedulerContract {
  readonly mode: 'browser-open' | 'backend-scheduler';
  getNextRunAt(
    summary: AggregationSyncSummary | null,
    config: AggregationSyncConfig
  ): string | null;
  isSyncDue(
    summary: AggregationSyncSummary | null,
    config: AggregationSyncConfig,
    nowMs?: number
  ): boolean;
  triggerScheduledSync(): Promise<void>;
}

export function getNextAggregationSyncAt(
  summary: AggregationSyncSummary | null,
  config: AggregationSyncConfig
): string | null {
  if (!config.autoSyncEnabled) {
    return null;
  }
  const baseIso = summary?.lastSuccessfulSyncAt || summary?.syncedAt;
  if (!baseIso) {
    return new Date().toISOString();
  }
  const baseMs = Date.parse(baseIso);
  if (Number.isNaN(baseMs)) {
    return new Date().toISOString();
  }
  const intervalMs = config.autoSyncIntervalHours * 60 * 60 * 1000;
  return new Date(baseMs + intervalMs).toISOString();
}

export function isAggregationSyncDue(
  summary: AggregationSyncSummary | null,
  config: AggregationSyncConfig,
  nowMs: number = Date.now()
): boolean {
  if (!config.autoSyncEnabled) {
    return false;
  }
  if (!summary || !summary.lastSuccessfulSyncAt) {
    return true;
  }
  const lastMs = Date.parse(summary.lastSuccessfulSyncAt);
  if (Number.isNaN(lastMs)) {
    return true;
  }
  const intervalMs = config.autoSyncIntervalHours * 60 * 60 * 1000;
  return nowMs - lastMs >= intervalMs;
}

/**
 * Browser-open scheduler (checks while Workspace is active and catches up on reopen).
 * When continuous background execution is needed while the app is closed, swap in a
 * server-side cron/worker implementing `AggregationSyncSchedulerContract`.
 */
export const browserAggregationSyncScheduler: AggregationSyncSchedulerContract = {
  mode: 'browser-open',
  getNextRunAt: getNextAggregationSyncAt,
  isSyncDue: isAggregationSyncDue,
  async triggerScheduledSync() {
    await syncAllArticleSources();
  },
};
