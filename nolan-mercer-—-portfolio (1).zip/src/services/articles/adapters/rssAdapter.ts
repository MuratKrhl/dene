import { FeedParseResult, RawFeedItem } from '../../../types/article';
import { decodeHtmlEntities } from '../../medium/mediumParser';
import {
  estimateReadingTimeIfSubstantial,
  extractSafeImageUrlFromHtml,
  normalizeArticleUrl,
  parseOptionalIsoDate,
  sanitizeFeedHtmlToText,
  stripCdata,
} from './sanitizeHtml';

export class FeedParseError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'FeedParseError';
  }
}

function getChildTextByTags(parent: Element, tagNames: string[]): string {
  for (const tag of tagNames) {
    const shortTag = tag.split(':').pop()!.toLowerCase();
    const direct = Array.from(parent.children).find((el) => {
      const t = el.tagName?.toLowerCase() || '';
      const l = el.localName?.toLowerCase() || '';
      return t === tag.toLowerCase() || l === shortTag;
    });
    if (direct && direct.textContent) {
      return direct.textContent.trim();
    }
    const byTag = parent.getElementsByTagName(tag);
    if (byTag.length > 0 && byTag[0].textContent) {
      return byTag[0].textContent.trim();
    }
  }
  return '';
}

function getMediaImageFromNode(node: Element): string | null {
  const candidates = ['media:content', 'media:thumbnail', 'enclosure'];
  for (const tag of candidates) {
    const els = Array.from(node.getElementsByTagName(tag));
    for (const el of els) {
      const type = (el.getAttribute('type') || '').toLowerCase();
      if (tag === 'enclosure' && type && !type.startsWith('image/')) {
        continue;
      }
      const url = el.getAttribute('url');
      if (url && (url.startsWith('https://') || url.startsWith('http://'))) {
        return url.replace(/^http:\/\//i, 'https://');
      }
    }
  }
  return null;
}

function resolveFeedUrl(rawLink: string, baseWebsiteUrl?: string): string {
  const trimmed = (rawLink || '').trim();
  if (!trimmed) return '';
  if (trimmed.startsWith('/') && baseWebsiteUrl) {
    try {
      return normalizeArticleUrl(new URL(trimmed, baseWebsiteUrl).toString());
    } catch {
      return '';
    }
  }
  return normalizeArticleUrl(trimmed);
}

function parseRssWithBrowserDom(
  xmlText: string,
  baseWebsiteUrl?: string
): FeedParseResult {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlText, 'text/xml');
  const parseErrors = doc.getElementsByTagName('parsererror');
  if (parseErrors.length > 0) {
    if (xmlText.includes('<rss') || xmlText.includes('<channel')) {
      return parseRssWithRegexFallback(xmlText, baseWebsiteUrl);
    }
    throw new FeedParseError(
      `Invalid RSS XML: ${parseErrors[0].textContent?.slice(0, 120) || 'parse error'}`
    );
  }

  const channelNode = doc.getElementsByTagName('channel')[0];
  const feedTitle =
    (channelNode ? getChildTextByTags(channelNode, ['title']) : '') || 'RSS Feed';
  const rssItems = Array.from(doc.getElementsByTagName('item'));

  if (!channelNode && rssItems.length === 0) {
    throw new FeedParseError('RSS document does not contain a <channel> element.');
  }

  const items: RawFeedItem[] = [];
  let skippedInvalidCount = 0;

  for (const node of rssItems) {
    const title = decodeHtmlEntities(getChildTextByTags(node, ['title'])).trim();
    if (!title) {
      skippedInvalidCount++;
      continue;
    }

    let rawLink = getChildTextByTags(node, ['link']);
    if (!rawLink) {
      const linkEl = Array.from(node.getElementsByTagName('link')).find((el) =>
        Boolean(el.getAttribute('href'))
      );
      rawLink = linkEl?.getAttribute('href') || '';
    }
    const articleUrl = resolveFeedUrl(rawLink, baseWebsiteUrl);
    if (!articleUrl) {
      skippedInvalidCount++;
      continue;
    }

    const rawGuid = getChildTextByTags(node, ['guid', 'id']);
    const guid = rawGuid
      ? resolveFeedUrl(rawGuid, baseWebsiteUrl) || rawGuid
      : articleUrl;

    // Never invent an author when absent
    const rawAuthor = decodeHtmlEntities(
      getChildTextByTags(node, ['dc:creator', 'creator', 'author', 'name'])
    ).trim();
    const author = rawAuthor || null;

    // Never invent a publication date when absent
    const publishedAt = parseOptionalIsoDate(
      getChildTextByTags(node, ['pubDate', 'published', 'dc:date', 'updated'])
    );
    const updatedAt = parseOptionalIsoDate(
      getChildTextByTags(node, ['atom:updated', 'updated'])
    );

    const contentEncoded = getChildTextByTags(node, [
      'content:encoded',
      'encoded',
      'content',
    ]);
    const descriptionRaw = getChildTextByTags(node, ['description', 'summary']);
    const richestHtml =
      contentEncoded.length > descriptionRaw.length ? contentEncoded : descriptionRaw;

    const imageUrl =
      getMediaImageFromNode(node) ||
      extractSafeImageUrlFromHtml(contentEncoded) ||
      extractSafeImageUrlFromHtml(descriptionRaw);

    const { summary, contentSnippet, content, paragraphs } =
      sanitizeFeedHtmlToText(richestHtml);

    const categoryEls = Array.from(node.getElementsByTagName('category'));
    const tags = Array.from(
      new Set(
        categoryEls
          .map((el) =>
            decodeHtmlEntities(el.textContent || el.getAttribute('term') || '')
              .trim()
              .toLowerCase()
          )
          .filter(Boolean)
      )
    );

    items.push({
      guid,
      title,
      author,
      publishedAt,
      updatedAt,
      summary,
      contentSnippet,
      content,
      imageUrl,
      articleUrl,
      tags,
      paragraphs,
      readingTime: estimateReadingTimeIfSubstantial(content || contentSnippet),
    });
  }

  return { feedTitle, items, skippedInvalidCount };
}

function extractXmlTag(block: string, tagName: string): string {
  const escaped = tagName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(
    `<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`,
    'i'
  );
  const match = block.match(regex);
  return match ? stripCdata(match[1]) : '';
}

function extractAllXmlTags(block: string, tagName: string): string[] {
  const escaped = tagName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(
    `<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`,
    'gi'
  );
  const values: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = regex.exec(block)) !== null) {
    const cleaned = stripCdata(m[1]).trim();
    if (cleaned) values.push(cleaned);
  }
  return values;
}

function extractMediaUrlRegex(block: string): string | null {
  const match = block.match(
    /<(?:media:content|media:thumbnail|enclosure)\b[^>]+url=["']([^"']+)["'][^>]*>/i
  );
  if (!match) return null;
  const candidate = decodeHtmlEntities(match[1].trim());
  if (!candidate.startsWith('http')) return null;
  return candidate.replace(/^http:\/\//i, 'https://');
}

function parseRssWithRegexFallback(
  xmlText: string,
  baseWebsiteUrl?: string
): FeedParseResult {
  if (!xmlText.includes('<rss') && !xmlText.includes('<channel')) {
    throw new FeedParseError('Invalid RSS XML: missing <rss> or <channel>.');
  }

  const feedTitle =
    decodeHtmlEntities(extractXmlTag(xmlText, 'title')) || 'RSS Feed';
  const itemBlocks = xmlText.match(/<item\b[\s\S]*?<\/item>/gi) || [];

  const items: RawFeedItem[] = [];
  let skippedInvalidCount = 0;

  for (const block of itemBlocks) {
    const title = decodeHtmlEntities(extractXmlTag(block, 'title')).trim();
    if (!title) {
      skippedInvalidCount++;
      continue;
    }

    const rawLink = extractXmlTag(block, 'link');
    const articleUrl = resolveFeedUrl(rawLink, baseWebsiteUrl);
    if (!articleUrl) {
      skippedInvalidCount++;
      continue;
    }

    const rawGuid = extractXmlTag(block, 'guid');
    const guid = rawGuid
      ? resolveFeedUrl(rawGuid, baseWebsiteUrl) || rawGuid
      : articleUrl;

    const rawAuthor = decodeHtmlEntities(
      extractXmlTag(block, 'dc:creator') || extractXmlTag(block, 'author')
    ).trim();
    const author = rawAuthor || null;

    const publishedAt = parseOptionalIsoDate(
      extractXmlTag(block, 'pubDate') ||
        extractXmlTag(block, 'dc:date') ||
        extractXmlTag(block, 'published')
    );
    const updatedAt = parseOptionalIsoDate(
      extractXmlTag(block, 'atom:updated') || extractXmlTag(block, 'updated')
    );

    const contentEncoded = extractXmlTag(block, 'content:encoded');
    const descriptionRaw = extractXmlTag(block, 'description');
    const richestHtml =
      contentEncoded.length > descriptionRaw.length ? contentEncoded : descriptionRaw;

    const imageUrl =
      extractMediaUrlRegex(block) ||
      extractSafeImageUrlFromHtml(contentEncoded) ||
      extractSafeImageUrlFromHtml(descriptionRaw);

    const { summary, contentSnippet, content, paragraphs } =
      sanitizeFeedHtmlToText(richestHtml);

    const tags = Array.from(
      new Set(
        extractAllXmlTags(block, 'category').map((t) =>
          decodeHtmlEntities(t).toLowerCase()
        )
      )
    );

    items.push({
      guid,
      title,
      author,
      publishedAt,
      updatedAt,
      summary,
      contentSnippet,
      content,
      imageUrl,
      articleUrl,
      tags,
      paragraphs,
      readingTime: estimateReadingTimeIfSubstantial(content || contentSnippet),
    });
  }

  return { feedTitle, items, skippedInvalidCount };
}

export function parseRssFeed(
  xmlText: string,
  baseWebsiteUrl?: string
): FeedParseResult {
  if (!xmlText || !xmlText.trim()) {
    throw new FeedParseError('RSS XML payload is empty.');
  }
  if (typeof DOMParser !== 'undefined') {
    return parseRssWithBrowserDom(xmlText, baseWebsiteUrl);
  }
  return parseRssWithRegexFallback(xmlText, baseWebsiteUrl);
}
