import { FeedParseResult, RawFeedItem } from '../../../types/article';
import { FeedParseError } from './rssAdapter';
import {
  estimateReadingTimeIfSubstantial,
  extractSafeImageUrlFromHtml,
  normalizeArticleUrl,
  parseOptionalIsoDate,
  sanitizeFeedHtmlToText,
} from './sanitizeHtml';

interface JsonFeedAuthor {
  name?: string;
}

interface JsonFeedItem {
  id?: string;
  url?: string;
  external_url?: string;
  title?: string;
  content_html?: string;
  content_text?: string;
  summary?: string;
  image?: string;
  banner_image?: string;
  date_published?: string;
  date_modified?: string;
  author?: JsonFeedAuthor;
  authors?: JsonFeedAuthor[];
  tags?: string[];
}

interface JsonFeedDocument {
  title?: string;
  items?: JsonFeedItem[];
}

export function parseJsonFeed(
  rawJson: string,
  baseWebsiteUrl?: string
): FeedParseResult {
  if (!rawJson || !rawJson.trim()) {
    throw new FeedParseError('JSON Feed payload is empty.');
  }

  let doc: JsonFeedDocument;
  try {
    doc = JSON.parse(rawJson) as JsonFeedDocument;
  } catch {
    throw new FeedParseError('Invalid JSON Feed payload.');
  }

  if (!doc || !Array.isArray(doc.items)) {
    throw new FeedParseError('JSON Feed is missing an "items" array.');
  }

  const feedTitle = (doc.title || '').trim() || 'JSON Feed';
  const items: RawFeedItem[] = [];
  let skippedInvalidCount = 0;

  for (const entry of doc.items) {
    const title = (entry.title || '').trim();
    const rawUrl = (entry.url || entry.external_url || '').trim();
    let articleUrl = '';
    if (rawUrl.startsWith('/') && baseWebsiteUrl) {
      try {
        articleUrl = normalizeArticleUrl(new URL(rawUrl, baseWebsiteUrl).toString());
      } catch {
        articleUrl = '';
      }
    } else {
      articleUrl = normalizeArticleUrl(rawUrl);
    }

    if (!title || !articleUrl) {
      skippedInvalidCount++;
      continue;
    }

    const guid = (entry.id || '').trim() || articleUrl;
    const rawAuthor =
      entry.authors?.find((a) => Boolean(a?.name?.trim()))?.name?.trim() ||
      entry.author?.name?.trim() ||
      '';
    const author = rawAuthor || null;

    const publishedAt = parseOptionalIsoDate(entry.date_published);
    const updatedAt = parseOptionalIsoDate(entry.date_modified);

    const htmlBody = entry.content_html || '';
    const textBody = entry.content_text || entry.summary || '';
    const sanitized = htmlBody
      ? sanitizeFeedHtmlToText(htmlBody)
      : sanitizeFeedHtmlToText(textBody);

    const rawImg = entry.image || entry.banner_image || '';
    const imageUrl =
      rawImg && rawImg.startsWith('http')
        ? rawImg.replace(/^http:\/\//i, 'https://')
        : extractSafeImageUrlFromHtml(htmlBody);

    const summary = (entry.summary || sanitized.summary || '').trim();
    const tags = Array.from(
      new Set(
        (Array.isArray(entry.tags) ? entry.tags : [])
          .map((t) => String(t).trim().toLowerCase())
          .filter(Boolean)
      )
    );

    items.push({
      guid,
      title,
      author,
      publishedAt,
      updatedAt,
      summary: summary.length > 260 ? `${summary.slice(0, 257).trimEnd()}…` : summary,
      contentSnippet: sanitized.contentSnippet || summary,
      content: sanitized.content,
      imageUrl,
      articleUrl,
      tags,
      paragraphs: sanitized.paragraphs,
      readingTime: estimateReadingTimeIfSubstantial(
        sanitized.content || sanitized.contentSnippet
      ),
    });
  }

  return { feedTitle, items, skippedInvalidCount };
}
