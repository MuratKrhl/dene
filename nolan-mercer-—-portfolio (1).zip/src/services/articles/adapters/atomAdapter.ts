import { FeedParseResult, RawFeedItem } from '../../../types/article';
import { decodeHtmlEntities } from '../../medium/mediumParser';
import { FeedParseError } from './rssAdapter';
import {
  estimateReadingTimeIfSubstantial,
  extractSafeImageUrlFromHtml,
  normalizeArticleUrl,
  parseOptionalIsoDate,
  sanitizeFeedHtmlToText,
  stripCdata,
} from './sanitizeHtml';

function resolveUrl(href: string, baseWebsiteUrl?: string): string {
  const trimmed = (href || '').trim();
  if (!trimmed) return '';
  if (trimmed.startsWith('/') && baseWebsiteUrl) {
    try {
      return normalizeArticleUrl(new URL(trimmed, baseWebsiteUrl).toString());
    } catch {
      return '';
    }
  }
  return normalizeArticleUrl(trimmed);
}

function parseAtomWithDom(
  xmlText: string,
  baseWebsiteUrl?: string
): FeedParseResult {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlText, 'text/xml');
  const parseErrors = doc.getElementsByTagName('parsererror');
  if (parseErrors.length > 0) {
    if (xmlText.includes('<feed') && xmlText.includes('<entry')) {
      return parseAtomWithRegex(xmlText, baseWebsiteUrl);
    }
    throw new FeedParseError(
      `Invalid Atom XML: ${parseErrors[0].textContent?.slice(0, 120) || 'parse error'}`
    );
  }

  const feedNode = doc.getElementsByTagName('feed')[0];
  if (!feedNode) {
    throw new FeedParseError('Atom document does not contain a <feed> element.');
  }

  const feedTitleEl = Array.from(feedNode.children).find(
    (el) => (el.localName || el.tagName).toLowerCase() === 'title'
  );
  const feedTitle = feedTitleEl?.textContent?.trim() || 'Atom Feed';
  const entries = Array.from(doc.getElementsByTagName('entry'));

  const items: RawFeedItem[] = [];
  let skippedInvalidCount = 0;

  for (const entry of entries) {
    const titleEl = entry.getElementsByTagName('title')[0];
    const title = decodeHtmlEntities(titleEl?.textContent || '').trim();
    if (!title) {
      skippedInvalidCount++;
      continue;
    }

    const linkEls = Array.from(entry.getElementsByTagName('link'));
    const alternateLink =
      linkEls.find((el) => (el.getAttribute('rel') || 'alternate') === 'alternate') ||
      linkEls[0];
    const rawHref =
      alternateLink?.getAttribute('href') || alternateLink?.textContent || '';
    const articleUrl = resolveUrl(rawHref, baseWebsiteUrl);
    if (!articleUrl) {
      skippedInvalidCount++;
      continue;
    }

    const rawId = entry.getElementsByTagName('id')[0]?.textContent?.trim() || '';
    const guid = rawId ? resolveUrl(rawId, baseWebsiteUrl) || rawId : articleUrl;

    const authorName =
      entry
        .getElementsByTagName('author')[0]
        ?.getElementsByTagName('name')[0]
        ?.textContent?.trim() ||
      entry.getElementsByTagName('dc:creator')[0]?.textContent?.trim() ||
      '';
    const author = authorName ? decodeHtmlEntities(authorName) : null;

    const publishedRaw =
      entry.getElementsByTagName('published')[0]?.textContent ||
      entry.getElementsByTagName('updated')[0]?.textContent ||
      '';
    const updatedRaw =
      entry.getElementsByTagName('updated')[0]?.textContent || '';

    const publishedAt = parseOptionalIsoDate(publishedRaw);
    const updatedAt = parseOptionalIsoDate(updatedRaw);

    const contentRaw =
      entry.getElementsByTagName('content')[0]?.textContent || '';
    const summaryRaw =
      entry.getElementsByTagName('summary')[0]?.textContent || '';
    const richestHtml =
      contentRaw.length > summaryRaw.length ? contentRaw : summaryRaw;

    const imageUrl =
      extractSafeImageUrlFromHtml(contentRaw) ||
      extractSafeImageUrlFromHtml(summaryRaw);

    const { summary, contentSnippet, content, paragraphs } =
      sanitizeFeedHtmlToText(richestHtml);

    const categoryEls = Array.from(entry.getElementsByTagName('category'));
    const tags = Array.from(
      new Set(
        categoryEls
          .map((el) =>
            decodeHtmlEntities(
              el.getAttribute('term') ||
                el.getAttribute('label') ||
                el.textContent ||
                ''
            )
              .trim()
              .toLowerCase()
          )
          .filter(Boolean)
      )
    );

    items.push({
      guid,
      title,
      author,
      publishedAt,
      updatedAt,
      summary,
      contentSnippet,
      content,
      imageUrl,
      articleUrl,
      tags,
      paragraphs,
      readingTime: estimateReadingTimeIfSubstantial(content || contentSnippet),
    });
  }

  return { feedTitle, items, skippedInvalidCount };
}

function extractTag(block: string, tag: string): string {
  const m = block.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, 'i'));
  return m ? stripCdata(m[1]) : '';
}

function parseAtomWithRegex(
  xmlText: string,
  baseWebsiteUrl?: string
): FeedParseResult {
  if (!xmlText.includes('<feed')) {
    throw new FeedParseError('Invalid Atom XML: missing <feed> root.');
  }

  const feedTitle = decodeHtmlEntities(extractTag(xmlText, 'title')) || 'Atom Feed';
  const entryBlocks = xmlText.match(/<entry\b[\s\S]*?<\/entry>/gi) || [];

  const items: RawFeedItem[] = [];
  let skippedInvalidCount = 0;

  for (const block of entryBlocks) {
    const title = decodeHtmlEntities(extractTag(block, 'title')).trim();
    if (!title) {
      skippedInvalidCount++;
      continue;
    }

    const linkMatch =
      block.match(/<link[^>]+rel=["']alternate["'][^>]+href=["']([^"']+)["'][^>]*>/i) ||
      block.match(/<link[^>]+href=["']([^"']+)["'][^>]*>/i);
    const articleUrl = resolveUrl(linkMatch ? linkMatch[1] : '', baseWebsiteUrl);
    if (!articleUrl) {
      skippedInvalidCount++;
      continue;
    }

    const rawId = extractTag(block, 'id');
    const guid = rawId ? resolveUrl(rawId, baseWebsiteUrl) || rawId : articleUrl;

    const authorBlock = extractTag(block, 'author');
    const authorRaw = decodeHtmlEntities(extractTag(authorBlock, 'name')).trim();
    const author = authorRaw || null;

    const publishedAt = parseOptionalIsoDate(
      extractTag(block, 'published') || extractTag(block, 'updated')
    );
    const updatedAt = parseOptionalIsoDate(extractTag(block, 'updated'));

    const contentRaw = extractTag(block, 'content');
    const summaryRaw = extractTag(block, 'summary');
    const richestHtml =
      contentRaw.length > summaryRaw.length ? contentRaw : summaryRaw;
    const imageUrl =
      extractSafeImageUrlFromHtml(contentRaw) ||
      extractSafeImageUrlFromHtml(summaryRaw);
    const { summary, contentSnippet, content, paragraphs } =
      sanitizeFeedHtmlToText(richestHtml);

    const catMatches = Array.from(
      block.matchAll(/<category[^>]+term=["']([^"']+)["'][^>]*>/gi)
    );
    const tags = Array.from(
      new Set(catMatches.map((m) => decodeHtmlEntities(m[1]).trim().toLowerCase()).filter(Boolean))
    );

    items.push({
      guid,
      title,
      author,
      publishedAt,
      updatedAt,
      summary,
      contentSnippet,
      content,
      imageUrl,
      articleUrl,
      tags,
      paragraphs,
      readingTime: estimateReadingTimeIfSubstantial(content || contentSnippet),
    });
  }

  return { feedTitle, items, skippedInvalidCount };
}

export function parseAtomFeed(
  xmlText: string,
  baseWebsiteUrl?: string
): FeedParseResult {
  if (!xmlText || !xmlText.trim()) {
    throw new FeedParseError('Atom XML payload is empty.');
  }
  if (typeof DOMParser !== 'undefined') {
    return parseAtomWithDom(xmlText, baseWebsiteUrl);
  }
  return parseAtomWithRegex(xmlText, baseWebsiteUrl);
}
