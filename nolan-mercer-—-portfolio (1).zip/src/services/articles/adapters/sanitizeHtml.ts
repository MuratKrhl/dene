import { decodeHtmlEntities } from '../../medium/mediumParser';

const TRACKING_QUERY_PARAMS = new Set([
  'source',
  'utm_source',
  'utm_medium',
  'utm_campaign',
  'utm_term',
  'utm_content',
  'sk',
  'fbclid',
  'gclid',
  'mc_cid',
  'mc_eid',
]);

export function normalizeArticleUrl(rawUrl: string): string {
  if (!rawUrl || typeof rawUrl !== 'string') return '';
  const trimmed = rawUrl.trim();
  if (!trimmed) return '';
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return '';
    }
    for (const key of Array.from(parsed.searchParams.keys())) {
      if (TRACKING_QUERY_PARAMS.has(key.toLowerCase())) {
        parsed.searchParams.delete(key);
      }
    }
    parsed.hash = '';
    const serialized = parsed.toString();
    return serialized.endsWith('/') ? serialized.slice(0, -1) : serialized;
  } catch {
    return trimmed.split('?')[0].replace(/\/+$/, '');
  }
}

export function stripCdata(raw: string): string {
  return raw
    .replace(/^\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*$/, '$1')
    .trim();
}

/**
 * Sanitizes untrusted feed HTML into safe, readable plain-text paragraphs
 * without ever rendering raw HTML or executing scripts/event handlers.
 */
export function sanitizeFeedHtmlToText(html: string): {
  summary: string;
  contentSnippet: string;
  content: string;
  paragraphs: string[];
} {
  if (!html || !html.trim()) {
    return { summary: '', contentSnippet: '', content: '', paragraphs: [] };
  }

  // Extract explicit Medium snippet if present
  const mediumSnippetMatch = html.match(
    /<p[^>]*class=["'][^"']*medium-feed-snippet[^"']*["'][^>]*>([\s\S]*?)<\/p>/i
  );

  // Strip dangerous/non-content tags and boilerplate feed footers
  const stripped = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<iframe[\s\S]*?<\/iframe>/gi, ' ')
    .replace(/<object[\s\S]*?<\/object>/gi, ' ')
    .replace(/<embed[\s\S]*?>/gi, ' ')
    .replace(/<svg[\s\S]*?<\/svg>/gi, ' ')
    .replace(
      /<p[^>]*class=["'][^"']*medium-feed-image[^"']*["'][^>]*>[\s\S]*?<\/p>/gi,
      ''
    )
    .replace(
      /<p[^>]*class=["'][^"']*medium-feed-link[^"']*["'][^>]*>[\s\S]*?<\/p>/gi,
      ''
    )
    .replace(/<a[^>]*>\s*Continue reading on Medium[\s\S]*?<\/a>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|h1|h2|h3|h4|h5|h6|li|blockquote|tr|section)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ');

  const plainText = decodeHtmlEntities(stripped)
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();

  const paragraphs = plainText
    .split(/\n+/)
    .map((p) => p.trim())
    .filter(
      (p) =>
        p.length > 0 &&
        !/^continue reading on medium/i.test(p) &&
        !/^the post .* appeared first on /i.test(p)
    );

  const explicitSnippet = mediumSnippetMatch
    ? decodeHtmlEntities(mediumSnippetMatch[1].replace(/<[^>]+>/g, ' '))
        .replace(/\s+/g, ' ')
        .trim()
    : paragraphs[0] || '';

  const contentSnippet = paragraphs.slice(0, 3).join('\n\n') || explicitSnippet;
  const fullSanitized = paragraphs.join('\n\n');
  const summary =
    explicitSnippet.length > 260
      ? `${explicitSnippet.slice(0, 257).trimEnd()}…`
      : explicitSnippet;

  // Only populate `content` when the feed delivered multi-paragraph substantial prose
  const wordCount = fullSanitized.split(/\s+/).filter(Boolean).length;
  const content = wordCount >= 120 ? fullSanitized : '';

  return {
    summary,
    contentSnippet,
    content,
    paragraphs,
  };
}

export function extractSafeImageUrlFromHtml(html: string): string | null {
  if (!html) return null;
  const imgRegex = /<img[^>]+src=["']([^"']+)["'][^>]*>/gi;
  let match: RegExpExecArray | null;
  while ((match = imgRegex.exec(html)) !== null) {
    const candidate = decodeHtmlEntities(match[1].trim());
    if (!candidate.startsWith('https://') && !candidate.startsWith('http://')) {
      continue;
    }
    if (
      candidate.includes('/_/stat?') ||
      candidate.includes('stat?event=') ||
      candidate.includes('width=1') ||
      candidate.includes('pixel') ||
      candidate.startsWith('javascript:')
    ) {
      continue;
    }
    return candidate.replace(/^http:\/\//i, 'https://');
  }
  return null;
}

/**
 * Returns ISO-8601 date string ONLY when feed supplies a real parseable timestamp.
 * Never fabricates a date when missing or invalid.
 */
export function parseOptionalIsoDate(rawDate: string | null | undefined): string | null {
  if (!rawDate || typeof rawDate !== 'string') return null;
  const trimmed = rawDate.trim();
  if (!trimmed) return null;
  const ms = Date.parse(trimmed);
  if (Number.isNaN(ms) || ms <= 0) return null;
  return new Date(ms).toISOString();
}

export function estimateReadingTimeIfSubstantial(text: string): string | null {
  if (!text) return null;
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  if (words < 180) return null;
  const minutes = Math.max(1, Math.round(words / 220));
  return `${minutes} min read`;
}
