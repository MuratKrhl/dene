import { AggregatedArticle } from '../../types/article';
import { normalizeArticleUrl } from './adapters/sanitizeHtml';
import {
  isValidArticleDate,
  shouldArchiveAggregatedArticle,
} from './articleNormalizer';

function normalizeTitleKey(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function getArticleDedupeKeys(article: {
  guid?: string;
  articleUrl?: string;
  title?: string;
  publishedAt?: string | null;
  sourceId?: string;
}): string[] {
  const keys: string[] = [];

  if (article.guid && article.guid.trim()) {
    const gNorm = normalizeArticleUrl(article.guid);
    keys.push(`guid:${(gNorm || article.guid).trim().toLowerCase()}`);
  }

  if (article.articleUrl && article.articleUrl.trim()) {
    const uNorm = normalizeArticleUrl(article.articleUrl);
    if (uNorm) {
      keys.push(`url:${uNorm.toLowerCase()}`);
    }
  }

  if (article.title && article.publishedAt && isValidArticleDate(article.publishedAt)) {
    const dayKey = new Date(Date.parse(article.publishedAt))
      .toISOString()
      .slice(0, 10);
    const titleNorm = normalizeTitleKey(article.title);
    if (titleNorm.length >= 12) {
      keys.push(`title-day:${titleNorm}|${dayKey}`);
    }
  }

  return keys;
}

export function deduplicateAndMergeArticles(
  existingArticles: AggregatedArticle[],
  incomingArticles: AggregatedArticle[],
  nowMs: number = Date.now()
): {
  nextArticles: AggregatedArticle[];
  newCount: number;
  duplicatesSkipped: number;
} {
  const cloned = existingArticles.map((a) => ({
    ...a,
    matchedSourceIds: [...(a.matchedSourceIds || [a.sourceId])],
    matchedSourceNames: [...(a.matchedSourceNames || [a.sourceName])],
    matchedSourceGroups: [...(a.matchedSourceGroups || [a.sourceGroup])],
    categories: [...(a.categories || [a.category])],
    tags: [...(a.tags || [])],
    paragraphs: [...(a.paragraphs || [])],
  }));

  const indexByKey = new Map<string, number>();
  cloned.forEach((article, idx) => {
    for (const key of getArticleDedupeKeys(article)) {
      if (!indexByKey.has(key)) {
        indexByKey.set(key, idx);
      }
    }
  });

  let newCount = 0;
  let duplicatesSkipped = 0;
  const nowIso = new Date(nowMs).toISOString();

  for (const incoming of incomingArticles) {
    const keys = getArticleDedupeKeys(incoming);
    let matchedIdx: number | undefined;
    for (const key of keys) {
      if (indexByKey.has(key)) {
        matchedIdx = indexByKey.get(key);
        break;
      }
    }

    if (matchedIdx !== undefined) {
      duplicatesSkipped++;
      const current = cloned[matchedIdx];
      const effectivePublishedAt = current.publishedAt || incoming.publishedAt;
      const effectiveIsArchived = isValidArticleDate(effectivePublishedAt)
        ? shouldArchiveAggregatedArticle(effectivePublishedAt, nowMs)
        : current.isArchived;

      const merged: AggregatedArticle = {
        ...current,
        author: current.author || incoming.author,
        publishedAt: effectivePublishedAt,
        updatedAt: incoming.updatedAt || current.updatedAt,
        summary:
          current.summary.length >= incoming.summary.length
            ? current.summary
            : incoming.summary,
        contentSnippet:
          current.contentSnippet.length >= incoming.contentSnippet.length
            ? current.contentSnippet
            : incoming.contentSnippet,
        content:
          current.content.length >= incoming.content.length
            ? current.content
            : incoming.content,
        imageUrl: current.imageUrl || incoming.imageUrl,
        matchedSourceIds: Array.from(
          new Set([...current.matchedSourceIds, ...incoming.matchedSourceIds])
        ),
        matchedSourceNames: Array.from(
          new Set([
            ...current.matchedSourceNames,
            ...incoming.matchedSourceNames,
          ])
        ),
        matchedSourceGroups: Array.from(
          new Set([
            ...current.matchedSourceGroups,
            ...incoming.matchedSourceGroups,
          ])
        ),
        categories: Array.from(
          new Set([...current.categories, ...incoming.categories])
        ),
        tags: Array.from(new Set([...current.tags, ...incoming.tags])),
        readingTime: current.readingTime || incoming.readingTime,
        paragraphs:
          current.paragraphs.length >= incoming.paragraphs.length
            ? current.paragraphs
            : incoming.paragraphs,
        contentType:
          current.contentType === 'security-advisory' ||
          incoming.contentType === 'security-advisory'
            ? 'security-advisory'
            : current.contentType,
        // Preserve user state & archive status strictly
        isRead: current.isRead,
        isFavorite: current.isFavorite,
        isArchived: effectiveIsArchived,
        archivedAt: effectiveIsArchived ? current.archivedAt || nowIso : null,
      };

      cloned[matchedIdx] = merged;
      for (const key of getArticleDedupeKeys(merged)) {
        if (!indexByKey.has(key)) {
          indexByKey.set(key, matchedIdx);
        }
      }
    } else {
      const nextIdx = cloned.length;
      cloned.push(incoming);
      newCount++;
      for (const key of keys) {
        if (!indexByKey.has(key)) {
          indexByKey.set(key, nextIdx);
        }
      }
    }
  }

  // Sort newest first; invalid/null dates sit gracefully after dated articles
  cloned.sort((a, b) => {
    const ta = a.publishedAt ? Date.parse(a.publishedAt) : 0;
    const tb = b.publishedAt ? Date.parse(b.publishedAt) : 0;
    const safeA = Number.isNaN(ta) ? 0 : ta;
    const safeB = Number.isNaN(tb) ? 0 : tb;
    if (safeB !== safeA) return safeB - safeA;
    return Date.parse(b.fetchedAt) - Date.parse(a.fetchedAt);
  });

  return {
    nextArticles: cloned,
    newCount,
    duplicatesSkipped,
  };
}
