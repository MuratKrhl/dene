import { ARTICLE_RETENTION_DAYS, AggregatedArticle, RawFeedItem } from '../../types/article';
import { ArticleSource } from '../../types/articleSource';
import { MediumArticle } from '../../types/medium';
import { normalizeArticleUrl } from './adapters/sanitizeHtml';

export const ARTICLE_RETENTION_MS = ARTICLE_RETENTION_DAYS * 24 * 60 * 60 * 1000;

export function isValidArticleDate(publishedAt: string | null | undefined): boolean {
  if (!publishedAt || typeof publishedAt !== 'string') return false;
  const ms = Date.parse(publishedAt);
  return !Number.isNaN(ms) && ms > 0;
}

/**
 * Only articles with a valid publication date strictly older than 30 days move to Archive.
 * Missing or invalid dates are NEVER automatically archived or deleted.
 */
export function shouldArchiveAggregatedArticle(
  publishedAt: string | null | undefined,
  nowMs: number = Date.now()
): boolean {
  if (!isValidArticleDate(publishedAt)) return false;
  const publishedMs = Date.parse(publishedAt!);
  return nowMs - publishedMs > ARTICLE_RETENTION_MS;
}

export function makeStableArticleId(
  guid: string,
  articleUrl: string,
  sourceId: string
): string {
  const normalizedUrl = normalizeArticleUrl(articleUrl);
  const mediumHex = (guid || normalizedUrl).match(/\/p\/([a-zA-Z0-9_-]+)/);
  if (mediumHex && sourceId.startsWith('medium-')) {
    return `medium-${mediumHex[1]}`;
  }
  const seed = guid || normalizedUrl || `${sourceId}-${Date.now()}`;
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash * 31 + seed.charCodeAt(i)) | 0;
  }
  const prefix = sourceId.startsWith('medium-') ? 'medium' : 'art';
  return `${prefix}-${Math.abs(hash).toString(36)}`;
}

/**
 * Classifies topic keywords in Red Hat, Kubernetes, Security, AI, and Dev feeds
 * into accurate categories/tags without inventing unverified content.
 */
function inferDerivedTagsAndCategories(
  item: RawFeedItem,
  source: ArticleSource
): { primaryCategory: string; categories: string[]; tags: string[] } {
  const haystack = `${item.title} ${item.summary} ${item.tags.join(' ')}`.toLowerCase();
  const extraTags = new Set<string>(item.tags);
  const categories = new Set<string>([source.category]);

  // Red Hat middleware & platform taxonomy
  if (source.sourceGroup === 'Red Hat' || haystack.includes('red hat')) {
    if (haystack.includes('jboss') || haystack.includes('eap') || haystack.includes('wildfly')) {
      extraTags.add('jboss');
      extraTags.add('middleware');
      categories.add('JBoss');
      categories.add('Middleware');
    }
    if (haystack.includes('openshift')) {
      extraTags.add('openshift');
      extraTags.add('kubernetes');
      categories.add('OpenShift');
    }
    if (haystack.includes('rhel') || haystack.includes('red hat enterprise linux')) {
      extraTags.add('rhel');
      extraTags.add('linux');
      categories.add('Linux');
    }
    if (haystack.includes('ansible')) {
      extraTags.add('ansible');
      extraTags.add('devops');
      categories.add('DevOps');
    }
    if (/\bjava\b|\bquarkus\b|\bjvm\b/.test(haystack)) {
      extraTags.add('java');
      categories.add('Java');
    }
  }

  if (/\bkubernetes\b|\bk8s\b|\bhelm\b|\bpod\b/.test(haystack)) {
    extraTags.add('kubernetes');
    extraTags.add('containers');
  }
  if (/\bnginx\b|\breverse proxy\b|\benvoy\b/.test(haystack)) {
    extraTags.add('reverse-proxy');
    extraTags.add('networking');
  }
  if (/\bcve-\d{4}-\d+\b/.test(haystack)) {
    extraTags.add('cve');
    extraTags.add('vulnerability');
  }
  if (source.defaultContentType === 'security-advisory') {
    extraTags.add('security-advisory');
    categories.add('Security Advisory');
  }

  for (const tag of source.tags) {
    extraTags.add(tag.toLowerCase());
  }

  return {
    primaryCategory: source.category,
    categories: Array.from(categories),
    tags: Array.from(extraTags).filter(Boolean),
  };
}

export function normalizeFeedItemToArticle(
  item: RawFeedItem,
  source: ArticleSource,
  nowIso: string = new Date().toISOString()
): AggregatedArticle {
  const normalizedUrl = normalizeArticleUrl(item.articleUrl);
  const { primaryCategory, categories, tags } = inferDerivedTagsAndCategories(
    item,
    source
  );
  const shouldArchive = shouldArchiveAggregatedArticle(
    item.publishedAt,
    Date.parse(nowIso)
  );

  return {
    id: makeStableArticleId(item.guid, normalizedUrl, source.id),
    guid: item.guid || normalizedUrl,
    title: item.title,
    author: item.author,
    publishedAt: item.publishedAt,
    updatedAt: item.updatedAt,
    summary: item.summary,
    contentSnippet: item.contentSnippet,
    content: item.content,
    imageUrl: item.imageUrl,
    articleUrl: normalizedUrl,
    sourceId: source.id,
    sourceName: source.name,
    sourceGroup: source.sourceGroup,
    sourceType: source.sourceType,
    matchedSourceIds: [source.id],
    matchedSourceNames: [source.name],
    matchedSourceGroups: [source.sourceGroup],
    category: primaryCategory,
    categories,
    tags,
    contentType: source.defaultContentType,
    isRead: false,
    isFavorite: false,
    isArchived: shouldArchive,
    archivedAt: shouldArchive ? nowIso : null,
    fetchedAt: nowIso,
    readingTime: item.readingTime,
    paragraphs: item.paragraphs,
  };
}

export function convertLegacyMediumArticle(
  medium: MediumArticle,
  nowMs: number = Date.now()
): AggregatedArticle {
  const normalizedUrl = normalizeArticleUrl(medium.articleUrl);
  const validDate = isValidArticleDate(medium.publishedAt);
  const archived =
    medium.retentionStatus === 'archived' ||
    (validDate && shouldArchiveAggregatedArticle(medium.publishedAt, nowMs));
  const categories =
    medium.sourceCategories && medium.sourceCategories.length > 0
      ? [...medium.sourceCategories]
      : [medium.sourceCategory];
  const matchedSourceIds = categories.map(
    (cat) => `medium-${cat.toLowerCase().replace(/\s+/g, '-')}`
  );
  const matchedSourceNames = categories.map((cat) => `Medium · ${cat}`);

  return {
    id: medium.id,
    guid: medium.guid || normalizedUrl,
    title: medium.title,
    author: medium.author || null,
    publishedAt: validDate ? medium.publishedAt : null,
    updatedAt: null,
    summary: medium.summary || '',
    contentSnippet: medium.contentSnippet || '',
    content:
      medium.rssParagraphs && medium.rssParagraphs.length >= 3
        ? medium.rssParagraphs.join('\n\n')
        : '',
    imageUrl: medium.image || null,
    articleUrl: normalizedUrl || medium.articleUrl,
    sourceId: matchedSourceIds[0] || `medium-${medium.sourceTag}`,
    sourceName: `Medium · ${medium.sourceCategory}`,
    sourceGroup: 'Medium',
    sourceType: 'rss',
    matchedSourceIds,
    matchedSourceNames,
    matchedSourceGroups: ['Medium'],
    category: medium.sourceCategory,
    categories,
    tags: Array.from(
      new Set([
        ...(medium.sourceTags || [medium.sourceTag]),
        'medium',
      ])
    ),
    contentType: 'article',
    isRead: Boolean(medium.isRead),
    isFavorite: Boolean(medium.isFavorite),
    isArchived: archived,
    archivedAt: archived ? medium.archivedAt || new Date(nowMs).toISOString() : null,
    fetchedAt: medium.fetchedAt || new Date(nowMs).toISOString(),
    readingTime: medium.readingTime || null,
    paragraphs: medium.rssParagraphs || [],
    featured: medium.featured,
  };
}

export function reconcileAggregatedRetention(
  articles: AggregatedArticle[],
  nowMs: number = Date.now()
): { articles: AggregatedArticle[]; changed: boolean } {
  let changed = false;
  const nowIso = new Date(nowMs).toISOString();

  const next = articles.map((article) => {
    // Missing/invalid dates must NEVER be mistakenly archived or deleted
    if (!isValidArticleDate(article.publishedAt)) {
      return article;
    }

    const shouldArchive = shouldArchiveAggregatedArticle(
      article.publishedAt,
      nowMs
    );
    const targetArchivedAt = shouldArchive
      ? article.archivedAt || nowIso
      : null;

    if (
      article.isArchived !== shouldArchive ||
      (article.archivedAt ?? null) !== targetArchivedAt
    ) {
      changed = true;
      return {
        ...article,
        isArchived: shouldArchive,
        archivedAt: targetArchivedAt,
      };
    }

    return article;
  });

  return { articles: next, changed };
}
