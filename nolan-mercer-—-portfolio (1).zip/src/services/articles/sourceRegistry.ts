import { INITIAL_ARTICLE_SOURCES } from '../../data/articleSources';
import {
  ArticleSource,
  ArticleSourceGroup,
  ArticleSourceStatus,
} from '../../types/articleSource';

const dynamicRegisteredSources: ArticleSource[] = [];

/**
 * Central source registry: adding a new source only requires registering it here
 * or in `src/data/articleSources/*` without modifying aggregator code.
 */
export function registerArticleSource(source: ArticleSource): void {
  const existingIdx = dynamicRegisteredSources.findIndex(
    (s) => s.id === source.id
  );
  if (existingIdx >= 0) {
    dynamicRegisteredSources[existingIdx] = { ...source };
  } else {
    dynamicRegisteredSources.push({ ...source });
  }
}

export function getCanonicalArticleSources(): ArticleSource[] {
  const merged = new Map<string, ArticleSource>();
  for (const src of INITIAL_ARTICLE_SOURCES) {
    merged.set(src.id, { ...src, tags: [...src.tags] });
  }
  for (const src of dynamicRegisteredSources) {
    merged.set(src.id, { ...src, tags: [...src.tags] });
  }
  return Array.from(merged.values());
}

export function mergeWithCanonicalSources(
  savedSources: ArticleSource[]
): ArticleSource[] {
  const byId = new Map<string, ArticleSource>();
  for (const s of savedSources) {
    if (s && typeof s.id === 'string') {
      byId.set(s.id, s);
    }
  }

  return getCanonicalArticleSources().map((def) => {
    const saved = byId.get(def.id);
    if (!saved) return def;

    if (def.sourceType === 'unsupported') {
      return {
        ...def,
        enabled: false,
        status: 'unsupported' as ArticleSourceStatus,
        errorMessage: def.errorMessage,
      };
    }

    const restoredStatus: ArticleSourceStatus =
      saved.status === 'syncing' ? 'idle' : saved.status || def.status;

    return {
      ...def,
      enabled: typeof saved.enabled === 'boolean' ? saved.enabled : def.enabled,
      lastFetchedAt: saved.lastFetchedAt || null,
      lastSuccessfulFetchAt: saved.lastSuccessfulFetchAt || null,
      status: restoredStatus,
      errorMessage: saved.errorMessage ?? def.errorMessage,
      lastArticleCount:
        typeof saved.lastArticleCount === 'number'
          ? saved.lastArticleCount
          : def.lastArticleCount ?? 0,
    };
  });
}

export function filterSourcesByGroup(
  sources: ArticleSource[],
  group: ArticleSourceGroup
): ArticleSource[] {
  return sources.filter((s) => s.sourceGroup === group);
}

export function getSyncableEnabledSources(
  sources: ArticleSource[]
): ArticleSource[] {
  return sources.filter(
    (s) => s.enabled && s.sourceType !== 'unsupported' && Boolean(s.feedUrl)
  );
}
