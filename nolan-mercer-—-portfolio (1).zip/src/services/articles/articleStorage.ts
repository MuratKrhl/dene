import {
  ARTICLE_SYNC_CONFIG_VERSION,
  DEFAULT_AGGREGATION_SYNC_CONFIG,
} from '../../data/articleSources';
import { AggregatedArticle } from '../../types/article';
import {
  AGGREGATION_SYNC_INTERVAL_OPTIONS,
  AggregationSyncConfig,
  AggregationSyncIntervalHours,
  AggregationSyncSummary,
  ArticleSource,
} from '../../types/articleSource';
import { MediumArticle, MediumCategoryName } from '../../types/medium';
import { getMediumStorageAdapter } from '../medium/mediumStorageService';
import { deduplicateAndMergeArticles } from './articleDeduplicator';
import { convertLegacyMediumArticle } from './articleNormalizer';
import { mergeWithCanonicalSources } from './sourceRegistry';

const DB_NAME = 'mk-workspace-articles-db-v1';
const DB_VERSION = 1;
const ARTICLES_STORE = 'articles';
const META_STORE = 'meta';
const META_SOURCES_KEY = 'sources';
const META_SUMMARY_KEY = 'syncSummary';
const META_CONFIG_KEY = 'syncConfig';
const META_MIGRATED_MEDIUM_KEY = 'migratedMediumV1';

const FALLBACK_ARTICLES_KEY = 'mk-aggregated-articles-v1';
const FALLBACK_SOURCES_KEY = 'mk-aggregated-sources-v1';
const FALLBACK_SUMMARY_KEY = 'mk-aggregated-sync-summary-v1';
const FALLBACK_CONFIG_KEY = 'mk-aggregated-sync-config-v1';

class ArticleIndexedDbStorage {
  private memoryArticles: AggregatedArticle[] = [];
  private memorySources: ArticleSource[] = mergeWithCanonicalSources([]);
  private memorySummary: AggregationSyncSummary | null = null;
  private memoryConfig: AggregationSyncConfig = {
    ...DEFAULT_AGGREGATION_SYNC_CONFIG,
  };
  private initialized = false;
  private initPromise: Promise<void> | null = null;

  private hasIndexedDb(): boolean {
    try {
      return (
        typeof window !== 'undefined' &&
        typeof window.indexedDB !== 'undefined'
      );
    } catch {
      return false;
    }
  }

  private hasLocalStorage(): boolean {
    try {
      return (
        typeof window !== 'undefined' &&
        typeof window.localStorage !== 'undefined'
      );
    } catch {
      return false;
    }
  }

  private openDatabase(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = window.indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(ARTICLES_STORE)) {
          const store = db.createObjectStore(ARTICLES_STORE, { keyPath: 'id' });
          store.createIndex('publishedAt', 'publishedAt', { unique: false });
          store.createIndex('sourceGroup', 'sourceGroup', { unique: false });
          store.createIndex('isArchived', 'isArchived', { unique: false });
          store.createIndex('articleUrl', 'articleUrl', { unique: false });
        }
        if (!db.objectStoreNames.contains(META_STORE)) {
          db.createObjectStore(META_STORE, { keyPath: 'key' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () =>
        reject(request.error || new Error('Failed to open IndexedDB.'));
    });
  }

  private async idbGetAllArticles(db: IDBDatabase): Promise<AggregatedArticle[]> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(ARTICLES_STORE, 'readonly');
      const req = tx.objectStore(ARTICLES_STORE).getAll();
      req.onsuccess = () =>
        resolve(Array.isArray(req.result) ? (req.result as AggregatedArticle[]) : []);
      req.onerror = () => reject(req.error);
    });
  }

  private async idbReplaceAllArticles(
    db: IDBDatabase,
    articles: AggregatedArticle[]
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(ARTICLES_STORE, 'readwrite');
      const store = tx.objectStore(ARTICLES_STORE);
      store.clear();
      for (const article of articles) {
        store.put(article);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  private async idbGetMeta<T>(db: IDBDatabase, key: string): Promise<T | null> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(META_STORE, 'readonly');
      const req = tx.objectStore(META_STORE).get(key);
      req.onsuccess = () => {
        const row = req.result as { key: string; value: T } | undefined;
        resolve(row ? row.value : null);
      };
      req.onerror = () => reject(req.error);
    });
  }

  private async idbSetMeta<T>(
    db: IDBDatabase,
    key: string,
    value: T
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(META_STORE, 'readwrite');
      tx.objectStore(META_STORE).put({ key, value });
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  private readFallbackLocalStorage(): void {
    if (!this.hasLocalStorage()) return;
    try {
      const rawArticles = window.localStorage.getItem(FALLBACK_ARTICLES_KEY);
      if (rawArticles) {
        const parsed = JSON.parse(rawArticles);
        if (Array.isArray(parsed)) this.memoryArticles = parsed;
      }
      const rawSources = window.localStorage.getItem(FALLBACK_SOURCES_KEY);
      if (rawSources) {
        const parsed = JSON.parse(rawSources);
        if (Array.isArray(parsed)) {
          this.memorySources = mergeWithCanonicalSources(parsed);
        }
      }
      const rawSummary = window.localStorage.getItem(FALLBACK_SUMMARY_KEY);
      if (rawSummary) {
        this.memorySummary = JSON.parse(rawSummary);
      }
      const rawConfig = window.localStorage.getItem(FALLBACK_CONFIG_KEY);
      if (rawConfig) {
        this.memoryConfig = this.normalizeConfig(JSON.parse(rawConfig));
      }
    } catch {
      // Keep memory defaults
    }
  }

  private normalizeConfig(
    raw: Partial<AggregationSyncConfig> | null | undefined
  ): AggregationSyncConfig {
    if (!raw) return { ...DEFAULT_AGGREGATION_SYNC_CONFIG };
    const hours = AGGREGATION_SYNC_INTERVAL_OPTIONS.includes(
      raw.autoSyncIntervalHours as AggregationSyncIntervalHours
    )
      ? (raw.autoSyncIntervalHours as AggregationSyncIntervalHours)
      : DEFAULT_AGGREGATION_SYNC_CONFIG.autoSyncIntervalHours;
    return {
      configVersion: ARTICLE_SYNC_CONFIG_VERSION,
      autoSyncEnabled:
        typeof raw.autoSyncEnabled === 'boolean'
          ? raw.autoSyncEnabled
          : DEFAULT_AGGREGATION_SYNC_CONFIG.autoSyncEnabled,
      autoSyncIntervalHours: hours,
      requestTimeoutMs:
        typeof raw.requestTimeoutMs === 'number' && raw.requestTimeoutMs >= 5000
          ? raw.requestTimeoutMs
          : DEFAULT_AGGREGATION_SYNC_CONFIG.requestTimeoutMs,
    };
  }

  /**
   * Initializes IndexedDB and performs a non-destructive import/merge of any existing
   * Medium RSS articles, sources, and sync timestamps stored in `mk-medium-articles-v1`.
   */
  async init(): Promise<void> {
    if (this.initialized) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      let db: IDBDatabase | null = null;
      if (this.hasIndexedDb()) {
        try {
          db = await this.openDatabase();
          const [idbArticles, idbSources, idbSummary, idbConfig, migratedFlag] =
            await Promise.all([
              this.idbGetAllArticles(db),
              this.idbGetMeta<ArticleSource[]>(db, META_SOURCES_KEY),
              this.idbGetMeta<AggregationSyncSummary>(db, META_SUMMARY_KEY),
              this.idbGetMeta<AggregationSyncConfig>(db, META_CONFIG_KEY),
              this.idbGetMeta<boolean>(db, META_MIGRATED_MEDIUM_KEY),
            ]);

          this.memoryArticles = idbArticles;
          this.memorySources = mergeWithCanonicalSources(idbSources || []);
          this.memorySummary = idbSummary || null;
          this.memoryConfig = this.normalizeConfig(idbConfig);

          if (!migratedFlag) {
            await this.importLegacyMediumDataNonDestructively(db);
            await this.idbSetMeta(db, META_MIGRATED_MEDIUM_KEY, true);
          }
        } catch (err) {
          console.warn(
            '[articleStorage] IndexedDB unavailable, falling back to local cache:',
            err
          );
          this.readFallbackLocalStorage();
          await this.importLegacyMediumDataNonDestructively(null);
        } finally {
          if (db) db.close();
        }
      } else {
        this.readFallbackLocalStorage();
        await this.importLegacyMediumDataNonDestructively(null);
      }

      this.initialized = true;
    })();

    try {
      await this.initPromise;
    } finally {
      this.initPromise = null;
    }
  }

  /**
   * Reads legacy Medium records (`mk-medium-*`) WITHOUT deleting them,
   * merging any existing articles, favorites, read flags, and sync status into the unified store.
   */
  private async importLegacyMediumDataNonDestructively(
    db: IDBDatabase | null
  ): Promise<void> {
    try {
      const legacyAdapter = getMediumStorageAdapter();
      const legacyArticlesRes = legacyAdapter.loadArticles();
      const legacyArticles =
        legacyArticlesRes instanceof Promise
          ? await legacyArticlesRes
          : legacyArticlesRes;

      if (Array.isArray(legacyArticles) && legacyArticles.length > 0) {
        const converted = legacyArticles.map((m) => convertLegacyMediumArticle(m));
        const { nextArticles } = deduplicateAndMergeArticles(
          this.memoryArticles,
          converted
        );
        this.memoryArticles = nextArticles;
        if (db) {
          await this.idbReplaceAllArticles(db, nextArticles);
        }
      }

      const legacySourcesRes = legacyAdapter.loadSources();
      const legacySources =
        legacySourcesRes instanceof Promise
          ? await legacySourcesRes
          : legacySourcesRes;
      if (Array.isArray(legacySources) && legacySources.length > 0) {
        const legacyById = new Map(legacySources.map((s) => [s.id, s]));
        this.memorySources = this.memorySources.map((src) => {
          const leg = legacyById.get(src.id);
          if (!leg) return src;
          return {
            ...src,
            enabled: typeof leg.enabled === 'boolean' ? leg.enabled : src.enabled,
            lastFetchedAt: src.lastFetchedAt || leg.lastFetchedAt,
            lastSuccessfulFetchAt:
              src.lastSuccessfulFetchAt || leg.lastSuccessfulFetchAt,
            status: src.status === 'idle' ? leg.status : src.status,
            errorMessage: src.errorMessage ?? leg.errorMessage,
            lastArticleCount: src.lastArticleCount || leg.lastArticleCount || 0,
          };
        });
        if (db) {
          await this.idbSetMeta(db, META_SOURCES_KEY, this.memorySources);
        }
      }
    } catch (err) {
      console.warn('[articleStorage] Legacy Medium bridge skipped:', err);
    }
  }

  getArticlesSnapshot(): AggregatedArticle[] {
    return this.memoryArticles;
  }

  getSourcesSnapshot(): ArticleSource[] {
    return this.memorySources;
  }

  getSummarySnapshot(): AggregationSyncSummary | null {
    return this.memorySummary;
  }

  getConfigSnapshot(): AggregationSyncConfig {
    return this.memoryConfig;
  }

  async saveArticles(articles: AggregatedArticle[]): Promise<void> {
    this.memoryArticles = articles;

    if (this.hasIndexedDb()) {
      try {
        const db = await this.openDatabase();
        await this.idbReplaceAllArticles(db, articles);
        db.close();
      } catch (err) {
        console.warn('[articleStorage] Failed to write articles to IndexedDB:', err);
      }
    } else if (this.hasLocalStorage()) {
      try {
        window.localStorage.setItem(
          FALLBACK_ARTICLES_KEY,
          JSON.stringify(articles)
        );
      } catch {
        // Ignore storage quota errors in fallback mode
      }
    }

    // Keep legacy `mk-medium-articles-v1` synced non-destructively for Medium articles
    this.syncMediumMirrorToLegacyStorage(articles);
  }

  private syncMediumMirrorToLegacyStorage(articles: AggregatedArticle[]): void {
    try {
      const legacyAdapter = getMediumStorageAdapter();
      const mediumRecords: MediumArticle[] = articles
        .filter((a) => a.matchedSourceGroups.includes('Medium') || a.sourceGroup === 'Medium')
        .map((a) => {
          const medCategories = a.categories.filter((c): c is MediumCategoryName =>
            [
              'Java',
              'JBoss',
              'Kubernetes',
              'OpenShift',
              'Nginx',
              'DevOps',
              'AI',
              'Google Cloud',
              'Azure',
              'AWS',
            ].includes(c)
          );
          const primaryMed: MediumCategoryName = medCategories[0] || 'AI';
          return {
            id: a.id,
            title: a.title,
            author: a.author || 'Medium Author',
            publishedAt: a.publishedAt || a.fetchedAt,
            summary: a.summary,
            contentSnippet: a.contentSnippet,
            image: a.imageUrl,
            articleUrl: a.articleUrl,
            guid: a.guid,
            source: 'medium',
            sourceCategory: primaryMed,
            sourceTag: primaryMed.toLowerCase().replace(/\s+/g, '-'),
            sourceCategories: medCategories.length > 0 ? medCategories : [primaryMed],
            sourceTags: a.tags,
            isRead: a.isRead,
            isFavorite: a.isFavorite,
            fetchedAt: a.fetchedAt,
            retentionStatus: a.isArchived ? 'archived' : 'active',
            archivedAt: a.archivedAt,
            readingTime: a.readingTime,
            rssParagraphs: a.paragraphs,
            featured: a.featured,
          };
        });
      legacyAdapter.saveArticles(mediumRecords);
    } catch {
      // Non-critical mirror sync
    }
  }

  async saveSources(sources: ArticleSource[]): Promise<void> {
    this.memorySources = sources;

    if (this.hasIndexedDb()) {
      try {
        const db = await this.openDatabase();
        await this.idbSetMeta(db, META_SOURCES_KEY, sources);
        db.close();
      } catch (err) {
        console.warn('[articleStorage] Failed to write sources to IndexedDB:', err);
      }
    } else if (this.hasLocalStorage()) {
      try {
        window.localStorage.setItem(FALLBACK_SOURCES_KEY, JSON.stringify(sources));
      } catch {
        // Ignore
      }
    }
  }

  async saveSummary(summary: AggregationSyncSummary): Promise<void> {
    this.memorySummary = summary;

    if (this.hasIndexedDb()) {
      try {
        const db = await this.openDatabase();
        await this.idbSetMeta(db, META_SUMMARY_KEY, summary);
        db.close();
      } catch (err) {
        console.warn('[articleStorage] Failed to write summary to IndexedDB:', err);
      }
    } else if (this.hasLocalStorage()) {
      try {
        window.localStorage.setItem(FALLBACK_SUMMARY_KEY, JSON.stringify(summary));
      } catch {
        // Ignore
      }
    }
  }

  async saveConfig(config: AggregationSyncConfig): Promise<void> {
    const normalized = this.normalizeConfig(config);
    this.memoryConfig = normalized;

    if (this.hasIndexedDb()) {
      try {
        const db = await this.openDatabase();
        await this.idbSetMeta(db, META_CONFIG_KEY, normalized);
        db.close();
      } catch (err) {
        console.warn('[articleStorage] Failed to write config to IndexedDB:', err);
      }
    } else if (this.hasLocalStorage()) {
      try {
        window.localStorage.setItem(
          FALLBACK_CONFIG_KEY,
          JSON.stringify(normalized)
        );
      } catch {
        // Ignore
      }
    }
  }

  /** Resets in-memory state cleanly for isolated unit tests. */
  resetForTest(): void {
    this.initialized = false;
    this.initPromise = null;
    this.memoryArticles = [];
    this.memorySources = mergeWithCanonicalSources([]);
    this.memorySummary = null;
    this.memoryConfig = { ...DEFAULT_AGGREGATION_SYNC_CONFIG };
  }
}

export const articleStorage = new ArticleIndexedDbStorage();
