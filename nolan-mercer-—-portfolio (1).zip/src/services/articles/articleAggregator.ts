import {
  AggregatedArticle,
  FeedParseResult,
} from '../../types/article';
import {
  AggregationSyncConfig,
  AggregationSyncSummary,
  ArticleSource,
  ArticleSourceSyncReport,
} from '../../types/articleSource';
import { parseAtomFeed } from './adapters/atomAdapter';
import { parseJsonFeed } from './adapters/jsonFeedAdapter';
import { parseRssFeed } from './adapters/rssAdapter';
import { deduplicateAndMergeArticles } from './articleDeduplicator';
import {
  normalizeFeedItemToArticle,
  reconcileAggregatedRetention,
} from './articleNormalizer';
import { articleStorage } from './articleStorage';
import { getSyncableEnabledSources } from './sourceRegistry';

export interface FeedFetchResponse {
  ok: boolean;
  payload: string;
  httpStatus: number;
  errorMessage: string | null;
  durationMs: number;
}

export interface FeedTransportAdapter {
  readonly name: string;
  fetchFeed(feedUrl: string, timeoutMs?: number): Promise<FeedFetchResponse>;
}

const DEFAULT_TIMEOUT_MS = 20_000;
const CONTROLLED_CONCURRENCY = 4;

const inFlightFeedFetches = new Map<string, Promise<FeedFetchResponse>>();
const inFlightSourceSyncs = new Map<
  string,
  Promise<{
    articles: AggregatedArticle[];
    sources: ArticleSource[];
    report: ArticleSourceSyncReport;
    summary: AggregationSyncSummary;
  }>
>();
let inFlightFullSync: Promise<{
  articles: AggregatedArticle[];
  sources: ArticleSource[];
  summary: AggregationSyncSummary;
}> | null = null;

function getConfiguredFeedProxyEndpoint(): string {
  try {
    const envObj = (
      import.meta as unknown as { env?: Record<string, string | undefined> }
    )?.env;
    if (envObj?.VITE_ARTICLE_FEED_PROXY_URL?.trim()) {
      return envObj.VITE_ARTICLE_FEED_PROXY_URL.trim();
    }
  } catch {
    // Non-Vite runtime
  }
  return '/api/articles/feed';
}

function buildProxyUrl(endpoint: string, feedUrl: string): string {
  const sep = endpoint.includes('?') ? '&' : '?';
  return `${endpoint}${sep}url=${encodeURIComponent(feedUrl)}`;
}

class SameOriginServerFeedTransport implements FeedTransportAdapter {
  readonly name = 'Workspace Multi-Source Feed Proxy';

  private async fetchOnce(
    feedUrl: string,
    timeoutMs: number
  ): Promise<FeedFetchResponse> {
    const startedAt = Date.now();
    const endpoint = getConfiguredFeedProxyEndpoint();
    const requestUrl = buildProxyUrl(endpoint, feedUrl);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(requestUrl, {
        method: 'GET',
        headers: {
          Accept:
            'application/rss+xml, application/atom+xml, application/feed+json, application/xml, text/xml, application/json',
        },
        signal: controller.signal,
      });

      const contentType = (response.headers.get('content-type') || '').toLowerCase();
      const rawText = await response.text();
      const durationMs = Date.now() - startedAt;

      if (!response.ok) {
        let serverError = `HTTP ${response.status} error fetching feed.`;
        if (contentType.includes('application/json')) {
          try {
            const parsed = JSON.parse(rawText) as { error?: string };
            if (parsed.error) serverError = parsed.error;
          } catch {
            // Keep default
          }
        } else if (response.status === 404) {
          serverError =
            'Article feed proxy (/api/articles/feed) returned 404. Ensure server.ts or VITE_ARTICLE_FEED_PROXY_URL is configured.';
        }
        return {
          ok: false,
          payload: '',
          httpStatus: response.status,
          errorMessage: serverError,
          durationMs,
        };
      }

      const lowerHead = rawText.trim().slice(0, 140).toLowerCase();
      if (
        lowerHead.startsWith('<!doctype html') ||
        lowerHead.startsWith('<html')
      ) {
        return {
          ok: false,
          payload: '',
          httpStatus: response.status,
          errorMessage:
            'Received HTML page instead of feed payload (proxy inactive or upstream returned HTML).',
          durationMs,
        };
      }

      if (!rawText.trim()) {
        return {
          ok: false,
          payload: '',
          httpStatus: response.status,
          errorMessage: 'Upstream feed returned an empty payload.',
          durationMs,
        };
      }

      return {
        ok: true,
        payload: rawText,
        httpStatus: response.status,
        errorMessage: null,
        durationMs,
      };
    } catch (err) {
      const durationMs = Date.now() - startedAt;
      const isTimeout =
        err instanceof Error &&
        (err.name === 'AbortError' || err.message.toLowerCase().includes('abort'));
      return {
        ok: false,
        payload: '',
        httpStatus: isTimeout ? 504 : 0,
        errorMessage: isTimeout
          ? `Feed request timed out after ${Math.round(timeoutMs / 1000)}s.`
          : err instanceof Error
            ? err.message
            : 'Network error fetching feed.',
        durationMs,
      };
    } finally {
      clearTimeout(timer);
    }
  }

  async fetchFeed(
    feedUrl: string,
    timeoutMs: number = DEFAULT_TIMEOUT_MS
  ): Promise<FeedFetchResponse> {
    const first = await this.fetchOnce(feedUrl, timeoutMs);
    if (!first.ok && first.httpStatus === 0) {
      await new Promise((r) => setTimeout(r, 500));
      return this.fetchOnce(feedUrl, timeoutMs);
    }
    return first;
  }
}

let activeTransport: FeedTransportAdapter = new SameOriginServerFeedTransport();

export function setArticleFeedTransport(adapter: FeedTransportAdapter): void {
  activeTransport = adapter;
}

function fetchFeedDeduplicated(
  feedUrl: string,
  timeoutMs: number
): Promise<FeedFetchResponse> {
  const existing = inFlightFeedFetches.get(feedUrl);
  if (existing) return existing;

  const promise = activeTransport
    .fetchFeed(feedUrl, timeoutMs)
    .finally(() => {
      inFlightFeedFetches.delete(feedUrl);
    });
  inFlightFeedFetches.set(feedUrl, promise);
  return promise;
}

function parseSourcePayload(
  source: ArticleSource,
  payload: string
): FeedParseResult {
  const trimmed = payload.trim();
  if (source.sourceType === 'json-feed' || trimmed.startsWith('{')) {
    return parseJsonFeed(payload, source.websiteUrl);
  }
  if (
    source.sourceType === 'atom' ||
    (trimmed.includes('<feed') && !trimmed.includes('<rss'))
  ) {
    return parseAtomFeed(payload, source.websiteUrl);
  }
  return parseRssFeed(payload, source.websiteUrl);
}

export function formatArticlePublishedDate(isoOrNull: string | null): string {
  if (!isoOrNull) return 'Date unavailable';
  const ms = Date.parse(isoOrNull);
  if (Number.isNaN(ms) || ms <= 0) return 'Date unavailable';
  return new Intl.DateTimeFormat('en-US', {
    month: 'long',
    day: '2-digit',
    year: 'numeric',
  }).format(new Date(ms));
}

export function formatArticleSyncTimestamp(iso: string | null): string {
  if (!iso) return 'Never synced';
  const ms = Date.parse(iso);
  if (Number.isNaN(ms) || ms <= 0) return iso;
  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(ms));
}

export async function initializeArticleAggregation(): Promise<{
  articles: AggregatedArticle[];
  sources: ArticleSource[];
  summary: AggregationSyncSummary | null;
  config: AggregationSyncConfig;
}> {
  await articleStorage.init();
  const snapshot = articleStorage.getArticlesSnapshot();
  const { articles, changed } = reconcileAggregatedRetention(snapshot);
  if (changed) {
    await articleStorage.saveArticles(articles);
  }
  return {
    articles,
    sources: articleStorage.getSourcesSnapshot(),
    summary: articleStorage.getSummarySnapshot(),
    config: articleStorage.getConfigSnapshot(),
  };
}

export function getAggregatedArticlesSync(): AggregatedArticle[] {
  return articleStorage.getArticlesSnapshot();
}

export function getArticleSourcesSync(): ArticleSource[] {
  return articleStorage.getSourcesSnapshot();
}

export function getAggregationSummarySync(): AggregationSyncSummary | null {
  return articleStorage.getSummarySnapshot();
}

export function getAggregationConfigSync(): AggregationSyncConfig {
  return articleStorage.getConfigSnapshot();
}

export async function saveAggregationConfig(
  config: AggregationSyncConfig
): Promise<AggregationSyncConfig> {
  await articleStorage.saveConfig(config);
  return articleStorage.getConfigSnapshot();
}

export async function setArticleSourceEnabled(
  sourceId: string,
  enabled: boolean
): Promise<ArticleSource[]> {
  await articleStorage.init();
  const sources = articleStorage.getSourcesSnapshot();
  const next = sources.map((src) => {
    if (src.id !== sourceId) return src;
    if (src.sourceType === 'unsupported') {
      return { ...src, enabled: false, status: 'unsupported' as const };
    }
    return { ...src, enabled };
  });
  await articleStorage.saveSources(next);
  return next;
}

export async function syncSingleArticleSource(sourceId: string): Promise<{
  articles: AggregatedArticle[];
  sources: ArticleSource[];
  report: ArticleSourceSyncReport;
  summary: AggregationSyncSummary;
}> {
  if (inFlightSourceSyncs.has(sourceId)) {
    return inFlightSourceSyncs.get(sourceId)!;
  }

  const runPromise = (async () => {
    await articleStorage.init();
    const sources = articleStorage.getSourcesSnapshot();
    const config = articleStorage.getConfigSnapshot();
    const existingArticles = articleStorage.getArticlesSnapshot();
    const prevSummary = articleStorage.getSummarySnapshot();
    const target = sources.find((s) => s.id === sourceId);

    if (!target) {
      throw new Error(`Article source not found: ${sourceId}`);
    }

    const nowIso = new Date().toISOString();

    if (target.sourceType === 'unsupported' || !target.feedUrl) {
      const report: ArticleSourceSyncReport = {
        sourceId: target.id,
        sourceName: target.name,
        sourceGroup: target.sourceGroup,
        feedUrl: target.feedUrl,
        sourceType: target.sourceType,
        ok: false,
        unsupported: true,
        fetchedCount: 0,
        newCount: 0,
        duplicatesSkipped: 0,
        errorMessage:
          target.errorMessage ||
          'Source does not publish a supported RSS/Atom/JSON feed.',
        durationMs: 0,
      };
      const nextSources = sources.map((s) =>
        s.id === target.id
          ? {
              ...s,
              status: 'unsupported' as const,
              errorMessage: report.errorMessage,
            }
          : s
      );
      const summary = buildSummaryFromRun(
        nextSources,
        existingArticles,
        [report],
        0,
        0,
        nowIso,
        prevSummary,
        existingArticles.length === 0,
        `${target.name} is unsupported: ${report.errorMessage}`
      );
      await articleStorage.saveSources(nextSources);
      await articleStorage.saveSummary(summary);
      return { articles: existingArticles, sources: nextSources, report, summary };
    }

    const fetchRes = await fetchFeedDeduplicated(
      target.feedUrl,
      config.requestTimeoutMs
    );

    let updatedArticles = existingArticles;
    let updatedSource: ArticleSource;
    let report: ArticleSourceSyncReport;

    if (!fetchRes.ok) {
      updatedSource = {
        ...target,
        lastFetchedAt: nowIso,
        status: 'error',
        errorMessage: fetchRes.errorMessage || 'Feed fetch failed.',
      };
      report = {
        sourceId: target.id,
        sourceName: target.name,
        sourceGroup: target.sourceGroup,
        feedUrl: target.feedUrl,
        sourceType: target.sourceType,
        ok: false,
        fetchedCount: 0,
        newCount: 0,
        duplicatesSkipped: 0,
        errorMessage: updatedSource.errorMessage,
        durationMs: fetchRes.durationMs,
      };
    } else {
      try {
        const parsed = parseSourcePayload(target, fetchRes.payload);
        const capped = parsed.items.slice(0, target.maxArticlesPerFetch);
        if (capped.length === 0) {
          const msg =
            'Feed returned valid markup but contained zero usable articles.';
          updatedSource = {
            ...target,
            lastFetchedAt: nowIso,
            status: 'error',
            errorMessage: msg,
            lastArticleCount: 0,
          };
          report = {
            sourceId: target.id,
            sourceName: target.name,
            sourceGroup: target.sourceGroup,
            feedUrl: target.feedUrl,
            sourceType: target.sourceType,
            ok: false,
            fetchedCount: 0,
            newCount: 0,
            duplicatesSkipped: 0,
            errorMessage: msg,
            durationMs: fetchRes.durationMs,
          };
        } else {
          const normalizedIncoming = capped.map((item) =>
            normalizeFeedItemToArticle(item, target, nowIso)
          );
          const merged = deduplicateAndMergeArticles(
            existingArticles,
            normalizedIncoming
          );
          updatedArticles = merged.nextArticles;
          updatedSource = {
            ...target,
            lastFetchedAt: nowIso,
            lastSuccessfulFetchAt: nowIso,
            status: 'success',
            errorMessage: null,
            lastArticleCount: capped.length,
          };
          report = {
            sourceId: target.id,
            sourceName: target.name,
            sourceGroup: target.sourceGroup,
            feedUrl: target.feedUrl,
            sourceType: target.sourceType,
            ok: true,
            fetchedCount: capped.length,
            newCount: merged.newCount,
            duplicatesSkipped: merged.duplicatesSkipped,
            errorMessage: null,
            durationMs: fetchRes.durationMs,
          };
        }
      } catch (err) {
        const parseMsg =
          err instanceof Error ? err.message : 'Failed to parse feed payload.';
        updatedSource = {
          ...target,
          lastFetchedAt: nowIso,
          status: 'error',
          errorMessage: parseMsg,
        };
        report = {
          sourceId: target.id,
          sourceName: target.name,
          sourceGroup: target.sourceGroup,
          feedUrl: target.feedUrl,
          sourceType: target.sourceType,
          ok: false,
          fetchedCount: 0,
          newCount: 0,
          duplicatesSkipped: 0,
          errorMessage: parseMsg,
          durationMs: fetchRes.durationMs,
        };
      }
    }

    const nextSources = sources.map((s) =>
      s.id === target.id ? updatedSource : s
    );
    const { articles: reconciled } = reconcileAggregatedRetention(updatedArticles);
    const summary = buildSummaryFromRun(
      nextSources,
      reconciled,
      [report],
      report.newCount,
      report.duplicatesSkipped,
      nowIso,
      prevSummary,
      existingArticles.length === 0,
      report.ok
        ? `${target.name} synced: ${report.fetchedCount} fetched (${report.newCount} new, ${report.duplicatesSkipped} duplicates skipped).`
        : `${target.name} failed: ${report.errorMessage}`
    );

    await articleStorage.saveArticles(reconciled);
    await articleStorage.saveSources(nextSources);
    await articleStorage.saveSummary(summary);

    return {
      articles: reconciled,
      sources: nextSources,
      report,
      summary,
    };
  })();

  inFlightSourceSyncs.set(sourceId, runPromise);
  try {
    return await runPromise;
  } finally {
    inFlightSourceSyncs.delete(sourceId);
  }
}

export async function syncAllArticleSources(): Promise<{
  articles: AggregatedArticle[];
  sources: ArticleSource[];
  summary: AggregationSyncSummary;
}> {
  if (inFlightFullSync) {
    return inFlightFullSync;
  }

  const runPromise = (async () => {
    await articleStorage.init();
    const sources = articleStorage.getSourcesSnapshot();
    const config = articleStorage.getConfigSnapshot();
    const syncableSources = getSyncableEnabledSources(sources);
    const existingArticles = articleStorage.getArticlesSnapshot();
    const prevSummary = articleStorage.getSummarySnapshot();
    const isInitialImport = existingArticles.length === 0;
    const nowIso = new Date().toISOString();

    const fetchedResults: Array<{
      source: ArticleSource;
      fetchRes: FeedFetchResponse;
    }> = new Array(syncableSources.length);

    let cursor = 0;
    const workerCount = Math.min(
      CONTROLLED_CONCURRENCY,
      Math.max(1, syncableSources.length)
    );
    const workers = Array.from({ length: workerCount }, async () => {
      while (cursor < syncableSources.length) {
        const idx = cursor++;
        const source = syncableSources[idx];
        const fetchRes = await fetchFeedDeduplicated(
          source.feedUrl,
          config.requestTimeoutMs
        );
        fetchedResults[idx] = { source, fetchRes };
      }
    });
    await Promise.all(workers);

    let workingArticles = [...existingArticles];
    let totalNew = 0;
    let totalSkipped = 0;
    const updatedById = new Map<string, ArticleSource>();
    const reports: ArticleSourceSyncReport[] = [];

    for (const entry of fetchedResults) {
      if (!entry) continue;
      const { source, fetchRes } = entry;

      if (!fetchRes.ok) {
        updatedById.set(source.id, {
          ...source,
          lastFetchedAt: nowIso,
          status: 'error',
          errorMessage: fetchRes.errorMessage || 'Feed fetch failed.',
        });
        reports.push({
          sourceId: source.id,
          sourceName: source.name,
          sourceGroup: source.sourceGroup,
          feedUrl: source.feedUrl,
          sourceType: source.sourceType,
          ok: false,
          fetchedCount: 0,
          newCount: 0,
          duplicatesSkipped: 0,
          errorMessage: fetchRes.errorMessage || 'Feed fetch failed.',
          durationMs: fetchRes.durationMs,
        });
        continue;
      }

      try {
        const parsed = parseSourcePayload(source, fetchRes.payload);
        const capped = parsed.items.slice(0, source.maxArticlesPerFetch);
        if (capped.length === 0) {
          const msg =
            'Feed returned valid markup but contained zero usable articles.';
          updatedById.set(source.id, {
            ...source,
            lastFetchedAt: nowIso,
            status: 'error',
            errorMessage: msg,
            lastArticleCount: 0,
          });
          reports.push({
            sourceId: source.id,
            sourceName: source.name,
            sourceGroup: source.sourceGroup,
            feedUrl: source.feedUrl,
            sourceType: source.sourceType,
            ok: false,
            fetchedCount: 0,
            newCount: 0,
            duplicatesSkipped: 0,
            errorMessage: msg,
            durationMs: fetchRes.durationMs,
          });
          continue;
        }

        const normalized = capped.map((item) =>
          normalizeFeedItemToArticle(item, source, nowIso)
        );
        const merged = deduplicateAndMergeArticles(workingArticles, normalized);
        workingArticles = merged.nextArticles;
        totalNew += merged.newCount;
        totalSkipped += merged.duplicatesSkipped;

        updatedById.set(source.id, {
          ...source,
          lastFetchedAt: nowIso,
          lastSuccessfulFetchAt: nowIso,
          status: 'success',
          errorMessage: null,
          lastArticleCount: capped.length,
        });
        reports.push({
          sourceId: source.id,
          sourceName: source.name,
          sourceGroup: source.sourceGroup,
          feedUrl: source.feedUrl,
          sourceType: source.sourceType,
          ok: true,
          fetchedCount: capped.length,
          newCount: merged.newCount,
          duplicatesSkipped: merged.duplicatesSkipped,
          errorMessage: null,
          durationMs: fetchRes.durationMs,
        });
      } catch (err) {
        const parseErr =
          err instanceof Error ? err.message : 'Failed to parse feed payload.';
        updatedById.set(source.id, {
          ...source,
          lastFetchedAt: nowIso,
          status: 'error',
          errorMessage: parseErr,
        });
        reports.push({
          sourceId: source.id,
          sourceName: source.name,
          sourceGroup: source.sourceGroup,
          feedUrl: source.feedUrl,
          sourceType: source.sourceType,
          ok: false,
          fetchedCount: 0,
          newCount: 0,
          duplicatesSkipped: 0,
          errorMessage: parseErr,
          durationMs: fetchRes.durationMs,
        });
      }
    }

    // Also include unsupported sources transparently in reports
    for (const src of sources) {
      if (src.sourceType === 'unsupported') {
        reports.push({
          sourceId: src.id,
          sourceName: src.name,
          sourceGroup: src.sourceGroup,
          feedUrl: src.feedUrl,
          sourceType: src.sourceType,
          ok: false,
          unsupported: true,
          fetchedCount: 0,
          newCount: 0,
          duplicatesSkipped: 0,
          errorMessage: src.errorMessage,
          durationMs: 0,
        });
      }
    }

    const nextSources = sources.map((s) => updatedById.get(s.id) || s);
    const { articles: reconciled } = reconcileAggregatedRetention(workingArticles);

    const succeededCount = reports.filter((r) => r.ok).length;
    const failedCount = reports.filter((r) => !r.ok && !r.unsupported).length;
    const message =
      failedCount === 0
        ? `${succeededCount} active sources synced (${totalNew} new, ${totalSkipped} duplicates skipped).`
        : succeededCount > 0
          ? `Partial sync: ${succeededCount}/${syncableSources.length} active feeds succeeded, ${failedCount} failed (${totalNew} new, ${totalSkipped} duplicates skipped).`
          : `Sync failed across ${failedCount} active feeds. Existing saved articles are preserved.`;

    const summary = buildSummaryFromRun(
      nextSources,
      reconciled,
      reports,
      totalNew,
      totalSkipped,
      nowIso,
      prevSummary,
      isInitialImport,
      message
    );

    await articleStorage.saveArticles(reconciled);
    await articleStorage.saveSources(nextSources);
    await articleStorage.saveSummary(summary);

    return {
      articles: reconciled,
      sources: nextSources,
      summary,
    };
  })();

  inFlightFullSync = runPromise;
  try {
    return await runPromise;
  } finally {
    inFlightFullSync = null;
  }
}

function buildSummaryFromRun(
  sources: ArticleSource[],
  articles: AggregatedArticle[],
  reports: ArticleSourceSyncReport[],
  newArticlesAdded: number,
  duplicatesSkipped: number,
  nowIso: string,
  prevSummary: AggregationSyncSummary | null,
  isInitialImport: boolean,
  message: string
): AggregationSyncSummary {
  const enabledSources = sources.filter(
    (s) => s.enabled && s.sourceType !== 'unsupported'
  ).length;
  const succeededSources = sources.filter(
    (s) => s.enabled && s.status === 'success'
  ).length;
  const failedSources = sources.filter(
    (s) => s.enabled && s.status === 'error'
  ).length;
  const unsupportedSources = sources.filter(
    (s) => s.sourceType === 'unsupported'
  ).length;
  const anyRunSucceeded = reports.some((r) => r.ok);

  return {
    syncedAt: nowIso,
    lastSuccessfulSyncAt: anyRunSucceeded
      ? nowIso
      : prevSummary?.lastSuccessfulSyncAt || null,
    totalSources: sources.length,
    enabledSources,
    succeededSources,
    failedSources,
    unsupportedSources,
    newArticlesAdded,
    duplicatesSkipped,
    totalStoredArticles: articles.length,
    reports,
    partialFailure: failedSources > 0 && succeededSources > 0,
    isInitialImport,
    message,
  };
}

export async function toggleAggregatedArticleFavorite(
  articleId: string
): Promise<AggregatedArticle[]> {
  await articleStorage.init();
  const articles = articleStorage.getArticlesSnapshot();
  const next = articles.map((a) =>
    a.id === articleId ? { ...a, isFavorite: !a.isFavorite } : a
  );
  await articleStorage.saveArticles(next);
  return next;
}

export async function setAggregatedArticleRead(
  articleId: string,
  isRead: boolean
): Promise<AggregatedArticle[]> {
  await articleStorage.init();
  const articles = articleStorage.getArticlesSnapshot();
  const next = articles.map((a) =>
    a.id === articleId ? { ...a, isRead } : a
  );
  await articleStorage.saveArticles(next);
  return next;
}

export async function deleteAggregatedArticleById(
  articleId: string
): Promise<AggregatedArticle[]> {
  await articleStorage.init();
  const articles = articleStorage.getArticlesSnapshot();
  const next = articles.filter((a) => a.id !== articleId);
  await articleStorage.saveArticles(next);
  return next;
}

export async function findAggregatedArticleById(
  articleId: string
): Promise<AggregatedArticle | null> {
  await articleStorage.init();
  const decoded = decodeURIComponent(articleId);
  const articles = articleStorage.getArticlesSnapshot();
  return (
    articles.find((a) => a.id === decoded || a.id === articleId) || null
  );
}
