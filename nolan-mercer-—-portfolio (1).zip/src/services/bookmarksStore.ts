import { RAINDROP_BOOKMARKS, RaindropBookmark } from '../data/portfolioData';

const BOOKMARKS_STORAGE_KEY = 'mk-raindrop-bookmarks-v1';

export function loadBookmarks(): RaindropBookmark[] {
  try {
    const saved = localStorage.getItem(BOOKMARKS_STORAGE_KEY);
    if (saved !== null) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        const defaultsById = new Map(RAINDROP_BOOKMARKS.map((b) => [b.id, b]));
        return parsed.map((item: RaindropBookmark) => {
          const def = defaultsById.get(item.id);
          return {
            ...item,
            iconKey: item.iconKey || def?.iconKey || 'auto',
            iconUrl: item.iconUrl || def?.iconUrl,
          };
        });
      }
    }
  } catch {
    // Fallback to defaults
  }
  return RAINDROP_BOOKMARKS;
}

export function saveBookmarks(next: RaindropBookmark[]): void {
  try {
    localStorage.setItem(BOOKMARKS_STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Ignore storage failures
  }
}
