import {
  DEFAULT_MEDIUM_SYNC_CONFIG,
  INITIAL_MEDIUM_SOURCES,
  MEDIUM_SYNC_CONFIG_VERSION,
} from '../../data/mediumSources';
import {
  MEDIUM_RSS_REAL_FEED_LIMIT,
  MEDIUM_SYNC_INTERVAL_OPTIONS,
  MediumArticle,
  MediumSource,
  MediumStorageAdapter,
  MediumSyncConfig,
  MediumSyncIntervalHours,
  MediumSyncSummary,
} from '../../types/medium';

const ARTICLES_KEY = 'mk-medium-articles-v1';
const SOURCES_KEY = 'mk-medium-sources-v1';
const SYNC_SUMMARY_KEY = 'mk-medium-sync-summary-v1';
const SYNC_CONFIG_KEY = 'mk-medium-sync-config-v1';

class LocalMediumStorageAdapter implements MediumStorageAdapter {
  private memoryArticles: MediumArticle[] = [];
  private memorySources: MediumSource[] = INITIAL_MEDIUM_SOURCES.map((s) => ({
    ...s,
  }));
  private memorySummary: MediumSyncSummary | null = null;
  private memoryConfig: MediumSyncConfig = { ...DEFAULT_MEDIUM_SYNC_CONFIG };

  private hasStorage(): boolean {
    try {
      return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
    } catch {
      return false;
    }
  }

  loadArticles(): MediumArticle[] {
    if (!this.hasStorage()) return this.memoryArticles;
    try {
      const raw = window.localStorage.getItem(ARTICLES_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? (parsed as MediumArticle[]) : [];
    } catch (err) {
      console.warn('[mediumStorage] Failed to read articles from localStorage:', err);
      return this.memoryArticles;
    }
  }

  saveArticles(articles: MediumArticle[]): void {
    this.memoryArticles = articles;
    if (!this.hasStorage()) return;
    try {
      window.localStorage.setItem(ARTICLES_KEY, JSON.stringify(articles));
    } catch (err) {
      console.warn('[mediumStorage] Failed to persist articles (quota/storage error):', err);
    }
  }

  loadSources(): MediumSource[] {
    if (!this.hasStorage()) return this.memorySources;
    try {
      const raw = window.localStorage.getItem(SOURCES_KEY);
      if (!raw) {
        return INITIAL_MEDIUM_SOURCES.map((s) => ({ ...s }));
      }
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) {
        return INITIAL_MEDIUM_SOURCES.map((s) => ({ ...s }));
      }
      const byId = new Map<string, MediumSource>();
      (parsed as MediumSource[]).forEach((src) => {
        if (src && typeof src.id === 'string') {
          byId.set(src.id, src);
        }
      });

      // Keep canonical RSS URLs/tags from central config while preserving persisted fetch telemetry
      return INITIAL_MEDIUM_SOURCES.map((def) => {
        const saved = byId.get(def.id);
        if (!saved) return { ...def };
        return {
          ...def,
          enabled: typeof saved.enabled === 'boolean' ? saved.enabled : def.enabled,
          lastFetchedAt: saved.lastFetchedAt || null,
          lastSuccessfulFetchAt: saved.lastSuccessfulFetchAt || null,
          status: saved.status === 'syncing' ? 'idle' : saved.status || 'idle',
          errorMessage: saved.errorMessage || null,
          lastArticleCount:
            typeof saved.lastArticleCount === 'number' ? saved.lastArticleCount : 0,
        };
      });
    } catch (err) {
      console.warn('[mediumStorage] Failed to read sources from localStorage:', err);
      return this.memorySources;
    }
  }

  saveSources(sources: MediumSource[]): void {
    this.memorySources = sources;
    if (!this.hasStorage()) return;
    try {
      window.localStorage.setItem(SOURCES_KEY, JSON.stringify(sources));
    } catch (err) {
      console.warn('[mediumStorage] Failed to persist sources:', err);
    }
  }

  loadLastSyncSummary(): MediumSyncSummary | null {
    if (!this.hasStorage()) return this.memorySummary;
    try {
      const raw = window.localStorage.getItem(SYNC_SUMMARY_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as MediumSyncSummary;
      return {
        ...parsed,
        duplicatesSkipped:
          typeof parsed.duplicatesSkipped === 'number'
            ? parsed.duplicatesSkipped
            : parsed.duplicatesMerged || 0,
      };
    } catch {
      return this.memorySummary;
    }
  }

  saveLastSyncSummary(summary: MediumSyncSummary): void {
    this.memorySummary = summary;
    if (!this.hasStorage()) return;
    try {
      window.localStorage.setItem(SYNC_SUMMARY_KEY, JSON.stringify(summary));
    } catch (err) {
      console.warn('[mediumStorage] Failed to persist sync summary:', err);
    }
  }

  loadSyncConfig(): MediumSyncConfig {
    if (!this.hasStorage()) return this.memoryConfig;
    try {
      const raw = window.localStorage.getItem(SYNC_CONFIG_KEY);
      if (!raw) return { ...DEFAULT_MEDIUM_SYNC_CONFIG };
      const parsed = JSON.parse(raw) as Partial<MediumSyncConfig>;

      // Migrate v1 configs (6h / 12s defaults) seamlessly to v2 collection defaults (3h / 20s)
      if ((parsed.configVersion ?? 1) < MEDIUM_SYNC_CONFIG_VERSION) {
        const migrated: MediumSyncConfig = {
          ...DEFAULT_MEDIUM_SYNC_CONFIG,
          autoSyncEnabled:
            typeof parsed.autoSyncEnabled === 'boolean'
              ? parsed.autoSyncEnabled
              : DEFAULT_MEDIUM_SYNC_CONFIG.autoSyncEnabled,
        };
        this.saveSyncConfig(migrated);
        return migrated;
      }

      const rawHours = parsed.autoSyncIntervalHours;
      const hours: MediumSyncIntervalHours = MEDIUM_SYNC_INTERVAL_OPTIONS.includes(
        rawHours as MediumSyncIntervalHours
      )
        ? (rawHours as MediumSyncIntervalHours)
        : DEFAULT_MEDIUM_SYNC_CONFIG.autoSyncIntervalHours;

      const timeoutMs =
        typeof parsed.requestTimeoutMs === 'number' &&
        parsed.requestTimeoutMs >= 5000
          ? parsed.requestTimeoutMs
          : DEFAULT_MEDIUM_SYNC_CONFIG.requestTimeoutMs;

      return {
        configVersion: MEDIUM_SYNC_CONFIG_VERSION,
        autoSyncEnabled:
          typeof parsed.autoSyncEnabled === 'boolean'
            ? parsed.autoSyncEnabled
            : true,
        autoSyncIntervalHours: hours,
        maxArticlesPerFeed: MEDIUM_RSS_REAL_FEED_LIMIT,
        requestTimeoutMs: timeoutMs,
      };
    } catch {
      return { ...DEFAULT_MEDIUM_SYNC_CONFIG };
    }
  }

  saveSyncConfig(config: MediumSyncConfig): void {
    const normalized: MediumSyncConfig = {
      ...config,
      configVersion: MEDIUM_SYNC_CONFIG_VERSION,
      maxArticlesPerFeed: Math.min(
        Math.max(1, config.maxArticlesPerFeed || MEDIUM_RSS_REAL_FEED_LIMIT),
        MEDIUM_RSS_REAL_FEED_LIMIT
      ),
    };
    this.memoryConfig = normalized;
    if (!this.hasStorage()) return;
    try {
      window.localStorage.setItem(SYNC_CONFIG_KEY, JSON.stringify(normalized));
    } catch (err) {
      console.warn('[mediumStorage] Failed to persist sync config:', err);
    }
  }
}

let activeStorageAdapter: MediumStorageAdapter = new LocalMediumStorageAdapter();

/**
 * Allows swapping the local storage implementation with a future REST / database adapter.
 */
export function setMediumStorageAdapter(adapter: MediumStorageAdapter): void {
  activeStorageAdapter = adapter;
}

export function getMediumStorageAdapter(): MediumStorageAdapter {
  return activeStorageAdapter;
}
