import { DEFAULT_MEDIUM_SYNC_CONFIG } from '../../data/mediumSources';
import {
  MEDIUM_RETENTION_DAYS,
  MEDIUM_RSS_REAL_FEED_LIMIT,
  MediumArticle,
  MediumArticleRetentionStatus,
  MediumBackgroundSyncScheduler,
  MediumCategoryName,
  MediumSource,
  MediumSourceSyncReport,
  MediumSyncConfig,
  MediumSyncSummary,
} from '../../types/medium';
import { normalizeMediumUrl, parseMediumRssXml } from './mediumParser';
import { fetchMediumRssXml, MediumRssFetchResult } from './mediumRssService';
import { getMediumStorageAdapter } from './mediumStorageService';

export const MEDIUM_RETENTION_MS = MEDIUM_RETENTION_DAYS * 24 * 60 * 60 * 1000;

export function isValidPublishedDate(publishedAt: string): boolean {
  const ms = Date.parse(publishedAt);
  return !Number.isNaN(ms) && ms > 0;
}

/**
 * Only articles with a valid publication date strictly older than 30 days should move to Archive.
 * Articles with invalid/unparseable dates are NEVER deleted or accidentally archived.
 */
export function shouldArchiveMediumArticle(
  publishedAt: string,
  nowMs: number = Date.now()
): boolean {
  const publishedMs = Date.parse(publishedAt);
  if (Number.isNaN(publishedMs) || publishedMs <= 0) {
    return false;
  }
  return nowMs - publishedMs > MEDIUM_RETENTION_MS;
}

export function isPublishedWithinLast30Days(
  publishedAt: string,
  nowMs: number = Date.now()
): boolean {
  const publishedMs = Date.parse(publishedAt);
  if (Number.isNaN(publishedMs) || publishedMs <= 0) return false;
  return nowMs - publishedMs <= MEDIUM_RETENTION_MS;
}

export function getMediumArticleRetentionStatus(
  article: Pick<MediumArticle, 'publishedAt' | 'retentionStatus'>,
  nowMs: number = Date.now()
): MediumArticleRetentionStatus {
  if (!isValidPublishedDate(article.publishedAt)) {
    return article.retentionStatus || 'active';
  }
  return shouldArchiveMediumArticle(article.publishedAt, nowMs)
    ? 'archived'
    : 'active';
}

export function reconcileMediumArticleRetention(
  articles: MediumArticle[],
  nowMs: number = Date.now()
): { articles: MediumArticle[]; changed: boolean } {
  let changed = false;
  const nowIso = new Date(nowMs).toISOString();

  const next = articles.map((article) => {
    if (!isValidPublishedDate(article.publishedAt)) {
      // Preserve invalid-date articles as-is without accidental deletion or archiving
      const safeStatus: MediumArticleRetentionStatus =
        article.retentionStatus || 'active';
      if (article.retentionStatus !== safeStatus) {
        changed = true;
        return { ...article, retentionStatus: safeStatus };
      }
      return article;
    }

    const archived = shouldArchiveMediumArticle(article.publishedAt, nowMs);
    const targetStatus: MediumArticleRetentionStatus = archived
      ? 'archived'
      : 'active';
    const targetArchivedAt =
      targetStatus === 'archived' ? article.archivedAt || nowIso : null;

    if (
      article.retentionStatus !== targetStatus ||
      (article.archivedAt ?? null) !== targetArchivedAt
    ) {
      changed = true;
      return {
        ...article,
        retentionStatus: targetStatus,
        archivedAt: targetArchivedAt,
      };
    }
    return article;
  });

  return { articles: next, changed };
}

const CONTROLLED_CONCURRENCY = 3;

const inFlightSourceSyncs = new Map<
  string,
  Promise<{
    articles: MediumArticle[];
    sources: MediumSource[];
    report: MediumSourceSyncReport;
    summary: MediumSyncSummary;
  }>
>();

let inFlightFullSync: Promise<{
  articles: MediumArticle[];
  sources: MediumSource[];
  summary: MediumSyncSummary;
}> | null = null;

function makeArticleStableId(guid: string, articleUrl: string): string {
  const base = guid || normalizeMediumUrl(articleUrl);
  // Extract Medium post hex id when present (`https://medium.com/p/45a0f8595a94`)
  const pMatch = base.match(/\/p\/([a-zA-Z0-9_-]+)/);
  if (pMatch) {
    return `medium-${pMatch[1]}`;
  }
  // Deterministic compact hash fallback
  let hash = 0;
  for (let i = 0; i < base.length; i++) {
    hash = (hash * 31 + base.charCodeAt(i)) | 0;
  }
  return `medium-${Math.abs(hash).toString(36)}`;
}

function getDedupeKeys(guid: string, articleUrl: string): string[] {
  const keys: string[] = [];
  if (guid) keys.push(`guid:${guid.toLowerCase()}`);
  const norm = normalizeMediumUrl(articleUrl);
  if (norm) keys.push(`url:${norm.toLowerCase()}`);
  return keys;
}

export function loadMediumSources(): MediumSource[] {
  const res = getMediumStorageAdapter().loadSources();
  return Array.isArray(res) ? res : [];
}

export function loadMediumArticles(nowMs: number = Date.now()): MediumArticle[] {
  const storage = getMediumStorageAdapter();
  const res = storage.loadArticles();
  if (!Array.isArray(res)) return [];

  // Automatically transition >30d articles to 'archived' in the single store (never deletes!)
  const { articles: reconciled, changed } = reconcileMediumArticleRetention(
    res,
    nowMs
  );
  if (changed) {
    storage.saveArticles(reconciled);
  }

  return [...reconciled].sort((a, b) => {
    const ta = Date.parse(a.publishedAt);
    const tb = Date.parse(b.publishedAt);
    return (Number.isNaN(tb) ? 0 : tb) - (Number.isNaN(ta) ? 0 : ta);
  });
}

export function loadLastMediumSyncSummary(): MediumSyncSummary | null {
  const res = getMediumStorageAdapter().loadLastSyncSummary();
  return res instanceof Promise ? null : res;
}

export function loadMediumSyncConfig(): MediumSyncConfig {
  const res = getMediumStorageAdapter().loadSyncConfig();
  return res instanceof Promise ? { ...DEFAULT_MEDIUM_SYNC_CONFIG } : res;
}

export function saveMediumSyncConfig(config: MediumSyncConfig): void {
  getMediumStorageAdapter().saveSyncConfig(config);
}

export function getNextScheduledSyncAt(
  summary: MediumSyncSummary | null,
  config: MediumSyncConfig
): string | null {
  if (!config.autoSyncEnabled) {
    return null;
  }
  const baseIso = summary?.lastSuccessfulSyncAt || summary?.syncedAt;
  if (!baseIso) {
    return new Date().toISOString();
  }
  const baseMs = Date.parse(baseIso);
  if (Number.isNaN(baseMs)) {
    return new Date().toISOString();
  }
  const intervalMs = config.autoSyncIntervalHours * 60 * 60 * 1000;
  return new Date(baseMs + intervalMs).toISOString();
}

export function isMediumSyncDue(
  summary: MediumSyncSummary | null,
  config: MediumSyncConfig
): boolean {
  if (!config.autoSyncEnabled) {
    return false;
  }
  if (!summary || !summary.lastSuccessfulSyncAt) {
    return true;
  }
  const lastMs = Date.parse(summary.lastSuccessfulSyncAt);
  if (Number.isNaN(lastMs)) return true;
  const intervalMs = config.autoSyncIntervalHours * 60 * 60 * 1000;
  return Date.now() - lastMs >= intervalMs;
}

/**
 * Browser-open scheduler implementation. When the application is closed, browser timers
 * do not run; swap this implementation with a server-side cron/worker scheduler later
 * using the same `MediumBackgroundSyncScheduler` contract.
 */
export const browserOpenSyncScheduler: MediumBackgroundSyncScheduler = {
  mode: 'browser-open',
  getNextRunAt: getNextScheduledSyncAt,
  async triggerScheduledSync() {
    await syncAllMediumSources();
  },
};

export function formatMediumPublishedDate(isoOrDate: string): string {
  const ms = Date.parse(isoOrDate);
  if (Number.isNaN(ms)) return isoOrDate;
  return new Intl.DateTimeFormat('en-US', {
    month: 'long',
    day: '2-digit',
    year: 'numeric',
  }).format(new Date(ms));
}

export function formatMediumSyncTimestamp(iso: string | null): string {
  if (!iso) return 'Never synced';
  const ms = Date.parse(iso);
  if (Number.isNaN(ms)) return iso;
  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(ms));
}

function mergeArticlesWithSourceItems(
  existingArticles: MediumArticle[],
  source: MediumSource,
  parsedItems: ReturnType<typeof parseMediumRssXml>['items'],
  nowIso: string
): {
  nextArticles: MediumArticle[];
  newCount: number;
  mergedDuplicateCount: number;
} {
  const cloned = existingArticles.map((a) => ({
    ...a,
    sourceCategories: [...(a.sourceCategories || [a.sourceCategory])],
    sourceTags: [...(a.sourceTags || [a.sourceTag])],
  }));

  const indexByKey = new Map<string, number>();
  cloned.forEach((article, idx) => {
    getDedupeKeys(article.guid, article.articleUrl).forEach((key) => {
      if (!indexByKey.has(key)) {
        indexByKey.set(key, idx);
      }
    });
  });

  let newCount = 0;
  let mergedDuplicateCount = 0;

  for (const item of parsedItems) {
    const keys = getDedupeKeys(item.guid, item.articleUrl);
    let existingIdx: number | undefined;
    for (const k of keys) {
      if (indexByKey.has(k)) {
        existingIdx = indexByKey.get(k);
        break;
      }
    }

    const combinedTags = Array.from(
      new Set([source.tag, ...item.itemTags.map((t) => t.toLowerCase())])
    );

    const shouldBeArchived = shouldArchiveMediumArticle(item.publishedAt);

    if (existingIdx !== undefined) {
      mergedDuplicateCount++;
      const current = cloned[existingIdx];
      const nextCategories = Array.from(
        new Set<MediumCategoryName>([...current.sourceCategories, source.name])
      );
      const nextTags = Array.from(
        new Set([...current.sourceTags, ...combinedTags])
      );
      const effectivePublishedAt = current.publishedAt || item.publishedAt;
      const nextStatus: MediumArticleRetentionStatus = isValidPublishedDate(
        effectivePublishedAt
      )
        ? shouldArchiveMediumArticle(effectivePublishedAt)
          ? 'archived'
          : 'active'
        : current.retentionStatus || 'active';

      cloned[existingIdx] = {
        ...current,
        // Refresh snippet metadata if upstream improved, while preserving Read, Favorite & Archive state
        title: item.title || current.title,
        author: item.author || current.author,
        summary: item.summary || current.summary,
        contentSnippet: item.contentSnippet || current.contentSnippet,
        image: current.image || item.image,
        readingTime: current.readingTime || item.readingTime,
        rssParagraphs:
          item.rssParagraphs.length > (current.rssParagraphs?.length || 0)
            ? item.rssParagraphs
            : current.rssParagraphs,
        sourceCategories: nextCategories,
        sourceTags: nextTags,
        retentionStatus: nextStatus,
        archivedAt:
          nextStatus === 'archived' ? current.archivedAt || nowIso : null,
      };
    } else {
      newCount++;
      const initialStatus: MediumArticleRetentionStatus = shouldBeArchived
        ? 'archived'
        : 'active';
      const newArticle: MediumArticle = {
        id: makeArticleStableId(item.guid, item.articleUrl),
        title: item.title,
        author: item.author,
        publishedAt: item.publishedAt,
        summary: item.summary,
        contentSnippet: item.contentSnippet,
        image: item.image,
        articleUrl: item.articleUrl,
        guid: item.guid,
        source: 'medium',
        sourceCategory: source.name,
        sourceTag: source.tag,
        sourceCategories: [source.name],
        sourceTags: combinedTags,
        isRead: false,
        isFavorite: false,
        fetchedAt: nowIso,
        retentionStatus: initialStatus,
        archivedAt: initialStatus === 'archived' ? nowIso : null,
        readingTime: item.readingTime,
        rssParagraphs: item.rssParagraphs,
      };

      const insertedIdx = cloned.length;
      cloned.push(newArticle);
      keys.forEach((k) => indexByKey.set(k, insertedIdx));
    }
  }

  cloned.sort((a, b) => {
    const ta = Date.parse(a.publishedAt);
    const tb = Date.parse(b.publishedAt);
    return (Number.isNaN(tb) ? 0 : tb) - (Number.isNaN(ta) ? 0 : ta);
  });

  return {
    nextArticles: cloned,
    newCount,
    mergedDuplicateCount,
  };
}

export async function syncSingleMediumSource(
  sourceId: string
): Promise<{
  articles: MediumArticle[];
  sources: MediumSource[];
  report: MediumSourceSyncReport;
  summary: MediumSyncSummary;
}> {
  if (inFlightFullSync) {
    await inFlightFullSync.catch(() => undefined);
  }
  const existingInFlight = inFlightSourceSyncs.get(sourceId);
  if (existingInFlight) {
    return existingInFlight;
  }

  const runPromise = (async () => {
    const storage = getMediumStorageAdapter();
    const sources = loadMediumSources();
    const config = loadMediumSyncConfig();
    const existingArticles = loadMediumArticles();
    const target = sources.find((s) => s.id === sourceId);

    if (!target) {
      throw new Error(`Medium source not found: ${sourceId}`);
    }

    const isInitialImport = existingArticles.length === 0;
    const maxPerFeed = Math.min(
      config.maxArticlesPerFeed || MEDIUM_RSS_REAL_FEED_LIMIT,
      MEDIUM_RSS_REAL_FEED_LIMIT
    );

    const nowIso = new Date().toISOString();
    const fetchResult = await fetchMediumRssXml(
      target.rssUrl,
      config.requestTimeoutMs
    );

    let updatedArticles = existingArticles;
    let report: MediumSourceSyncReport;
    let updatedSource: MediumSource;

    if (!fetchResult.ok) {
      updatedSource = {
        ...target,
        lastFetchedAt: nowIso,
        status: 'error',
        errorMessage: fetchResult.errorMessage || 'Unknown RSS fetch failure.',
      };
      report = {
        sourceId: target.id,
        sourceName: target.name,
        rssUrl: target.rssUrl,
        ok: false,
        fetchedCount: 0,
        newCount: 0,
        mergedDuplicateCount: 0,
        errorMessage: updatedSource.errorMessage,
        durationMs: fetchResult.durationMs,
      };
    } else {
      try {
        const parsed = parseMediumRssXml(fetchResult.xml);
        const cappedItems = parsed.items.slice(0, maxPerFeed);

        if (cappedItems.length === 0) {
          const emptyMsg =
            'RSS feed returned valid XML but contained zero valid articles.';
          updatedSource = {
            ...target,
            lastFetchedAt: nowIso,
            status: 'error',
            errorMessage: emptyMsg,
            lastArticleCount: 0,
          };
          report = {
            sourceId: target.id,
            sourceName: target.name,
            rssUrl: target.rssUrl,
            ok: false,
            fetchedCount: 0,
            newCount: 0,
            mergedDuplicateCount: 0,
            errorMessage: emptyMsg,
            durationMs: fetchResult.durationMs,
          };
        } else {
          const merged = mergeArticlesWithSourceItems(
            existingArticles,
            target,
            cappedItems,
            nowIso
          );
          updatedArticles = merged.nextArticles;
          updatedSource = {
            ...target,
            lastFetchedAt: nowIso,
            lastSuccessfulFetchAt: nowIso,
            status: 'success',
            errorMessage: null,
            lastArticleCount: cappedItems.length,
          };
          report = {
            sourceId: target.id,
            sourceName: target.name,
            rssUrl: target.rssUrl,
            ok: true,
            fetchedCount: cappedItems.length,
            newCount: merged.newCount,
            mergedDuplicateCount: merged.mergedDuplicateCount,
            errorMessage: null,
            durationMs: fetchResult.durationMs,
          };
        }
      } catch (err) {
        const parseMsg =
          err instanceof Error ? err.message : 'Failed to parse RSS XML.';
        console.error('[mediumArticleService] Parse error:', target.rssUrl, err);
        updatedSource = {
          ...target,
          lastFetchedAt: nowIso,
          status: 'error',
          errorMessage: parseMsg,
        };
        report = {
          sourceId: target.id,
          sourceName: target.name,
          rssUrl: target.rssUrl,
          ok: false,
          fetchedCount: 0,
          newCount: 0,
          mergedDuplicateCount: 0,
          errorMessage: parseMsg,
          durationMs: fetchResult.durationMs,
        };
      }
    }

    const nextSources = sources.map((s) =>
      s.id === target.id ? updatedSource : s
    );

    const prevSummary = loadLastMediumSyncSummary();
    const succeededSources = nextSources.filter((s) => s.status === 'success').length;
    const failedSources = nextSources.filter((s) => s.status === 'error').length;

    const summary: MediumSyncSummary = {
      syncedAt: nowIso,
      lastSuccessfulSyncAt: report.ok
        ? nowIso
        : prevSummary?.lastSuccessfulSyncAt || null,
      totalSources: nextSources.filter((s) => s.enabled).length,
      succeededSources,
      failedSources,
      newArticlesAdded: report.newCount,
      duplicatesMerged: report.mergedDuplicateCount,
      duplicatesSkipped: report.mergedDuplicateCount,
      totalStoredArticles: updatedArticles.length,
      reports: [report],
      partialFailure: !report.ok,
      isInitialImport,
      message: report.ok
        ? `${target.name} synced: ${report.fetchedCount} fetched (${report.newCount} new, ${report.mergedDuplicateCount} duplicates skipped).`
        : `${target.name} failed: ${report.errorMessage}`,
    };

    storage.saveArticles(updatedArticles);
    storage.saveSources(nextSources);
    storage.saveLastSyncSummary(summary);

    return {
      articles: updatedArticles,
      sources: nextSources,
      report,
      summary,
    };
  })();

  inFlightSourceSyncs.set(sourceId, runPromise);
  try {
    return await runPromise;
  } finally {
    inFlightSourceSyncs.delete(sourceId);
  }
}

export async function syncAllMediumSources(): Promise<{
  articles: MediumArticle[];
  sources: MediumSource[];
  summary: MediumSyncSummary;
}> {
  if (inFlightFullSync) {
    return inFlightFullSync;
  }

  const runPromise = (async () => {
    const storage = getMediumStorageAdapter();
    const sources = loadMediumSources();
    const config = loadMediumSyncConfig();
    const enabledSources = sources.filter((s) => s.enabled);
    const existingArticles = loadMediumArticles();
    const prevSummary = loadLastMediumSyncSummary();
    const isInitialImport = existingArticles.length === 0;
    const maxPerFeed = Math.min(
      config.maxArticlesPerFeed || MEDIUM_RSS_REAL_FEED_LIMIT,
      MEDIUM_RSS_REAL_FEED_LIMIT
    );
    const nowIso = new Date().toISOString();

    // Controlled parallel worker pool (max 3 concurrent feeds) so 1 failure never stops others
    // and no duplicate concurrent requests hit the exact same source.
    const resultsByIndex: PromiseSettledResult<{
      source: MediumSource;
      result: MediumRssFetchResult;
    }>[] = new Array(enabledSources.length);

    let cursor = 0;
    const workerCount = Math.min(CONTROLLED_CONCURRENCY, enabledSources.length);
    const workers = Array.from({ length: workerCount }, async () => {
      while (true) {
        const idx = cursor++;
        if (idx >= enabledSources.length) break;
        const source = enabledSources[idx];
        try {
          const result = await fetchMediumRssXml(
            source.rssUrl,
            config.requestTimeoutMs
          );
          resultsByIndex[idx] = { status: 'fulfilled', value: { source, result } };
        } catch (reason) {
          resultsByIndex[idx] = { status: 'rejected', reason };
        }
      }
    });
    await Promise.all(workers);

    let workingArticles = existingArticles;
    let totalNew = 0;
    let totalSkipped = 0;
    const reports: MediumSourceSyncReport[] = [];
    const updatedById = new Map<string, MediumSource>();

    for (let i = 0; i < enabledSources.length; i++) {
      const source = enabledSources[i];
      const settled = resultsByIndex[i];

      if (!settled || settled.status === 'rejected') {
        const msg =
          settled?.status === 'rejected' && settled.reason instanceof Error
            ? settled.reason.message
            : 'Unexpected fetch rejection';
        updatedById.set(source.id, {
          ...source,
          lastFetchedAt: nowIso,
          status: 'error',
          errorMessage: msg,
        });
        reports.push({
          sourceId: source.id,
          sourceName: source.name,
          rssUrl: source.rssUrl,
          ok: false,
          fetchedCount: 0,
          newCount: 0,
          mergedDuplicateCount: 0,
          errorMessage: msg,
          durationMs: 0,
        });
        continue;
      }

      const { result } = settled.value;
      if (!result.ok) {
        updatedById.set(source.id, {
          ...source,
          lastFetchedAt: nowIso,
          status: 'error',
          errorMessage: result.errorMessage || 'Failed to fetch RSS feed.',
        });
        reports.push({
          sourceId: source.id,
          sourceName: source.name,
          rssUrl: source.rssUrl,
          ok: false,
          fetchedCount: 0,
          newCount: 0,
          mergedDuplicateCount: 0,
          errorMessage: result.errorMessage,
          durationMs: result.durationMs,
        });
        continue;
      }

      try {
        const parsed = parseMediumRssXml(result.xml);
        const cappedItems = parsed.items.slice(0, maxPerFeed);

        if (cappedItems.length === 0) {
          const emptyErr = 'Feed returned valid XML but 0 usable articles.';
          updatedById.set(source.id, {
            ...source,
            lastFetchedAt: nowIso,
            status: 'error',
            errorMessage: emptyErr,
            lastArticleCount: 0,
          });
          reports.push({
            sourceId: source.id,
            sourceName: source.name,
            rssUrl: source.rssUrl,
            ok: false,
            fetchedCount: 0,
            newCount: 0,
            mergedDuplicateCount: 0,
            errorMessage: emptyErr,
            durationMs: result.durationMs,
          });
          continue;
        }

        const merged = mergeArticlesWithSourceItems(
          workingArticles,
          source,
          cappedItems,
          nowIso
        );
        workingArticles = merged.nextArticles;
        totalNew += merged.newCount;
        totalSkipped += merged.mergedDuplicateCount;

        updatedById.set(source.id, {
          ...source,
          lastFetchedAt: nowIso,
          lastSuccessfulFetchAt: nowIso,
          status: 'success',
          errorMessage: null,
          lastArticleCount: cappedItems.length,
        });
        reports.push({
          sourceId: source.id,
          sourceName: source.name,
          rssUrl: source.rssUrl,
          ok: true,
          fetchedCount: cappedItems.length,
          newCount: merged.newCount,
          mergedDuplicateCount: merged.mergedDuplicateCount,
          errorMessage: null,
          durationMs: result.durationMs,
        });
      } catch (err) {
        const parseErr =
          err instanceof Error ? err.message : 'XML parse failure.';
        console.error('[mediumArticleService] Feed parse failed:', source.rssUrl, err);
        updatedById.set(source.id, {
          ...source,
          lastFetchedAt: nowIso,
          status: 'error',
          errorMessage: parseErr,
        });
        reports.push({
          sourceId: source.id,
          sourceName: source.name,
          rssUrl: source.rssUrl,
          ok: false,
          fetchedCount: 0,
          newCount: 0,
          mergedDuplicateCount: 0,
          errorMessage: parseErr,
          durationMs: result.durationMs,
        });
      }
    }

    const nextSources = sources.map((s) => updatedById.get(s.id) || s);
    const succeededSources = reports.filter((r) => r.ok).length;
    const failedSources = reports.filter((r) => !r.ok).length;
    const anySucceeded = succeededSources > 0;
    const partialFailure = failedSources > 0 && succeededSources > 0;

    let message = '';
    if (succeededSources === enabledSources.length) {
      message = isInitialImport
        ? `Initial import completed across ${succeededSources} feeds: ${workingArticles.length} unique articles collected (${totalSkipped} cross-tag duplicates skipped).`
        : `All ${succeededSources} Medium feeds synced (${totalNew} new added, ${totalSkipped} duplicates skipped).`;
    } else if (anySucceeded) {
      message = `Partial sync: ${succeededSources}/${enabledSources.length} feeds succeeded, ${failedSources} failed (${totalNew} new added, ${totalSkipped} duplicates skipped).`;
    } else {
      message = `Sync failed for all ${failedSources} feeds. Existing collected articles remain saved.`;
    }

    const summary: MediumSyncSummary = {
      syncedAt: nowIso,
      lastSuccessfulSyncAt: anySucceeded
        ? nowIso
        : prevSummary?.lastSuccessfulSyncAt || null,
      totalSources: enabledSources.length,
      succeededSources,
      failedSources,
      newArticlesAdded: totalNew,
      duplicatesMerged: totalSkipped,
      duplicatesSkipped: totalSkipped,
      totalStoredArticles: workingArticles.length,
      reports,
      partialFailure,
      isInitialImport,
      message,
    };

    storage.saveArticles(workingArticles);
    storage.saveSources(nextSources);
    storage.saveLastSyncSummary(summary);

    return {
      articles: workingArticles,
      sources: nextSources,
      summary,
    };
  })();

  inFlightFullSync = runPromise;
  try {
    return await runPromise;
  } finally {
    inFlightFullSync = null;
  }
}

export function setMediumArticleReadState(
  articleId: string,
  isRead: boolean
): MediumArticle[] {
  const articles = loadMediumArticles();
  const next = articles.map((a) =>
    a.id === articleId ? { ...a, isRead } : a
  );
  getMediumStorageAdapter().saveArticles(next);
  return next;
}

export function toggleMediumArticleFavorite(articleId: string): MediumArticle[] {
  const articles = loadMediumArticles();
  const next = articles.map((a) =>
    a.id === articleId ? { ...a, isFavorite: !a.isFavorite } : a
  );
  getMediumStorageAdapter().saveArticles(next);
  return next;
}

export function findMediumArticleById(articleId: string): MediumArticle | null {
  const decoded = decodeURIComponent(articleId);
  const articles = loadMediumArticles();
  return articles.find((a) => a.id === decoded || a.id === articleId) || null;
}

/**
 * Only deletes a stored Medium article when explicitly requested by the user.
 * Articles are never deleted automatically after 30 days.
 */
export function deleteMediumArticleById(articleId: string): MediumArticle[] {
  const articles = loadMediumArticles();
  const next = articles.filter((a) => a.id !== articleId);
  getMediumStorageAdapter().saveArticles(next);
  return next;
}
