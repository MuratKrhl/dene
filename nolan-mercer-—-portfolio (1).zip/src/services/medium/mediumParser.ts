import { MediumParseResult, ParsedMediumFeedItem } from '../../types/medium';

export class MediumXmlParseError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'MediumXmlParseError';
  }
}

const TRACKING_QUERY_PARAMS = new Set([
  'source',
  'utm_source',
  'utm_medium',
  'utm_campaign',
  'utm_term',
  'utm_content',
  'sk',
]);

/**
 * Strips Medium RSS tracking parameters (`?source=rss------java-5`) and trailing slashes
 * so cross-tag occurrences of the same post normalize to a canonical URL.
 */
export function normalizeMediumUrl(rawUrl: string): string {
  if (!rawUrl || typeof rawUrl !== 'string') return '';
  const trimmed = rawUrl.trim();
  if (!trimmed) return '';
  try {
    const parsed = new URL(trimmed);
    for (const key of Array.from(parsed.searchParams.keys())) {
      if (TRACKING_QUERY_PARAMS.has(key.toLowerCase())) {
        parsed.searchParams.delete(key);
      }
    }
    parsed.hash = '';
    const serialized = parsed.toString();
    return serialized.endsWith('/') ? serialized.slice(0, -1) : serialized;
  } catch {
    return trimmed.split('?')[0].replace(/\/+$/, '');
  }
}

export function decodeHtmlEntities(input: string): string {
  if (!input) return '';
  return input
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;|&#x27;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&rsquo;/g, '’')
    .replace(/&lsquo;/g, '‘')
    .replace(/&rdquo;/g, '”')
    .replace(/&ldquo;/g, '“')
    .replace(/&mdash;/g, '—')
    .replace(/&ndash;/g, '–')
    .replace(/&hellip;/g, '…')
    .replace(/&raquo;/g, '»')
    .replace(/&#(\d+);/g, (_m, dec) => String.fromCharCode(Number(dec)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_m, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    );
}

function stripCdata(raw: string): string {
  return raw
    .replace(/^\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*$/, '$1')
    .trim();
}

function stripHtmlTags(html: string): string {
  return decodeHtmlEntities(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/(p|div|h1|h2|h3|h4|li|blockquote)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  )
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

function extractImageFromHtml(html: string): string | null {
  if (!html) return null;
  const imgRegex = /<img[^>]+src=["']([^"']+)["'][^>]*>/gi;
  let match: RegExpExecArray | null;
  while ((match = imgRegex.exec(html)) !== null) {
    const candidate = decodeHtmlEntities(match[1].trim());
    if (!candidate.startsWith('https://') && !candidate.startsWith('http://')) {
      continue;
    }
    // Filter out Medium 1x1 analytics pixel images
    if (
      candidate.includes('/_/stat?') ||
      candidate.includes('stat?event=') ||
      candidate.includes('width=1')
    ) {
      continue;
    }
    return candidate.replace(/^http:\/\//i, 'https://');
  }
  return null;
}

function extractMediumSnippetAndParagraphs(rawHtml: string): {
  summary: string;
  contentSnippet: string;
  paragraphs: string[];
} {
  if (!rawHtml) {
    return { summary: '', contentSnippet: '', paragraphs: [] };
  }

  // Medium RSS embeds <p class="medium-feed-snippet">...</p> inside <description>
  const snippetMatch = rawHtml.match(
    /<p[^>]*class=["'][^"']*medium-feed-snippet[^"']*["'][^>]*>([\s\S]*?)<\/p>/i
  );

  // Strip the Medium image and "Continue reading on Medium »" footer link
  const cleanedHtml = rawHtml
    .replace(/<p[^>]*class=["'][^"']*medium-feed-image[^"']*["'][^>]*>[\s\S]*?<\/p>/gi, '')
    .replace(/<p[^>]*class=["'][^"']*medium-feed-link[^"']*["'][^>]*>[\s\S]*?<\/p>/gi, '')
    .replace(/<a[^>]*>\s*Continue reading on Medium[\s\S]*?<\/a>/gi, '');

  const plainText = stripHtmlTags(cleanedHtml);
  const paragraphs = plainText
    .split(/\n+/)
    .map((p) => p.trim())
    .filter((p) => p.length > 0 && !/^continue reading on medium/i.test(p));

  const explicitSnippet = snippetMatch
    ? stripHtmlTags(snippetMatch[1])
    : paragraphs[0] || '';

  const contentSnippet = paragraphs.join('\n\n') || explicitSnippet;
  const summary =
    explicitSnippet.length > 260
      ? `${explicitSnippet.slice(0, 257).trimEnd()}…`
      : explicitSnippet;

  return {
    summary,
    contentSnippet,
    paragraphs,
  };
}

/**
 * Computes reading time ONLY when RSS payload actually contains full/substantial text
 * (>= 180 words). Returns null for brief RSS snippets to avoid fabricating read times.
 */
function calculateReliableReadingTime(text: string): string | null {
  const words = text
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;
  if (words < 180) {
    return null;
  }
  const minutes = Math.max(1, Math.round(words / 220));
  return `${minutes} min read`;
}

function parsePublishedIsoDate(rawDate: string): string {
  const trimmed = rawDate.trim();
  if (!trimmed) {
    return new Date().toISOString();
  }
  const timestamp = Date.parse(trimmed);
  if (Number.isNaN(timestamp)) {
    return new Date().toISOString();
  }
  return new Date(timestamp).toISOString();
}

function getChildTextByTags(parent: Element, tagNames: string[]): string {
  for (const tag of tagNames) {
    const shortTag = tag.split(':').pop()!.toLowerCase();
    const direct = Array.from(parent.children).find((el) => {
      const t = el.tagName?.toLowerCase() || '';
      const l = el.localName?.toLowerCase() || '';
      return t === tag.toLowerCase() || l === shortTag;
    });
    if (direct && direct.textContent) {
      return direct.textContent.trim();
    }
    const byTag = parent.getElementsByTagName(tag);
    if (byTag.length > 0 && byTag[0].textContent) {
      return byTag[0].textContent.trim();
    }
  }
  return '';
}

function getMediaImageFromNode(node: Element): string | null {
  const candidates = ['media:content', 'media:thumbnail', 'enclosure'];
  for (const tag of candidates) {
    const els = Array.from(node.getElementsByTagName(tag));
    for (const el of els) {
      const url = el.getAttribute('url');
      if (url && url.startsWith('http')) {
        return url.replace(/^http:\/\//i, 'https://');
      }
    }
  }
  return null;
}

function parseWithBrowserDom(xmlText: string): MediumParseResult {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlText, 'text/xml');
  const parseErrors = doc.getElementsByTagName('parsererror');
  if (parseErrors.length > 0) {
    // If the document still clearly looks like RSS/Atom XML, try the tolerant tag parser before failing
    if (xmlText.includes('<rss') || xmlText.includes('<feed')) {
      return parseWithNodeFallback(xmlText);
    }
    throw new MediumXmlParseError(
      `Invalid RSS XML structure: ${parseErrors[0].textContent?.slice(0, 120) || 'parse error'}`
    );
  }

  const channelNode =
    doc.getElementsByTagName('channel')[0] ||
    doc.getElementsByTagName('feed')[0];

  const channelTitle =
    (channelNode ? getChildTextByTags(channelNode, ['title']) : '') ||
    'Medium RSS Feed';

  const rssItems = Array.from(doc.getElementsByTagName('item'));
  const atomEntries =
    rssItems.length === 0 ? Array.from(doc.getElementsByTagName('entry')) : [];
  const rawNodes = rssItems.length > 0 ? rssItems : atomEntries;

  if (rawNodes.length === 0 && !channelNode) {
    throw new MediumXmlParseError(
      'RSS document does not contain a <channel> or <feed> element.'
    );
  }

  const items: ParsedMediumFeedItem[] = [];
  let skippedInvalidCount = 0;

  for (const node of rawNodes) {
    const title = decodeHtmlEntities(getChildTextByTags(node, ['title'])).trim();
    if (!title) {
      skippedInvalidCount++;
      continue;
    }

    let rawLink = getChildTextByTags(node, ['link']);
    if (!rawLink) {
      const linkEl = Array.from(node.getElementsByTagName('link')).find((el) =>
        Boolean(el.getAttribute('href'))
      );
      rawLink = linkEl?.getAttribute('href') || '';
    }
    const normalizedUrl = normalizeMediumUrl(rawLink);
    if (!normalizedUrl) {
      skippedInvalidCount++;
      continue;
    }

    const rawGuid = getChildTextByTags(node, ['guid', 'id']);
    const guid = rawGuid
      ? normalizeMediumUrl(rawGuid) || rawGuid
      : normalizedUrl;

    const author =
      decodeHtmlEntities(
        getChildTextByTags(node, ['dc:creator', 'creator', 'author', 'name'])
      ).trim() || 'Medium Author';

    const rawDate = getChildTextByTags(node, [
      'pubDate',
      'atom:updated',
      'updated',
      'published',
      'dc:date',
    ]);
    const publishedAt = parsePublishedIsoDate(rawDate);

    const contentEncoded = getChildTextByTags(node, [
      'content:encoded',
      'encoded',
      'content',
    ]);
    const descriptionRaw = getChildTextByTags(node, ['description', 'summary']);
    const richestHtml =
      contentEncoded.length > descriptionRaw.length
        ? contentEncoded
        : descriptionRaw;

    const image =
      getMediaImageFromNode(node) ||
      extractImageFromHtml(contentEncoded) ||
      extractImageFromHtml(descriptionRaw);

    const { summary, contentSnippet, paragraphs } =
      extractMediumSnippetAndParagraphs(richestHtml);

    const categoryEls = Array.from(node.getElementsByTagName('category'));
    const itemTags = Array.from(
      new Set(
        categoryEls
          .map((el) =>
            (el.textContent || el.getAttribute('term') || '')
              .trim()
              .toLowerCase()
          )
          .filter(Boolean)
      )
    );

    const readingTime = calculateReliableReadingTime(contentSnippet);

    items.push({
      title,
      author,
      publishedAt,
      summary,
      contentSnippet,
      image,
      articleUrl: normalizedUrl,
      guid,
      itemTags,
      readingTime,
      rssParagraphs: paragraphs,
    });
  }

  return {
    feedTitle: channelTitle,
    items,
    skippedInvalidCount,
  };
}

function extractXmlTag(block: string, tagName: string): string {
  const escaped = tagName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`, 'i');
  const match = block.match(regex);
  return match ? stripCdata(match[1]) : '';
}

function extractAllXmlTags(block: string, tagName: string): string[] {
  const escaped = tagName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${escaped}>`, 'gi');
  const values: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = regex.exec(block)) !== null) {
    const cleaned = stripCdata(m[1]).trim();
    if (cleaned) values.push(cleaned);
  }
  return values;
}

/**
 * Regex-based RSS XML parser fallback for non-DOM Node test/verification scripts.
 */
function parseWithNodeFallback(xmlText: string): MediumParseResult {
  if (!xmlText.includes('<rss') && !xmlText.includes('<feed')) {
    throw new MediumXmlParseError('Invalid RSS XML: missing <rss> or <feed> root.');
  }

  const feedTitle =
    decodeHtmlEntities(extractXmlTag(xmlText, 'title')) || 'Medium RSS Feed';
  const itemBlocks = xmlText.match(/<item\b[\s\S]*?<\/item>/gi) || [];

  const items: ParsedMediumFeedItem[] = [];
  let skippedInvalidCount = 0;

  for (const block of itemBlocks) {
    const title = decodeHtmlEntities(extractXmlTag(block, 'title')).trim();
    if (!title) {
      skippedInvalidCount++;
      continue;
    }

    const rawLink = extractXmlTag(block, 'link');
    const normalizedUrl = normalizeMediumUrl(rawLink);
    if (!normalizedUrl) {
      skippedInvalidCount++;
      continue;
    }

    const rawGuid = extractXmlTag(block, 'guid');
    const guid = rawGuid ? normalizeMediumUrl(rawGuid) || rawGuid : normalizedUrl;
    const author =
      decodeHtmlEntities(
        extractXmlTag(block, 'dc:creator') || extractXmlTag(block, 'author')
      ).trim() || 'Medium Author';

    const rawDate =
      extractXmlTag(block, 'pubDate') || extractXmlTag(block, 'atom:updated');
    const publishedAt = parsePublishedIsoDate(rawDate);

    const contentEncoded = extractXmlTag(block, 'content:encoded');
    const descriptionRaw = extractXmlTag(block, 'description');
    const richestHtml =
      contentEncoded.length > descriptionRaw.length ? contentEncoded : descriptionRaw;

    const image =
      extractImageFromHtml(contentEncoded) || extractImageFromHtml(descriptionRaw);
    const { summary, contentSnippet, paragraphs } =
      extractMediumSnippetAndParagraphs(richestHtml);

    const itemTags = Array.from(
      new Set(
        extractAllXmlTags(block, 'category').map((t) => t.toLowerCase())
      )
    );

    const readingTime = calculateReliableReadingTime(contentSnippet);

    items.push({
      title,
      author,
      publishedAt,
      summary,
      contentSnippet,
      image,
      articleUrl: normalizedUrl,
      guid,
      itemTags,
      readingTime,
      rssParagraphs: paragraphs,
    });
  }

  return {
    feedTitle,
    items,
    skippedInvalidCount,
  };
}

export function parseMediumRssXml(xmlText: string): MediumParseResult {
  if (!xmlText || !xmlText.trim()) {
    throw new MediumXmlParseError('RSS XML payload is empty.');
  }

  if (typeof DOMParser !== 'undefined') {
    return parseWithBrowserDom(xmlText);
  }
  return parseWithNodeFallback(xmlText);
}
