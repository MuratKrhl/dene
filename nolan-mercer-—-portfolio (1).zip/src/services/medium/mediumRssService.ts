export interface MediumRssFetchResult {
  ok: boolean;
  xml: string;
  httpStatus: number;
  errorMessage: string | null;
  endpointUsed: string;
  durationMs: number;
}

export interface MediumRssProxyAdapter {
  readonly name: string;
  fetchFeedXml(rssUrl: string, timeoutMs?: number): Promise<MediumRssFetchResult>;
}

const DEFAULT_TIMEOUT_MS = 20_000;
const inFlightFetchByUrl = new Map<string, Promise<MediumRssFetchResult>>();

function getConfiguredProxyEndpoint(): string {
  try {
    const envVal = (import.meta as unknown as { env?: Record<string, string | undefined> })
      ?.env?.VITE_MEDIUM_RSS_PROXY_URL;
    if (envVal && envVal.trim()) {
      return envVal.trim();
    }
  } catch {
    // Non-Vite runtime fallback
  }
  return '/api/medium/rss';
}

function buildProxyRequestUrl(endpoint: string, rssUrl: string): string {
  const separator = endpoint.includes('?') ? '&' : '?';
  return `${endpoint}${separator}url=${encodeURIComponent(rssUrl)}`;
}

function isValidRssXmlText(body: string): boolean {
  const trimmed = body.trim();
  if (!trimmed) return false;
  return (
    trimmed.includes('<rss') ||
    trimmed.includes('<feed') ||
    (trimmed.startsWith('<?xml') && trimmed.includes('<channel'))
  );
}

/**
 * Default RSS adapter communicating strictly with the app's own backend/serverless endpoint
 * (/api/medium/rss via Express + Vite middleware in dev, or Node/serverless proxy in production).
 * Never uses public third-party CORS proxy services.
 */
export class AppServerRssProxyAdapter implements MediumRssProxyAdapter {
  readonly name = 'Workspace Server RSS Proxy';

  private async fetchOnce(
    rssUrl: string,
    timeoutMs: number
  ): Promise<MediumRssFetchResult> {
    const startedAt = Date.now();
    const proxyEndpoint = getConfiguredProxyEndpoint();
    const requestUrl = buildProxyRequestUrl(proxyEndpoint, rssUrl);

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(requestUrl, {
        method: 'GET',
        headers: {
          Accept: 'application/rss+xml, application/xml, text/xml, application/json',
        },
        signal: controller.signal,
      });

      const contentType = (response.headers.get('content-type') || '').toLowerCase();
      const rawText = await response.text();
      const durationMs = Date.now() - startedAt;

      if (!response.ok) {
        let serverError = `HTTP ${response.status} error while fetching feed.`;
        if (contentType.includes('application/json')) {
          try {
            const parsedJson = JSON.parse(rawText) as { error?: string };
            if (parsedJson.error) {
              serverError = parsedJson.error;
            }
          } catch {
            // Keep default HTTP message
          }
        } else if (response.status === 404) {
          serverError =
            'RSS proxy endpoint (/api/medium/rss) returned 404. Ensure the backend server or VITE_MEDIUM_RSS_PROXY_URL is active.';
        }

        console.error('[mediumRssService] HTTP error:', {
          rssUrl,
          requestUrl,
          status: response.status,
          serverError,
        });

        return {
          ok: false,
          xml: '',
          httpStatus: response.status,
          errorMessage: serverError,
          endpointUsed: proxyEndpoint,
          durationMs,
        };
      }

      // Detect SPA HTML fallback when running on pure static hosting without an API proxy
      const trimmedLower = rawText.trim().slice(0, 120).toLowerCase();
      if (
        trimmedLower.startsWith('<!doctype html') ||
        trimmedLower.startsWith('<html')
      ) {
        const msg =
          'RSS proxy route is not active in this static hosting environment. Start with `server.ts` or set VITE_MEDIUM_RSS_PROXY_URL for production serverless sync.';
        console.error('[mediumRssService] Received HTML instead of XML:', {
          rssUrl,
          proxyEndpoint,
        });
        return {
          ok: false,
          xml: '',
          httpStatus: response.status,
          errorMessage: msg,
          endpointUsed: proxyEndpoint,
          durationMs,
        };
      }

      if (!rawText.trim()) {
        return {
          ok: false,
          xml: '',
          httpStatus: response.status,
          errorMessage: 'Empty RSS response received from feed.',
          endpointUsed: proxyEndpoint,
          durationMs,
        };
      }

      if (!isValidRssXmlText(rawText)) {
        return {
          ok: false,
          xml: '',
          httpStatus: response.status,
          errorMessage: 'Invalid XML payload: missing <rss> or <feed> root.',
          endpointUsed: proxyEndpoint,
          durationMs,
        };
      }

      return {
        ok: true,
        xml: rawText,
        httpStatus: response.status,
        errorMessage: null,
        endpointUsed: proxyEndpoint,
        durationMs,
      };
    } catch (err) {
      const durationMs = Date.now() - startedAt;
      const isTimeout =
        err instanceof Error &&
        (err.name === 'AbortError' || err.message.toLowerCase().includes('abort'));

      const errorMessage = isTimeout
        ? `RSS request timed out after ${Math.round(timeoutMs / 1000)}s.`
        : err instanceof TypeError
          ? 'Network or CORS error reaching the RSS proxy endpoint.'
          : err instanceof Error
            ? err.message
            : 'Unexpected error fetching Medium RSS feed.';

      console.error('[mediumRssService] Request exception:', {
        rssUrl,
        proxyEndpoint,
        error: err,
      });

      return {
        ok: false,
        xml: '',
        httpStatus: isTimeout ? 504 : 0,
        errorMessage,
        endpointUsed: proxyEndpoint,
        durationMs,
      };
    } finally {
      clearTimeout(timer);
    }
  }

  async fetchFeedXml(
    rssUrl: string,
    timeoutMs: number = DEFAULT_TIMEOUT_MS
  ): Promise<MediumRssFetchResult> {
    const firstAttempt = await this.fetchOnce(rssUrl, timeoutMs);
    // Retry once on transient client network failure (status 0)
    if (!firstAttempt.ok && firstAttempt.httpStatus === 0) {
      await new Promise((r) => setTimeout(r, 500));
      return this.fetchOnce(rssUrl, timeoutMs);
    }
    return firstAttempt;
  }
}

let activeRssAdapter: MediumRssProxyAdapter = new AppServerRssProxyAdapter();

export function setMediumRssAdapter(adapter: MediumRssProxyAdapter): void {
  activeRssAdapter = adapter;
}

export function getMediumRssAdapter(): MediumRssProxyAdapter {
  return activeRssAdapter;
}

export function fetchMediumRssXml(
  rssUrl: string,
  timeoutMs: number = DEFAULT_TIMEOUT_MS
): Promise<MediumRssFetchResult> {
  // Never send multiple concurrent requests to the exact same feed URL
  const existing = inFlightFetchByUrl.get(rssUrl);
  if (existing) {
    return existing;
  }

  const promise = activeRssAdapter
    .fetchFeedXml(rssUrl, timeoutMs)
    .finally(() => {
      inFlightFetchByUrl.delete(rssUrl);
    });

  inFlightFetchByUrl.set(rssUrl, promise);
  return promise;
}
