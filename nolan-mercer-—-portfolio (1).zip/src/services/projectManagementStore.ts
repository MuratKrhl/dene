import {
  INITIAL_PM_SCHEDULE,
  INITIAL_PM_TASKS,
  PmScheduleItem,
  PmTaskRow,
} from '../data/projectManagementData';

export const PM_TASKS_STORAGE_KEY = 'mk-pm-tasks-v1';
export const PM_SCHEDULE_STORAGE_KEY = 'mk-pm-schedule-v1';

export function loadPmTasks(): PmTaskRow[] {
  try {
    const raw = localStorage.getItem(PM_TASKS_STORAGE_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // Fallback to initial
  }
  return INITIAL_PM_TASKS;
}

export function savePmTasks(tasks: PmTaskRow[]): void {
  try {
    localStorage.setItem(PM_TASKS_STORAGE_KEY, JSON.stringify(tasks));
  } catch {
    // Ignore storage error
  }
}

export function loadPmSchedule(): PmScheduleItem[] {
  try {
    const raw = localStorage.getItem(PM_SCHEDULE_STORAGE_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // Fallback to initial
  }
  return INITIAL_PM_SCHEDULE;
}

export function savePmSchedule(items: PmScheduleItem[]): void {
  try {
    localStorage.setItem(PM_SCHEDULE_STORAGE_KEY, JSON.stringify(items));
  } catch {
    // Ignore storage error
  }
}
