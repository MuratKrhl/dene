import {
  SimilarArticleDto,
  TechHubArticleDto,
  TechHubCategoryDto,
  TechHubDiscoveryResult,
  TechHubFeedTestResult,
  TechHubScanHistoryDto,
  TechHubSourceDto,
  TechHubStatusDto,
} from '../types/techKnowledgeHub';

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers || {}),
    },
  });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || `Request failed with HTTP ${res.status}`);
  }
  return data;
}

export const techKnowledgeHubApi = {
  getCategories(): Promise<{ categories: TechHubCategoryDto[] }> {
    return apiJson('/api/tech-hub/categories');
  },

  getStatus(): Promise<TechHubStatusDto> {
    return apiJson('/api/tech-hub/status');
  },

  updateConfig(payload: {
    scheduler?: Partial<TechHubStatusDto['scheduler']>;
    aiConfig?: Partial<TechHubStatusDto['aiConfig']>;
  }): Promise<{
    scheduler: TechHubStatusDto['scheduler'];
    aiConfig: TechHubStatusDto['aiConfig'];
    geminiConfigured: boolean;
  }> {
    return apiJson('/api/tech-hub/config', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getSources(): Promise<{ sources: TechHubSourceDto[] }> {
    return apiJson('/api/tech-hub/sources');
  },

  createSource(payload: {
    name: string;
    siteUrl: string;
    feedUrl: string;
    categoryIds: string[];
    enabled?: boolean;
    keywordFilter?: string[] | null;
  }): Promise<{ source: TechHubSourceDto }> {
    return apiJson('/api/tech-hub/sources', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateSource(
    id: string,
    payload: {
      name?: string;
      siteUrl?: string;
      feedUrl?: string;
      enabled?: boolean;
      categoryIds?: string[];
      keywordFilter?: string[] | null;
    }
  ): Promise<{ source: TechHubSourceDto }> {
    return apiJson(`/api/tech-hub/sources/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  deleteSource(id: string): Promise<{ ok: boolean }> {
    return apiJson(`/api/tech-hub/sources/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
  },

  testFeedUrl(feedUrl: string): Promise<TechHubFeedTestResult> {
    return apiJson('/api/tech-hub/sources/test-url', {
      method: 'POST',
      body: JSON.stringify({ feedUrl }),
    });
  },

  discoverFeeds(siteUrl: string): Promise<TechHubDiscoveryResult> {
    return apiJson('/api/tech-hub/sources/discover', {
      method: 'POST',
      body: JSON.stringify({ siteUrl }),
    });
  },

  testSource(id: string): Promise<TechHubFeedTestResult & { discovery?: TechHubDiscoveryResult }> {
    return apiJson(`/api/tech-hub/sources/${encodeURIComponent(id)}/test`, {
      method: 'POST',
    });
  },

  scanSource(id: string): Promise<{
    ok: boolean;
    newAdded: number;
    duplicatesSkipped: number;
    error: string | null;
  }> {
    return apiJson(`/api/tech-hub/sources/${encodeURIComponent(id)}/scan`, {
      method: 'POST',
    });
  },

  scanAll(): Promise<{
    alreadyRunning: boolean;
    scannedSources: number;
    succeeded: number;
    failed: number;
    newAdded: number;
    duplicatesSkipped: number;
  }> {
    return apiJson('/api/tech-hub/scan', { method: 'POST' });
  },

  getScanHistory(sourceId?: string): Promise<{ history: TechHubScanHistoryDto[] }> {
    const qs = sourceId ? `?sourceId=${encodeURIComponent(sourceId)}` : '';
    return apiJson(`/api/tech-hub/scan-history${qs}`);
  },

  getArticles(params: {
    categoryId?: string;
    sourceId?: string;
    archived?: boolean;
    unreadOnly?: boolean;
    favoritesOnly?: boolean;
    aiOnly?: boolean;
    from?: string;
    to?: string;
    q?: string;
    sort?: 'newest' | 'oldest' | 'important';
    page?: number;
    pageSize?: number;
  }): Promise<{
    items: TechHubArticleDto[];
    pagination: { total: number; page: number; pageSize: number; totalPages: number };
  }> {
    const sp = new URLSearchParams();
    if (params.categoryId) sp.set('categoryId', params.categoryId);
    if (params.sourceId) sp.set('sourceId', params.sourceId);
    if (typeof params.archived === 'boolean') sp.set('archived', String(params.archived));
    if (params.unreadOnly) sp.set('unreadOnly', 'true');
    if (params.favoritesOnly) sp.set('favoritesOnly', 'true');
    if (params.aiOnly) sp.set('aiOnly', 'true');
    if (params.from) sp.set('from', params.from);
    if (params.to) sp.set('to', params.to);
    if (params.q) sp.set('q', params.q);
    if (params.sort) sp.set('sort', params.sort);
    if (params.page) sp.set('page', String(params.page));
    if (params.pageSize) sp.set('pageSize', String(params.pageSize));
    const query = sp.toString();
    return apiJson(`/api/tech-hub/articles${query ? `?${query}` : ''}`);
  },

  getArticleDetail(id: string): Promise<{
    article: TechHubArticleDto;
    similarArticles: SimilarArticleDto[];
  }> {
    return apiJson(`/api/tech-hub/articles/${encodeURIComponent(id)}`);
  },

  updateArticleState(
    id: string,
    payload: {
      isRead?: boolean;
      isFavorite?: boolean;
      isArchived?: boolean;
      note?: string;
    }
  ): Promise<{
    ok: boolean;
    id: string;
    isRead: boolean;
    isFavorite: boolean;
    isArchived: boolean;
    archivedAt: string | null;
  }> {
    return apiJson(`/api/tech-hub/articles/${encodeURIComponent(id)}/state`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  summarizeArticle(id: string): Promise<{ ok: boolean; article: TechHubArticleDto }> {
    return apiJson(`/api/tech-hub/articles/${encodeURIComponent(id)}/summarize`, {
      method: 'POST',
    });
  },
};
