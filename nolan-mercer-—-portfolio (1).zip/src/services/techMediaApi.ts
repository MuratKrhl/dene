import {
  PodcastEpisode,
  PodcastSeries,
  TechEvent,
  TechEventAttendanceMode,
  TechEventType,
  TechVideo,
} from '../types/technology';

export type MediaContentType = 'podcast' | 'event' | 'youtube';
export type MediaSourceType =
  | 'rss'
  | 'atom'
  | 'ical'
  | 'youtube-api'
  | 'official-api'
  | 'manual'
  | 'unsupported';
export type MediaVerificationStatus = 'verified' | 'unverified' | 'error';

export interface MediaSourceDto {
  id: string;
  name: string;
  description: string;
  contentType: MediaContentType;
  sourceType: MediaSourceType;
  websiteUrl: string;
  feedOrEndpoint: string;
  youtubeTargetKind?: 'channel' | 'playlist' | 'video';
  youtubeTargetId?: string;
  category: string;
  categories: string[];
  enabled: boolean;
  verificationStatus: MediaVerificationStatus;
  verificationNote: string | null;
  lastSuccessfulSyncAt: string | null;
  lastAttemptedSyncAt: string | null;
  nextSyncAt: string | null;
  syncIntervalHours: number;
  lastError: string | null;
  lastHttpStatus: number | null;
  consecutiveFailures: number;
  collectedCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface MediaTypeScheduleDto {
  autoSyncEnabled: boolean;
  intervalHours: number;
  lastSyncAt: string | null;
  lastSuccessfulSyncAt: string | null;
}

export interface MediaSchedulerConfigDto {
  podcast: MediaTypeScheduleDto;
  event: MediaTypeScheduleDto;
  youtube: MediaTypeScheduleDto;
}

export interface YouTubeQuotaDto {
  lastResetDate: string;
  requestsToday: number;
  quotaUnitsEstimateToday: number;
  quotaExceededUntil: string | null;
  lastError: string | null;
}

export interface MediaSyncHistoryDto {
  syncId: string;
  startedAt: string;
  finishedAt: string;
  contentType: MediaContentType | 'all';
  sourceId: string;
  sourceName: string;
  trigger: 'startup' | 'scheduled' | 'manual' | 'retry' | 'test';
  status: 'success' | 'partial' | 'error' | 'unsupported';
  httpStatus: number | null;
  newItems: number;
  duplicatesSkipped: number;
  updatedItems: number;
  errors: number;
  errorMessage: string | null;
  durationMs: number;
}

export interface MediaStatusDto {
  activeTypeLocks: MediaContentType[];
  activeSourceLocks: string[];
  youtubeApiConfigured: boolean;
  youtubeQuota: YouTubeQuotaDto;
  scheduler: MediaSchedulerConfigDto;
  counts: {
    sourcesTotal: number;
    sourcesVerifiedEnabled: number;
    sourcesFailed: number;
    sourcesUnverified: number;
    podcastSeries: number;
    podcastEpisodes: number;
    eventsActive: number;
    eventsPast: number;
    eventsUnverified: number;
    videos: number;
  };
}

export interface TestMediaSourceResponse {
  ok: boolean;
  detectedSourceType: MediaSourceType;
  feedOrEndpoint: string;
  websiteUrl?: string;
  resolvedName?: string;
  resolvedAuthor?: string;
  artworkUrl?: string;
  youtubeTargetKind?: 'channel' | 'playlist' | 'video';
  youtubeTargetId?: string;
  httpStatus: number | null;
  itemCount: number;
  sampleTitles: string[];
  warning?: string | null;
  error: string | null;
  durationMs: number;
  duplicateSource?: {
    id: string;
    name: string;
    feedOrEndpoint: string;
  } | null;
  source?: MediaSourceDto;
}

interface RawBackendSeries {
  id: string;
  sourceId: string;
  title: string;
  publisher: string | null;
  author: string | null;
  description: string;
  artworkUrl: string | null;
  websiteUrl: string;
  feedUrl: string;
  language: string | null;
  category: string;
  categories: string[];
  lastSyncedAt: string | null;
  isFollowed: boolean;
  isFavorite: boolean;
  episodeCount: number;
}

interface RawBackendEpisode {
  id: string;
  guid: string;
  canonicalUrl: string;
  seriesId: string;
  seriesTitle: string;
  publisher: string | null;
  title: string;
  description: string;
  publishedAt: string | null;
  updatedAt: string | null;
  artworkUrl: string | null;
  duration: string | null;
  durationSeconds: number | null;
  audioUrl: string | null;
  originalUrl: string;
  category: string;
  categories: string[];
  sourceId: string;
  matchedSourceIds: string[];
  isPlayed: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  playbackPosition: number;
  fetchedAt: string;
}

interface RawBackendEvent {
  id: string;
  guid: string;
  canonicalUrl: string;
  eventName: string;
  organizer: string;
  startDate: string | null;
  startTime: string | null;
  endDate: string | null;
  timezone: string | null;
  attendanceMode: TechEventAttendanceMode;
  location: string | null;
  description: string;
  registrationUrl: string | null;
  originalUrl: string;
  sourceId: string;
  matchedSourceIds: string[];
  category: string;
  categories: string[];
  eventType: TechEventType;
  status: 'upcoming' | 'ongoing' | 'past' | 'unverified';
  verificationStatus: 'verified' | 'unverified';
  verificationNote: string | null;
  publishedAt: string | null;
  updatedAt: string | null;
  fetchedAt: string;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  isManual?: boolean;
}

interface RawBackendVideo {
  id: string;
  videoId: string;
  guid: string;
  canonicalUrl: string;
  title: string;
  description: string;
  channelName: string;
  channelId: string;
  playlistId: string | null;
  playlistName: string | null;
  publishedAt: string | null;
  updatedAt: string | null;
  thumbnailUrl: string | null;
  embedUrl: string;
  originalUrl: string;
  duration: string | null;
  durationSeconds: number | null;
  category: string;
  categories: string[];
  sourceId: string;
  matchedSourceIds: string[];
  fetchedAt: string;
  isWatched: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  archivedAt: string | null;
  isManual?: boolean;
}

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers || {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(
      (data as { error?: string }).error || `Request failed (${res.status})`
    );
  }
  return data as T;
}

export function mapSeriesToFrontend(raw: RawBackendSeries): PodcastSeries {
  return {
    id: raw.id,
    title: raw.title,
    description: raw.description,
    author: raw.author,
    publisher: raw.publisher,
    artworkUrl: raw.artworkUrl,
    websiteUrl: raw.websiteUrl,
    feedUrl: raw.feedUrl,
    language: raw.language,
    category: raw.category,
    tags: raw.categories || [raw.category],
    sourceId: raw.sourceId,
    lastFetchedAt: raw.lastSyncedAt,
    status: 'success',
    isFollowed: raw.isFollowed,
    isFavorite: raw.isFavorite,
    episodeCount: raw.episodeCount,
  };
}

export function mapEpisodeToFrontend(raw: RawBackendEpisode): PodcastEpisode {
  return {
    id: raw.id,
    guid: raw.guid,
    seriesId: raw.seriesId,
    seriesTitle: raw.seriesTitle,
    publisher: raw.publisher,
    title: raw.title,
    description: raw.description,
    publishedAt: raw.publishedAt,
    updatedAt: raw.updatedAt,
    dateStatus: raw.publishedAt ? 'valid' : 'unknown',
    duration: raw.duration,
    durationSeconds: raw.durationSeconds,
    audioUrl: raw.audioUrl,
    artworkUrl: raw.artworkUrl,
    episodeUrl: raw.originalUrl,
    contentType: 'podcast-episode',
    category: raw.category,
    tags: raw.categories || [raw.category],
    sourceId: raw.sourceId,
    matchedSourceIds: raw.matchedSourceIds,
    isPlayed: raw.isPlayed,
    isFavorite: raw.isFavorite,
    isArchived: raw.isArchived,
    archivedAt: raw.archivedAt,
    playbackPosition: raw.playbackPosition,
    fetchedAt: raw.fetchedAt,
  };
}

export function mapEventToFrontend(raw: RawBackendEvent): TechEvent {
  return {
    id: raw.id,
    guid: raw.guid,
    eventName: raw.eventName,
    organizer: raw.organizer,
    startDate: raw.startDate,
    startTime: raw.startTime,
    endDate: raw.endDate,
    timezone: raw.timezone,
    attendanceMode: raw.attendanceMode,
    publishedAt: raw.publishedAt,
    dateStatus: raw.startDate ? 'valid' : 'unknown',
    location: raw.location,
    eventType: raw.eventType,
    description: raw.description,
    registrationUrl: raw.registrationUrl || raw.originalUrl,
    sourceUrl: raw.originalUrl,
    sourceId: raw.sourceId,
    matchedSourceIds: raw.matchedSourceIds,
    tags: raw.categories || [raw.category],
    status: raw.status,
    verificationStatus: raw.verificationStatus,
    verificationNote: raw.verificationNote,
    isFavorite: raw.isFavorite,
    isArchived: raw.isArchived,
    archivedAt: raw.archivedAt,
    fetchedAt: raw.fetchedAt,
    isManual: raw.isManual,
  };
}

export function mapVideoToFrontend(raw: RawBackendVideo): TechVideo {
  return {
    id: raw.id,
    videoId: raw.videoId,
    guid: raw.guid,
    title: raw.title,
    description: raw.description,
    channelName: raw.channelName,
    channelId: raw.channelId,
    publishedAt: raw.publishedAt,
    updatedAt: raw.updatedAt,
    dateStatus: raw.publishedAt ? 'valid' : 'unknown',
    thumbnailUrl: raw.thumbnailUrl,
    videoUrl: raw.originalUrl,
    embedUrl: raw.embedUrl,
    duration: raw.duration,
    durationSeconds: raw.durationSeconds,
    category: raw.category,
    tags: raw.categories || [raw.category],
    sourceId: raw.sourceId,
    matchedSourceIds: raw.matchedSourceIds,
    playlistId: raw.playlistId,
    playlistName: raw.playlistName,
    fetchedAt: raw.fetchedAt,
    isWatched: raw.isWatched,
    isFavorite: raw.isFavorite,
    isArchived: raw.isArchived,
    archivedAt: raw.archivedAt,
    isManual: raw.isManual,
  };
}

export async function fetchMediaStatus(): Promise<MediaStatusDto> {
  return apiJson<MediaStatusDto>('/api/tech-media/status');
}

export async function patchMediaScheduler(
  patch: Partial<
    Record<
      MediaContentType,
      { autoSyncEnabled?: boolean; intervalHours?: number }
    >
  >
): Promise<{ scheduler: MediaSchedulerConfigDto }> {
  return apiJson('/api/tech-media/scheduler', {
    method: 'PATCH',
    body: JSON.stringify(patch),
  });
}

export async function fetchMediaSources(
  contentType?: MediaContentType
): Promise<MediaSourceDto[]> {
  const q = contentType ? `?contentType=${encodeURIComponent(contentType)}` : '';
  const res = await apiJson<{ sources: MediaSourceDto[] }>(
    `/api/tech-media/sources${q}`
  );
  return res.sources;
}

export async function testMediaSourceInput(payload: {
  contentType: MediaContentType;
  sourceType?: MediaSourceType;
  feedOrEndpoint: string;
  websiteUrl?: string;
  name?: string;
  category?: string;
  excludeId?: string;
}): Promise<TestMediaSourceResponse> {
  return apiJson('/api/tech-media/sources/test', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function testExistingMediaSource(
  sourceId: string
): Promise<TestMediaSourceResponse> {
  return apiJson(`/api/tech-media/sources/${encodeURIComponent(sourceId)}/test`, {
    method: 'POST',
  });
}

export async function createMediaSource(payload: {
  name: string;
  description?: string;
  contentType: MediaContentType;
  sourceType?: MediaSourceType;
  websiteUrl?: string;
  feedOrEndpoint: string;
  category: string;
  categories?: string[];
  syncIntervalHours: number;
  enabled: boolean;
}): Promise<{ source: MediaSourceDto }> {
  return apiJson('/api/tech-media/sources', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function updateMediaSource(
  sourceId: string,
  patch: Partial<{
    name: string;
    description: string;
    websiteUrl: string;
    feedOrEndpoint: string;
    category: string;
    categories: string[];
    syncIntervalHours: number;
    enabled: boolean;
  }>
): Promise<{ source: MediaSourceDto }> {
  return apiJson(`/api/tech-media/sources/${encodeURIComponent(sourceId)}`, {
    method: 'PATCH',
    body: JSON.stringify(patch),
  });
}

export async function deleteMediaSource(sourceId: string): Promise<void> {
  await apiJson(`/api/tech-media/sources/${encodeURIComponent(sourceId)}`, {
    method: 'DELETE',
  });
}

export async function syncSingleMediaSourceApi(
  sourceId: string
): Promise<{ result: MediaSyncHistoryDto }> {
  return apiJson(`/api/tech-media/sources/${encodeURIComponent(sourceId)}/sync`, {
    method: 'POST',
  });
}

export async function syncMediaByTypeApi(
  contentType: MediaContentType | 'all' = 'all'
): Promise<{ skippedDueToLock?: boolean; results: MediaSyncHistoryDto[] }> {
  return apiJson('/api/tech-media/sync', {
    method: 'POST',
    body: JSON.stringify({ contentType }),
  });
}

export async function retryFailedMediaSourcesApi(
  contentType?: MediaContentType
): Promise<{ results: MediaSyncHistoryDto[] }> {
  return apiJson('/api/tech-media/retry-failed', {
    method: 'POST',
    body: JSON.stringify({ contentType }),
  });
}

export async function fetchMediaSyncHistory(
  contentType?: MediaContentType
): Promise<MediaSyncHistoryDto[]> {
  const q = contentType ? `?contentType=${encodeURIComponent(contentType)}` : '';
  const res = await apiJson<{ history: MediaSyncHistoryDto[] }>(
    `/api/tech-media/sync-history${q}`
  );
  return res.history;
}

export async function clearMediaSyncHistory(): Promise<void> {
  await apiJson('/api/tech-media/sync-history', { method: 'DELETE' });
}

export async function fetchMediaPodcasts(): Promise<{
  series: PodcastSeries[];
  episodes: PodcastEpisode[];
}> {
  const res = await apiJson<{
    series: RawBackendSeries[];
    episodes: RawBackendEpisode[];
  }>('/api/tech-media/podcasts');
  return {
    series: res.series.map(mapSeriesToFrontend),
    episodes: res.episodes.map(mapEpisodeToFrontend),
  };
}

export async function patchMediaPodcastSeries(
  seriesId: string,
  patch: { isFollowed?: boolean; isFavorite?: boolean }
): Promise<void> {
  await apiJson(
    `/api/tech-media/podcasts/series/${encodeURIComponent(seriesId)}`,
    {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }
  );
}

export async function patchMediaPodcastEpisode(
  episodeId: string,
  patch: {
    isPlayed?: boolean;
    isFavorite?: boolean;
    isArchived?: boolean;
    playbackPosition?: number;
  }
): Promise<void> {
  await apiJson(
    `/api/tech-media/podcasts/episodes/${encodeURIComponent(episodeId)}`,
    {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }
  );
}

export async function deleteMediaPodcastEpisode(episodeId: string): Promise<void> {
  await apiJson(
    `/api/tech-media/podcasts/episodes/${encodeURIComponent(episodeId)}`,
    {
      method: 'DELETE',
    }
  );
}

export async function fetchMediaEvents(): Promise<TechEvent[]> {
  const res = await apiJson<{ events: RawBackendEvent[] }>(
    '/api/tech-media/events'
  );
  return res.events.map(mapEventToFrontend);
}

export async function createManualMediaEvent(payload: {
  eventName: string;
  organizer: string;
  startDate?: string;
  startTime?: string;
  endDate?: string;
  timezone?: string;
  attendanceMode?: TechEventAttendanceMode;
  location?: string;
  eventType: TechEventType;
  registrationUrl: string;
  description?: string;
  category?: string;
}): Promise<TechEvent> {
  const res = await apiJson<{ event: RawBackendEvent }>(
    '/api/tech-media/events',
    {
      method: 'POST',
      body: JSON.stringify(payload),
    }
  );
  return mapEventToFrontend(res.event);
}

export async function patchMediaEvent(
  eventId: string,
  patch: { isFavorite?: boolean; isArchived?: boolean }
): Promise<void> {
  await apiJson(`/api/tech-media/events/${encodeURIComponent(eventId)}`, {
    method: 'PATCH',
    body: JSON.stringify(patch),
  });
}

export async function deleteMediaEvent(eventId: string): Promise<void> {
  await apiJson(`/api/tech-media/events/${encodeURIComponent(eventId)}`, {
    method: 'DELETE',
  });
}

export async function fetchMediaVideos(): Promise<{
  videos: TechVideo[];
  youtubeApiConfigured: boolean;
  youtubeQuota: YouTubeQuotaDto;
}> {
  const res = await apiJson<{
    videos: RawBackendVideo[];
    youtubeApiConfigured: boolean;
    youtubeQuota: YouTubeQuotaDto;
  }>('/api/tech-media/videos');
  return {
    videos: res.videos.map(mapVideoToFrontend),
    youtubeApiConfigured: res.youtubeApiConfigured,
    youtubeQuota: res.youtubeQuota,
  };
}

export async function createManualMediaVideo(payload: {
  title: string;
  channelName: string;
  videoUrl: string;
  category?: string;
  duration?: string;
  description?: string;
}): Promise<TechVideo> {
  const res = await apiJson<{ video: RawBackendVideo }>(
    '/api/tech-media/videos',
    {
      method: 'POST',
      body: JSON.stringify(payload),
    }
  );
  return mapVideoToFrontend(res.video);
}

export async function patchMediaVideo(
  videoId: string,
  patch: { isWatched?: boolean; isFavorite?: boolean; isArchived?: boolean }
): Promise<void> {
  await apiJson(`/api/tech-media/videos/${encodeURIComponent(videoId)}`, {
    method: 'PATCH',
    body: JSON.stringify(patch),
  });
}

export async function deleteMediaVideo(videoId: string): Promise<void> {
  await apiJson(`/api/tech-media/videos/${encodeURIComponent(videoId)}`, {
    method: 'DELETE',
  });
}
