import { DateStatus } from '../../types/technology';

export const DEFAULT_ACTIVE_WINDOW_DAYS = 30;
const DAY_MS = 24 * 60 * 60 * 1000;

export function parseStrictPublishedDate(raw: string | null | undefined): {
  publishedAt: string | null;
  dateStatus: DateStatus;
} {
  if (!raw || typeof raw !== 'string') {
    return { publishedAt: null, dateStatus: 'unknown' };
  }
  const trimmed = raw.trim();
  if (!trimmed) {
    return { publishedAt: null, dateStatus: 'unknown' };
  }
  const ms = Date.parse(trimmed);
  if (Number.isNaN(ms) || ms <= 0) {
    return { publishedAt: null, dateStatus: 'unknown' };
  }
  return { publishedAt: new Date(ms).toISOString(), dateStatus: 'valid' };
}

export function isOlderThanActiveWindow(
  publishedAt: string | null,
  activeWindowDays: number = DEFAULT_ACTIVE_WINDOW_DAYS,
  nowMs: number = Date.now()
): boolean {
  if (!publishedAt) return false;
  const ms = Date.parse(publishedAt);
  if (Number.isNaN(ms) || ms <= 0) return false;
  return nowMs - ms > activeWindowDays * DAY_MS;
}

export interface ArchivableDatedItem {
  publishedAt: string | null;
  dateStatus: DateStatus;
  isArchived: boolean;
  archivedAt: string | null;
}

/**
 * Applies the 30-day retention rule across any dated item WITHOUT deleting data.
 * Missing or invalid dates (`dateStatus === 'unknown'`) are NEVER archived or deleted.
 */
export function reconcileItemRetention<T extends ArchivableDatedItem>(
  items: T[],
  activeWindowDays: number = DEFAULT_ACTIVE_WINDOW_DAYS,
  nowMs: number = Date.now()
): { items: T[]; changed: boolean } {
  let changed = false;
  const nowIso = new Date(nowMs).toISOString();

  const next = items.map((item) => {
    if (item.dateStatus !== 'valid' || !item.publishedAt) {
      return item;
    }
    const ms = Date.parse(item.publishedAt);
    if (Number.isNaN(ms) || ms <= 0) {
      return item;
    }

    const shouldArchive = nowMs - ms > activeWindowDays * DAY_MS;
    const targetArchivedAt = shouldArchive ? item.archivedAt || nowIso : null;

    if (
      item.isArchived !== shouldArchive ||
      (item.archivedAt ?? null) !== targetArchivedAt
    ) {
      changed = true;
      return {
        ...item,
        isArchived: shouldArchive,
        archivedAt: targetArchivedAt,
      };
    }

    return item;
  });

  return { items: next, changed };
}

export function formatTechDate(isoOrNull: string | null): string {
  if (!isoOrNull) return 'Unknown Date';
  const ms = Date.parse(isoOrNull);
  if (Number.isNaN(ms) || ms <= 0) return 'Unknown Date';
  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date(ms));
}

export function formatTechTimestamp(isoOrNull: string | null): string {
  if (!isoOrNull) return 'Never';
  const ms = Date.parse(isoOrNull);
  if (Number.isNaN(ms) || ms <= 0) return isoOrNull;
  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(ms));
}
