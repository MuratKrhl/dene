import { GitHubRepository } from '../../github/types';
import { AggregatedArticle } from '../../types/article';
import {
  LearningItem,
  LearningProgressStatus,
  PodcastEpisode,
  PodcastSeries,
  SecurityRecord,
  SecuritySeverity,
  TechEvent,
  TechEventStatus,
  TechVideo,
} from '../../types/technology';

export const DISCOVER_SOURCES = [
  'Medium',
  'Official Engineering Blogs',
  'YouTube',
  'Podcasts',
  'GitHub',
  'Security Advisories',
  'Conferences',
  'Technical Documentation',
] as const;

export type DiscoverSource = (typeof DISCOVER_SOURCES)[number];

export const DISCOVER_CONTENT_TYPES = [
  'Articles',
  'Videos',
  'Podcasts',
  'Repositories',
  'Security Updates',
  'Documentation',
] as const;

export type DiscoverContentType = (typeof DISCOVER_CONTENT_TYPES)[number];

export const DISCOVER_TECHNOLOGIES = [
  'Java',
  'Spring Boot',
  'JBoss / WildFly',
  'WebSphere',
  'OpenShift / Kubernetes',
  'Docker',
  'Ansible',
  'Nginx / Apache',
  'AI / LLM',
  'Cloud',
  'DevOps',
  'Security',
] as const;

export type DiscoverTechnology = (typeof DISCOVER_TECHNOLOGIES)[number];

export type DiscoverDateRange = '30d' | '7d' | '90d' | 'all' | 'archive';
export type DiscoverSortOption = 'latest' | 'relevance';
export type DiscoverViewMode = 'list' | 'grid';

export interface UnifiedFeedItem {
  id: string;
  kind:
    | 'article'
    | 'video'
    | 'podcast'
    | 'github'
    | 'learning'
    | 'security'
    | 'event';
  originalId: string;
  title: string;
  description: string;
  url: string;
  internalPath?: string;
  publishedAt: string | null;
  fetchedAt: string;
  isArchived: boolean;
  sourceGroup: DiscoverSource;
  sourceName: string;
  contentType: DiscoverContentType;
  technologies: DiscoverTechnology[];
  rawTags: string[];
  isFavorite: boolean;
  isConsumed: boolean;
  thumbnailUrl?: string | null;
  authorOrOrg?: string;
  duration?: string | null;
  cvss?: number | null;
  severity?: SecuritySeverity | null;
  cveId?: string | null;
  stars?: number;
  language?: string | null;
  podcastSeriesId?: string;
  podcastEpisode?: PodcastEpisode;
  githubRepo?: GitHubRepository;
  learningStatus?: LearningProgressStatus;
  eventLocation?: string | null;
  eventStatus?: TechEventStatus;
}

export interface DiscoverFilterState {
  sources: DiscoverSource[];
  contentTypes: DiscoverContentType[];
  technologies: DiscoverTechnology[];
  dateRange: DiscoverDateRange;
  searchQuery: string;
  sort: DiscoverSortOption;
  viewMode: DiscoverViewMode;
  page: number;
}

export const DEFAULT_DISCOVER_FILTER: DiscoverFilterState = {
  sources: [],
  contentTypes: [],
  technologies: [],
  dateRange: '30d',
  searchQuery: '',
  sort: 'latest',
  viewMode: 'list',
  page: 1,
};

export const DISCOVER_PAGE_SIZE = 10;

const TECH_RULES: Array<{ tech: DiscoverTechnology; patterns: RegExp[] }> = [
  {
    tech: 'Java',
    patterns: [/\bjava\b(?!script)/i, /\bjdk\b/i, /\bjvm\b/i, /\bmaven\b/i, /\bgradle\b/i, /\bjakarta\b/i],
  },
  {
    tech: 'Spring Boot',
    patterns: [/\bspring[\s-]?boot\b/i, /\bspring[\s-]?cloud\b/i, /\bspring[\s-]?security\b/i, /\bspring[\s-]?framework\b/i],
  },
  {
    tech: 'JBoss / WildFly',
    patterns: [/\bjboss\b/i, /\bwildfly\b/i, /\bquarkus\b/i, /\bundertow\b/i, /\beap\b/i],
  },
  {
    tech: 'WebSphere',
    patterns: [/\bwebsphere\b/i, /\bopen[\s-]?liberty\b/i, /\bwebsphere[\s-]?liberty\b/i],
  },
  {
    tech: 'OpenShift / Kubernetes',
    patterns: [/\bopenshift\b/i, /\bkubernetes\b/i, /\bk8s\b/i, /\bkubectl\b/i, /\bhelm\b/i, /\bcncf\b/i, /\bistio\b/i, /\bkubecon\b/i],
  },
  {
    tech: 'Docker',
    patterns: [/\bdocker\b/i, /\bcontainerd\b/i, /\bpodman\b/i, /\bcontainers?\b/i, /\bdockerfile\b/i],
  },
  {
    tech: 'Ansible',
    patterns: [/\bansible\b/i, /\bplaybook\b/i, /\bawx\b/i],
  },
  {
    tech: 'Nginx / Apache',
    patterns: [/\bnginx\b/i, /\bapache\b/i, /\bhttpd\b/i, /\bhaproxy\b/i, /\bingress\b/i],
  },
  {
    tech: 'AI / LLM',
    patterns: [/\bai\b/i, /\bllm\b/i, /\bopenai\b/i, /\banthropic\b/i, /\bclaude\b/i, /\bgemini\b/i, /\bmachine[\s-]?learning\b/i, /\brag\b/i, /\bagents?\b/i, /\bgenerative\b/i],
  },
  {
    tech: 'Cloud',
    patterns: [/\baws\b/i, /\bcloud\b/i, /\bgcp\b/i, /\bgoogle[\s-]?cloud\b/i, /\bazure\b/i, /\bcloudflare\b/i, /\bserverless\b/i, /\bcloud[\s-]?native\b/i],
  },
  {
    tech: 'DevOps',
    patterns: [/\bdevops\b/i, /\bci\/cd\b/i, /\bcicd\b/i, /\bterraform\b/i, /\bgithub[\s-]?actions\b/i, /\bgitops\b/i, /\bsre\b/i, /\bobservability\b/i, /\blinux\b/i, /\brhel\b/i],
  },
  {
    tech: 'Security',
    patterns: [/\bsecurity\b/i, /\bcve-\d+/i, /\bcve\b/i, /\bcisa\b/i, /\bvulnerability\b/i, /\bexploit\b/i, /\bzero[\s-]?trust\b/i, /\bransomware\b/i, /\badvisory\b/i, /\bmalware\b/i, /\bauth\b/i],
  },
];

export function classifyTechnologies(
  textParts: Array<string | null | undefined>,
  tags: string[] = []
): DiscoverTechnology[] {
  const combined = [...textParts.filter(Boolean), ...tags].join(' ');
  const matched: DiscoverTechnology[] = [];
  for (const rule of TECH_RULES) {
    if (rule.patterns.some((rx) => rx.test(combined))) {
      matched.push(rule.tech);
    }
  }
  return matched;
}

function mapArticleSourceGroup(art: AggregatedArticle): {
  sourceGroup: DiscoverSource;
  contentType: DiscoverContentType;
} {
  if (art.contentType === 'security-advisory' || art.sourceGroup === 'Security') {
    return { sourceGroup: 'Security Advisories', contentType: 'Security Updates' };
  }
  if (art.sourceGroup === 'Medium') {
    return { sourceGroup: 'Medium', contentType: 'Articles' };
  }
  return { sourceGroup: 'Official Engineering Blogs', contentType: 'Articles' };
}

export function buildUnifiedDiscoverFeed(input: {
  articles: AggregatedArticle[];
  videos: TechVideo[];
  podcastEpisodes: PodcastEpisode[];
  githubRepos: GitHubRepository[];
  savedGithubRepoIds: number[];
  learningItems: LearningItem[];
  securityRecords: SecurityRecord[];
  events: TechEvent[];
}): UnifiedFeedItem[] {
  const savedRepoSet = new Set(input.savedGithubRepoIds);
  const items: UnifiedFeedItem[] = [];

  for (const art of input.articles) {
    const mapped = mapArticleSourceGroup(art);
    const technologies = classifyTechnologies(
      [art.title, art.summary, art.category, art.sourceName, art.sourceGroup],
      art.tags
    );
    items.push({
      id: `article:${art.id}`,
      kind: 'article',
      originalId: art.id,
      title: art.title,
      description: art.summary || '',
      url: art.articleUrl,
      internalPath: `/journal/${encodeURIComponent(art.id)}`,
      publishedAt: art.publishedAt,
      fetchedAt: art.fetchedAt,
      isArchived: art.isArchived,
      sourceGroup: mapped.sourceGroup,
      sourceName: art.sourceName,
      contentType: mapped.contentType,
      technologies,
      rawTags: art.tags,
      isFavorite: art.isFavorite,
      isConsumed: art.isRead,
      thumbnailUrl: art.imageUrl,
      authorOrOrg: art.author || undefined,
      duration: art.readingTime,
    });
  }

  for (const vid of input.videos) {
    const isRedHatTv = vid.channelName.toLowerCase().includes('red hat tv');
    const technologies = classifyTechnologies(
      [vid.title, vid.description, vid.channelName, vid.category],
      vid.tags
    );
    items.push({
      id: `video:${vid.id}`,
      kind: 'video',
      originalId: vid.id,
      title: vid.title,
      description: vid.description || '',
      url: vid.videoUrl,
      publishedAt: vid.publishedAt,
      fetchedAt: vid.fetchedAt,
      isArchived: vid.isArchived,
      sourceGroup: isRedHatTv ? 'Official Engineering Blogs' : 'YouTube',
      sourceName: vid.channelName,
      contentType: 'Videos',
      technologies,
      rawTags: vid.tags,
      isFavorite: vid.isFavorite,
      isConsumed: vid.isWatched,
      thumbnailUrl: vid.thumbnailUrl,
      authorOrOrg: vid.channelName,
      duration: vid.duration,
    });
  }

  for (const ep of input.podcastEpisodes) {
    const technologies = classifyTechnologies(
      [ep.title, ep.description, ep.seriesTitle, ep.category],
      ep.tags
    );
    items.push({
      id: `podcast:${ep.id}`,
      kind: 'podcast',
      originalId: ep.id,
      title: ep.title,
      description: ep.description || '',
      url: ep.episodeUrl,
      publishedAt: ep.publishedAt,
      fetchedAt: ep.fetchedAt,
      isArchived: ep.isArchived,
      sourceGroup: 'Podcasts',
      sourceName: ep.seriesTitle,
      contentType: 'Podcasts',
      technologies,
      rawTags: ep.tags,
      isFavorite: ep.isFavorite,
      isConsumed: ep.isPlayed,
      thumbnailUrl: ep.artworkUrl,
      authorOrOrg: ep.seriesTitle,
      duration: ep.duration,
      podcastSeriesId: ep.seriesId,
      podcastEpisode: ep,
    });
  }

  for (const repo of input.githubRepos) {
    const technologies = classifyTechnologies(
      [repo.fullName, repo.description, repo.language],
      repo.topics || []
    );
    items.push({
      id: `github:${repo.id}`,
      kind: 'github',
      originalId: String(repo.id),
      title: repo.fullName,
      description: repo.description || `${repo.language || 'Open-source'} repository on GitHub`,
      url: repo.htmlUrl,
      internalPath: `/knowledge-hub/github/repositories/${encodeURIComponent(repo.owner.login)}/${encodeURIComponent(repo.name)}`,
      publishedAt: repo.pushedAt || repo.updatedAt || repo.createdAt,
      fetchedAt: repo.lastRefreshedAt || repo.updatedAt,
      isArchived: false,
      sourceGroup: 'GitHub',
      sourceName: repo.owner.login,
      contentType: 'Repositories',
      technologies,
      rawTags: repo.topics || [],
      isFavorite: savedRepoSet.has(repo.id),
      isConsumed: false,
      authorOrOrg: repo.owner.login,
      stars: repo.stargazersCount,
      language: repo.language,
      githubRepo: repo,
    });
  }

  for (const item of input.learningItems) {
    const technologies = classifyTechnologies(
      [item.title, item.description, item.platform, item.category],
      item.tags
    );
    items.push({
      id: `learning:${item.id}`,
      kind: 'learning',
      originalId: item.id,
      title: item.title,
      description: item.description || '',
      url: item.url,
      publishedAt: item.publishedAt,
      fetchedAt: item.fetchedAt,
      isArchived: item.isArchived,
      sourceGroup: 'Technical Documentation',
      sourceName: item.platform,
      contentType: 'Documentation',
      technologies,
      rawTags: item.tags,
      isFavorite: item.isFavorite,
      isConsumed: item.learningStatus === 'completed',
      authorOrOrg: item.platform,
      duration: item.duration,
      learningStatus: item.learningStatus,
    });
  }

  for (const sec of input.securityRecords) {
    const technologies = Array.from(
      new Set<DiscoverTechnology>([
        'Security',
        ...classifyTechnologies(
          [sec.cveId, sec.title, sec.description, sec.source, ...sec.affectedProducts],
          sec.tags
        ),
      ])
    );
    items.push({
      id: `security:${sec.id}`,
      kind: 'security',
      originalId: sec.id,
      title: sec.cveId ? `${sec.cveId} — ${sec.title}` : sec.title,
      description: sec.description || '',
      url: sec.url,
      publishedAt: sec.publishedAt,
      fetchedAt: sec.fetchedAt,
      isArchived: sec.isArchived,
      sourceGroup: 'Security Advisories',
      sourceName: sec.source,
      contentType: 'Security Updates',
      technologies,
      rawTags: sec.tags,
      isFavorite: sec.isFavorite,
      isConsumed: sec.isRead,
      authorOrOrg: sec.source,
      cvss: sec.cvss,
      severity: sec.severity,
      cveId: sec.cveId,
    });
  }

  for (const evt of input.events) {
    const technologies = classifyTechnologies(
      [evt.eventName, evt.description, evt.organizer, evt.location],
      evt.tags
    );
    items.push({
      id: `event:${evt.id}`,
      kind: 'event',
      originalId: evt.id,
      title: evt.eventName,
      description: evt.description || `${evt.organizer} · ${evt.eventType}`,
      url: evt.registrationUrl,
      publishedAt: evt.startDate || evt.publishedAt,
      fetchedAt: evt.fetchedAt,
      isArchived: evt.isArchived,
      sourceGroup: 'Conferences',
      sourceName: evt.organizer,
      contentType: 'Articles',
      technologies,
      rawTags: evt.tags,
      isFavorite: evt.isFavorite,
      isConsumed: false,
      authorOrOrg: evt.organizer,
      eventLocation: evt.location,
      eventStatus: evt.status,
    });
  }

  return items;
}

function getItemTimestampMs(item: UnifiedFeedItem): number {
  const ts = Date.parse(item.publishedAt || item.fetchedAt);
  return Number.isNaN(ts) ? 0 : ts;
}

function computeRelevanceScore(
  item: UnifiedFeedItem,
  queryLower: string,
  selectedTechs: DiscoverTechnology[]
): number {
  let score = 0;
  if (queryLower) {
    const titleLower = item.title.toLowerCase();
    const descLower = item.description.toLowerCase();
    const srcLower = item.sourceName.toLowerCase();
    if (titleLower === queryLower) score += 120;
    else if (titleLower.includes(queryLower)) score += 70;
    const words = queryLower.split(/\s+/).filter(Boolean);
    for (const w of words) {
      if (titleLower.includes(w)) score += 25;
      if (item.technologies.some((t) => t.toLowerCase().includes(w))) score += 18;
      if (item.rawTags.some((t) => t.toLowerCase().includes(w))) score += 14;
      if (srcLower.includes(w)) score += 10;
      if (descLower.includes(w)) score += 6;
    }
  }
  if (selectedTechs.length > 0) {
    const matches = selectedTechs.filter((t) => item.technologies.includes(t)).length;
    score += matches * 20;
  }
  if (item.isFavorite) score += 5;
  if (item.severity === 'CRITICAL') score += 8;
  return score;
}

export function filterAndSortUnifiedFeed(
  items: UnifiedFeedItem[],
  filter: DiscoverFilterState,
  nowMs: number = Date.now()
): UnifiedFeedItem[] {
  const q = filter.searchQuery.trim().toLowerCase();
  const windowDaysMap: Record<'7d' | '30d' | '90d', number> = {
    '7d': 7,
    '30d': 30,
    '90d': 90,
  };

  const filtered = items.filter((item) => {
    if (filter.dateRange === 'archive') {
      if (!item.isArchived) return false;
    } else if (filter.dateRange !== 'all') {
      if (item.isArchived) return false;
      const days = windowDaysMap[filter.dateRange];
      const ts = getItemTimestampMs(item);
      if (ts > 0 && nowMs - ts > days * 86_400_000) {
        return false;
      }
    }

    if (
      filter.sources.length > 0 &&
      !filter.sources.includes(item.sourceGroup)
    ) {
      return false;
    }

    if (
      filter.contentTypes.length > 0 &&
      !filter.contentTypes.includes(item.contentType)
    ) {
      return false;
    }

    if (
      filter.technologies.length > 0 &&
      !filter.technologies.some((t) => item.technologies.includes(t))
    ) {
      return false;
    }

    if (q) {
      const hay = [
        item.title,
        item.description,
        item.sourceName,
        item.sourceGroup,
        item.contentType,
        item.cveId || '',
        item.language || '',
        ...item.technologies,
        ...item.rawTags,
      ]
        .join(' ')
        .toLowerCase();
      if (!hay.includes(q)) return false;
    }

    return true;
  });

  return filtered.slice().sort((a, b) => {
    if (filter.sort === 'relevance') {
      const scoreDiff =
        computeRelevanceScore(b, q, filter.technologies) -
        computeRelevanceScore(a, q, filter.technologies);
      if (scoreDiff !== 0) return scoreDiff;
    }
    return getItemTimestampMs(b) - getItemTimestampMs(a);
  });
}

export function parseDiscoverFilterFromSearch(
  search: string,
  legacyPreset?: string
): DiscoverFilterState {
  const params = new URLSearchParams(search.startsWith('?') ? search.slice(1) : search);

  const parseCsv = <T extends string>(
    raw: string | null,
    allowed: readonly T[]
  ): T[] => {
    if (!raw) return [];
    const set = new Set<string>(allowed);
    return raw
      .split(',')
      .map((v) => v.trim())
      .filter((v): v is T => set.has(v));
  };

  let sources = parseCsv(params.get('source'), DISCOVER_SOURCES);
  let contentTypes = parseCsv(params.get('type'), DISCOVER_CONTENT_TYPES);
  const technologies = parseCsv(params.get('tech'), DISCOVER_TECHNOLOGIES);

  // Seamless backward-compatible mapping for old sub-tab routes
  if (sources.length === 0 && contentTypes.length === 0 && legacyPreset) {
    if (legacyPreset === 'articles') contentTypes = ['Articles'];
    else if (legacyPreset === 'videos') contentTypes = ['Videos'];
    else if (legacyPreset === 'podcasts') contentTypes = ['Podcasts'];
    else if (legacyPreset === 'learning') contentTypes = ['Documentation'];
    else if (legacyPreset === 'events') sources = ['Conferences'];
  }

  const rangeParam = params.get('range');
  const dateRange: DiscoverDateRange =
    rangeParam === '7d' ||
    rangeParam === '30d' ||
    rangeParam === '90d' ||
    rangeParam === 'all' ||
    rangeParam === 'archive'
      ? rangeParam
      : '30d';

  const sortParam = params.get('sort');
  const sort: DiscoverSortOption =
    sortParam === 'relevance' ? 'relevance' : 'latest';

  const viewParam = params.get('view');
  const viewMode: DiscoverViewMode = viewParam === 'grid' ? 'grid' : 'list';

  const pageNum = Number(params.get('page') || '1');
  const page = Number.isFinite(pageNum) && pageNum >= 1 ? Math.floor(pageNum) : 1;

  return {
    sources,
    contentTypes,
    technologies,
    dateRange,
    searchQuery: params.get('q') || '',
    sort,
    viewMode,
    page,
  };
}

export function serializeDiscoverFilterToSearch(
  state: DiscoverFilterState
): string {
  const params = new URLSearchParams();
  if (state.sources.length > 0) {
    params.set('source', state.sources.join(','));
  }
  if (state.contentTypes.length > 0) {
    params.set('type', state.contentTypes.join(','));
  }
  if (state.technologies.length > 0) {
    params.set('tech', state.technologies.join(','));
  }
  if (state.dateRange !== '30d') {
    params.set('range', state.dateRange);
  }
  if (state.searchQuery.trim()) {
    params.set('q', state.searchQuery.trim());
  }
  if (state.sort !== 'latest') {
    params.set('sort', state.sort);
  }
  if (state.viewMode !== 'list') {
    params.set('view', state.viewMode);
  }
  if (state.page > 1) {
    params.set('page', String(state.page));
  }
  const str = params.toString();
  return str ? `?${str}` : '';
}

export function buildPersonalizedRecommendations(
  items: UnifiedFeedItem[],
  podcastSeries: PodcastSeries[],
  limit: number = 4
): { items: UnifiedFeedItem[]; matchedTopics: DiscoverTechnology[] } {
  const affinity = new Map<DiscoverTechnology, number>();

  for (const item of items) {
    if (item.isFavorite) {
      for (const tech of item.technologies) {
        affinity.set(tech, (affinity.get(tech) || 0) + 3);
      }
    } else if (item.isConsumed) {
      for (const tech of item.technologies) {
        affinity.set(tech, (affinity.get(tech) || 0) + 1);
      }
    }
  }

  for (const show of podcastSeries) {
    if (show.isFollowed || show.isFavorite) {
      const showTechs = classifyTechnologies(
        [show.title, show.description, show.category],
        show.tags
      );
      for (const tech of showTechs) {
        affinity.set(tech, (affinity.get(tech) || 0) + 2);
      }
    }
  }

  const matchedTopics = Array.from(affinity.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([tech]) => tech)
    .slice(0, 4);

  const candidates = items
    .filter((i) => !i.isArchived && !i.isConsumed)
    .slice()
    .sort((a, b) => {
      const scoreA = a.technologies.reduce(
        (sum, t) => sum + (affinity.get(t) || 0),
        0
      );
      const scoreB = b.technologies.reduce(
        (sum, t) => sum + (affinity.get(t) || 0),
        0
      );
      if (scoreB !== scoreA) return scoreB - scoreA;
      return getItemTimestampMs(b) - getItemTimestampMs(a);
    });

  // Encourage source diversity in recommendations
  const picked: UnifiedFeedItem[] = [];
  const usedKinds = new Map<string, number>();
  for (const item of candidates) {
    const countForSource = usedKinds.get(item.sourceGroup) || 0;
    if (countForSource >= 2 && candidates.length > limit * 2) continue;
    picked.push(item);
    usedKinds.set(item.sourceGroup, countForSource + 1);
    if (picked.length >= limit) break;
  }

  return { items: picked, matchedTopics };
}
