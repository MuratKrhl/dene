import {
  LearningContentKind,
  LearningItem,
  LearningProgressStatus,
  PodcastEpisode,
  PodcastSeries,
  SecurityRecord,
  TechContentType,
  TechEvent,
  TechEventStatus,
  TechEventType,
  TechSettings,
  TechSource,
  TechSyncHistoryEntry,
  TechVideo,
} from '../../types/technology';
import {
  syncAllArticleSources,
  syncSingleArticleSource,
} from '../articles/articleAggregator';
import {
  parseEventsPayload,
  parseLearningPayload,
  parsePodcastRssFeed,
  parseSecurityPayload,
  parseYouTubePayloadToVideos,
} from './adapters';
import { deduplicateRecords, mergeTagsAndSources } from './deduplicator';
import {
  isOlderThanActiveWindow,
  parseStrictPublishedDate,
  reconcileItemRetention,
} from './retentionEngine';
import { techStorage } from './techStorage';

export interface TechFetchResult {
  ok: boolean;
  payload: string;
  httpStatus: number;
  errorMessage: string | null;
  quotaExceeded?: boolean;
  durationMs: number;
}

export interface TechTransportAdapter {
  fetchFeed(feedUrl: string, timeoutMs: number): Promise<TechFetchResult>;
  fetchYouTubeChannel(
    channelId: string,
    maxResults: number,
    timeoutMs: number
  ): Promise<TechFetchResult>;
  checkHealth(): Promise<{
    ok: boolean;
    youtubeApiConfigured: boolean;
    nvdApiConfigured: boolean;
  }>;
}

class SameOriginTechTransport implements TechTransportAdapter {
  private async fetchRaw(
    endpointUrl: string,
    timeoutMs: number
  ): Promise<TechFetchResult> {
    const started = Date.now();
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(endpointUrl, { signal: ctrl.signal });
      const ct = (res.headers.get('content-type') || '').toLowerCase();
      const text = await res.text();
      const durationMs = Date.now() - started;

      if (!res.ok) {
        let errorMessage = `HTTP ${res.status} error fetching feed.`;
        let quotaExceeded = false;
        if (ct.includes('json')) {
          try {
            const j = JSON.parse(text) as {
              error?: string;
              quotaExceeded?: boolean;
            };
            if (j.error) errorMessage = j.error;
            if (j.quotaExceeded) quotaExceeded = true;
          } catch {
            // Keep default message
          }
        }
        return {
          ok: false,
          payload: '',
          httpStatus: res.status,
          errorMessage,
          quotaExceeded,
          durationMs,
        };
      }

      const head = text.trim().slice(0, 120).toLowerCase();
      if (head.startsWith('<!doctype html') || head.startsWith('<html')) {
        return {
          ok: false,
          payload: '',
          httpStatus: res.status,
          errorMessage: 'Upstream returned HTML instead of structured RSS/Atom/JSON.',
          durationMs,
        };
      }

      if (!text.trim()) {
        return {
          ok: false,
          payload: '',
          httpStatus: res.status,
          errorMessage: 'Upstream feed returned an empty payload.',
          durationMs,
        };
      }

      return {
        ok: true,
        payload: text,
        httpStatus: res.status,
        errorMessage: null,
        durationMs,
      };
    } catch (err) {
      const durationMs = Date.now() - started;
      const isTimeout =
        err instanceof Error &&
        (err.name === 'AbortError' || err.message.toLowerCase().includes('abort'));
      return {
        ok: false,
        payload: '',
        httpStatus: isTimeout ? 504 : 0,
        errorMessage: isTimeout
          ? `Request timed out after ${Math.round(timeoutMs / 1000)}s.`
          : err instanceof Error
            ? err.message
            : 'Network error fetching feed.',
        durationMs,
      };
    } finally {
      clearTimeout(timer);
    }
  }

  async fetchFeed(feedUrl: string, timeoutMs: number): Promise<TechFetchResult> {
    return this.fetchRaw(
      `/api/technology/feed?url=${encodeURIComponent(feedUrl)}`,
      timeoutMs
    );
  }

  async fetchYouTubeChannel(
    channelId: string,
    maxResults: number,
    timeoutMs: number
  ): Promise<TechFetchResult> {
    return this.fetchRaw(
      `/api/technology/youtube/videos?channelId=${encodeURIComponent(channelId)}&maxResults=${maxResults}`,
      timeoutMs
    );
  }

  async checkHealth(): Promise<{
    ok: boolean;
    youtubeApiConfigured: boolean;
    nvdApiConfigured: boolean;
  }> {
    try {
      const res = await fetch('/api/technology/health');
      if (!res.ok) {
        return { ok: false, youtubeApiConfigured: false, nvdApiConfigured: false };
      }
      const j = (await res.json()) as {
        ok?: boolean;
        youtubeApiConfigured?: boolean;
        nvdApiConfigured?: boolean;
      };
      return {
        ok: Boolean(j.ok),
        youtubeApiConfigured: Boolean(j.youtubeApiConfigured),
        nvdApiConfigured: Boolean(j.nvdApiConfigured),
      };
    } catch {
      return { ok: false, youtubeApiConfigured: false, nvdApiConfigured: false };
    }
  }
}

let activeTransport: TechTransportAdapter = new SameOriginTechTransport();

export function setTechTransportAdapter(adapter: TechTransportAdapter): void {
  activeTransport = adapter;
}

export function getTechTransportAdapter(): TechTransportAdapter {
  return activeTransport;
}

export interface BackendTechSchedulerContract {
  readonly mode: 'browser-open' | 'backend-cron';
  getNextSourceFetchAt(source: TechSource, settings: TechSettings): string | null;
  isSourceDue(source: TechSource, settings: TechSettings, nowMs?: number): boolean;
  syncDueSources(): Promise<{ syncedSources: number }>;
}

export function computeNextFetchAt(
  source: TechSource,
  settings: TechSettings,
  baseIso: string
): string | null {
  if (!settings.globalAutoSync || !source.enabled) return null;
  const intervalMinutes =
    source.syncInterval > 0
      ? source.syncInterval
      : settings.defaultSyncIntervalHours * 60;
  if (intervalMinutes <= 0) return null;
  const baseMs = Date.parse(baseIso);
  if (Number.isNaN(baseMs)) return null;
  return new Date(baseMs + intervalMinutes * 60_000).toISOString();
}

export function isTechSourceDue(
  source: TechSource,
  settings: TechSettings,
  nowMs: number = Date.now()
): boolean {
  if (!settings.globalAutoSync || !source.enabled) return false;
  if (
    source.sourceType === 'unsupported' ||
    source.sourceType === 'manual'
  ) {
    return false;
  }
  const intervalMinutes =
    source.syncInterval > 0
      ? source.syncInterval
      : settings.defaultSyncIntervalHours * 60;
  if (intervalMinutes <= 0) return false;

  // Backoff on repeated consecutive failures (>3 failures -> double interval, cap 24h)
  const effectiveIntervalMs =
    source.consecutiveFailures >= 3
      ? Math.min(24 * 60, intervalMinutes * 2) * 60_000
      : intervalMinutes * 60_000;

  if (!source.lastSuccessfulFetchAt) {
    if (!source.lastFetchedAt) return true;
    const lastAttemptMs = Date.parse(source.lastFetchedAt);
    return Number.isNaN(lastAttemptMs) || nowMs - lastAttemptMs >= effectiveIntervalMs;
  }

  const lastOkMs = Date.parse(source.lastSuccessfulFetchAt);
  if (Number.isNaN(lastOkMs)) return true;
  return nowMs - lastOkMs >= effectiveIntervalMs;
}

const inFlightSourceSyncs = new Map<string, Promise<TechSyncHistoryEntry>>();
let inFlightBatchSync: Promise<TechSyncHistoryEntry[]> | null = null;

async function fetchWithRetry(
  source: TechSource,
  settings: TechSettings
): Promise<TechFetchResult> {
  const exec = () => {
    if (source.sourceType === 'youtube-api' && source.channelId) {
      return activeTransport.fetchYouTubeChannel(
        source.channelId,
        15,
        settings.requestTimeoutMs
      );
    }
    return activeTransport.fetchFeed(source.feedUrl, settings.requestTimeoutMs);
  };

  let res = await exec();
  // Never retry on quota exceeded or HTTP 400/404 permanent errors
  const shouldRetry =
    !res.ok &&
    !res.quotaExceeded &&
    settings.retryCount > 0 &&
    (res.httpStatus === 0 || res.httpStatus === 504 || res.httpStatus >= 500 || res.httpStatus === 429);

  if (shouldRetry) {
    await new Promise((r) => setTimeout(r, 600));
    res = await exec();
  }
  return res;
}

export async function initializeTechnologyCenter(): Promise<void> {
  await techStorage.init();
  const settings = techStorage.getSettings();
  const days = settings.activeWindowDays || 30;

  const vidRes = reconcileItemRetention(techStorage.getVideos(), days);
  if (vidRes.changed) await techStorage.saveVideos(vidRes.items);

  const epRes = reconcileItemRetention(techStorage.getPodcastEpisodes(), days);
  if (epRes.changed) await techStorage.savePodcastEpisodes(epRes.items);

  const learnRes = reconcileItemRetention(techStorage.getLearningItems(), days);
  if (learnRes.changed) await techStorage.saveLearningItems(learnRes.items);

  const secRes = reconcileItemRetention(techStorage.getSecurityRecords(), days);
  if (secRes.changed) await techStorage.saveSecurityRecords(secRes.items);

  const evtRes = reconcileItemRetention(techStorage.getEvents(), days);
  if (evtRes.changed) await techStorage.saveEvents(evtRes.items);
}

export async function syncSingleTechnologySource(
  sourceId: string
): Promise<TechSyncHistoryEntry> {
  if (inFlightSourceSyncs.has(sourceId)) {
    return inFlightSourceSyncs.get(sourceId)!;
  }

  const run = (async (): Promise<TechSyncHistoryEntry> => {
    await techStorage.init();
    const sources = techStorage.getSources();
    const settings = techStorage.getSettings();
    const target = sources.find((s) => s.id === sourceId);

    if (!target) {
      // Check if it belongs to unified Article sources
      const artRes = await syncSingleArticleSource(sourceId);
      const nowIso = new Date().toISOString();
      const entry: TechSyncHistoryEntry = {
        syncId: `sync-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        startedAt: nowIso,
        finishedAt: nowIso,
        contentType: 'article',
        sourceId,
        sourceName: artRes.report.sourceName,
        status: artRes.report.unsupported
          ? 'unsupported'
          : artRes.report.ok
            ? 'success'
            : 'error',
        newItems: artRes.report.newCount,
        duplicates: artRes.report.duplicatesSkipped,
        updatedItems: 0,
        errors: artRes.report.ok || artRes.report.unsupported ? 0 : 1,
        errorMessage: artRes.report.errorMessage,
        durationMs: artRes.report.durationMs,
      };
      await techStorage.appendSyncHistory([entry]);
      return entry;
    }

    const startedAt = new Date().toISOString();
    const startedMs = Date.now();

    if (
      target.sourceType === 'unsupported' ||
      target.sourceType === 'manual' ||
      (!target.feedUrl && !target.channelId)
    ) {
      const entry: TechSyncHistoryEntry = {
        syncId: `sync-${startedMs}-${target.id}`,
        startedAt,
        finishedAt: new Date().toISOString(),
        contentType: target.contentType,
        sourceId: target.id,
        sourceName: target.name,
        status: 'unsupported',
        newItems: 0,
        duplicates: 0,
        updatedItems: 0,
        errors: 0,
        errorMessage:
          target.errorMessage ||
          'Source does not provide an automated RSS/Atom/API endpoint.',
        durationMs: 0,
      };
      await techStorage.appendSyncHistory([entry]);
      return entry;
    }

    const fetchRes = await fetchWithRetry(target, settings);
    const finishedAt = new Date().toISOString();
    const durationMs = Date.now() - startedMs;

    let newItems = 0;
    let duplicates = 0;
    let updatedItems = 0;
    let totalForSource = target.itemCount;

    if (!fetchRes.ok) {
      const updatedSources = techStorage.getSources().map((s) =>
        s.id === target.id
          ? {
              ...s,
              lastFetchedAt: finishedAt,
              nextFetchAt: computeNextFetchAt(s, settings, finishedAt),
              status: 'error' as const,
              errorMessage: fetchRes.errorMessage || 'Feed sync failed.',
              consecutiveFailures: s.consecutiveFailures + 1,
              updatedAt: finishedAt,
            }
          : s
      );
      await techStorage.saveSources(updatedSources);

      const entry: TechSyncHistoryEntry = {
        syncId: `sync-${startedMs}-${target.id}`,
        startedAt,
        finishedAt,
        contentType: target.contentType,
        sourceId: target.id,
        sourceName: target.name,
        status: 'error',
        newItems: 0,
        duplicates: 0,
        updatedItems: 0,
        errors: 1,
        errorMessage: fetchRes.errorMessage || 'Feed sync failed.',
        durationMs,
      };
      await techStorage.appendSyncHistory([entry]);
      return entry;
    }

    try {
      const days = settings.activeWindowDays || 30;

      if (target.contentType === 'video') {
        const parsed = parseYouTubePayloadToVideos(
          fetchRes.payload,
          target,
          days
        );
        const existing = techStorage.getVideos();
        const merged = deduplicateRecords(
          existing.map((v) => ({ ...v, externalId: v.videoId, url: v.videoUrl })),
          parsed.map((v) => ({ ...v, externalId: v.videoId, url: v.videoUrl })),
          (cur, inc) => {
            const extra = mergeTagsAndSources(
              cur.tags,
              inc.tags,
              cur.matchedSourceIds,
              inc.matchedSourceIds
            );
            const nextDuration = cur.duration || inc.duration;
            const changed =
              extra.tags.length !== cur.tags.length ||
              extra.matchedSourceIds.length !== cur.matchedSourceIds.length ||
              nextDuration !== cur.duration;
            return {
              changed,
              merged: {
                ...cur,
                ...extra,
                duration: nextDuration,
                durationSeconds: cur.durationSeconds ?? inc.durationSeconds,
                thumbnailUrl: cur.thumbnailUrl || inc.thumbnailUrl,
              },
            };
          }
        );
        const finalVideos: TechVideo[] = merged.nextRecords.map(
          ({ externalId: _e, url: _u, ...rest }) => rest
        );
        const reconciled = reconcileItemRetention(finalVideos, days).items;
        await techStorage.saveVideos(reconciled);
        newItems = merged.newCount;
        duplicates = merged.duplicatesSkipped;
        updatedItems = merged.updatedCount;
        totalForSource = reconciled.filter((v) =>
          v.matchedSourceIds.includes(target.id)
        ).length;
      } else if (target.contentType === 'podcast') {
        const { series, episodes } = parsePodcastRssFeed(
          fetchRes.payload,
          target,
          days
        );

        const existingSeries = techStorage.getPodcastSeries();
        const existingMatch = existingSeries.find(
          (s) => s.id === series.id || s.sourceId === target.id
        );
        const nextSeriesList = existingMatch
          ? existingSeries.map((s) =>
              s.id === existingMatch.id
                ? {
                    ...series,
                    id: existingMatch.id,
                    isFollowed: existingMatch.isFollowed,
                    isFavorite: existingMatch.isFavorite,
                  }
                : s
            )
          : [...existingSeries, series];

        const effectiveSeriesId = existingMatch ? existingMatch.id : series.id;
        const incomingEps = episodes.map((e) => ({
          ...e,
          seriesId: effectiveSeriesId,
          externalId: e.guid,
          url: e.audioUrl || e.episodeUrl,
        }));

        const merged = deduplicateRecords(
          techStorage.getPodcastEpisodes().map((e) => ({
            ...e,
            externalId: e.guid,
            url: e.audioUrl || e.episodeUrl,
          })),
          incomingEps,
          (cur, inc) => {
            const extra = mergeTagsAndSources(
              cur.tags,
              inc.tags,
              cur.matchedSourceIds,
              inc.matchedSourceIds
            );
            const changed =
              extra.tags.length !== cur.tags.length ||
              extra.matchedSourceIds.length !== cur.matchedSourceIds.length ||
              (!cur.audioUrl && Boolean(inc.audioUrl));
            return {
              changed,
              merged: {
                ...cur,
                ...extra,
                audioUrl: cur.audioUrl || inc.audioUrl,
                artworkUrl: cur.artworkUrl || inc.artworkUrl,
                duration: cur.duration || inc.duration,
                durationSeconds: cur.durationSeconds ?? inc.durationSeconds,
                // Preserve user playback position & played/favorite/archived flags!
              },
            };
          }
        );

        const finalEpisodes: PodcastEpisode[] = merged.nextRecords.map(
          ({ externalId: _e, url: _u, ...rest }) => rest
        );
        const reconciledEps = reconcileItemRetention(finalEpisodes, days).items;
        const updatedSeriesCounts = nextSeriesList.map((s) => ({
          ...s,
          episodeCount: reconciledEps.filter((ep) => ep.seriesId === s.id).length,
        }));

        await techStorage.savePodcastSeries(updatedSeriesCounts);
        await techStorage.savePodcastEpisodes(reconciledEps);
        newItems = merged.newCount;
        duplicates = merged.duplicatesSkipped;
        updatedItems = merged.updatedCount;
        totalForSource = reconciledEps.filter((e) =>
          e.matchedSourceIds.includes(target.id)
        ).length;
      } else if (target.contentType === 'learning') {
        const parsed = parseLearningPayload(fetchRes.payload, target, days);
        const merged = deduplicateRecords(
          techStorage.getLearningItems().map((l) => ({ ...l, externalId: l.guid })),
          parsed.map((l) => ({ ...l, externalId: l.guid })),
          (cur, inc) => {
            const extra = mergeTagsAndSources(
              cur.tags,
              inc.tags,
              cur.matchedSourceIds,
              inc.matchedSourceIds
            );
            return {
              changed:
                extra.tags.length !== cur.tags.length ||
                extra.matchedSourceIds.length !== cur.matchedSourceIds.length,
              merged: { ...cur, ...extra },
            };
          }
        );
        const finalLearning: LearningItem[] = merged.nextRecords.map(
          ({ externalId: _e, ...rest }) => rest
        );
        const reconciled = reconcileItemRetention(finalLearning, days).items;
        await techStorage.saveLearningItems(reconciled);
        newItems = merged.newCount;
        duplicates = merged.duplicatesSkipped;
        updatedItems = merged.updatedCount;
        totalForSource = reconciled.filter((l) =>
          l.matchedSourceIds.includes(target.id)
        ).length;
      } else if (target.contentType === 'security') {
        const parsed = parseSecurityPayload(fetchRes.payload, target, days);
        const merged = deduplicateRecords(
          techStorage
            .getSecurityRecords()
            .map((r) => ({ ...r, externalId: r.cveId || r.guid })),
          parsed.map((r) => ({ ...r, externalId: r.cveId || r.guid })),
          (cur, inc) => {
            const extra = mergeTagsAndSources(
              cur.tags,
              inc.tags,
              cur.matchedSourceIds,
              inc.matchedSourceIds
            );
            const nextCvss = cur.cvss ?? inc.cvss;
            const nextSeverity = cur.severity ?? inc.severity;
            const changed =
              extra.tags.length !== cur.tags.length ||
              extra.matchedSourceIds.length !== cur.matchedSourceIds.length ||
              nextCvss !== cur.cvss;
            return {
              changed,
              merged: {
                ...cur,
                ...extra,
                cvss: nextCvss,
                severity: nextSeverity,
                affectedProducts:
                  cur.affectedProducts.length > 0
                    ? cur.affectedProducts
                    : inc.affectedProducts,
              },
            };
          }
        );
        const finalSec: SecurityRecord[] = merged.nextRecords.map(
          ({ externalId: _e, ...rest }) => rest
        );
        const reconciled = reconcileItemRetention(finalSec, days).items;
        await techStorage.saveSecurityRecords(reconciled);
        newItems = merged.newCount;
        duplicates = merged.duplicatesSkipped;
        updatedItems = merged.updatedCount;
        totalForSource = reconciled.filter((r) =>
          r.matchedSourceIds.includes(target.id)
        ).length;
      } else if (target.contentType === 'event') {
        const parsed = parseEventsPayload(fetchRes.payload, target, days);
        const merged = deduplicateRecords(
          techStorage
            .getEvents()
            .map((e) => ({ ...e, externalId: e.guid, url: e.sourceUrl })),
          parsed.map((e) => ({ ...e, externalId: e.guid, url: e.sourceUrl })),
          (cur, inc) => {
            const extra = mergeTagsAndSources(
              cur.tags,
              inc.tags,
              cur.matchedSourceIds,
              inc.matchedSourceIds
            );
            return {
              changed:
                extra.tags.length !== cur.tags.length ||
                extra.matchedSourceIds.length !== cur.matchedSourceIds.length,
              merged: { ...cur, ...extra },
            };
          }
        );
        const finalEvents: TechEvent[] = merged.nextRecords.map(
          ({ externalId: _e, url: _u, ...rest }) => rest
        );
        const reconciled = reconcileItemRetention(finalEvents, days).items;
        await techStorage.saveEvents(reconciled);
        newItems = merged.newCount;
        duplicates = merged.duplicatesSkipped;
        updatedItems = merged.updatedCount;
        totalForSource = reconciled.filter((e) =>
          e.matchedSourceIds.includes(target.id)
        ).length;
      }

      const updatedSources = techStorage.getSources().map((s) =>
        s.id === target.id
          ? {
              ...s,
              lastFetchedAt: finishedAt,
              lastSuccessfulFetchAt: finishedAt,
              nextFetchAt: computeNextFetchAt(s, settings, finishedAt),
              status: 'success' as const,
              errorMessage: null,
              consecutiveFailures: 0,
              itemCount: totalForSource,
              updatedAt: finishedAt,
            }
          : s
      );
      await techStorage.saveSources(updatedSources);
      await techStorage.saveSettings({
        ...settings,
        lastGlobalSyncAt: finishedAt,
        lastSuccessfulSyncAt: finishedAt,
      });

      const entry: TechSyncHistoryEntry = {
        syncId: `sync-${startedMs}-${target.id}`,
        startedAt,
        finishedAt,
        contentType: target.contentType,
        sourceId: target.id,
        sourceName: target.name,
        status: 'success',
        newItems,
        duplicates,
        updatedItems,
        errors: 0,
        errorMessage: null,
        durationMs,
      };
      await techStorage.appendSyncHistory([entry]);
      return entry;
    } catch (parseErr) {
      const msg =
        parseErr instanceof Error ? parseErr.message : 'Failed parsing feed payload.';
      const updatedSources = techStorage.getSources().map((s) =>
        s.id === target.id
          ? {
              ...s,
              lastFetchedAt: finishedAt,
              nextFetchAt: computeNextFetchAt(s, settings, finishedAt),
              status: 'error' as const,
              errorMessage: msg,
              consecutiveFailures: s.consecutiveFailures + 1,
              updatedAt: finishedAt,
            }
          : s
      );
      await techStorage.saveSources(updatedSources);

      const entry: TechSyncHistoryEntry = {
        syncId: `sync-${startedMs}-${target.id}`,
        startedAt,
        finishedAt,
        contentType: target.contentType,
        sourceId: target.id,
        sourceName: target.name,
        status: 'error',
        newItems: 0,
        duplicates: 0,
        updatedItems: 0,
        errors: 1,
        errorMessage: msg,
        durationMs: Date.now() - startedMs,
      };
      await techStorage.appendSyncHistory([entry]);
      return entry;
    }
  })();

  inFlightSourceSyncs.set(sourceId, run);
  try {
    return await run;
  } finally {
    inFlightSourceSyncs.delete(sourceId);
  }
}

export async function syncMultipleTechnologySources(
  sourceIds: string[],
  includeArticles: boolean = false
): Promise<TechSyncHistoryEntry[]> {
  if (inFlightBatchSync) return inFlightBatchSync;

  const run = (async () => {
    await techStorage.init();
    const results: TechSyncHistoryEntry[] = [];
    const queue = [...sourceIds];
    const concurrency = 3;

    const workers = Array.from(
      { length: Math.min(concurrency, Math.max(1, queue.length)) },
      async () => {
        while (queue.length > 0) {
          const nextId = queue.shift();
          if (!nextId) break;
          const entry = await syncSingleTechnologySource(nextId);
          results.push(entry);
        }
      }
    );
    await Promise.all(workers);

    if (includeArticles) {
      const startedAt = new Date().toISOString();
      const startedMs = Date.now();
      const artSync = await syncAllArticleSources();
      const finishedAt = new Date().toISOString();
      const artEntry: TechSyncHistoryEntry = {
        syncId: `sync-${startedMs}-articles-batch`,
        startedAt,
        finishedAt,
        contentType: 'article',
        sourceId: 'articles-all',
        sourceName: `All Article Feeds (${artSync.summary.succeededSources}/${artSync.summary.enabledSources})`,
        status:
          artSync.summary.failedSources > 0
            ? artSync.summary.succeededSources > 0
              ? 'partial'
              : 'error'
            : 'success',
        newItems: artSync.summary.newArticlesAdded,
        duplicates: artSync.summary.duplicatesSkipped,
        updatedItems: 0,
        errors: artSync.summary.failedSources,
        errorMessage:
          artSync.summary.failedSources > 0 ? artSync.summary.message : null,
        durationMs: Date.now() - startedMs,
      };
      await techStorage.appendSyncHistory([artEntry]);
      results.push(artEntry);
    }

    return results;
  })();

  inFlightBatchSync = run;
  try {
    return await run;
  } finally {
    inFlightBatchSync = null;
  }
}

export async function syncTechnologyByContentType(
  contentType: Exclude<TechContentType, 'article'>
): Promise<TechSyncHistoryEntry[]> {
  await techStorage.init();
  const ids = techStorage
    .getSources()
    .filter(
      (s) =>
        s.contentType === contentType &&
        s.enabled &&
        s.sourceType !== 'unsupported' &&
        s.sourceType !== 'manual'
    )
    .map((s) => s.id);
  return syncMultipleTechnologySources(ids, false);
}

export async function syncAllTechnologySources(
  includeArticles: boolean = true
): Promise<TechSyncHistoryEntry[]> {
  await techStorage.init();
  const ids = techStorage
    .getSources()
    .filter(
      (s) =>
        s.enabled &&
        s.sourceType !== 'unsupported' &&
        s.sourceType !== 'manual'
    )
    .map((s) => s.id);
  return syncMultipleTechnologySources(ids, includeArticles);
}

export async function retryFailedTechnologySources(): Promise<
  TechSyncHistoryEntry[]
> {
  await techStorage.init();
  const failedIds = techStorage
    .getSources()
    .filter(
      (s) =>
        s.enabled &&
        s.status === 'error' &&
        s.sourceType !== 'unsupported' &&
        s.sourceType !== 'manual'
    )
    .map((s) => s.id);
  return syncMultipleTechnologySources(failedIds, false);
}

export async function syncDueTechnologySources(): Promise<TechSyncHistoryEntry[]> {
  await techStorage.init();
  const settings = techStorage.getSettings();
  if (!settings.globalAutoSync) return [];
  const nowMs = Date.now();
  const dueIds = techStorage
    .getSources()
    .filter((s) => isTechSourceDue(s, settings, nowMs))
    .map((s) => s.id);
  if (dueIds.length === 0) return [];
  return syncMultipleTechnologySources(dueIds, false);
}

export const browserTechScheduler: BackendTechSchedulerContract = {
  mode: 'browser-open',
  getNextSourceFetchAt: (source, settings) =>
    source.nextFetchAt ||
    computeNextFetchAt(
      source,
      settings,
      source.lastSuccessfulFetchAt || new Date().toISOString()
    ),
  isSourceDue: isTechSourceDue,
  async syncDueSources() {
    const res = await syncDueTechnologySources();
    return { syncedSources: res.length };
  },
};

// ===========================================================================
// USER ACTIONS & STATE MUTATIONS (Always preserving user flags)
// ===========================================================================
export async function toggleVideoWatched(id: string): Promise<TechVideo[]> {
  await techStorage.init();
  const next = techStorage
    .getVideos()
    .map((v) => (v.id === id ? { ...v, isWatched: !v.isWatched } : v));
  await techStorage.saveVideos(next);
  return next;
}

export async function toggleVideoFavorite(id: string): Promise<TechVideo[]> {
  await techStorage.init();
  const next = techStorage
    .getVideos()
    .map((v) => (v.id === id ? { ...v, isFavorite: !v.isFavorite } : v));
  await techStorage.saveVideos(next);
  return next;
}

export async function unarchiveItemCheck(
  publishedAt: string | null,
  activeWindowDays: number
): Promise<{ staysArchivedByAge: boolean }> {
  return {
    staysArchivedByAge: isOlderThanActiveWindow(publishedAt, activeWindowDays),
  };
}

export async function toggleVideoArchive(
  id: string
): Promise<{ videos: TechVideo[]; staysArchivedNote: string | null }> {
  await techStorage.init();
  const settings = techStorage.getSettings();
  let staysArchivedNote: string | null = null;
  const next = techStorage.getVideos().map((v) => {
    if (v.id !== id) return v;
    if (v.isArchived) {
      if (isOlderThanActiveWindow(v.publishedAt, settings.activeWindowDays)) {
        staysArchivedNote = `Published date is older than ${settings.activeWindowDays} days, so this video remains in the Archive view rather than Latest.`;
        return v;
      }
      return { ...v, isArchived: false, archivedAt: null };
    }
    return { ...v, isArchived: true, archivedAt: new Date().toISOString() };
  });
  await techStorage.saveVideos(next);
  return { videos: next, staysArchivedNote };
}

export async function deleteVideoById(id: string): Promise<TechVideo[]> {
  await techStorage.init();
  const next = techStorage.getVideos().filter((v) => v.id !== id);
  await techStorage.saveVideos(next);
  return next;
}

export async function addManualVideo(input: {
  title: string;
  channelName: string;
  videoUrl: string;
  category: string;
  duration?: string;
  description?: string;
}): Promise<TechVideo[]> {
  await techStorage.init();
  const nowIso = new Date().toISOString();
  const cleanUrl = input.videoUrl.trim();
  const item: TechVideo = {
    id: `vid-manual-${Date.now()}`,
    videoId: `manual-${Date.now()}`,
    guid: `manual-video-${cleanUrl}-${Date.now()}`,
    title: input.title.trim(),
    description: input.description?.trim() || '',
    channelName: input.channelName.trim() || 'Red Hat TV',
    channelId: '',
    publishedAt: nowIso,
    updatedAt: null,
    dateStatus: 'valid',
    thumbnailUrl: null,
    videoUrl: cleanUrl,
    duration: input.duration?.trim() || null,
    durationSeconds: null,
    category: input.category.trim() || 'Red Hat',
    tags: ['manual', input.category.trim().toLowerCase() || 'video'],
    sourceId: 'vid-redhat-tv',
    matchedSourceIds: ['vid-redhat-tv'],
    playlistName: 'Manual Entries',
    fetchedAt: nowIso,
    isWatched: false,
    isFavorite: false,
    isArchived: false,
    archivedAt: null,
    isManual: true,
  };
  const next = [item, ...techStorage.getVideos()];
  await techStorage.saveVideos(next);
  return next;
}

// Podcasts
export async function togglePodcastSeriesFollow(
  seriesId: string
): Promise<PodcastSeries[]> {
  await techStorage.init();
  const next = techStorage
    .getPodcastSeries()
    .map((s) => (s.id === seriesId ? { ...s, isFollowed: !s.isFollowed } : s));
  await techStorage.savePodcastSeries(next);
  return next;
}

export async function togglePodcastEpisodePlayed(
  episodeId: string
): Promise<PodcastEpisode[]> {
  await techStorage.init();
  const next = techStorage
    .getPodcastEpisodes()
    .map((e) => (e.id === episodeId ? { ...e, isPlayed: !e.isPlayed } : e));
  await techStorage.savePodcastEpisodes(next);
  return next;
}

export async function togglePodcastEpisodeFavorite(
  episodeId: string
): Promise<PodcastEpisode[]> {
  await techStorage.init();
  const next = techStorage
    .getPodcastEpisodes()
    .map((e) => (e.id === episodeId ? { ...e, isFavorite: !e.isFavorite } : e));
  await techStorage.savePodcastEpisodes(next);
  return next;
}

export async function updateEpisodePlaybackPosition(
  episodeId: string,
  positionSeconds: number,
  markPlayedIfFinished: boolean = false
): Promise<void> {
  await techStorage.init();
  const next = techStorage.getPodcastEpisodes().map((e) =>
    e.id === episodeId
      ? {
          ...e,
          playbackPosition: Math.max(0, Math.floor(positionSeconds)),
          isPlayed: markPlayedIfFinished ? true : e.isPlayed,
        }
      : e
  );
  await techStorage.savePodcastEpisodes(next);
}

export async function togglePodcastEpisodeArchive(
  id: string
): Promise<{ episodes: PodcastEpisode[]; staysArchivedNote: string | null }> {
  await techStorage.init();
  const settings = techStorage.getSettings();
  let staysArchivedNote: string | null = null;
  const next = techStorage.getPodcastEpisodes().map((e) => {
    if (e.id !== id) return e;
    if (e.isArchived) {
      if (isOlderThanActiveWindow(e.publishedAt, settings.activeWindowDays)) {
        staysArchivedNote = `Episode published date is older than ${settings.activeWindowDays} days, so it remains in Archive.`;
        return e;
      }
      return { ...e, isArchived: false, archivedAt: null };
    }
    return { ...e, isArchived: true, archivedAt: new Date().toISOString() };
  });
  await techStorage.savePodcastEpisodes(next);
  return { episodes: next, staysArchivedNote };
}

export async function deletePodcastEpisodeById(
  id: string
): Promise<PodcastEpisode[]> {
  await techStorage.init();
  const next = techStorage.getPodcastEpisodes().filter((e) => e.id !== id);
  await techStorage.savePodcastEpisodes(next);
  return next;
}

// Learning
export async function setLearningItemStatus(
  id: string,
  learningStatus: LearningProgressStatus
): Promise<LearningItem[]> {
  await techStorage.init();
  const next = techStorage
    .getLearningItems()
    .map((l) => (l.id === id ? { ...l, learningStatus } : l));
  await techStorage.saveLearningItems(next);
  return next;
}

export async function toggleLearningFavorite(id: string): Promise<LearningItem[]> {
  await techStorage.init();
  const next = techStorage
    .getLearningItems()
    .map((l) => (l.id === id ? { ...l, isFavorite: !l.isFavorite } : l));
  await techStorage.saveLearningItems(next);
  return next;
}

export async function addManualLearningItem(input: {
  title: string;
  platform: string;
  url: string;
  category: string;
  contentType: LearningContentKind;
  level?: string;
  duration?: string;
  description?: string;
}): Promise<LearningItem[]> {
  await techStorage.init();
  const nowIso = new Date().toISOString();
  const item: LearningItem = {
    id: `learn-manual-${Date.now()}`,
    guid: `manual-learn-${input.url.trim()}-${Date.now()}`,
    title: input.title.trim(),
    description: input.description?.trim() || '',
    platform: input.platform.trim() || 'Manual Resource',
    category: input.category.trim() || 'DevOps',
    contentType: input.contentType,
    level: input.level?.trim() || null,
    duration: input.duration?.trim() || null,
    url: input.url.trim(),
    sourceId: 'learn-manual',
    matchedSourceIds: ['learn-manual'],
    tags: [input.contentType, input.platform.toLowerCase()],
    publishedAt: nowIso,
    updatedAt: null,
    dateStatus: 'valid',
    learningStatus: 'not-started',
    isFavorite: false,
    isArchived: false,
    archivedAt: null,
    fetchedAt: nowIso,
    isManual: true,
  };
  const next = [item, ...techStorage.getLearningItems()];
  await techStorage.saveLearningItems(next);
  return next;
}

export async function deleteLearningItemById(id: string): Promise<LearningItem[]> {
  await techStorage.init();
  const next = techStorage.getLearningItems().filter((l) => l.id !== id);
  await techStorage.saveLearningItems(next);
  return next;
}

// Security
export async function toggleSecurityRead(id: string): Promise<SecurityRecord[]> {
  await techStorage.init();
  const next = techStorage
    .getSecurityRecords()
    .map((r) => (r.id === id ? { ...r, isRead: !r.isRead } : r));
  await techStorage.saveSecurityRecords(next);
  return next;
}

export async function toggleSecurityFavorite(
  id: string
): Promise<SecurityRecord[]> {
  await techStorage.init();
  const next = techStorage
    .getSecurityRecords()
    .map((r) => (r.id === id ? { ...r, isFavorite: !r.isFavorite } : r));
  await techStorage.saveSecurityRecords(next);
  return next;
}

export async function deleteSecurityRecordById(
  id: string
): Promise<SecurityRecord[]> {
  await techStorage.init();
  const next = techStorage.getSecurityRecords().filter((r) => r.id !== id);
  await techStorage.saveSecurityRecords(next);
  return next;
}

// Events
export async function toggleEventFavorite(id: string): Promise<TechEvent[]> {
  await techStorage.init();
  const next = techStorage
    .getEvents()
    .map((e) => (e.id === id ? { ...e, isFavorite: !e.isFavorite } : e));
  await techStorage.saveEvents(next);
  return next;
}

export async function addManualEvent(input: {
  eventName: string;
  organizer: string;
  startDate?: string;
  endDate?: string;
  location?: string;
  eventType: TechEventType;
  registrationUrl: string;
  description?: string;
}): Promise<TechEvent[]> {
  await techStorage.init();
  const nowIso = new Date().toISOString();
  const parsedStart = parseStrictPublishedDate(input.startDate);
  const parsedEnd = parseStrictPublishedDate(input.endDate);
  const nowMs = Date.now();
  let status: TechEventStatus = 'unknown';
  if (parsedStart.publishedAt) {
    const startMs = Date.parse(parsedStart.publishedAt);
    const endMs = parsedEnd.publishedAt
      ? Date.parse(parsedEnd.publishedAt)
      : startMs + 86400_000;
    if (endMs < nowMs) status = 'past';
    else if (startMs <= nowMs && endMs >= nowMs) status = 'ongoing';
    else status = 'upcoming';
  }

  const evt: TechEvent = {
    id: `evt-manual-${Date.now()}`,
    guid: `manual-evt-${input.eventName}-${Date.now()}`,
    eventName: input.eventName.trim(),
    organizer: input.organizer.trim(),
    startDate: parsedStart.publishedAt,
    endDate: parsedEnd.publishedAt,
    publishedAt: parsedStart.publishedAt || nowIso,
    dateStatus: parsedStart.publishedAt ? 'valid' : 'unknown',
    location: input.location?.trim() || null,
    eventType: input.eventType,
    description: input.description?.trim() || '',
    registrationUrl: input.registrationUrl.trim(),
    sourceUrl: input.registrationUrl.trim(),
    sourceId: 'evt-manual',
    matchedSourceIds: ['evt-manual'],
    tags: [input.eventType, input.organizer.toLowerCase()],
    status,
    isFavorite: false,
    isArchived: status === 'past',
    archivedAt: status === 'past' ? nowIso : null,
    fetchedAt: nowIso,
    isManual: true,
  };
  const next = [evt, ...techStorage.getEvents()];
  await techStorage.saveEvents(next);
  return next;
}

export async function deleteEventById(id: string): Promise<TechEvent[]> {
  await techStorage.init();
  const next = techStorage.getEvents().filter((e) => e.id !== id);
  await techStorage.saveEvents(next);
  return next;
}

// Source Management CRUD (never deletes collected items when a source is deleted!)
export async function addCustomTechSource(input: {
  name: string;
  description: string;
  websiteUrl: string;
  feedUrl: string;
  channelId?: string;
  sourceType: TechSource['sourceType'];
  contentType: TechSource['contentType'];
  category: string;
  tags: string[];
  syncInterval: number;
}): Promise<TechSource[]> {
  await techStorage.init();
  const nowIso = new Date().toISOString();
  const newSource: TechSource = {
    id: `custom-${input.contentType}-${Date.now()}`,
    name: input.name.trim(),
    description: input.description.trim(),
    websiteUrl: input.websiteUrl.trim(),
    feedUrl: input.feedUrl.trim(),
    channelId: input.channelId?.trim() || undefined,
    sourceType: input.sourceType,
    contentType: input.contentType,
    category: input.category.trim() || 'General',
    tags: input.tags,
    enabled: input.sourceType !== 'unsupported' && input.sourceType !== 'manual',
    syncInterval: input.syncInterval,
    lastFetchedAt: null,
    lastSuccessfulFetchAt: null,
    nextFetchAt: null,
    status:
      input.sourceType === 'unsupported' || input.sourceType === 'manual'
        ? 'unsupported'
        : 'idle',
    errorMessage: null,
    consecutiveFailures: 0,
    itemCount: 0,
    createdAt: nowIso,
    updatedAt: nowIso,
  };
  const next = [...techStorage.getSources(), newSource];
  await techStorage.saveSources(next);
  return next;
}

export async function updateTechSource(
  sourceId: string,
  patch: Partial<TechSource>
): Promise<TechSource[]> {
  await techStorage.init();
  const nowIso = new Date().toISOString();
  const next = techStorage.getSources().map((s) =>
    s.id === sourceId ? { ...s, ...patch, updatedAt: nowIso } : s
  );
  await techStorage.saveSources(next);
  return next;
}

export async function deleteTechSourceDefinitionOnly(
  sourceId: string
): Promise<TechSource[]> {
  await techStorage.init();
  // Explicitly ONLY removes the source definition; stored videos/podcasts/etc. stay intact.
  const next = techStorage.getSources().filter((s) => s.id !== sourceId);
  await techStorage.saveSources(next);
  return next;
}

export async function testTechFeedUrl(
  feedUrl: string,
  timeoutMs: number = 15_000
): Promise<{ ok: boolean; message: string; durationMs: number }> {
  const res = await activeTransport.fetchFeed(feedUrl, timeoutMs);
  if (!res.ok) {
    return {
      ok: false,
      message: res.errorMessage || `HTTP ${res.httpStatus}`,
      durationMs: res.durationMs,
    };
  }
  return {
    ok: true,
    message: `Valid feed payload received (${res.payload.length.toLocaleString()} bytes).`,
    durationMs: res.durationMs,
  };
}
