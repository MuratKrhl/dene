import { normalizeArticleUrl } from '../articles/adapters/sanitizeHtml';

export interface DeduplicatableRecord {
  id: string;
  guid: string;
  externalId?: string | null;
  url?: string | null;
  sourceId: string;
  matchedSourceIds: string[];
  tags: string[];
}

export function buildDedupKeys(record: DeduplicatableRecord): string[] {
  const keys: string[] = [];
  if (record.guid && record.guid.trim()) {
    keys.push(`guid:${record.guid.trim().toLowerCase()}`);
  }
  if (record.externalId && record.externalId.trim()) {
    keys.push(`ext:${record.externalId.trim().toLowerCase()}`);
  }
  if (record.url && record.url.trim()) {
    const norm = normalizeArticleUrl(record.url);
    if (norm) {
      keys.push(`url:${norm.toLowerCase()}`);
    }
  }
  keys.push(`src:${record.sourceId.toLowerCase()}::${record.id.toLowerCase()}`);
  return keys;
}

/**
 * Deduplicates incoming records against existing ones using priority:
 * 1. GUID
 * 2. External Content ID (videoId / cveId / etc.)
 * 3. Normalized Original URL
 * 4. Source-scoped unique ID
 *
 * Strictly preserves user state via `mergeIntoExisting`.
 */
export function deduplicateRecords<T extends DeduplicatableRecord>(
  existing: T[],
  incoming: T[],
  mergeIntoExisting: (current: T, next: T) => { merged: T; changed: boolean }
): {
  nextRecords: T[];
  newCount: number;
  duplicatesSkipped: number;
  updatedCount: number;
} {
  const working = [...existing];
  const keyToIndex = new Map<string, number>();

  working.forEach((rec, idx) => {
    for (const k of buildDedupKeys(rec)) {
      if (!keyToIndex.has(k)) {
        keyToIndex.set(k, idx);
      }
    }
  });

  let newCount = 0;
  let duplicatesSkipped = 0;
  let updatedCount = 0;

  for (const item of incoming) {
    const keys = buildDedupKeys(item);
    let foundIdx: number | undefined;
    for (const k of keys) {
      const hit = keyToIndex.get(k);
      if (hit !== undefined) {
        foundIdx = hit;
        break;
      }
    }

    if (foundIdx !== undefined) {
      duplicatesSkipped += 1;
      const current = working[foundIdx];
      const { merged, changed } = mergeIntoExisting(current, item);
      if (changed) {
        updatedCount += 1;
      }
      working[foundIdx] = merged;
      for (const k of buildDedupKeys(merged)) {
        if (!keyToIndex.has(k)) {
          keyToIndex.set(k, foundIdx);
        }
      }
    } else {
      const newIdx = working.length;
      working.push(item);
      newCount += 1;
      for (const k of keys) {
        if (!keyToIndex.has(k)) {
          keyToIndex.set(k, newIdx);
        }
      }
    }
  }

  return {
    nextRecords: working,
    newCount,
    duplicatesSkipped,
    updatedCount,
  };
}

export function mergeTagsAndSources(
  aTags: string[],
  bTags: string[],
  aSources: string[],
  bSources: string[]
): { tags: string[]; matchedSourceIds: string[] } {
  return {
    tags: Array.from(new Set([...aTags, ...bTags])).slice(0, 16),
    matchedSourceIds: Array.from(new Set([...aSources, ...bSources])),
  };
}
