import {
  DEFAULT_TECH_SETTINGS,
  INITIAL_TECH_SOURCES,
  TECH_SCHEMA_VERSION,
} from '../../data/technologySources';
import {
  LearningItem,
  PodcastEpisode,
  PodcastPlayerState,
  PodcastSeries,
  SecurityRecord,
  TechEvent,
  TechnologyBackupPayload,
  TechSettings,
  TechSource,
  TechSyncHistoryEntry,
  TechVideo,
} from '../../types/technology';

const DB_NAME = 'mk-workspace-technology-db-v1';
const DB_VERSION = 1;

const STORES = {
  SOURCES: 'sources',
  VIDEOS: 'videos',
  PODCAST_SERIES: 'podcastSeries',
  PODCAST_EPISODES: 'podcastEpisodes',
  LEARNING: 'learningItems',
  SECURITY: 'securityRecords',
  EVENTS: 'events',
  SYNC_HISTORY: 'syncHistory',
  META: 'meta',
} as const;

const META_SETTINGS_KEY = 'techSettings';
const META_PLAYER_KEY = 'podcastPlayerState';
const META_SCHEMA_KEY = 'schemaVersion';

const LS_FALLBACK_KEY = 'mk-workspace-technology-fallback-v1';
const MAX_SYNC_HISTORY = 200;

const DEFAULT_PLAYER_STATE: PodcastPlayerState = {
  currentEpisodeId: null,
  currentSeriesId: null,
  volume: 0.9,
  playbackRate: 1,
  lastUpdatedAt: null,
};

function mergeCanonicalSources(saved: TechSource[]): TechSource[] {
  const savedById = new Map(saved.map((s) => [s.id, s]));
  const canonicalIds = new Set(INITIAL_TECH_SOURCES.map((s) => s.id));

  const mergedCanonical = INITIAL_TECH_SOURCES.map((def) => {
    const existing = savedById.get(def.id);
    if (!existing) return { ...def };
    if (def.sourceType === 'unsupported' || def.sourceType === 'manual') {
      return {
        ...def,
        lastFetchedAt: existing.lastFetchedAt || null,
        lastSuccessfulFetchAt: existing.lastSuccessfulFetchAt || null,
        itemCount: existing.itemCount || 0,
      };
    }
    return {
      ...def,
      enabled:
        typeof existing.enabled === 'boolean' ? existing.enabled : def.enabled,
      syncInterval:
        typeof existing.syncInterval === 'number'
          ? existing.syncInterval
          : def.syncInterval,
      lastFetchedAt: existing.lastFetchedAt || null,
      lastSuccessfulFetchAt: existing.lastSuccessfulFetchAt || null,
      nextFetchAt: existing.nextFetchAt || null,
      status: existing.status === 'syncing' ? 'idle' : existing.status || 'idle',
      errorMessage: existing.errorMessage || null,
      consecutiveFailures: existing.consecutiveFailures || 0,
      itemCount: existing.itemCount || 0,
      updatedAt: existing.updatedAt || def.updatedAt,
    };
  });

  // Preserve user-added custom sources
  const customSources = saved.filter((s) => !canonicalIds.has(s.id));
  return [...mergedCanonical, ...customSources];
}

class TechnologyStorageService {
  private initialized = false;
  private initPromise: Promise<void> | null = null;

  private sources: TechSource[] = mergeCanonicalSources([]);
  private videos: TechVideo[] = [];
  private podcastSeries: PodcastSeries[] = [];
  private podcastEpisodes: PodcastEpisode[] = [];
  private learningItems: LearningItem[] = [];
  private securityRecords: SecurityRecord[] = [];
  private events: TechEvent[] = [];
  private syncHistory: TechSyncHistoryEntry[] = [];
  private settings: TechSettings = { ...DEFAULT_TECH_SETTINGS };
  private playerState: PodcastPlayerState = { ...DEFAULT_PLAYER_STATE };

  private hasIndexedDb(): boolean {
    try {
      return typeof window !== 'undefined' && typeof window.indexedDB !== 'undefined';
    } catch {
      return false;
    }
  }

  private hasLocalStorage(): boolean {
    try {
      return (
        typeof window !== 'undefined' && typeof window.localStorage !== 'undefined'
      );
    } catch {
      return false;
    }
  }

  private openDb(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const req = window.indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        const entityStores = [
          STORES.SOURCES,
          STORES.VIDEOS,
          STORES.PODCAST_SERIES,
          STORES.PODCAST_EPISODES,
          STORES.LEARNING,
          STORES.SECURITY,
          STORES.EVENTS,
        ];
        for (const name of entityStores) {
          if (!db.objectStoreNames.contains(name)) {
            db.createObjectStore(name, { keyPath: 'id' });
          }
        }
        if (!db.objectStoreNames.contains(STORES.SYNC_HISTORY)) {
          db.createObjectStore(STORES.SYNC_HISTORY, { keyPath: 'syncId' });
        }
        if (!db.objectStoreNames.contains(STORES.META)) {
          db.createObjectStore(STORES.META, { keyPath: 'key' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () =>
        reject(req.error || new Error('Failed to open Technology IndexedDB.'));
    });
  }

  private idbGetAll<T>(db: IDBDatabase, storeName: string): Promise<T[]> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const req = tx.objectStore(storeName).getAll();
      req.onsuccess = () =>
        resolve(Array.isArray(req.result) ? (req.result as T[]) : []);
      req.onerror = () => reject(req.error);
    });
  }

  private idbReplaceAll<T>(
    db: IDBDatabase,
    storeName: string,
    records: T[]
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.clear();
      for (const rec of records) {
        store.put(rec);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  private idbGetMeta<T>(db: IDBDatabase, key: string): Promise<T | null> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.META, 'readonly');
      const req = tx.objectStore(STORES.META).get(key);
      req.onsuccess = () => {
        const row = req.result as { key: string; value: T } | undefined;
        resolve(row ? row.value : null);
      };
      req.onerror = () => reject(req.error);
    });
  }

  private idbSetMeta<T>(db: IDBDatabase, key: string, value: T): Promise<void> {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.META, 'readwrite');
      tx.objectStore(STORES.META).put({ key, value });
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  private persistFallbackSnapshot(): void {
    if (!this.hasLocalStorage()) return;
    try {
      const payload = {
        schemaVersion: TECH_SCHEMA_VERSION,
        sources: this.sources,
        videos: this.videos,
        podcastSeries: this.podcastSeries,
        podcastEpisodes: this.podcastEpisodes,
        learningItems: this.learningItems,
        securityRecords: this.securityRecords,
        events: this.events,
        syncHistory: this.syncHistory,
        settings: this.settings,
        playerState: this.playerState,
      };
      window.localStorage.setItem(LS_FALLBACK_KEY, JSON.stringify(payload));
    } catch {
      // Ignore quota fallback error
    }
  }

  private loadFallbackSnapshot(): void {
    if (!this.hasLocalStorage()) return;
    try {
      const raw = window.localStorage.getItem(LS_FALLBACK_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as Partial<TechnologyBackupPayload>;
      if (Array.isArray(parsed.sources)) {
        this.sources = mergeCanonicalSources(parsed.sources);
      }
      if (Array.isArray(parsed.videos)) this.videos = parsed.videos;
      if (Array.isArray(parsed.podcastSeries))
        this.podcastSeries = parsed.podcastSeries;
      if (Array.isArray(parsed.podcastEpisodes))
        this.podcastEpisodes = parsed.podcastEpisodes;
      if (Array.isArray(parsed.learningItems))
        this.learningItems = parsed.learningItems;
      if (Array.isArray(parsed.securityRecords))
        this.securityRecords = parsed.securityRecords;
      if (Array.isArray(parsed.events)) this.events = parsed.events;
      if (Array.isArray(parsed.syncHistory)) this.syncHistory = parsed.syncHistory;
      if (parsed.settings) {
        this.settings = { ...DEFAULT_TECH_SETTINGS, ...parsed.settings };
      }
      if (parsed.playerState) {
        this.playerState = { ...DEFAULT_PLAYER_STATE, ...parsed.playerState };
      }
    } catch {
      // Keep defaults
    }
  }

  async init(): Promise<void> {
    if (this.initialized) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      let db: IDBDatabase | null = null;
      if (this.hasIndexedDb()) {
        try {
          db = await this.openDb();
          const [
            sources,
            videos,
            podcastSeries,
            podcastEpisodes,
            learningItems,
            securityRecords,
            events,
            syncHistory,
            settings,
            playerState,
          ] = await Promise.all([
            this.idbGetAll<TechSource>(db, STORES.SOURCES),
            this.idbGetAll<TechVideo>(db, STORES.VIDEOS),
            this.idbGetAll<PodcastSeries>(db, STORES.PODCAST_SERIES),
            this.idbGetAll<PodcastEpisode>(db, STORES.PODCAST_EPISODES),
            this.idbGetAll<LearningItem>(db, STORES.LEARNING),
            this.idbGetAll<SecurityRecord>(db, STORES.SECURITY),
            this.idbGetAll<TechEvent>(db, STORES.EVENTS),
            this.idbGetAll<TechSyncHistoryEntry>(db, STORES.SYNC_HISTORY),
            this.idbGetMeta<TechSettings>(db, META_SETTINGS_KEY),
            this.idbGetMeta<PodcastPlayerState>(db, META_PLAYER_KEY),
          ]);

          this.sources = mergeCanonicalSources(sources);
          this.videos = videos;
          this.podcastSeries = podcastSeries;
          this.podcastEpisodes = podcastEpisodes;
          this.learningItems = learningItems;
          this.securityRecords = securityRecords;
          this.events = events;
          this.syncHistory = syncHistory.sort(
            (a, b) => Date.parse(b.startedAt) - Date.parse(a.startedAt)
          );
          this.settings = { ...DEFAULT_TECH_SETTINGS, ...(settings || {}) };
          this.playerState = { ...DEFAULT_PLAYER_STATE, ...(playerState || {}) };

          await this.idbSetMeta(db, META_SCHEMA_KEY, TECH_SCHEMA_VERSION);
        } catch (err) {
          console.warn(
            '[techStorage] IndexedDB unavailable, falling back to localStorage:',
            err
          );
          this.loadFallbackSnapshot();
        } finally {
          if (db) db.close();
        }
      } else {
        this.loadFallbackSnapshot();
      }
      this.initialized = true;
    })();

    try {
      await this.initPromise;
    } finally {
      this.initPromise = null;
    }
  }

  getSources = () => this.sources;
  getVideos = () => this.videos;
  getPodcastSeries = () => this.podcastSeries;
  getPodcastEpisodes = () => this.podcastEpisodes;
  getLearningItems = () => this.learningItems;
  getSecurityRecords = () => this.securityRecords;
  getEvents = () => this.events;
  getSyncHistory = () => this.syncHistory;
  getSettings = () => this.settings;
  getPlayerState = () => this.playerState;

  private async saveStore<T>(storeName: string, data: T[]): Promise<void> {
    if (this.hasIndexedDb()) {
      try {
        const db = await this.openDb();
        await this.idbReplaceAll(db, storeName, data);
        db.close();
        return;
      } catch (err) {
        console.warn(`[techStorage] Failed writing ${storeName}:`, err);
      }
    }
    this.persistFallbackSnapshot();
  }

  async saveSources(sources: TechSource[]): Promise<void> {
    this.sources = sources;
    await this.saveStore(STORES.SOURCES, sources);
  }

  async saveVideos(videos: TechVideo[]): Promise<void> {
    this.videos = videos;
    await this.saveStore(STORES.VIDEOS, videos);
  }

  async savePodcastSeries(series: PodcastSeries[]): Promise<void> {
    this.podcastSeries = series;
    await this.saveStore(STORES.PODCAST_SERIES, series);
  }

  async savePodcastEpisodes(episodes: PodcastEpisode[]): Promise<void> {
    this.podcastEpisodes = episodes;
    await this.saveStore(STORES.PODCAST_EPISODES, episodes);
  }

  async saveLearningItems(items: LearningItem[]): Promise<void> {
    this.learningItems = items;
    await this.saveStore(STORES.LEARNING, items);
  }

  async saveSecurityRecords(records: SecurityRecord[]): Promise<void> {
    this.securityRecords = records;
    await this.saveStore(STORES.SECURITY, records);
  }

  async saveEvents(events: TechEvent[]): Promise<void> {
    this.events = events;
    await this.saveStore(STORES.EVENTS, events);
  }

  async appendSyncHistory(entries: TechSyncHistoryEntry[]): Promise<void> {
    const next = [...entries, ...this.syncHistory].slice(0, MAX_SYNC_HISTORY);
    this.syncHistory = next;
    await this.saveStore(STORES.SYNC_HISTORY, next);
  }

  async clearSyncHistory(): Promise<void> {
    this.syncHistory = [];
    await this.saveStore(STORES.SYNC_HISTORY, []);
  }

  async saveSettings(settings: TechSettings): Promise<void> {
    this.settings = { ...DEFAULT_TECH_SETTINGS, ...settings, schemaVersion: TECH_SCHEMA_VERSION };
    if (this.hasIndexedDb()) {
      try {
        const db = await this.openDb();
        await this.idbSetMeta(db, META_SETTINGS_KEY, this.settings);
        db.close();
        return;
      } catch (err) {
        console.warn('[techStorage] Failed saving settings:', err);
      }
    }
    this.persistFallbackSnapshot();
  }

  async savePlayerState(state: PodcastPlayerState): Promise<void> {
    this.playerState = { ...state, lastUpdatedAt: new Date().toISOString() };
    if (this.hasIndexedDb()) {
      try {
        const db = await this.openDb();
        await this.idbSetMeta(db, META_PLAYER_KEY, this.playerState);
        db.close();
        return;
      } catch {
        // Ignore transient write error during playback ticks
      }
    }
    this.persistFallbackSnapshot();
  }

  exportBackup(): TechnologyBackupPayload {
    return {
      exportedAt: new Date().toISOString(),
      schemaVersion: TECH_SCHEMA_VERSION,
      sources: this.sources,
      videos: this.videos,
      podcastSeries: this.podcastSeries,
      podcastEpisodes: this.podcastEpisodes,
      learningItems: this.learningItems,
      securityRecords: this.securityRecords,
      events: this.events,
      syncHistory: this.syncHistory,
      settings: this.settings,
      playerState: this.playerState,
    };
  }

  async restoreBackup(payload: TechnologyBackupPayload): Promise<void> {
    if (!payload || typeof payload !== 'object' || payload.schemaVersion !== TECH_SCHEMA_VERSION) {
      throw new Error('Incompatible or invalid Technology Center backup format.');
    }
    // Backup snapshot safely before replacing
    const preRestoreSnapshot = this.exportBackup();
    try {
      await Promise.all([
        this.saveSources(
          Array.isArray(payload.sources)
            ? mergeCanonicalSources(payload.sources)
            : this.sources
        ),
        this.saveVideos(Array.isArray(payload.videos) ? payload.videos : []),
        this.savePodcastSeries(
          Array.isArray(payload.podcastSeries) ? payload.podcastSeries : []
        ),
        this.savePodcastEpisodes(
          Array.isArray(payload.podcastEpisodes) ? payload.podcastEpisodes : []
        ),
        this.saveLearningItems(
          Array.isArray(payload.learningItems) ? payload.learningItems : []
        ),
        this.saveSecurityRecords(
          Array.isArray(payload.securityRecords) ? payload.securityRecords : []
        ),
        this.saveEvents(Array.isArray(payload.events) ? payload.events : []),
        this.saveSettings(payload.settings || DEFAULT_TECH_SETTINGS),
      ]);
      if (Array.isArray(payload.syncHistory)) {
        this.syncHistory = payload.syncHistory.slice(0, MAX_SYNC_HISTORY);
        await this.saveStore(STORES.SYNC_HISTORY, this.syncHistory);
      }
    } catch (err) {
      // Roll back on failure
      await this.saveSources(preRestoreSnapshot.sources);
      await this.saveVideos(preRestoreSnapshot.videos);
      await this.savePodcastSeries(preRestoreSnapshot.podcastSeries);
      await this.savePodcastEpisodes(preRestoreSnapshot.podcastEpisodes);
      await this.saveLearningItems(preRestoreSnapshot.learningItems);
      await this.saveSecurityRecords(preRestoreSnapshot.securityRecords);
      await this.saveEvents(preRestoreSnapshot.events);
      throw err;
    }
  }

  estimateStorageBreakdown(): {
    totalBytes: number;
    counts: Record<string, number>;
  } {
    const counts = {
      sources: this.sources.length,
      videos: this.videos.length,
      podcastSeries: this.podcastSeries.length,
      podcastEpisodes: this.podcastEpisodes.length,
      learningItems: this.learningItems.length,
      securityRecords: this.securityRecords.length,
      events: this.events.length,
      syncHistory: this.syncHistory.length,
    };
    const totalBytes = JSON.stringify(this.exportBackup()).length * 2;
    return { totalBytes, counts };
  }

  resetForTest(): void {
    this.initialized = false;
    this.initPromise = null;
    this.sources = mergeCanonicalSources([]);
    this.videos = [];
    this.podcastSeries = [];
    this.podcastEpisodes = [];
    this.learningItems = [];
    this.securityRecords = [];
    this.events = [];
    this.syncHistory = [];
    this.settings = { ...DEFAULT_TECH_SETTINGS };
    this.playerState = { ...DEFAULT_PLAYER_STATE };
  }
}

export const techStorage = new TechnologyStorageService();
