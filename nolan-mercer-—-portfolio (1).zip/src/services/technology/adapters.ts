import {
  LearningContentKind,
  LearningItem,
  PodcastEpisode,
  PodcastSeries,
  SecurityRecord,
  SecurityRecordKind,
  SecuritySeverity,
  TechEvent,
  TechSource,
  TechVideo,
} from '../../types/technology';
import {
  normalizeArticleUrl,
  sanitizeFeedHtmlToText,
} from '../articles/adapters/sanitizeHtml';
import { parseAtomFeed } from '../articles/adapters/atomAdapter';
import { parseRssFeed } from '../articles/adapters/rssAdapter';
import {
  isOlderThanActiveWindow,
  parseStrictPublishedDate,
} from './retentionEngine';

function decodeXmlEntities(input: string): string {
  return input
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x([0-9a-fA-F]+);/g, (_m, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    )
    .replace(/&#(\d+);/g, (_m, dec) => String.fromCharCode(Number(dec)))
    .trim();
}

function extractFirstTagText(xml: string, tagNames: string[]): string {
  for (const tag of tagNames) {
    const escaped = tag.replace(':', '\\:');
    const re = new RegExp(`<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)</${escaped}>`, 'i');
    const m = re.exec(xml);
    if (m && m[1]) {
      const cleaned = decodeXmlEntities(m[1]).replace(/<[^>]+>/g, '').trim();
      if (cleaned) return cleaned;
    }
  }
  return '';
}

function extractRawTagInner(xml: string, tagNames: string[]): string {
  for (const tag of tagNames) {
    const escaped = tag.replace(':', '\\:');
    const re = new RegExp(`<${escaped}(?:\\s[^>]*)?>([\\s\\S]*?)</${escaped}>`, 'i');
    const m = re.exec(xml);
    if (m && m[1]) return m[1];
  }
  return '';
}

function extractAttr(tagXml: string, attrName: string): string | null {
  const re = new RegExp(`${attrName}\\s*=\\s*["']([^"']+)["']`, 'i');
  const m = re.exec(tagXml);
  return m && m[1] ? decodeXmlEntities(m[1]) : null;
}

function makeStableId(prefix: string, rawKey: string): string {
  let hash = 2166136261;
  for (let i = 0; i < rawKey.length; i += 1) {
    hash ^= rawKey.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return `${prefix}-${(hash >>> 0).toString(36)}`;
}

export function formatIsoDurationToClock(isoDuration: string | null): {
  formatted: string | null;
  seconds: number | null;
} {
  if (!isoDuration) return { formatted: null, seconds: null };
  const m = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/i.exec(isoDuration.trim());
  if (!m) return { formatted: null, seconds: null };
  const h = Number(m[1] || 0);
  const min = Number(m[2] || 0);
  const s = Number(m[3] || 0);
  const totalSeconds = h * 3600 + min * 60 + s;
  if (totalSeconds <= 0) return { formatted: null, seconds: null };
  const formatted =
    h > 0
      ? `${h}:${String(min).padStart(2, '0')}:${String(s).padStart(2, '0')}`
      : `${min}:${String(s).padStart(2, '0')}`;
  return { formatted, seconds: totalSeconds };
}

export function normalizeDurationString(raw: string | null | undefined): {
  formatted: string | null;
  seconds: number | null;
} {
  if (!raw || !raw.trim()) return { formatted: null, seconds: null };
  const trimmed = raw.trim();
  if (/^\d+$/.test(trimmed)) {
    const total = Number(trimmed);
    if (!Number.isFinite(total) || total <= 0)
      return { formatted: null, seconds: null };
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    return {
      formatted:
        h > 0
          ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
          : `${m}:${String(s).padStart(2, '0')}`,
      seconds: total,
    };
  }
  const parts = trimmed.split(':').map((p) => Number(p));
  if (parts.every((n) => !Number.isNaN(n) && n >= 0)) {
    if (parts.length === 2) {
      return {
        formatted: `${parts[0]}:${String(parts[1]).padStart(2, '0')}`,
        seconds: parts[0] * 60 + parts[1],
      };
    }
    if (parts.length === 3) {
      return {
        formatted: `${parts[0]}:${String(parts[1]).padStart(2, '0')}:${String(parts[2]).padStart(2, '0')}`,
        seconds: parts[0] * 3600 + parts[1] * 60 + parts[2],
      };
    }
  }
  return { formatted: trimmed, seconds: null };
}

// ===========================================================================
// 1. VIDEO ADAPTERS (YouTube Data API JSON + YouTube Atom XML)
// ===========================================================================
export interface YouTubeApiProxyResponse {
  ok: boolean;
  mode: 'youtube-data-api';
  channelId: string;
  channelTitle: string;
  items: Array<{
    videoId: string;
    title: string;
    description: string;
    channelName: string;
    channelId: string;
    publishedAt: string | null;
    thumbnailUrl: string | null;
    videoUrl: string;
    isoDuration: string | null;
  }>;
}

export function parseYouTubePayloadToVideos(
  payload: string,
  source: TechSource,
  activeWindowDays: number
): TechVideo[] {
  const nowIso = new Date().toISOString();
  const trimmed = payload.trim();

  if (trimmed.startsWith('{')) {
    const parsed = JSON.parse(trimmed) as YouTubeApiProxyResponse;
    if (!parsed || !Array.isArray(parsed.items)) {
      throw new Error('Invalid YouTube API proxy JSON response.');
    }
    return parsed.items
      .filter((item) => item.title && item.videoUrl)
      .map((item) => {
        const { publishedAt, dateStatus } = parseStrictPublishedDate(
          item.publishedAt
        );
        const archived =
          dateStatus === 'valid' &&
          isOlderThanActiveWindow(publishedAt, activeWindowDays);
        const { formatted, seconds } = formatIsoDurationToClock(
          item.isoDuration
        );
        const cleanUrl = normalizeArticleUrl(item.videoUrl);
        const safeThumb =
          item.thumbnailUrl && /^https?:\/\//i.test(item.thumbnailUrl.trim())
            ? item.thumbnailUrl.trim()
            : null;
        return {
          id: makeStableId('vid', item.videoId || cleanUrl),
          videoId: item.videoId,
          guid: `yt:video:${item.videoId || cleanUrl}`,
          title: item.title.trim(),
          description: sanitizeFeedHtmlToText(item.description || '').summary,
          channelName: item.channelName || source.name,
          channelId: item.channelId || source.channelId || '',
          publishedAt,
          updatedAt: null,
          dateStatus,
          thumbnailUrl: safeThumb,
          videoUrl: cleanUrl,
          duration: formatted,
          durationSeconds: seconds,
          category: source.category,
          tags: [...source.tags],
          sourceId: source.id,
          matchedSourceIds: [source.id],
          playlistName: `${source.name} Uploads`,
          fetchedAt: nowIso,
          isWatched: false,
          isFavorite: false,
          isArchived: archived,
          archivedAt: archived ? nowIso : null,
        };
      });
  }

  // Official YouTube Atom XML Feed parser
  const entryRegex = /<entry\b[^>]*>([\s\S]*?)<\/entry>/gi;
  const channelTitle =
    extractFirstTagText(trimmed, ['title']) || source.name;
  const videos: TechVideo[] = [];

  let match: RegExpExecArray | null;
  while ((match = entryRegex.exec(trimmed)) !== null) {
    const entryXml = match[1];
    const videoId = extractFirstTagText(entryXml, ['yt:videoId']);
    const channelId =
      extractFirstTagText(entryXml, ['yt:channelId']) || source.channelId || '';
    const title = extractFirstTagText(entryXml, ['title']);
    const pubRaw = extractFirstTagText(entryXml, ['published']);
    const updRaw = extractFirstTagText(entryXml, ['updated']);
    const linkMatch = /<link\b[^>]*href=["']([^"']+)["'][^>]*>/i.exec(entryXml);
    const videoUrl = normalizeArticleUrl(
      (linkMatch && linkMatch[1]) ||
        (videoId ? `https://www.youtube.com/watch?v=${videoId}` : '')
    );
    const thumbMatch = /<media:thumbnail\b[^>]*url=["']([^"']+)["']/i.exec(
      entryXml
    );
    const descRaw = extractFirstTagText(entryXml, ['media:description']);

    if (!title || !videoUrl) continue;

    const { publishedAt, dateStatus } = parseStrictPublishedDate(pubRaw);
    const { publishedAt: updatedAt } = parseStrictPublishedDate(updRaw);
    const archived =
      dateStatus === 'valid' &&
      isOlderThanActiveWindow(publishedAt, activeWindowDays);

    videos.push({
      id: makeStableId('vid', videoId || videoUrl),
      videoId: videoId || makeStableId('yt', videoUrl),
      guid: `yt:video:${videoId || videoUrl}`,
      title,
      description: sanitizeFeedHtmlToText(descRaw).summary,
      channelName: channelTitle,
      channelId,
      publishedAt,
      updatedAt,
      dateStatus,
      thumbnailUrl: thumbMatch ? thumbMatch[1] : null,
      videoUrl,
      duration: null, // YouTube Atom does not expose duration; never fabricate
      durationSeconds: null,
      category: source.category,
      tags: [...source.tags],
      sourceId: source.id,
      matchedSourceIds: [source.id],
      playlistName: `${channelTitle} Uploads`,
      fetchedAt: nowIso,
      isWatched: false,
      isFavorite: false,
      isArchived: archived,
      archivedAt: archived ? nowIso : null,
    });
  }

  if (videos.length === 0) {
    throw new Error('YouTube channel feed returned zero playable video entries.');
  }
  return videos;
}

// ===========================================================================
// 2. PODCAST RSS ADAPTER (Series + Episodes with real enclosures & artwork)
// ===========================================================================
export function parsePodcastRssFeed(
  xml: string,
  source: TechSource,
  activeWindowDays: number,
  maxEpisodes: number = 25
): { series: PodcastSeries; episodes: PodcastEpisode[] } {
  const channelMatch = /<channel\b[^>]*>([\s\S]*?)<\/channel>/i.exec(xml);
  const channelBody = channelMatch ? channelMatch[1] : xml;
  const firstItemIdx = channelBody.search(/<item\b/i);
  const channelHeader =
    firstItemIdx >= 0 ? channelBody.slice(0, firstItemIdx) : channelBody;

  const seriesTitle =
    extractFirstTagText(channelHeader, ['title']) || source.name;
  const seriesDesc = sanitizeFeedHtmlToText(
    extractRawTagInner(channelHeader, ['description', 'itunes:summary'])
  ).summary;
  const seriesAuthor =
    extractFirstTagText(channelHeader, ['itunes:author', 'managingEditor']) ||
    null;
  const seriesPublisher =
    extractFirstTagText(channelHeader, [
      'itunes:name',
      'itunes:author',
      'copyright',
    ]) || source.name;
  const seriesWebsite =
    normalizeArticleUrl(extractFirstTagText(channelHeader, ['link'])) ||
    source.websiteUrl;
  const language =
    extractFirstTagText(channelHeader, ['language']) || null;

  let seriesArtwork: string | null = null;
  const itunesImgMatch = /<itunes:image\b[^>]*>/i.exec(channelHeader);
  if (itunesImgMatch) {
    seriesArtwork = extractAttr(itunesImgMatch[0], 'href');
  }
  if (!seriesArtwork) {
    const imgUrl = extractFirstTagText(
      extractRawTagInner(channelHeader, ['image']),
      ['url']
    );
    if (imgUrl && imgUrl.startsWith('http')) {
      seriesArtwork = imgUrl;
    }
  }

  const seriesId = makeStableId('pod-series', source.feedUrl || source.id);
  const nowIso = new Date().toISOString();

  const itemRegex = /<item\b[^>]*>([\s\S]*?)<\/item>/gi;
  const episodes: PodcastEpisode[] = [];
  let match: RegExpExecArray | null;

  while (
    (match = itemRegex.exec(channelBody)) !== null &&
    episodes.length < maxEpisodes
  ) {
    const itemXml = match[1];
    const title = extractFirstTagText(itemXml, ['title']);
    if (!title) continue;

    const guid =
      extractFirstTagText(itemXml, ['guid']) ||
      extractFirstTagText(itemXml, ['link']) ||
      title;
    const rawLink = extractFirstTagText(itemXml, ['link']);
    const enclosureMatch = /<enclosure\b[^>]*>/i.exec(itemXml);
    const enclosureUrl = enclosureMatch
      ? extractAttr(enclosureMatch[0], 'url')
      : null;
    const enclosureType = enclosureMatch
      ? extractAttr(enclosureMatch[0], 'type')
      : null;
    const isAudioUrl =
      enclosureUrl &&
      enclosureUrl.startsWith('http') &&
      (!enclosureType || enclosureType.toLowerCase().includes('audio') || enclosureType.toLowerCase().includes('mpeg'));
    const audioUrl = isAudioUrl ? enclosureUrl : null;
    const episodeUrl = normalizeArticleUrl(
      rawLink || audioUrl || seriesWebsite
    );

    const pubRaw = extractFirstTagText(itemXml, ['pubDate', 'dc:date']);
    const { publishedAt, dateStatus } = parseStrictPublishedDate(pubRaw);
    const archived =
      dateStatus === 'valid' &&
      isOlderThanActiveWindow(publishedAt, activeWindowDays);

    const rawDesc = extractRawTagInner(itemXml, [
      'content:encoded',
      'description',
      'itunes:summary',
    ]);
    const cleanDesc = sanitizeFeedHtmlToText(rawDesc).summary;

    const rawDur = extractFirstTagText(itemXml, ['itunes:duration']);
    const { formatted: duration, seconds: durationSeconds } =
      normalizeDurationString(rawDur);

    const epImgMatch = /<itunes:image\b[^>]*>/i.exec(itemXml);
    const epArtwork =
      (epImgMatch ? extractAttr(epImgMatch[0], 'href') : null) ||
      seriesArtwork;

    episodes.push({
      id: makeStableId('pod-ep', `${seriesId}::${guid}`),
      guid,
      seriesId,
      seriesTitle,
      title,
      description: cleanDesc,
      publishedAt,
      updatedAt: null,
      dateStatus,
      duration,
      durationSeconds,
      audioUrl,
      artworkUrl: epArtwork,
      episodeUrl,
      contentType: 'podcast-episode',
      category: source.category,
      tags: [...source.tags],
      sourceId: source.id,
      matchedSourceIds: [source.id],
      isPlayed: false,
      isFavorite: false,
      isArchived: archived,
      archivedAt: archived ? nowIso : null,
      playbackPosition: 0,
      fetchedAt: nowIso,
    });
  }

  if (episodes.length === 0) {
    throw new Error('Podcast RSS feed returned zero valid episodes.');
  }

  const series: PodcastSeries = {
    id: seriesId,
    title: seriesTitle,
    description: seriesDesc,
    author: seriesAuthor,
    publisher: seriesPublisher,
    artworkUrl: seriesArtwork,
    websiteUrl: seriesWebsite,
    feedUrl: source.feedUrl,
    language,
    category: source.category,
    tags: [...source.tags],
    sourceId: source.id,
    lastFetchedAt: nowIso,
    status: 'success',
    isFollowed: false,
    isFavorite: false,
    episodeCount: episodes.length,
  };

  return { series, episodes };
}

// ===========================================================================
// 3. SECURITY ADAPTERS (NVD API 2.0, CISA KEV, Red Hat Security API, RSS)
// ===========================================================================
function mapSeverityFromScore(score: number | null): SecuritySeverity | null {
  if (score === null || Number.isNaN(score)) return null;
  if (score >= 9.0) return 'CRITICAL';
  if (score >= 7.0) return 'HIGH';
  if (score >= 4.0) return 'MEDIUM';
  if (score > 0) return 'LOW';
  return 'INFO';
}

function normalizeSeverityText(raw: string | null | undefined): SecuritySeverity | null {
  if (!raw) return null;
  const upper = raw.trim().toUpperCase();
  if (upper === 'CRITICAL') return 'CRITICAL';
  if (upper === 'IMPORTANT' || upper === 'HIGH') return 'HIGH';
  if (upper === 'MODERATE' || upper === 'MEDIUM') return 'MEDIUM';
  if (upper === 'LOW') return 'LOW';
  if (upper === 'INFO' || upper === 'NONE') return 'INFO';
  return null;
}

export function parseSecurityPayload(
  payload: string,
  source: TechSource,
  activeWindowDays: number
): SecurityRecord[] {
  const nowIso = new Date().toISOString();
  const trimmed = payload.trim();

  // A. NVD CVE API 2.0 JSON (exclude CISA KEV which also has "vulnerabilities" + "catalogVersion")
  if (
    trimmed.startsWith('{') &&
    trimmed.includes('"vulnerabilities"') &&
    !trimmed.includes('"catalogVersion"')
  ) {
    const json = JSON.parse(trimmed) as {
      vulnerabilities?: Array<{
        cve?: {
          id?: string;
          published?: string;
          lastModified?: string;
          vulnStatus?: string;
          descriptions?: Array<{ lang?: string; value?: string }>;
          metrics?: {
            cvssMetricV31?: Array<{ cvssData?: { baseScore?: number; baseSeverity?: string } }>;
            cvssMetricV30?: Array<{ cvssData?: { baseScore?: number; baseSeverity?: string } }>;
            cvssMetricV2?: Array<{ cvssData?: { baseScore?: number }; baseSeverity?: string }>;
          };
          references?: Array<{ url?: string }>;
          configurations?: Array<{
            nodes?: Array<{
              cpeMatch?: Array<{ criteria?: string }>;
            }>;
          }>;
        };
      }>;
    };

    const records: SecurityRecord[] = [];
    for (const entry of json.vulnerabilities || []) {
      const cve = entry.cve;
      if (!cve?.id) continue;
      const descObj =
        cve.descriptions?.find((d) => d.lang === 'en') || cve.descriptions?.[0];
      const v31 = cve.metrics?.cvssMetricV31?.[0]?.cvssData;
      const v30 = cve.metrics?.cvssMetricV30?.[0]?.cvssData;
      const v2 = cve.metrics?.cvssMetricV2?.[0];
      const cvss =
        v31?.baseScore ?? v30?.baseScore ?? v2?.cvssData?.baseScore ?? null;
      const severity =
        normalizeSeverityText(v31?.baseSeverity || v30?.baseSeverity || v2?.baseSeverity) ||
        mapSeverityFromScore(cvss);

      const affectedProducts: string[] = [];
      for (const cfg of cve.configurations || []) {
        for (const node of cfg.nodes || []) {
          for (const m of node.cpeMatch || []) {
            if (m.criteria && affectedProducts.length < 8) {
              const parts = m.criteria.split(':');
              const label =
                parts.length >= 5
                  ? `${parts[3]} ${parts[4]} ${parts[5] !== '*' ? parts[5] : ''}`.trim()
                  : m.criteria;
              if (label && !affectedProducts.includes(label)) {
                affectedProducts.push(label);
              }
            }
          }
        }
      }

      const references = (cve.references || [])
        .map((r) => r.url)
        .filter((u): u is string => Boolean(u && u.startsWith('http')))
        .slice(0, 6);

      const { publishedAt, dateStatus } = parseStrictPublishedDate(cve.published);
      const { publishedAt: modifiedAt } = parseStrictPublishedDate(
        cve.lastModified
      );
      const archived =
        dateStatus === 'valid' &&
        isOlderThanActiveWindow(publishedAt, activeWindowDays);

      records.push({
        id: makeStableId('sec', cve.id),
        guid: cve.id,
        cveId: cve.id,
        title: `${cve.id}${severity ? ` · ${severity}` : ''}`,
        description: descObj?.value || '',
        publishedAt,
        modifiedAt,
        dateStatus,
        cvss,
        severity,
        affectedProducts,
        references,
        url: `https://nvd.nist.gov/vuln/detail/${cve.id}`,
        source: source.name,
        sourceId: source.id,
        matchedSourceIds: [source.id],
        contentType: 'cve',
        status: cve.vulnStatus || 'Analyzed',
        tags: [...source.tags],
        isRead: false,
        isFavorite: false,
        isArchived: archived,
        archivedAt: archived ? nowIso : null,
        fetchedAt: nowIso,
      });
    }
    return records;
  }

  // B. CISA Known Exploited Vulnerabilities JSON
  if (trimmed.startsWith('{') && trimmed.includes('"catalogVersion"')) {
    const json = JSON.parse(trimmed) as {
      vulnerabilities?: Array<{
        cveID?: string;
        vendorProject?: string;
        product?: string;
        vulnerabilityName?: string;
        dateAdded?: string;
        shortDescription?: string;
        requiredAction?: string;
        dueDate?: string;
        knownRansomwareCampaignUse?: string;
      }>;
    };
    const recent = (json.vulnerabilities || [])
      .slice()
      .sort((a, b) => Date.parse(b.dateAdded || '') - Date.parse(a.dateAdded || ''))
      .slice(0, 25);

    return recent
      .filter((v) => v.cveID)
      .map((v) => {
        const cveId = v.cveID!;
        const { publishedAt, dateStatus } = parseStrictPublishedDate(v.dateAdded);
        const archived =
          dateStatus === 'valid' &&
          isOlderThanActiveWindow(publishedAt, activeWindowDays);
        const affected = [
          [v.vendorProject, v.product].filter(Boolean).join(' '),
        ].filter(Boolean);

        return {
          id: makeStableId('sec', `kev::${cveId}`),
          guid: cveId,
          cveId,
          title: `${cveId}: ${v.vulnerabilityName || 'Known Exploited Vulnerability'}`,
          description: [
            v.shortDescription || '',
            v.requiredAction ? `Required Action: ${v.requiredAction}` : '',
            v.dueDate ? `Due Date: ${v.dueDate}` : '',
          ]
            .filter(Boolean)
            .join(' '),
          publishedAt,
          modifiedAt: null,
          dateStatus,
          cvss: null, // CISA KEV JSON does not include CVSS; never fabricate
          severity: 'HIGH' as SecuritySeverity,
          affectedProducts: affected,
          references: [
            `https://nvd.nist.gov/vuln/detail/${cveId}`,
            'https://www.cisa.gov/known-exploited-vulnerabilities-catalog',
          ],
          url: `https://nvd.nist.gov/vuln/detail/${cveId}`,
          source: source.name,
          sourceId: source.id,
          matchedSourceIds: [source.id],
          contentType: 'exploit',
          status:
            v.knownRansomwareCampaignUse === 'Known'
              ? 'Actively Exploited (Ransomware)'
              : 'Actively Exploited',
          tags: [...source.tags, 'kev'],
          isRead: false,
          isFavorite: false,
          isArchived: archived,
          archivedAt: archived ? nowIso : null,
          fetchedAt: nowIso,
        };
      });
  }

  // C. Red Hat Security Data API JSON array
  if (trimmed.startsWith('[')) {
    const arr = JSON.parse(trimmed) as Array<{
      CVE?: string;
      severity?: string;
      public_date?: string;
      bugzilla_description?: string;
      cvss3_score?: string | number;
      resource_url?: string;
      advisories?: string[];
      affected_packages?: string[];
    }>;

    return arr
      .filter((row) => row.CVE)
      .slice(0, 25)
      .map((row) => {
        const cveId = row.CVE!;
        const parsedCvss =
          row.cvss3_score !== undefined && row.cvss3_score !== null
            ? Number(row.cvss3_score)
            : NaN;
        const cvss = !Number.isNaN(parsedCvss) ? parsedCvss : null;
        const severity =
          normalizeSeverityText(row.severity) || mapSeverityFromScore(cvss);
        const { publishedAt, dateStatus } = parseStrictPublishedDate(
          row.public_date
        );
        const archived =
          dateStatus === 'valid' &&
          isOlderThanActiveWindow(publishedAt, activeWindowDays);
        const webUrl = `https://access.redhat.com/security/cve/${cveId}`;

        return {
          id: makeStableId('sec', `rh::${cveId}`),
          guid: cveId,
          cveId,
          title: `${cveId}${row.bugzilla_description ? ` — ${row.bugzilla_description}` : ''}`,
          description: row.bugzilla_description || '',
          publishedAt,
          modifiedAt: null,
          dateStatus,
          cvss,
          severity,
          affectedProducts: Array.isArray(row.affected_packages)
            ? row.affected_packages.slice(0, 8)
            : [],
          references: [
            webUrl,
            ...(Array.isArray(row.advisories)
              ? row.advisories
                  .slice(0, 4)
                  .map((a) => `https://access.redhat.com/errata/${a}`)
              : []),
          ],
          url: webUrl,
          source: source.name,
          sourceId: source.id,
          matchedSourceIds: [source.id],
          contentType: 'cve',
          status:
            Array.isArray(row.advisories) && row.advisories.length > 0
              ? `Advisory Issued (${row.advisories[0]})`
              : 'Tracked by Red Hat',
          tags: [...source.tags],
          isRead: false,
          isFavorite: false,
          isArchived: archived,
          archivedAt: archived ? nowIso : null,
          fetchedAt: nowIso,
        };
      });
  }

  // D. Security RSS/Atom Feeds (CISA Advisories, The Hacker News, BleepingComputer, SecurityWeek)
  const parsed =
    trimmed.includes('<feed') && !trimmed.includes('<rss')
      ? parseAtomFeed(trimmed, source.websiteUrl)
      : parseRssFeed(trimmed, source.websiteUrl);

  return parsed.items.slice(0, 20).map((item) => {
    const cleanUrl = normalizeArticleUrl(item.articleUrl);
    const { publishedAt, dateStatus } = parseStrictPublishedDate(item.publishedAt);
    const archived =
      dateStatus === 'valid' &&
      isOlderThanActiveWindow(publishedAt, activeWindowDays);
    const textBlob = `${item.title} ${item.summary}`;
    const cveMatch = /\bCVE-\d{4}-\d{4,7}\b/i.exec(textBlob);
    const cveId = cveMatch ? cveMatch[0].toUpperCase() : null;

    let kind: SecurityRecordKind = 'vulnerability-news';
    if (source.id === 'sec-cisa-advisories') {
      kind = 'security-advisory';
    } else if (/ransomware|malware|trojan|botnet|wiper/i.test(textBlob)) {
      kind = 'malware';
    } else if (/zero-day|exploit|poc|actively exploited/i.test(textBlob)) {
      kind = 'exploit';
    } else if (/research|analysis|campaign|apt/i.test(textBlob)) {
      kind = 'security-research';
    }

    return {
      id: makeStableId('sec', item.guid || cleanUrl),
      guid: item.guid || cleanUrl,
      cveId,
      title: item.title,
      description: item.summary,
      publishedAt,
      modifiedAt: null,
      dateStatus,
      cvss: null, // Never fabricate CVSS for news feeds
      severity: null,
      affectedProducts: [],
      references: [cleanUrl],
      url: cleanUrl,
      source: source.name,
      sourceId: source.id,
      matchedSourceIds: [source.id],
      contentType: kind,
      status: kind === 'security-advisory' ? 'Official Advisory' : 'Published',
      tags: Array.from(new Set([...source.tags, ...item.tags])).slice(0, 12),
      isRead: false,
      isFavorite: false,
      isArchived: archived,
      archivedAt: archived ? nowIso : null,
      fetchedAt: nowIso,
    };
  });
}

// ===========================================================================
// 4. LEARNING ADAPTER
// ===========================================================================
export function parseLearningPayload(
  payload: string,
  source: TechSource,
  activeWindowDays: number
): LearningItem[] {
  const nowIso = new Date().toISOString();
  const trimmed = payload.trim();
  const parsed =
    trimmed.includes('<feed') && !trimmed.includes('<rss')
      ? parseAtomFeed(trimmed, source.websiteUrl)
      : parseRssFeed(trimmed, source.websiteUrl);

  return parsed.items.slice(0, 20).map((item) => {
    const cleanUrl = normalizeArticleUrl(item.articleUrl);
    const { publishedAt, dateStatus } = parseStrictPublishedDate(item.publishedAt);
    const archived =
      dateStatus === 'valid' &&
      isOlderThanActiveWindow(publishedAt, activeWindowDays);

    const textBlob = `${item.title} ${item.summary}`;
    let kind: LearningContentKind = 'tutorial';
    if (/full course|bootcamp|certification|crash course/i.test(textBlob)) {
      kind = 'course';
    } else if (/lab|hands-on|playground|sandbox/i.test(textBlob)) {
      kind = 'lab';
    } else if (/roadmap|learning path|curriculum/i.test(textBlob)) {
      kind = 'learning-path';
    } else if (/documentation|reference guide|cheatsheet/i.test(textBlob)) {
      kind = 'documentation';
    }

    return {
      id: makeStableId('learn', item.guid || cleanUrl),
      guid: item.guid || cleanUrl,
      title: item.title,
      description: item.summary,
      platform: source.name,
      category: source.category,
      contentType: kind,
      level: /beginner|intro|basics|101/i.test(textBlob)
        ? 'Beginner'
        : /advanced|deep dive|production/i.test(textBlob)
          ? 'Advanced'
          : null,
      duration: null, // Never fabricate course duration if absent
      url: cleanUrl,
      sourceId: source.id,
      matchedSourceIds: [source.id],
      tags: Array.from(new Set([...source.tags, ...item.tags])).slice(0, 12),
      publishedAt,
      updatedAt: null,
      dateStatus,
      learningStatus: 'not-started',
      isFavorite: false,
      isArchived: archived,
      archivedAt: archived ? nowIso : null,
      fetchedAt: nowIso,
    };
  });
}

// ===========================================================================
// 5. EVENTS ADAPTER (Official RSS Events — zero fabricated event dates)
// ===========================================================================
export function parseEventsPayload(
  payload: string,
  source: TechSource,
  activeWindowDays: number
): TechEvent[] {
  const nowIso = new Date().toISOString();
  const trimmed = payload.trim();
  const parsed =
    trimmed.includes('<feed') && !trimmed.includes('<rss')
      ? parseAtomFeed(trimmed, source.websiteUrl)
      : parseRssFeed(trimmed, source.websiteUrl);

  return parsed.items.slice(0, 20).map((item) => {
    const cleanUrl = normalizeArticleUrl(item.articleUrl);
    const { publishedAt, dateStatus } = parseStrictPublishedDate(item.publishedAt);
    const archived =
      dateStatus === 'valid' &&
      isOlderThanActiveWindow(publishedAt, activeWindowDays);
    const textBlob = `${item.title} ${item.summary}`;

    const eventType = /webinar|livestream|online workshop/i.test(textBlob)
      ? 'webinar'
      : /summit/i.test(textBlob)
        ? 'summit'
        : 'conference';

    return {
      id: makeStableId('evt', item.guid || cleanUrl),
      guid: item.guid || cleanUrl,
      eventName: item.title,
      organizer: source.name,
      // Only set startDate/endDate when explicitly verified; RSS pubDate is feed publication date
      startDate: null,
      endDate: null,
      publishedAt,
      dateStatus,
      location: null,
      eventType,
      description: item.summary,
      registrationUrl: cleanUrl,
      sourceUrl: cleanUrl,
      sourceId: source.id,
      matchedSourceIds: [source.id],
      tags: Array.from(new Set([...source.tags, ...item.tags])).slice(0, 10),
      status: 'upcoming',
      isFavorite: false,
      isArchived: archived,
      archivedAt: archived ? nowIso : null,
      fetchedAt: nowIso,
    };
  });
}
