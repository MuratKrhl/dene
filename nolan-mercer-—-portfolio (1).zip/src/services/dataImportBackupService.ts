import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import {
  ENVIRONMENT_TABS,
  EnvironmentEntry,
  EnvironmentTabKey,
} from '../data/environmentData';
import {
  INITIAL_PM_FOLDERS,
  PM_TABS,
  PmPriority,
  PmStatus,
  PmTaskRow,
  ProjectManagementTabKey,
} from '../data/projectManagementData';

export type ImportDomain = 'environment' | 'pm';
export type TargetTabKey = EnvironmentTabKey | ProjectManagementTabKey;

export interface ParsedSpreadsheetResult {
  fileName: string;
  format: 'csv' | 'xlsx';
  sheetNames: string[];
  activeSheet: string;
  headers: string[];
  rows: Record<string, string>[];
}

export interface ImportBackupSnapshot {
  id: string;
  createdAt: string;
  createdAtLabel: string;
  domain: ImportDomain;
  tabKey: TargetTabKey;
  tabLabel: string;
  reason: string;
  rowCount: number;
  data: EnvironmentEntry[] | PmTaskRow[];
}

const BACKUP_STORAGE_KEY = 'mk-admin-upload-backups-v1';
const MAX_BACKUPS = 30;

function normalizeHeader(key: string): string {
  return key
    .trim()
    .toLowerCase()
    .replace(/ğ/g, 'g')
    .replace(/ü/g, 'u')
    .replace(/ş/g, 's')
    .replace(/ı/g, 'i')
    .replace(/İ/g, 'i')
    .replace(/ö/g, 'o')
    .replace(/ç/g, 'c')
    .replace(/[^a-z0-9]+/g, '');
}

function getField(row: Record<string, string>, aliases: string[]): string {
  const entries = Object.entries(row);
  for (const alias of aliases) {
    const target = normalizeHeader(alias);
    for (const [rawKey, val] of entries) {
      if (normalizeHeader(rawKey) === target) {
        const str = String(val ?? '').trim();
        if (str !== '') return str;
      }
    }
  }
  return '';
}

function formatNowLabel(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function formatDateShort(): string {
  return new Date().toLocaleDateString('en-US', {
    month: 'short',
    day: '2-digit',
    year: 'numeric',
  });
}

export function getTabLabel(domain: ImportDomain, tabKey: TargetTabKey): string {
  if (domain === 'environment') {
    return (
      ENVIRONMENT_TABS.find((t) => t.key === tabKey)?.label || String(tabKey)
    );
  }
  return PM_TABS.find((t) => t.key === tabKey)?.label || String(tabKey);
}

/* ============================================================================
 * PARSING (CSV & XLSX / XLS)
 * ========================================================================== */

export async function parseSpreadsheetFile(
  file: File,
  preferredSheet?: string
): Promise<ParsedSpreadsheetResult> {
  const lower = file.name.toLowerCase();
  const isCsv = lower.endsWith('.csv') || file.type.includes('csv');

  if (isCsv) {
    const rawText = (await file.text()).replace(/^\uFEFF/, '');
    const result = Papa.parse<Record<string, unknown>>(rawText, {
      header: true,
      skipEmptyLines: 'greedy',
    });

    const headers = (result.meta.fields || []).filter((h) => h.trim() !== '');
    const rows: Record<string, string>[] = (result.data || []).map((rec) => {
      const normalized: Record<string, string> = {};
      for (const h of headers) {
        normalized[h] = String(rec[h] ?? '').trim();
      }
      return normalized;
    });

    return {
      fileName: file.name,
      format: 'csv',
      sheetNames: ['CSV'],
      activeSheet: 'CSV',
      headers,
      rows,
    };
  }

  // XLSX / XLS via SheetJS
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });
  const sheetNames = workbook.SheetNames;
  if (sheetNames.length === 0) {
    throw new Error('The uploaded workbook does not contain any sheets.');
  }

  const activeSheet =
    preferredSheet && sheetNames.includes(preferredSheet)
      ? preferredSheet
      : sheetNames[0];
  const sheet = workbook.Sheets[activeSheet];
  const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
    defval: '',
    raw: false,
  });

  const headerSet = new Set<string>();
  rawRows.forEach((r) => {
    Object.keys(r).forEach((k) => {
      if (!k.startsWith('__EMPTY')) headerSet.add(k);
    });
  });

  if (headerSet.size === 0 && rawRows.length > 0) {
    Object.keys(rawRows[0]).forEach((k) => headerSet.add(k));
  }

  const headers = Array.from(headerSet);
  const rows: Record<string, string>[] = rawRows.map((rec) => {
    const normalized: Record<string, string> = {};
    for (const h of headers) {
      normalized[h] = String(rec[h] ?? '').trim();
    }
    return normalized;
  });

  return {
    fileName: file.name,
    format: 'xlsx',
    sheetNames,
    activeSheet,
    headers,
    rows,
  };
}

/* ============================================================================
 * ROW MAPPING -> ENVIRONMENT & PROJECT MANAGEMENT TYPES
 * ========================================================================== */

function normalizeEnvZone(raw: string): EnvironmentEntry['env'] {
  const v = raw.trim().toLowerCase();
  if (v === 'uat') return 'UAT';
  if (v === 'pre-prod' || v === 'preprod' || v === 'pre prod' || v === 'stage')
    return 'Pre-Prod';
  if (v === 'dr' || v === 'disaster recovery') return 'DR';
  if (v === 'test' || v === 'qa' || v === 'dev') return 'Test';
  return 'Prod';
}

function normalizeEnvStatus(raw: string): EnvironmentEntry['status'] {
  const v = raw.trim().toLowerCase();
  if (v === 'healthy' || v === 'saglikli' || v === 'sağlıklı') return 'Healthy';
  if (v === 'active' || v === 'aktif') return 'Active';
  if (v === 'degraded' || v === 'bozuk' || v === 'uyari') return 'Degraded';
  if (v === 'maintenance' || v === 'bakim' || v === 'bakım')
    return 'Maintenance';
  if (v === 'standby' || v === 'yedek') return 'Standby';
  return 'Online';
}

function normalizeAlertLevel(raw: string): EnvironmentEntry['alertLevel'] {
  const v = raw.trim().toLowerCase();
  if (v === 'critical' || v === 'kritik') return 'critical';
  if (v === 'warning' || v === 'warn' || v === 'uyari' || v === 'uyarı')
    return 'warning';
  return 'none';
}

export function mapRowsToEnvironmentEntries(
  rows: Record<string, string>[],
  tabKey: EnvironmentTabKey
): { entries: EnvironmentEntry[]; skipped: number } {
  const tabConfig =
    ENVIRONMENT_TABS.find((t) => t.key === tabKey) || ENVIRONMENT_TABS[0];
  const today = formatDateShort();
  const stamp = Date.now();
  const entries: EnvironmentEntry[] = [];
  let skipped = 0;

  rows.forEach((row, index) => {
    const name = getField(row, [
      'name',
      'ad',
      'hostname',
      'host',
      'service',
      'servis',
      'instance',
      'title',
    ]);
    const endpoint = getField(row, [
      'endpoint',
      'ip',
      'url',
      'address',
      'adres',
      'hostport',
    ]);
    const code = getField(row, ['code', 'assetcode', 'asset code', 'kod']);

    if (!name && !endpoint && !code) {
      skipped++;
      return;
    }

    const capacity =
      getField(row, ['capacity', 'kapasite', 'resources', 'kaynak']) ||
      '4 Units';
    const rawCapValue = getField(row, ['capacityvalue', 'capacity value']);
    const parsedCap = rawCapValue
      ? parseInt(rawCapValue.replace(/[^\d]/g, ''), 10)
      : parseInt(capacity.replace(/[^\d]/g, ''), 10);

    const env = normalizeEnvZone(
      getField(row, ['env', 'environment', 'zone', 'ortam']) || 'Prod'
    );
    const status = normalizeEnvStatus(
      getField(row, ['status', 'durum', 'state']) || 'Online'
    );

    const existingId = getField(row, ['id']);
    const resolvedName = name || endpoint || code;

    entries.push({
      id: existingId || `env-imp-${tabKey}-${stamp}-${index}`,
      tab: tabKey,
      name: resolvedName,
      subtitle:
        getField(row, [
          'subtitle',
          'description',
          'aciklama',
          'açıklama',
          'role',
          'module',
        ]) || `${tabConfig.label} imported asset`,
      code:
        code.toUpperCase() ||
        `${tabConfig.codePlaceholder.slice(0, 4)}-${String(index + 1).padStart(
          2,
          '0'
        )}`,
      env,
      status,
      endpoint: endpoint || 'n/a',
      capacity,
      capacityValue: Number.isFinite(parsedCap) ? parsedCap : 4,
      usageOrLoad:
        getField(row, ['usageorload', 'usage', 'load', 'yuk', 'yük']) || '0%',
      version: getField(row, ['version', 'surum', 'sürüm']) || 'v1.0.0',
      expiryDate:
        getField(row, ['expirydate', 'expiry', 'cert', 'sla', 'sertifika']) ||
        'Dec 31, 2027',
      alertLevel: normalizeAlertLevel(
        getField(row, ['alertlevel', 'alert', 'uyari', 'uyarı'])
      ),
      alertNote:
        getField(row, ['alertnote', 'alert note', 'uyari notu']) || undefined,
      updatedAt:
        getField(row, ['updatedat', 'updated', 'guncelleme', 'tarih']) || today,
      owner:
        getField(row, ['owner', 'sahip', 'team', 'ekip', 'sorumlu']) ||
        'Middleware Ops',
      regionOrCluster:
        getField(row, [
          'regionorcluster',
          'cluster',
          'region',
          'lokasyon',
          'zonecluster',
        ]) || `${env} Zone`,
      notes: getField(row, ['notes', 'notlar', 'note']) || undefined,
      isCustom: true,
    });
  });

  return { entries, skipped };
}

function normalizePmPriority(raw: string): PmPriority {
  const v = raw.trim().toLowerCase();
  if (v === 'high' || v === 'yuksek' || v === 'yüksek' || v === 'kritik')
    return 'High';
  if (v === 'low' || v === 'dusuk' || v === 'düşük') return 'Low';
  return 'Medium';
}

function normalizePmStatus(raw: string): PmStatus {
  const v = raw.trim().toLowerCase();
  if (
    v === 'completed' ||
    v === 'done' ||
    v === 'tamamlandi' ||
    v === 'tamamlandı' ||
    v === 'kapali' ||
    v === 'kapalı'
  ) {
    return 'Completed';
  }
  if (
    v === 'in review' ||
    v === 'inreview' ||
    v === 'review' ||
    v === 'incelemede'
  ) {
    return 'In Review';
  }
  if (
    v === 'overdue' ||
    v === 'gecikmis' ||
    v === 'gecikmiş' ||
    v === 'delayed'
  ) {
    return 'Overdue';
  }
  return 'In Progress';
}

export function mapRowsToPmTasks(
  rows: Record<string, string>[],
  tabKey: ProjectManagementTabKey
): { tasks: PmTaskRow[]; skipped: number } {
  const tabFolders = INITIAL_PM_FOLDERS.filter((f) => f.tab === tabKey);
  const defaultFolderId = tabFolders[0]?.id || '';
  const tabLabel = PM_TABS.find((t) => t.key === tabKey)?.label || tabKey;
  const stamp = Date.now();
  const tasks: PmTaskRow[] = [];
  let skipped = 0;

  rows.forEach((row, index) => {
    const name = getField(row, [
      'name',
      'task',
      'title',
      'gorev',
      'görev',
      'bulgu',
      'ad',
    ]);
    if (!name) {
      skipped++;
      return;
    }

    const rawWs = getField(row, [
      'workstreamid',
      'workstream',
      'workstream_id',
      'isakisi',
      'iş akışı',
      'folder',
    ]);
    let matchedFolderId = defaultFolderId;
    if (rawWs) {
      const lowerWs = rawWs.toLowerCase();
      const found = tabFolders.find(
        (f) =>
          f.id.toLowerCase() === lowerWs ||
          f.title.toLowerCase() === lowerWs ||
          f.title.toLowerCase().includes(lowerWs)
      );
      if (found) matchedFolderId = found.id;
    }

    const existingId = getField(row, ['id']);

    tasks.push({
      id: existingId || `pm-imp-${tabKey}-${stamp}-${index}`,
      tab: tabKey,
      workstreamId: matchedFolderId,
      name,
      dateRange:
        getField(row, ['daterange', 'date', 'tarih', 'deadline', 'sure']) ||
        'TBD',
      priority: normalizePmPriority(
        getField(row, ['priority', 'oncelik', 'öncelik'])
      ),
      tag:
        getField(row, ['tag', 'tags', 'etiket', 'category', 'kategori']) ||
        tabLabel,
      status: normalizePmStatus(getField(row, ['status', 'durum', 'state'])),
      assignee:
        getField(row, ['assignee', 'owner', 'atanan', 'sorumlu', 'sahip']) ||
        'MK',
    });
  });

  return { tasks, skipped };
}

/* ============================================================================
 * EXPORT TO CSV & XLSX (FOR TEMPLATES, CURRENT EXPORTS, & BACKUP DOWNLOADS)
 * ========================================================================== */

function serializeEnvironmentRows(entries: EnvironmentEntry[]) {
  return entries.map((e) => ({
    ID: e.id,
    Name: e.name,
    Subtitle: e.subtitle,
    Code: e.code,
    Environment: e.env,
    Status: e.status,
    Endpoint: e.endpoint,
    Capacity: e.capacity,
    CapacityValue: e.capacityValue,
    UsageOrLoad: e.usageOrLoad,
    Version: e.version,
    ExpiryDate: e.expiryDate,
    AlertLevel: e.alertLevel || 'none',
    AlertNote: e.alertNote || '',
    UpdatedAt: e.updatedAt,
    Owner: e.owner,
    RegionOrCluster: e.regionOrCluster,
    Notes: e.notes || '',
  }));
}

function serializePmRows(
  tasks: PmTaskRow[],
  tabKey: ProjectManagementTabKey
) {
  const folderMap = new Map(
    INITIAL_PM_FOLDERS.filter((f) => f.tab === tabKey).map((f) => [
      f.id,
      f.title,
    ])
  );
  return tasks.map((t) => ({
    ID: t.id,
    Name: t.name,
    Workstream: folderMap.get(t.workstreamId) || t.workstreamId,
    WorkstreamId: t.workstreamId,
    DateRange: t.dateRange,
    Priority: t.priority,
    Tag: t.tag,
    Status: t.status,
    Assignee: t.assignee,
  }));
}

function triggerBlobDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function exportRowsToCsv(
  rows: Record<string, unknown>[],
  filename: string
) {
  const csv = Papa.unparse(rows);
  const blob = new Blob(['\uFEFF' + csv], {
    type: 'text/csv;charset=utf-8;',
  });
  triggerBlobDownload(blob, filename.endsWith('.csv') ? filename : `${filename}.csv`);
}

export function exportRowsToXlsx(
  rows: Record<string, unknown>[],
  sheetName: string,
  filename: string
) {
  const safeSheet = sheetName.replace(/[\\/?*[\]:]/g, '').slice(0, 31) || 'Data';
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, safeSheet);
  const out = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([out], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  triggerBlobDownload(
    blob,
    filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`
  );
}

export function exportTabRecords(
  domain: ImportDomain,
  tabKey: TargetTabKey,
  records: EnvironmentEntry[] | PmTaskRow[],
  format: 'csv' | 'xlsx',
  filenamePrefix: string
) {
  const rows =
    domain === 'environment'
      ? serializeEnvironmentRows(records as EnvironmentEntry[])
      : serializePmRows(records as PmTaskRow[], tabKey as ProjectManagementTabKey);

  const label = getTabLabel(domain, tabKey);
  if (format === 'csv') {
    exportRowsToCsv(rows, `${filenamePrefix}.csv`);
  } else {
    exportRowsToXlsx(rows, label, `${filenamePrefix}.xlsx`);
  }
}

export function downloadTemplateFile(
  domain: ImportDomain,
  tabKey: TargetTabKey,
  format: 'csv' | 'xlsx'
) {
  if (domain === 'environment') {
    const tabConfig =
      ENVIRONMENT_TABS.find((t) => t.key === tabKey) || ENVIRONMENT_TABS[0];
    const sampleRows: Record<string, unknown>[] = [
      {
        Name: `${tabKey}-node-01`,
        Subtitle: `${tabConfig.label} production runtime`,
        Code: tabConfig.codePlaceholder,
        Environment: 'Prod',
        Status: 'Online',
        Endpoint: '10.42.10.25:8443',
        Capacity: '16 vCPU / 64 GB',
        UsageOrLoad: '42%',
        Version: 'v1.0.0',
        ExpiryDate: 'Dec 31, 2027',
        AlertLevel: 'none',
        AlertNote: '',
        Owner: 'Middleware Ops',
        RegionOrCluster: 'DC-IST-01',
        Notes: 'Sample row — edit or replace before uploading',
      },
    ];
    if (format === 'csv') {
      exportRowsToCsv(sampleRows, `template-${tabKey}.csv`);
    } else {
      exportRowsToXlsx(sampleRows, tabConfig.label, `template-${tabKey}.xlsx`);
    }
  } else {
    const pmKey = tabKey as ProjectManagementTabKey;
    const firstWs = INITIAL_PM_FOLDERS.find((f) => f.tab === pmKey);
    const tabLabel = PM_TABS.find((t) => t.key === pmKey)?.label || pmKey;
    const sampleRows: Record<string, unknown>[] = [
      {
        Name: `Sample ${tabLabel} item`,
        Workstream: firstWs?.title || '',
        WorkstreamId: firstWs?.id || '',
        DateRange: '20 Nov - 15 Dec',
        Priority: 'High',
        Tag: tabLabel,
        Status: 'In Progress',
        Assignee: 'MK',
      },
    ];
    if (format === 'csv') {
      exportRowsToCsv(sampleRows, `template-${pmKey}.csv`);
    } else {
      exportRowsToXlsx(sampleRows, tabLabel, `template-${pmKey}.xlsx`);
    }
  }
}

/* ============================================================================
 * AUTOMATIC PRE-UPLOAD BACKUPS
 * ========================================================================== */

export function loadBackupSnapshots(): ImportBackupSnapshot[] {
  try {
    const raw = localStorage.getItem(BACKUP_STORAGE_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // Ignore storage read errors
  }
  return [];
}

function saveBackupSnapshots(snapshots: ImportBackupSnapshot[]) {
  try {
    localStorage.setItem(
      BACKUP_STORAGE_KEY,
      JSON.stringify(snapshots.slice(0, MAX_BACKUPS))
    );
  } catch {
    // Ignore storage write errors
  }
}

export function createBackupSnapshot(params: {
  domain: ImportDomain;
  tabKey: TargetTabKey;
  reason: string;
  data: EnvironmentEntry[] | PmTaskRow[];
}): ImportBackupSnapshot {
  const snapshot: ImportBackupSnapshot = {
    id: `bkp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    createdAt: new Date().toISOString(),
    createdAtLabel: formatNowLabel(),
    domain: params.domain,
    tabKey: params.tabKey,
    tabLabel: getTabLabel(params.domain, params.tabKey),
    reason: params.reason,
    rowCount: params.data.length,
    data: JSON.parse(JSON.stringify(params.data)),
  };

  const next = [snapshot, ...loadBackupSnapshots()].slice(0, MAX_BACKUPS);
  saveBackupSnapshots(next);
  return snapshot;
}

export function deleteBackupSnapshot(id: string): ImportBackupSnapshot[] {
  const next = loadBackupSnapshots().filter((b) => b.id !== id);
  saveBackupSnapshots(next);
  return next;
}

export function downloadBackupSnapshot(
  snapshot: ImportBackupSnapshot,
  format: 'csv' | 'xlsx'
) {
  const stamp = snapshot.createdAtLabel.replace(/[: ]+/g, '-');
  exportTabRecords(
    snapshot.domain,
    snapshot.tabKey,
    snapshot.data,
    format,
    `backup-${snapshot.tabKey}-${stamp}`
  );
}
