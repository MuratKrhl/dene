import React, { useMemo, useRef, useState } from 'react';
import {
  ArchiveRestore,
  ArrowUpRight,
  CheckCircle2,
  Database,
  Download,
  FileSpreadsheet,
  FolderKanban,
  History,
  Plus,
  Search,
  Server,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  ENVIRONMENT_TABS,
  EnvironmentEntry,
  EnvironmentTabKey,
  loadEnvironmentEntries,
  saveEnvironmentEntries,
} from '../data/environmentData';
import {
  INITIAL_PM_FOLDERS,
  PM_TABS,
  PmPriority,
  PmStatus,
  PmTaskRow,
  ProjectManagementTabKey,
} from '../data/projectManagementData';
import { loadPmTasks, savePmTasks } from '../services/projectManagementStore';
import {
  ImportBackupSnapshot,
  ImportDomain,
  ParsedSpreadsheetResult,
  TargetTabKey,
  createBackupSnapshot,
  deleteBackupSnapshot,
  downloadBackupSnapshot,
  downloadTemplateFile,
  exportTabRecords,
  getTabLabel,
  loadBackupSnapshots,
  mapRowsToEnvironmentEntries,
  mapRowsToPmTasks,
  parseSpreadsheetFile,
} from '../services/dataImportBackupService';

interface AdminDataImportsPanelProps {
  onNavigate: (path: string) => void;
  domain: ImportDomain;
}

type ImportMode = 'replace' | 'append';

export const AdminDataImportsPanel: React.FC<AdminDataImportsPanelProps> = ({
  onNavigate,
  domain,
}) => {
  const [envTab, setEnvTab] = useState<EnvironmentTabKey>('sunucu');
  const [pmTab, setPmTab] = useState<ProjectManagementTabKey>('bulgu-takip');

  const [envEntries, setEnvEntries] = useState<EnvironmentEntry[]>(() =>
    loadEnvironmentEntries()
  );
  const [pmTasks, setPmTasks] = useState<PmTaskRow[]>(() => loadPmTasks());
  const [backups, setBackups] = useState<ImportBackupSnapshot[]>(() =>
    loadBackupSnapshots()
  );

  // Upload & Parse state
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [parsedResult, setParsedResult] =
    useState<ParsedSpreadsheetResult | null>(null);
  const [importMode, setImportMode] = useState<ImportMode>('replace');
  const [autoDownloadBackup, setAutoDownloadBackup] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [parseError, setParseError] = useState('');
  const [statusMessage, setStatusMessage] = useState('');

  // Records table & Manual Add state
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [backupScopeFilter, setBackupScopeFilter] = useState<'tab' | 'all'>(
    'tab'
  );

  // Manual add Environment fields
  const [envName, setEnvName] = useState('');
  const [envSubtitle, setEnvSubtitle] = useState('');
  const [envCode, setEnvCode] = useState('');
  const [envZone, setEnvZone] = useState<EnvironmentEntry['env']>('Prod');
  const [envStatus, setEnvStatus] =
    useState<EnvironmentEntry['status']>('Online');
  const [envEndpoint, setEnvEndpoint] = useState('');
  const [envCapacity, setEnvCapacity] = useState('');
  const [envUsage, setEnvUsage] = useState('');
  const [envVersion, setEnvVersion] = useState('');
  const [envOwner, setEnvOwner] = useState('Middleware Ops');

  // Manual add PM fields
  const [pmName, setPmName] = useState('');
  const [pmWorkstreamId, setPmWorkstreamId] = useState('');
  const [pmDateRange, setPmDateRange] = useState('20 Nov - 10 Dec');
  const [pmPriority, setPmPriority] = useState<PmPriority>('Medium');
  const [pmStatus, setPmStatus] = useState<PmStatus>('In Progress');
  const [pmTag, setPmTag] = useState('Migration');
  const [pmAssignee, setPmAssignee] = useState('MK');

  const activeTabKey: TargetTabKey = domain === 'environment' ? envTab : pmTab;
  const activeTabLabel = getTabLabel(domain, activeTabKey);

  const activeEnvTabConfig =
    ENVIRONMENT_TABS.find((t) => t.key === envTab) || ENVIRONMENT_TABS[0];
  const activePmTabConfig =
    PM_TABS.find((t) => t.key === pmTab) || PM_TABS[0];
  const activePmFolders = useMemo(
    () => INITIAL_PM_FOLDERS.filter((f) => f.tab === pmTab),
    [pmTab]
  );

  const currentTabRecords = useMemo(() => {
    if (domain === 'environment') {
      return envEntries.filter((e) => e.tab === envTab);
    }
    return pmTasks.filter((t) => t.tab === pmTab);
  }, [domain, envEntries, envTab, pmTasks, pmTab]);

  const filteredRecords = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (domain === 'environment') {
      const list = envEntries.filter((e) => e.tab === envTab);
      if (!q) return list;
      return list.filter(
        (e) =>
          e.name.toLowerCase().includes(q) ||
          e.code.toLowerCase().includes(q) ||
          e.endpoint.toLowerCase().includes(q) ||
          e.owner.toLowerCase().includes(q) ||
          e.env.toLowerCase().includes(q)
      );
    } else {
      const list = pmTasks.filter((t) => t.tab === pmTab);
      if (!q) return list;
      return list.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.tag.toLowerCase().includes(q) ||
          t.assignee.toLowerCase().includes(q) ||
          t.status.toLowerCase().includes(q)
      );
    }
  }, [domain, envEntries, envTab, pmTasks, pmTab, search]);

  const mappedPreview = useMemo(() => {
    if (!parsedResult) return null;
    if (domain === 'environment') {
      const res = mapRowsToEnvironmentEntries(parsedResult.rows, envTab);
      return {
        domain: 'environment' as const,
        count: res.entries.length,
        skipped: res.skipped,
        envEntries: res.entries,
        pmTasks: [] as PmTaskRow[],
      };
    } else {
      const res = mapRowsToPmTasks(parsedResult.rows, pmTab);
      return {
        domain: 'pm' as const,
        count: res.tasks.length,
        skipped: res.skipped,
        envEntries: [] as EnvironmentEntry[],
        pmTasks: res.tasks,
      };
    }
  }, [parsedResult, domain, envTab, pmTab]);

  const domainBackups = useMemo(
    () => backups.filter((b) => b.domain === domain),
    [backups, domain]
  );

  const visibleBackups = useMemo(() => {
    if (backupScopeFilter === 'all') return domainBackups;
    return domainBackups.filter((b) => b.tabKey === activeTabKey);
  }, [domainBackups, backupScopeFilter, activeTabKey]);

  const persistEnv = (next: EnvironmentEntry[]) => {
    setEnvEntries(next);
    saveEnvironmentEntries(next);
  };

  const persistPm = (next: PmTaskRow[]) => {
    setPmTasks(next);
    savePmTasks(next);
  };

  const clearUploadSelection = () => {
    setSelectedFile(null);
    setParsedResult(null);
    setParseError('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSelectTargetTab = (nextKey: TargetTabKey) => {
    if (domain === 'environment') {
      setEnvTab(nextKey as EnvironmentTabKey);
    } else {
      setPmTab(nextKey as ProjectManagementTabKey);
    }
    setShowAddForm(false);
    setSearch('');
    setStatusMessage('');
  };

  const handleFileChosen = async (file: File, sheetName?: string) => {
    setParseError('');
    setStatusMessage('');
    const lower = file.name.toLowerCase();
    if (
      !lower.endsWith('.csv') &&
      !lower.endsWith('.xlsx') &&
      !lower.endsWith('.xls')
    ) {
      setParseError(
        'Unsupported file format. Please upload a .csv, .xlsx, or .xls file.'
      );
      return;
    }

    try {
      const parsed = await parseSpreadsheetFile(file, sheetName);
      if (parsed.rows.length === 0) {
        setParseError('The selected file/sheet contains no data rows.');
        setSelectedFile(file);
        setParsedResult(null);
        return;
      }
      setSelectedFile(file);
      setParsedResult(parsed);
    } catch (err) {
      setParseError(
        err instanceof Error
          ? err.message
          : 'Failed to read spreadsheet file.'
      );
      setParsedResult(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      void handleFileChosen(file);
    }
  };

  const handleApplyUpload = () => {
    if (!mappedPreview || mappedPreview.count === 0 || !parsedResult) return;

    // 1. Always take an automatic backup of the latest state before applying upload
    const currentSnapshotData =
      domain === 'environment'
        ? envEntries.filter((e) => e.tab === envTab)
        : pmTasks.filter((t) => t.tab === pmTab);

    const backup = createBackupSnapshot({
      domain,
      tabKey: activeTabKey,
      reason: `Before upload: ${parsedResult.fileName} (${importMode})`,
      data: currentSnapshotData,
    });
    setBackups(loadBackupSnapshots());

    if (autoDownloadBackup && currentSnapshotData.length > 0) {
      downloadBackupSnapshot(backup, 'xlsx');
    }

    // 2. Apply imported records to the selected tab
    if (domain === 'environment') {
      const otherTabs = envEntries.filter((e) => e.tab !== envTab);
      const existingCurrent = envEntries.filter((e) => e.tab === envTab);
      const nextForTab =
        importMode === 'replace'
          ? mappedPreview.envEntries
          : [...mappedPreview.envEntries, ...existingCurrent];
      persistEnv([...nextForTab, ...otherTabs]);
    } else {
      const otherTabs = pmTasks.filter((t) => t.tab !== pmTab);
      const existingCurrent = pmTasks.filter((t) => t.tab === pmTab);
      const nextForTab =
        importMode === 'replace'
          ? mappedPreview.pmTasks
          : [...mappedPreview.pmTasks, ...existingCurrent];
      persistPm([...nextForTab, ...otherTabs]);
    }

    setStatusMessage(
      `Backup taken (${backup.rowCount} previous rows saved) and ${mappedPreview.count} rows imported into "${activeTabLabel}".`
    );
    clearUploadSelection();
  };

  const handleRestoreBackup = (snapshot: ImportBackupSnapshot) => {
    // Safety backup of current state before restoring
    const currentRows =
      snapshot.domain === 'environment'
        ? envEntries.filter((e) => e.tab === snapshot.tabKey)
        : pmTasks.filter((t) => t.tab === snapshot.tabKey);

    createBackupSnapshot({
      domain: snapshot.domain,
      tabKey: snapshot.tabKey,
      reason: `Safety backup before restoring (${snapshot.createdAtLabel})`,
      data: currentRows,
    });

    if (snapshot.domain === 'environment') {
      const targetTab = snapshot.tabKey as EnvironmentTabKey;
      const otherTabs = envEntries.filter((e) => e.tab !== targetTab);
      persistEnv([...(snapshot.data as EnvironmentEntry[]), ...otherTabs]);
      setEnvTab(targetTab);
    } else {
      const targetTab = snapshot.tabKey as ProjectManagementTabKey;
      const otherTabs = pmTasks.filter((t) => t.tab !== targetTab);
      persistPm([...(snapshot.data as PmTaskRow[]), ...otherTabs]);
      setPmTab(targetTab);
    }

    setBackups(loadBackupSnapshots());
    setStatusMessage(
      `Restored ${snapshot.rowCount} rows into "${snapshot.tabLabel}" from backup (${snapshot.createdAtLabel}).`
    );
  };

  const handleDeleteBackup = (id: string) => {
    setBackups(deleteBackupSnapshot(id));
  };

  const handleClearCurrentTab = () => {
    if (currentTabRecords.length === 0) return;

    const backup = createBackupSnapshot({
      domain,
      tabKey: activeTabKey,
      reason: `Before clearing ${activeTabLabel}`,
      data: currentTabRecords,
    });
    setBackups(loadBackupSnapshots());

    if (domain === 'environment') {
      persistEnv(envEntries.filter((e) => e.tab !== envTab));
    } else {
      persistPm(pmTasks.filter((t) => t.tab !== pmTab));
    }

    setStatusMessage(
      `Backup created (${backup.rowCount} rows) and "${activeTabLabel}" cleared.`
    );
  };

  const handleDeleteSingleRecord = (id: string) => {
    if (domain === 'environment') {
      persistEnv(envEntries.filter((e) => e.id !== id));
    } else {
      persistPm(pmTasks.filter((t) => t.id !== id));
    }
  };

  const handleManualAddEnv = (e: React.FormEvent) => {
    e.preventDefault();
    if (!envName.trim() || !envEndpoint.trim()) return;

    const parsedCapNum = parseInt(envCapacity.replace(/[^\d]/g, ''), 10);
    const today = new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: '2-digit',
      year: 'numeric',
    });

    const entry: EnvironmentEntry = {
      id: `env-admin-${Date.now()}`,
      tab: envTab,
      name: envName.trim(),
      subtitle:
        envSubtitle.trim() || `${activeEnvTabConfig.label} runtime instance`,
      code:
        envCode.trim().toUpperCase() ||
        `${activeEnvTabConfig.codePlaceholder.slice(0, 4)}-${String(
          currentTabRecords.length + 1
        ).padStart(2, '0')}`,
      env: envZone,
      status: envStatus,
      endpoint: envEndpoint.trim(),
      capacity: envCapacity.trim() || '4 Units',
      capacityValue: Number.isFinite(parsedCapNum) ? parsedCapNum : 4,
      usageOrLoad: envUsage.trim() || '15%',
      version: envVersion.trim() || 'v1.0.0',
      expiryDate: 'Dec 31, 2027',
      alertLevel: 'none',
      updatedAt: today,
      owner: envOwner.trim() || 'Middleware Ops',
      regionOrCluster: `${envZone} Zone`,
      notes: 'Added via Admin Console.',
      isCustom: true,
    };

    persistEnv([entry, ...envEntries]);
    setEnvName('');
    setEnvSubtitle('');
    setEnvCode('');
    setEnvEndpoint('');
    setEnvCapacity('');
    setEnvUsage('');
    setEnvVersion('');
    setShowAddForm(false);
    setStatusMessage(`Added "${entry.name}" to ${activeEnvTabConfig.label}.`);
  };

  const handleManualAddPm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pmName.trim()) return;

    const row: PmTaskRow = {
      id: `pm-admin-${Date.now()}`,
      tab: pmTab,
      workstreamId: pmWorkstreamId || activePmFolders[0]?.id || '',
      name: pmName.trim(),
      dateRange: pmDateRange.trim() || 'TBD',
      priority: pmPriority,
      tag: pmTag.trim() || activePmTabConfig.label,
      status: pmStatus,
      assignee: pmAssignee.trim() || 'MK',
    };

    persistPm([row, ...pmTasks]);
    setPmName('');
    setShowAddForm(false);
    setStatusMessage(`Added "${row.name}" to ${activePmTabConfig.label}.`);
  };

  const viewTargetPath =
    domain === 'environment'
      ? envTab === 'sunucu'
        ? '/environment'
        : `/environment/${envTab}`
      : pmTab === 'bulgu-takip'
        ? '/project-management'
        : `/project-management/${pmTab}`;

  const tabCounts = useMemo(() => {
    const map: Record<string, number> = {};
    ENVIRONMENT_TABS.forEach((t) => {
      map[t.key] = envEntries.filter((e) => e.tab === t.key).length;
    });
    PM_TABS.forEach((t) => {
      map[t.key] = pmTasks.filter((task) => task.tab === t.key).length;
    });
    return map;
  }, [envEntries, pmTasks]);

  return (
    <section
      aria-label="Environment and Project Management Admin Imports"
      className="space-y-6"
    >
      {/* Target Tab Selector Card */}
      <div className="p-5 rounded-2xl bg-white border border-zinc-200 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              {domain === 'environment' ? (
                <Server className="w-4 h-4 text-[#2563EB]" aria-hidden="true" />
              ) : (
                <FolderKanban
                  className="w-4 h-4 text-[#2563EB]"
                  aria-hidden="true"
                />
              )}
              <h2 className="font-display text-lg font-semibold text-[#09090B]">
                {domain === 'environment'
                  ? 'Environment Inventory Data Control'
                  : 'Project Management Data Control'}
              </h2>
            </div>
            <p className="text-xs text-zinc-600">
              Select a {domain === 'environment' ? 'Environment' : 'Project Management'}{' '}
              tab below to upload CSV/XLSX spreadsheets, export data, or add and
              remove entries. Every upload automatically backs up the latest state
              first.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => onNavigate(viewTargetPath)}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 bg-[#FAFAFA] text-zinc-700 hover:border-zinc-300 transition-colors cursor-pointer whitespace-nowrap"
            >
              <span>View {activeTabLabel}</span>
              <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Specific Sub-tab Selector Pills */}
        <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-zinc-200">
          {(domain === 'environment' ? ENVIRONMENT_TABS : PM_TABS).map(
            (tab) => {
              const selected = activeTabKey === tab.key;
              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => handleSelectTargetTab(tab.key)}
                  className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                    selected
                      ? 'bg-[#2563EB]/10 border-[#2563EB] text-[#2563EB]'
                      : 'bg-[#FAFAFA] border-zinc-200 text-zinc-700 hover:border-zinc-300'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span
                    className={`font-mono text-[11px] tabular-nums ${
                      selected ? 'text-[#2563EB]' : 'text-zinc-400'
                    }`}
                  >
                    {tabCounts[tab.key] ?? 0}
                  </span>
                </button>
              );
            }
          )}
        </div>
      </div>

      {/* Status Notice */}
      {statusMessage && (
        <div
          role="status"
          className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center justify-between gap-3"
        >
          <div className="flex items-center gap-2">
            <CheckCircle2
              className="w-4 h-4 text-emerald-600 shrink-0"
              aria-hidden="true"
            />
            <span>{statusMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusMessage('')}
            aria-label="Dismiss notification"
            className="p-1 text-emerald-700 hover:text-emerald-950 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* CSV / XLSX Upload Card */}
      <div className="p-5 rounded-2xl bg-white border border-zinc-200 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <FileSpreadsheet
                className="w-4 h-4 text-[#2563EB]"
                aria-hidden="true"
              />
              <h3 className="font-display text-sm font-semibold text-[#09090B]">
                CSV / XLSX Import for {activeTabLabel}
              </h3>
            </div>
            <p className="text-xs text-zinc-600">
              Upload a <span className="font-mono">.csv</span>,{' '}
              <span className="font-mono">.xlsx</span>, or{' '}
              <span className="font-mono">.xls</span> file. Current data (
              {currentTabRecords.length} rows) is backed up automatically before
              import.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => downloadTemplateFile(domain, activeTabKey, 'xlsx')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-[#FAFAFA] text-zinc-700 hover:border-zinc-300 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Template .xlsx</span>
            </button>
            <button
              type="button"
              onClick={() => downloadTemplateFile(domain, activeTabKey, 'csv')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-[#FAFAFA] text-zinc-700 hover:border-zinc-300 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Template .csv</span>
            </button>
            <button
              type="button"
              onClick={() =>
                exportTabRecords(
                  domain,
                  activeTabKey,
                  currentTabRecords,
                  'xlsx',
                  `${activeTabKey}-export`
                )
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-[#2563EB] hover:border-[#2563EB] cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Export Current .xlsx</span>
            </button>
          </div>
        </div>

        {/* Upload Dropzone + Options */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`lg:col-span-7 p-6 rounded-xl border border-dashed transition-colors flex flex-col items-center justify-center text-center gap-2.5 ${
              isDragging
                ? 'border-[#2563EB] bg-[#2563EB]/5'
                : 'border-zinc-300 bg-[#FAFAFA]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) void handleFileChosen(file);
              }}
              className="hidden"
            />
            <div className="w-10 h-10 rounded-xl bg-white border border-zinc-200 flex items-center justify-center text-[#2563EB]">
              <Upload className="w-5 h-5" aria-hidden="true" />
            </div>
            <div className="space-y-1">
              <p className="text-xs font-medium text-[#09090B]">
                {selectedFile
                  ? selectedFile.name
                  : `Drop CSV or XLSX file for ${activeTabLabel}`}
              </p>
              <p className="text-[11px] text-zinc-500">
                Supports UTF-8 CSV and Excel workbooks (.xlsx / .xls)
              </p>
            </div>
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer"
              >
                Choose File
              </button>
              {selectedFile && (
                <button
                  type="button"
                  onClick={clearUploadSelection}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-100 cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          <div className="lg:col-span-5 p-4 rounded-xl bg-[#FAFAFA] border border-zinc-200 flex flex-col justify-between gap-3 text-xs">
            <div className="space-y-3">
              <div className="space-y-1.5">
                <span className="block text-[11px] font-medium text-zinc-600">
                  Import Mode
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setImportMode('replace')}
                    className={`px-3 py-2 rounded-lg border text-left transition-colors cursor-pointer ${
                      importMode === 'replace'
                        ? 'bg-white border-[#2563EB] text-[#2563EB] font-medium'
                        : 'bg-white/60 border-zinc-200 text-zinc-700'
                    }`}
                  >
                    <div>Replace Tab</div>
                    <div className="text-[10px] text-zinc-500 font-normal">
                      Overwrite current rows
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setImportMode('append')}
                    className={`px-3 py-2 rounded-lg border text-left transition-colors cursor-pointer ${
                      importMode === 'append'
                        ? 'bg-white border-[#2563EB] text-[#2563EB] font-medium'
                        : 'bg-white/60 border-zinc-200 text-zinc-700'
                    }`}
                  >
                    <div>Append Rows</div>
                    <div className="text-[10px] text-zinc-500 font-normal">
                      Keep existing &amp; add
                    </div>
                  </button>
                </div>
              </div>

              {parsedResult && parsedResult.sheetNames.length > 1 && (
                <div className="space-y-1">
                  <label
                    htmlFor="admin-sheet-select"
                    className="block text-[11px] font-medium text-zinc-600"
                  >
                    Workbook Sheet
                  </label>
                  <select
                    id="admin-sheet-select"
                    value={parsedResult.activeSheet}
                    onChange={(e) => {
                      if (selectedFile) {
                        void handleFileChosen(selectedFile, e.target.value);
                      }
                    }}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
                  >
                    {parsedResult.sheetNames.map((sheet) => (
                      <option key={sheet} value={sheet}>
                        {sheet}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <label className="flex items-start gap-2 cursor-pointer text-[11px] text-zinc-700 pt-1">
                <input
                  type="checkbox"
                  checked={autoDownloadBackup}
                  onChange={(e) => setAutoDownloadBackup(e.target.checked)}
                  className="mt-0.5 rounded border-zinc-300 cursor-pointer"
                />
                <span>
                  Auto-download <span className="font-mono">.xlsx</span> backup
                  file before applying upload (snapshot is always saved below)
                </span>
              </label>
            </div>

            {parseError && (
              <p role="alert" className="text-xs font-medium text-red-600">
                {parseError}
              </p>
            )}
          </div>
        </div>

        {/* Parsed File Preview & Confirm Apply */}
        {parsedResult && mappedPreview && (
          <div className="p-4 rounded-xl bg-[#FAFAFA] border border-zinc-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-0.5 text-xs">
                <div className="font-semibold text-[#09090B]">
                  Preview: {mappedPreview.count} valid rows ready for{' '}
                  {activeTabLabel}
                </div>
                <div className="text-[11px] text-zinc-500">
                  Source: {parsedResult.fileName} ({parsedResult.activeSheet})
                  {mappedPreview.skipped > 0
                    ? ` · ${mappedPreview.skipped} empty rows skipped`
                    : ''}
                </div>
              </div>

              <button
                type="button"
                disabled={mappedPreview.count === 0}
                onClick={handleApplyUpload}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 disabled:opacity-50 text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                <ArchiveRestore className="w-3.5 h-3.5" aria-hidden="true" />
                <span>
                  Backup Current &amp; Import {mappedPreview.count} Rows
                </span>
              </button>
            </div>

            {mappedPreview.count > 0 && (
              <div className="overflow-x-auto rounded-lg border border-zinc-200 bg-white">
                <table className="w-full text-left border-collapse text-[11px]">
                  <thead>
                    <tr className="bg-[#FAFAFA] border-b border-zinc-200 text-zinc-500">
                      {domain === 'environment' ? (
                        <>
                          <th className="px-3 py-2">Name</th>
                          <th className="px-3 py-2">Code</th>
                          <th className="px-3 py-2">Zone</th>
                          <th className="px-3 py-2">Status</th>
                          <th className="px-3 py-2">Endpoint</th>
                          <th className="px-3 py-2">Capacity</th>
                        </>
                      ) : (
                        <>
                          <th className="px-3 py-2">Name</th>
                          <th className="px-3 py-2">Date</th>
                          <th className="px-3 py-2">Priority</th>
                          <th className="px-3 py-2">Tag</th>
                          <th className="px-3 py-2">Status</th>
                          <th className="px-3 py-2">Assignee</th>
                        </>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200">
                    {domain === 'environment'
                      ? mappedPreview.envEntries.slice(0, 5).map((row) => (
                          <tr key={row.id}>
                            <td className="px-3 py-2 font-medium text-[#09090B]">
                              {row.name}
                            </td>
                            <td className="px-3 py-2 font-mono text-zinc-600">
                              {row.code}
                            </td>
                            <td className="px-3 py-2 text-zinc-600">{row.env}</td>
                            <td className="px-3 py-2 text-zinc-600">
                              {row.status}
                            </td>
                            <td className="px-3 py-2 font-mono text-zinc-600">
                              {row.endpoint}
                            </td>
                            <td className="px-3 py-2 text-zinc-600">
                              {row.capacity}
                            </td>
                          </tr>
                        ))
                      : mappedPreview.pmTasks.slice(0, 5).map((row) => (
                          <tr key={row.id}>
                            <td className="px-3 py-2 font-medium text-[#09090B]">
                              {row.name}
                            </td>
                            <td className="px-3 py-2 text-zinc-600">
                              {row.dateRange}
                            </td>
                            <td className="px-3 py-2 text-zinc-600">
                              {row.priority}
                            </td>
                            <td className="px-3 py-2 text-zinc-600">{row.tag}</td>
                            <td className="px-3 py-2 text-zinc-600">
                              {row.status}
                            </td>
                            <td className="px-3 py-2 font-mono text-zinc-600">
                              {row.assignee}
                            </td>
                          </tr>
                        ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Current Tab Records Management (Add / Search / Delete) */}
      <div className="rounded-2xl bg-white border border-zinc-200 overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-zinc-200 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <h3 className="font-display text-sm font-semibold text-[#09090B]">
              {activeTabLabel} Records
            </h3>
            <span className="font-mono text-xs text-zinc-500 tabular-nums">
              · {filteredRecords.length} shown ({currentTabRecords.length} total)
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative w-full sm:w-52">
              <Search
                className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={`Filter ${activeTabLabel}...`}
                aria-label={`Filter ${activeTabLabel} records`}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
              />
            </div>

            {currentTabRecords.length > 0 && (
              <button
                type="button"
                onClick={handleClearCurrentTab}
                className="px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:border-red-500 hover:text-red-600 transition-colors cursor-pointer whitespace-nowrap"
              >
                Backup &amp; Clear Tab
              </button>
            )}

            <button
              type="button"
              onClick={() => setShowAddForm((v) => !v)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" aria-hidden="true" />
              <span>
                Add {domain === 'environment' ? activeTabLabel : 'Task'}
              </span>
            </button>
          </div>
        </div>

        {/* Manual Single Entry Form inside Admin */}
        {showAddForm && domain === 'environment' && (
          <form
            onSubmit={handleManualAddEnv}
            className="p-5 bg-[#FAFAFA] border-b border-zinc-200 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end"
          >
            <div className="sm:col-span-3 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Name *
              </label>
              <input
                type="text"
                required
                value={envName}
                onChange={(e) => setEnvName(e.target.value)}
                placeholder={`${activeTabLabel} name`}
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-2 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Asset Code
              </label>
              <input
                type="text"
                value={envCode}
                onChange={(e) => setEnvCode(e.target.value)}
                placeholder={activeEnvTabConfig.codePlaceholder}
                className="w-full px-3 py-1.5 text-xs font-mono rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-3 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Endpoint / IP *
              </label>
              <input
                type="text"
                required
                value={envEndpoint}
                onChange={(e) => setEnvEndpoint(e.target.value)}
                placeholder="10.42.10.20:8443"
                className="w-full px-3 py-1.5 text-xs font-mono rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-2 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Zone
              </label>
              <select
                value={envZone}
                onChange={(e) =>
                  setEnvZone(e.target.value as EnvironmentEntry['env'])
                }
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              >
                <option value="Prod">Prod</option>
                <option value="UAT">UAT</option>
                <option value="Pre-Prod">Pre-Prod</option>
                <option value="DR">DR</option>
                <option value="Test">Test</option>
              </select>
            </div>
            <div className="sm:col-span-2 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Status
              </label>
              <select
                value={envStatus}
                onChange={(e) =>
                  setEnvStatus(e.target.value as EnvironmentEntry['status'])
                }
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              >
                <option value="Online">Online</option>
                <option value="Healthy">Healthy</option>
                <option value="Active">Active</option>
                <option value="Degraded">Degraded</option>
                <option value="Maintenance">Maintenance</option>
                <option value="Standby">Standby</option>
              </select>
            </div>
            <div className="sm:col-span-3 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Description
              </label>
              <input
                type="text"
                value={envSubtitle}
                onChange={(e) => setEnvSubtitle(e.target.value)}
                placeholder="Role or module note"
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-2 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Capacity
              </label>
              <input
                type="text"
                value={envCapacity}
                onChange={(e) => setEnvCapacity(e.target.value)}
                placeholder="16 vCPU / 64 GB"
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-2 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Usage / Load
              </label>
              <input
                type="text"
                value={envUsage}
                onChange={(e) => setEnvUsage(e.target.value)}
                placeholder="35%"
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-2 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Owner
              </label>
              <input
                type="text"
                value={envOwner}
                onChange={(e) => setEnvOwner(e.target.value)}
                placeholder="Middleware Ops"
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-3 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-600 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
              >
                Save Entry
              </button>
            </div>
          </form>
        )}

        {showAddForm && domain === 'pm' && (
          <form
            onSubmit={handleManualAddPm}
            className="p-5 bg-[#FAFAFA] border-b border-zinc-200 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end"
          >
            <div className="sm:col-span-4 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Task / Finding Title *
              </label>
              <input
                type="text"
                required
                value={pmName}
                onChange={(e) => setPmName(e.target.value)}
                placeholder={`New ${activeTabLabel} item...`}
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-3 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Workstream
              </label>
              <select
                value={pmWorkstreamId || activePmFolders[0]?.id || ''}
                onChange={(e) => setPmWorkstreamId(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              >
                {activePmFolders.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.title}
                  </option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-2 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Date Range
              </label>
              <input
                type="text"
                value={pmDateRange}
                onChange={(e) => setPmDateRange(e.target.value)}
                placeholder="20 Nov - 10 Dec"
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-3 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Tag
              </label>
              <input
                type="text"
                value={pmTag}
                onChange={(e) => setPmTag(e.target.value)}
                placeholder="Migration"
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-3 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Priority
              </label>
              <select
                value={pmPriority}
                onChange={(e) => setPmPriority(e.target.value as PmPriority)}
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
            <div className="sm:col-span-3 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Status
              </label>
              <select
                value={pmStatus}
                onChange={(e) => setPmStatus(e.target.value as PmStatus)}
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              >
                <option value="In Progress">In Progress</option>
                <option value="In Review">In Review</option>
                <option value="Completed">Completed</option>
                <option value="Overdue">Overdue</option>
              </select>
            </div>
            <div className="sm:col-span-3 space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Assignee
              </label>
              <input
                type="text"
                value={pmAssignee}
                onChange={(e) => setPmAssignee(e.target.value)}
                placeholder="MK"
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-white border border-zinc-200 text-[#09090B]"
              />
            </div>
            <div className="sm:col-span-3 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-600 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
              >
                Save Task
              </button>
            </div>
          </form>
        )}

        {/* Current Records Table */}
        {filteredRecords.length === 0 ? (
          <div className="py-10 text-center text-xs text-zinc-500">
            No records in {activeTabLabel}. Upload a CSV/XLSX file or add an
            entry above.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#FAFAFA] border-b border-zinc-200 text-[11px] font-medium text-zinc-500">
                  {domain === 'environment' ? (
                    <>
                      <th className="px-4 py-3">Name</th>
                      <th className="px-3 py-3">Code</th>
                      <th className="px-3 py-3">Environment</th>
                      <th className="px-3 py-3">Status</th>
                      <th className="px-3 py-3">Endpoint</th>
                      <th className="px-3 py-3">Owner</th>
                    </>
                  ) : (
                    <>
                      <th className="px-4 py-3">Task / Finding</th>
                      <th className="px-3 py-3">Date</th>
                      <th className="px-3 py-3">Priority</th>
                      <th className="px-3 py-3">Tag</th>
                      <th className="px-3 py-3">Status</th>
                      <th className="px-3 py-3">Assignee</th>
                    </>
                  )}
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200">
                {domain === 'environment'
                  ? (filteredRecords as EnvironmentEntry[]).map((row) => (
                      <tr
                        key={row.id}
                        className="hover:bg-zinc-50/80 transition-colors"
                      >
                        <td className="px-4 py-3">
                          <div className="font-semibold text-[#09090B]">
                            {row.name}
                          </div>
                          <div className="text-[11px] text-zinc-500 truncate max-w-[260px]">
                            {row.subtitle}
                          </div>
                        </td>
                        <td className="px-3 py-3 font-mono text-[11px] text-zinc-600 whitespace-nowrap">
                          {row.code}
                        </td>
                        <td className="px-3 py-3 text-zinc-700 whitespace-nowrap">
                          {row.env}
                        </td>
                        <td className="px-3 py-3 text-zinc-700 whitespace-nowrap">
                          {row.status}
                        </td>
                        <td className="px-3 py-3 font-mono text-[11px] text-zinc-600 max-w-[200px] truncate">
                          {row.endpoint}
                        </td>
                        <td className="px-3 py-3 text-zinc-600 whitespace-nowrap">
                          {row.owner}
                        </td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => handleDeleteSingleRecord(row.id)}
                            aria-label={`Delete ${row.name}`}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:border-red-500 hover:text-red-600 text-[11px] font-medium transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" aria-hidden="true" />
                            <span>Delete</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  : (filteredRecords as PmTaskRow[]).map((row) => (
                      <tr
                        key={row.id}
                        className="hover:bg-zinc-50/80 transition-colors"
                      >
                        <td className="px-4 py-3 font-medium text-[#09090B] max-w-[340px]">
                          {row.name}
                        </td>
                        <td className="px-3 py-3 text-zinc-600 whitespace-nowrap tabular-nums">
                          {row.dateRange}
                        </td>
                        <td className="px-3 py-3 text-zinc-700 whitespace-nowrap">
                          {row.priority}
                        </td>
                        <td className="px-3 py-3 text-zinc-600 whitespace-nowrap">
                          {row.tag}
                        </td>
                        <td className="px-3 py-3 text-zinc-700 whitespace-nowrap">
                          {row.status}
                        </td>
                        <td className="px-3 py-3 font-mono text-[11px] text-zinc-600 whitespace-nowrap">
                          {row.assignee}
                        </td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => handleDeleteSingleRecord(row.id)}
                            aria-label={`Delete ${row.name}`}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-600 hover:border-red-500 hover:text-red-600 text-[11px] font-medium transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" aria-hidden="true" />
                            <span>Delete</span>
                          </button>
                        </td>
                      </tr>
                    ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Automatic Backup Snapshots & Version History */}
      <div className="rounded-2xl bg-white border border-zinc-200 overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-zinc-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-[#2563EB]" aria-hidden="true" />
              <h3 className="font-display text-sm font-semibold text-[#09090B]">
                Pre-Upload Backups &amp; Snapshots
              </h3>
              <span className="font-mono text-xs text-zinc-500 tabular-nums">
                · {visibleBackups.length}
              </span>
            </div>
            <p className="text-xs text-zinc-600">
              Latest state snapshots created automatically whenever you upload
              or clear data. Restore or export any snapshot anytime.
            </p>
          </div>

          <div className="inline-flex p-0.5 rounded-lg bg-zinc-100 border border-zinc-200 text-xs">
            <button
              type="button"
              onClick={() => setBackupScopeFilter('tab')}
              className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                backupScopeFilter === 'tab'
                  ? 'bg-white text-[#09090B] shadow-xs'
                  : 'text-zinc-600'
              }`}
            >
              {activeTabLabel}
            </button>
            <button
              type="button"
              onClick={() => setBackupScopeFilter('all')}
              className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                backupScopeFilter === 'all'
                  ? 'bg-white text-[#09090B] shadow-xs'
                  : 'text-zinc-600'
              }`}
            >
              All {domain === 'environment' ? 'Environment' : 'Project Management'} Backups ({domainBackups.length})
            </button>
          </div>
        </div>

        {visibleBackups.length === 0 ? (
          <div className="py-10 text-center text-xs text-zinc-500">
            No backups recorded yet for{' '}
            {backupScopeFilter === 'tab' ? activeTabLabel : 'any tab'}. An
            automatic backup is saved as soon as you upload a CSV/XLSX file.
          </div>
        ) : (
          <div className="divide-y divide-zinc-200">
            {visibleBackups.map((snap) => (
              <div
                key={snap.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-zinc-50/70 transition-colors text-xs"
              >
                <div className="min-w-0 space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-[#09090B]">
                      {snap.tabLabel}
                    </span>
                    <span className="text-zinc-400">·</span>
                    <span className="font-mono text-[11px] text-zinc-500 tabular-nums">
                      {snap.rowCount} rows
                    </span>
                    <span className="text-zinc-400">·</span>
                    <span className="font-mono text-[11px] text-zinc-500 tabular-nums">
                      {snap.createdAtLabel}
                    </span>
                  </div>
                  <div className="text-[11px] text-zinc-600 truncate">
                    {snap.reason}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => downloadBackupSnapshot(snap, 'xlsx')}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-700 hover:border-zinc-300 text-[11px] font-medium cursor-pointer"
                  >
                    <Download className="w-3 h-3" aria-hidden="true" />
                    <span>.xlsx</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => downloadBackupSnapshot(snap, 'csv')}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-700 hover:border-zinc-300 text-[11px] font-medium cursor-pointer"
                  >
                    <Download className="w-3 h-3" aria-hidden="true" />
                    <span>.csv</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRestoreBackup(snap)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#2563EB]/30 bg-[#2563EB]/8 text-[#2563EB] hover:bg-[#2563EB] hover:text-white text-[11px] font-medium transition-colors cursor-pointer"
                  >
                    <ArchiveRestore className="w-3 h-3" aria-hidden="true" />
                    <span>Restore</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteBackup(snap.id)}
                    aria-label={`Delete backup ${snap.createdAtLabel}`}
                    className="p-1.5 rounded-md border border-zinc-200 bg-[#FAFAFA] text-zinc-500 hover:border-red-500 hover:text-red-600 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" aria-hidden="true" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
