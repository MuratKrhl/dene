import React from 'react';

interface SafeMarkdownProps {
  markdown: string;
}

function renderInline(text: string): React.ReactNode[] {
  // Parse inline code, bold, italic, and safe http(s) links without dangerouslySetInnerHTML
  const tokens = text.split(/(`[^`]+`|\[[^\]]+\]\([^)]+\)|\*\*[^*]+\*\*)/g);
  return tokens.map((token, idx) => {
    if (token.startsWith('`') && token.endsWith('`') && token.length >= 2) {
      return (
        <code
          key={idx}
          className="px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 font-mono text-[12px] text-[#09090B] dark:text-zinc-200"
        >
          {token.slice(1, -1)}
        </code>
      );
    }

    if (token.startsWith('**') && token.endsWith('**') && token.length >= 4) {
      return (
        <strong key={idx} className="font-semibold text-[#09090B] dark:text-[#FAFAFA]">
          {token.slice(2, -2)}
        </strong>
      );
    }

    const linkMatch = token.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (linkMatch) {
      const label = linkMatch[1];
      const href = linkMatch[2].trim();
      const isSafe =
        href.startsWith('https://') ||
        href.startsWith('http://') ||
        href.startsWith('#');
      if (!isSafe) {
        return <span key={idx}>{label}</span>;
      }
      return (
        <a
          key={idx}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#2563EB] dark:text-blue-400 hover:underline"
        >
          {label}
        </a>
      );
    }

    return <React.Fragment key={idx}>{token}</React.Fragment>;
  });
}

export const SafeMarkdown: React.FC<SafeMarkdownProps> = ({ markdown }) => {
  const lines = markdown.replace(/\r\n/g, '\n').split('\n');
  const blocks: React.ReactNode[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // Fenced code block
    if (line.trim().startsWith('```')) {
      const lang = line.trim().slice(3).trim();
      const codeLines: string[] = [];
      i += 1;
      while (i < lines.length && !lines[i].trim().startsWith('```')) {
        codeLines.push(lines[i]);
        i += 1;
      }
      blocks.push(
        <div
          key={`code-${i}`}
          className="rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden my-3"
        >
          {lang && (
            <div className="px-3.5 py-1.5 border-b border-zinc-800 text-[11px] font-mono text-zinc-400">
              {lang}
            </div>
          )}
          <pre className="p-3.5 text-xs font-mono text-zinc-100 overflow-x-auto leading-relaxed">
            <code>{codeLines.join('\n')}</code>
          </pre>
        </div>
      );
      i += 1;
      continue;
    }

    // Headings
    const headingMatch = line.match(/^(#{1,4})\s+(.+)$/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      const content = headingMatch[2].replace(/<[^>]+>/g, '').trim();
      const cls =
        level === 1
          ? 'font-display text-2xl font-bold text-[#09090B] dark:text-[#FAFAFA] pt-2 pb-2 border-b border-zinc-200 dark:border-zinc-800'
          : level === 2
            ? 'font-display text-xl font-semibold text-[#09090B] dark:text-[#FAFAFA] pt-4 pb-1 border-b border-zinc-100 dark:border-zinc-800/70'
            : 'font-display text-base font-semibold text-[#09090B] dark:text-[#FAFAFA] pt-3';
      blocks.push(
        <div key={`h-${i}`} className={cls}>
          {renderInline(content)}
        </div>
      );
      i += 1;
      continue;
    }

    // Unordered list block
    if (/^\s*[-*+]\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*[-*+]\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*[-*+]\s+/, ''));
        i += 1;
      }
      blocks.push(
        <ul
          key={`ul-${i}`}
          className="list-disc pl-5 space-y-1 text-sm text-zinc-700 dark:text-zinc-300"
        >
          {items.map((item, idx) => (
            <li key={idx}>{renderInline(item)}</li>
          ))}
        </ul>
      );
      continue;
    }

    // Blockquote
    if (line.trim().startsWith('>')) {
      blocks.push(
        <blockquote
          key={`bq-${i}`}
          className="pl-4 py-1 text-sm italic text-zinc-600 dark:text-zinc-400 border-l border-zinc-300 dark:border-zinc-700"
        >
          {renderInline(line.replace(/^\s*>\s?/, ''))}
        </blockquote>
      );
      i += 1;
      continue;
    }

    // Horizontal rule
    if (/^[-*_]{3,}$/.test(line.trim())) {
      blocks.push(
        <hr key={`hr-${i}`} className="border-zinc-200 dark:border-zinc-800 my-4" />
      );
      i += 1;
      continue;
    }

    // Skip raw HTML comment/tag lines safely
    if (line.trim().startsWith('<') && line.trim().endsWith('>')) {
      i += 1;
      continue;
    }

    if (!line.trim()) {
      i += 1;
      continue;
    }

    // Paragraph (coalesce contiguous non-empty lines)
    const paraLines: string[] = [];
    while (
      i < lines.length &&
      lines[i].trim() &&
      !lines[i].trim().startsWith('```') &&
      !/^#{1,4}\s+/.test(lines[i]) &&
      !/^\s*[-*+]\s+/.test(lines[i]) &&
      !lines[i].trim().startsWith('>')
    ) {
      paraLines.push(lines[i]);
      i += 1;
    }

    blocks.push(
      <p
        key={`p-${i}`}
        className="text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed"
      >
        {renderInline(paraLines.join(' '))}
      </p>
    );
  }

  return <div className="space-y-3">{blocks}</div>;
};
