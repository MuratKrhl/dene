import React, { useEffect, useState } from 'react';
import { Layers, Grid3X3 } from 'lucide-react';

interface ResilientImageProps {
  src?: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
  specimenType?: 'tokens' | 'grid';
}

export const ResilientImage: React.FC<ResilientImageProps> = ({
  src,
  alt,
  className = '',
  fallbackTitle = 'Visual Preview',
  specimenType,
}) => {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [src]);

  if (specimenType === 'tokens') {
    return (
      <div
        className={`relative w-full h-full overflow-hidden bg-zinc-100 dark:bg-zinc-900 flex flex-col justify-between p-6 select-none ${className}`}
        aria-label={alt}
      >
        <div className="flex items-center justify-between text-xs font-mono text-zinc-500 dark:text-zinc-400">
          <span>tokens.semantic.json</span>
          <Layers className="w-4 h-4 text-[#2563EB] dark:text-blue-400" aria-hidden="true" />
        </div>
        <div className="grid grid-cols-3 gap-3 my-auto py-4">
          <div className="rounded-lg bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 p-3">
            <div className="w-full h-7 rounded bg-[#09090B] dark:bg-zinc-100 mb-2" />
            <div className="text-[11px] font-mono text-zinc-700 dark:text-zinc-300 truncate">
              ink.primary
            </div>
            <div className="text-[10px] font-mono text-zinc-400">18.4:1 AA</div>
          </div>
          <div className="rounded-lg bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 p-3">
            <div className="w-full h-7 rounded bg-[#2563EB] mb-2" />
            <div className="text-[11px] font-mono text-zinc-700 dark:text-zinc-300 truncate">
              action.accent
            </div>
            <div className="text-[10px] font-mono text-zinc-400">5.1:1 AA</div>
          </div>
          <div className="rounded-lg bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 p-3">
            <div className="w-full h-7 rounded bg-zinc-200 dark:bg-zinc-800 mb-2" />
            <div className="text-[11px] font-mono text-zinc-700 dark:text-zinc-300 truncate">
              border.hairline
            </div>
            <div className="text-[10px] font-mono text-zinc-400">1px solid</div>
          </div>
        </div>
        <div className="flex items-center justify-between border-t border-zinc-200 dark:border-zinc-800 pt-3 text-[11px] font-mono text-zinc-500 dark:text-zinc-400">
          <span>48 Primitives</span>
          <span>Light / Dark Verified</span>
        </div>
      </div>
    );
  }

  if (specimenType === 'grid') {
    return (
      <div
        className={`relative w-full h-full overflow-hidden bg-zinc-100 dark:bg-zinc-900 flex flex-col justify-between p-6 select-none ${className}`}
        aria-label={alt}
      >
        <div className="flex items-center justify-between text-xs font-mono text-zinc-500 dark:text-zinc-400">
          <span>swiss-grid-12col</span>
          <Grid3X3 className="w-4 h-4 text-[#2563EB] dark:text-blue-400" aria-hidden="true" />
        </div>
        <div className="grid grid-cols-6 gap-2 my-auto py-4 h-36">
          <div className="col-span-4 rounded border border-dashed border-zinc-300 dark:border-zinc-700 bg-white/80 dark:bg-zinc-950/70 p-3 flex flex-col justify-between">
            <span className="font-display text-base font-semibold text-zinc-900 dark:text-zinc-100 leading-tight">
              Typography &amp; Spatial Cadence
            </span>
            <span className="text-[11px] font-mono text-zinc-500 dark:text-zinc-400">
              measure: 65ch · leading: 1.65
            </span>
          </div>
          <div className="col-span-2 rounded border border-dashed border-zinc-300 dark:border-zinc-700 bg-white/50 dark:bg-zinc-950/40 p-3 flex flex-col justify-end">
            <span className="text-[11px] font-mono text-zinc-500 dark:text-zinc-400">
              Marginalia track
            </span>
          </div>
        </div>
        <div className="flex items-center justify-between border-t border-zinc-200 dark:border-zinc-800 pt-3 text-[11px] font-mono text-zinc-500 dark:text-zinc-400">
          <span>Baseline 8px</span>
          <span>Print + Web CSS</span>
        </div>
      </div>
    );
  }

  if (!src || hasError) {
    return (
      <div
        className={`relative w-full h-full bg-zinc-100 dark:bg-zinc-900 flex flex-col items-center justify-center p-6 text-center ${className}`}
        role="img"
        aria-label={alt}
      >
        <Layers className="w-7 h-7 text-zinc-400 dark:text-zinc-600 mb-2" aria-hidden="true" />
        <span className="text-sm font-medium text-zinc-600 dark:text-zinc-400">
          {fallbackTitle}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      loading="lazy"
      decoding="async"
      onError={() => setHasError(true)}
      className={`w-full h-full object-cover ${className}`}
    />
  );
};
