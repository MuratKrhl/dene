import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  Check,
  CheckSquare,
  ChevronDown,
  ChevronRight,
  Clock,
  Code2,
  Copy,
  Download,
  ExternalLink,
  Eye,
  FileCode2,
  FileText,
  Folder,
  Globe,
  Heading2,
  Maximize2,
  Monitor,
  PencilLine,
  Plus,
  Save,
  Search,
  Star,
} from 'lucide-react';
import { ONENOTE_NEW_CONTEXT_KEY } from '../pages/OneNoteDetailPage';
import {
  OneNoteFileItem,
  OneNoteSource,
  OneNoteSourceType,
  formatOneNoteDate,
  formatOneNoteTimestamp,
  loadOneNoteFiles,
  loadOneNoteSources,
  saveOneNoteFiles,
  saveOneNoteSources,
} from '../services/oneNoteStore';

type SourceTypeFilter = 'all' | OneNoteSourceType | 'starred';
type EditorViewMode = 'edit' | 'preview';

interface KnowledgeOneNoteTabProps {
  onNavigate: (path: string) => void;
}

function getAccentBarClass(accent: OneNoteSource['accent']): string {
  switch (accent) {
    case 'emerald':
      return 'bg-emerald-500';
    case 'amber':
      return 'bg-amber-500';
    case 'slate':
      return 'bg-zinc-500';
    case 'cobalt':
    default:
      return 'bg-[#2563EB]';
  }
}

export const KnowledgeOneNoteTab: React.FC<KnowledgeOneNoteTabProps> = ({
  onNavigate,
}) => {
  const [sources, setSources] = useState<OneNoteSource[]>(() =>
    loadOneNoteSources().filter((s) => s.enabled)
  );
  const [files, setFiles] = useState<OneNoteFileItem[]>(() =>
    loadOneNoteFiles()
  );

  const [typeFilter, setTypeFilter] = useState<SourceTypeFilter>('all');
  const [selectedSourceId, setSelectedSourceId] = useState<string | null>(null);
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [expandedSources, setExpandedSources] = useState<Record<string, boolean>>(
    () => {
      const initial: Record<string, boolean> = {};
      loadOneNoteSources().forEach((s) => {
        initial[s.id] = true;
      });
      return initial;
    }
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFileId, setSelectedFileId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<EditorViewMode>('edit');

  // Draft state for explicit Update & Save tracking
  const [draftTitle, setDraftTitle] = useState('');
  const [draftSection, setDraftSection] = useState('');
  const [isCustomDraftSection, setIsCustomDraftSection] = useState(false);
  const [draftTagsText, setDraftTagsText] = useState('');
  const [draftContent, setDraftContent] = useState('');
  const [savedNotice, setSavedNotice] = useState('');
  const [copiedPath, setCopiedPath] = useState(false);

  const sourceMap = useMemo(() => {
    const map = new Map<string, OneNoteSource>();
    sources.forEach((s) => map.set(s.id, s));
    return map;
  }, [sources]);

  // Only show files whose parent source is enabled
  const enabledFiles = useMemo(
    () => files.filter((f) => sourceMap.has(f.sourceId)),
    [files, sourceMap]
  );

  const visibleSources = useMemo(() => {
    if (typeFilter === 'windows' || typeFilter === 'https') {
      return sources.filter((s) => s.type === typeFilter);
    }
    return sources;
  }, [sources, typeFilter]);

  const sectionsBySource = useMemo(() => {
    const map = new Map<string, string[]>();
    sources.forEach((src) => {
      const set = new Set<string>();
      enabledFiles
        .filter((f) => f.sourceId === src.id)
        .forEach((f) => set.add(f.section));
      map.set(src.id, Array.from(set));
    });
    return map;
  }, [sources, enabledFiles]);

  const filteredFiles = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return enabledFiles.filter((file) => {
      const parent = sourceMap.get(file.sourceId);
      if (!parent) return false;

      if (typeFilter === 'windows' && parent.type !== 'windows') return false;
      if (typeFilter === 'https' && parent.type !== 'https') return false;
      if (typeFilter === 'starred' && !file.starred) return false;
      if (selectedSourceId && file.sourceId !== selectedSourceId) return false;
      if (selectedSection && file.section !== selectedSection) return false;

      if (!q) return true;
      return (
        file.title.toLowerCase().includes(q) ||
        file.fileName.toLowerCase().includes(q) ||
        file.section.toLowerCase().includes(q) ||
        file.content.toLowerCase().includes(q) ||
        file.tags.some((t) => t.toLowerCase().includes(q)) ||
        parent.name.toLowerCase().includes(q) ||
        parent.location.toLowerCase().includes(q)
      );
    });
  }, [
    enabledFiles,
    sourceMap,
    typeFilter,
    selectedSourceId,
    selectedSection,
    searchQuery,
  ]);

  const activeFile = useMemo(() => {
    if (selectedFileId) {
      const found = filteredFiles.find((f) => f.id === selectedFileId);
      if (found) return found;
    }
    return filteredFiles[0] || null;
  }, [filteredFiles, selectedFileId]);

  const activeSource = activeFile
    ? sourceMap.get(activeFile.sourceId) || null
    : selectedSourceId
      ? sourceMap.get(selectedSourceId) || null
      : null;

  // Sync draft state whenever active file changes
  useEffect(() => {
    if (!activeFile) {
      setDraftTitle('');
      setDraftSection('');
      setDraftTagsText('');
      setDraftContent('');
      return;
    }
    setDraftTitle(activeFile.title);
    setDraftSection(activeFile.section);
    setIsCustomDraftSection(false);
    setDraftTagsText(activeFile.tags.join(', '));
    setDraftContent(activeFile.content);
    setSavedNotice('');
  }, [activeFile?.id]);

  const activeFileSourceSections = useMemo(() => {
    const set = new Set<string>();
    if (activeFile) {
      enabledFiles
        .filter((f) => f.sourceId === activeFile.sourceId)
        .forEach((f) => {
          if (f.section.trim()) set.add(f.section.trim());
        });
      if (activeFile.section.trim()) set.add(activeFile.section.trim());
    }
    if (draftSection.trim() && !isCustomDraftSection) {
      set.add(draftSection.trim());
    }
    if (set.size === 0) set.add('General Notes');
    return Array.from(set);
  }, [activeFile, enabledFiles, draftSection, isCustomDraftSection]);

  const hasUnsavedChanges = useMemo(() => {
    if (!activeFile) return false;
    return (
      draftTitle !== activeFile.title ||
      draftSection !== activeFile.section ||
      draftTagsText !== activeFile.tags.join(', ') ||
      draftContent !== activeFile.content
    );
  }, [activeFile, draftTitle, draftSection, draftTagsText, draftContent]);

  const persistFilesAndTouchSource = (
    nextFiles: OneNoteFileItem[],
    touchedSourceId?: string
  ) => {
    setFiles(nextFiles);
    saveOneNoteFiles(nextFiles);

    if (touchedSourceId) {
      const allSources = loadOneNoteSources().map((s) =>
        s.id === touchedSourceId
          ? { ...s, lastSynced: formatOneNoteTimestamp() }
          : s
      );
      saveOneNoteSources(allSources);
      setSources(allSources.filter((s) => s.enabled));
    }
  };

  const handleSaveUpdate = () => {
    if (!activeFile) return;
    const cleanTitle = draftTitle.trim() || activeFile.title;
    const cleanSection = draftSection.trim() || activeFile.section;
    const cleanTags = draftTagsText
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);
    const nextVersion = (activeFile.version || 1) + 1;

    const parentSrc = sourceMap.get(activeFile.sourceId);
    const sep = parentSrc?.type === 'windows' ? '\\' : '/';

    const updatedFiles = files.map((f) => {
      if (f.id !== activeFile.id) return f;
      return {
        ...f,
        title: cleanTitle,
        section: cleanSection,
        relativePath: parentSrc
          ? `${parentSrc.name}${sep}${cleanSection}${sep}${f.fileName}`
          : f.relativePath,
        tags: cleanTags,
        content: draftContent,
        updatedAt: formatOneNoteDate(),
        updatedBy: 'Admin',
        version: nextVersion,
      };
    });

    persistFilesAndTouchSource(updatedFiles, activeFile.sourceId);
    setDraftSection(cleanSection);
    setIsCustomDraftSection(false);
    setSavedNotice(`Updated v${nextVersion} · ${formatOneNoteTimestamp()}`);
  };

  // Ctrl+S / Cmd+S support inside OneNote workspace
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        if (activeFile && hasUnsavedChanges) {
          e.preventDefault();
          handleSaveUpdate();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  const handleAddPageInActiveNotebook = () => {
    const targetSource = activeSource || visibleSources[0] || sources[0];
    const section = selectedSection || activeFile?.section || 'General Notes';
    try {
      sessionStorage.setItem(
        ONENOTE_NEW_CONTEXT_KEY,
        JSON.stringify({
          sourceId: targetSource?.id,
          section,
        })
      );
    } catch {
      // Ignore storage error
    }
    onNavigate('/knowledge-hub/onenote/new');
  };

  const handleToggleStar = (id: string) => {
    const next = files.map((f) =>
      f.id === id ? { ...f, starred: !f.starred } : f
    );
    setFiles(next);
    saveOneNoteFiles(next);
  };

  const handleCopyLocation = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedPath(true);
      window.setTimeout(() => setCopiedPath(false), 1500);
    } catch {
      setCopiedPath(false);
    }
  };

  const handleExportActiveNote = () => {
    if (!activeFile) return;
    const content = `# ${draftTitle}\nSection: ${draftSection}\nSource: ${
      activeSource?.location || ''
    }\nUpdated: ${activeFile.updatedAt} (v${activeFile.version})\n\n${draftContent}`;
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeFile.fileName.replace(/\.[^.]+$/, '')}.md`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const appendSnippet = (snippet: string) => {
    setViewMode('edit');
    setDraftContent((prev) =>
      prev.endsWith('\n') || prev === '' ? `${prev}${snippet}` : `${prev}\n${snippet}`
    );
  };

  const handleTogglePreviewCheckbox = (lineIndex: number) => {
    const lines = draftContent.split('\n');
    const line = lines[lineIndex];
    if (!line) return;
    if (line.trimStart().startsWith('- [ ] ')) {
      lines[lineIndex] = line.replace('- [ ] ', '- [x] ');
    } else if (line.trimStart().startsWith('- [x] ')) {
      lines[lineIndex] = line.replace('- [x] ', '- [ ] ');
    } else {
      return;
    }
    const nextContent = lines.join('\n');
    setDraftContent(nextContent);
    if (activeFile) {
      const nextVersion = (activeFile.version || 1) + 1;
      const updatedFiles = files.map((f) =>
        f.id === activeFile.id
          ? {
              ...f,
              content: nextContent,
              updatedAt: formatOneNoteDate(),
              version: nextVersion,
            }
          : f
      );
      persistFilesAndTouchSource(updatedFiles, activeFile.sourceId);
      setSavedNotice(`Updated v${nextVersion} · ${formatOneNoteTimestamp()}`);
    }
  };

  if (sources.length === 0) {
    return (
      <div className="p-12 rounded-2xl bg-white border border-zinc-200 text-center space-y-3">
        <BookOpen
          className="w-8 h-8 text-[#2563EB] mx-auto"
          aria-hidden="true"
        />
        <h2 className="font-display text-lg font-semibold text-[#09090B]">
          No OneNote Sources Configured
        </h2>
        <p className="text-xs text-zinc-600 max-w-md mx-auto">
          Add a Windows UNC/local folder or HTTPS SharePoint/OneNote address
          under Admin &gt; OneNote to browse and update your notebook files
          here.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Top Workspace Control Bar */}
      <div className="p-4 rounded-2xl bg-white border border-zinc-200 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex p-0.5 rounded-lg bg-zinc-100 border border-zinc-200 text-xs">
            {(
              [
                { key: 'all', label: `All (${enabledFiles.length})` },
                { key: 'windows', label: 'Windows' },
                { key: 'https', label: 'HTTPS' },
                { key: 'starred', label: 'Starred' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.key}
                type="button"
                onClick={() => {
                  setTypeFilter(opt.key);
                  setSelectedSourceId(null);
                  setSelectedSection(null);
                }}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  typeFilter === opt.key
                    ? 'bg-white text-[#09090B] shadow-xs'
                    : 'text-zinc-600 hover:text-[#09090B]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {activeSource && (
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[11px] text-zinc-600 max-w-md truncate">
              {activeSource.type === 'windows' ? (
                <Monitor
                  className="w-3.5 h-3.5 text-[#2563EB] shrink-0"
                  aria-hidden="true"
                />
              ) : (
                <Globe
                  className="w-3.5 h-3.5 text-emerald-600 shrink-0"
                  aria-hidden="true"
                />
              )}
              <span className="font-mono truncate">{activeSource.location}</span>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-full sm:w-64">
            <Search
              className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search notebooks, files, notes..."
              aria-label="Search OneNote files"
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
            />
          </div>

          <button
            type="button"
            onClick={handleAddPageInActiveNotebook}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>New Page</span>
          </button>
        </div>
      </div>

      {/* 3-Pane Dribbble OneNote Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch min-h-[620px]">
        {/* PANE 1: Notebooks (Windows & HTTPS) & Sections */}
        <aside
          aria-label="OneNote notebooks and sections"
          className="lg:col-span-3 rounded-2xl bg-white border border-zinc-200 p-4 flex flex-col justify-between gap-4"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#09090B]">
                <BookOpen
                  className="w-4 h-4 text-[#2563EB]"
                  aria-hidden="true"
                />
                <span>Notebooks ({visibleSources.length})</span>
              </div>
              {(selectedSourceId || selectedSection) && (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedSourceId(null);
                    setSelectedSection(null);
                  }}
                  className="text-[11px] font-medium text-[#2563EB] hover:underline cursor-pointer"
                >
                  All
                </button>
              )}
            </div>

            <div className="space-y-2">
              {visibleSources.map((src) => {
                const isExpanded = expandedSources[src.id] ?? true;
                const isSrcSelected =
                  selectedSourceId === src.id && !selectedSection;
                const srcSections = sectionsBySource.get(src.id) || [];
                const srcFileCount = enabledFiles.filter(
                  (f) => f.sourceId === src.id
                ).length;

                return (
                  <div
                    key={src.id}
                    className="rounded-xl border border-zinc-200 bg-[#FAFAFA]/70 overflow-hidden"
                  >
                    <div className="flex items-center gap-1.5 p-2">
                      <span
                        aria-hidden="true"
                        className={`w-1 h-7 rounded-full shrink-0 ${getAccentBarClass(
                          src.accent
                        )}`}
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedSources((prev) => ({
                            ...prev,
                            [src.id]: !isExpanded,
                          }))
                        }
                        aria-label={`Toggle sections for ${src.name}`}
                        className="p-1 text-zinc-400 hover:text-zinc-700 cursor-pointer shrink-0"
                      >
                        {isExpanded ? (
                          <ChevronDown className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setSelectedSourceId(src.id);
                          setSelectedSection(null);
                        }}
                        className={`flex-1 min-w-0 text-left px-1.5 py-1 rounded-md transition-colors cursor-pointer ${
                          isSrcSelected ? 'bg-white shadow-2xs' : ''
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span
                            className={`text-xs font-semibold truncate ${
                              selectedSourceId === src.id
                                ? 'text-[#2563EB]'
                                : 'text-[#09090B]'
                            }`}
                          >
                            {src.name}
                          </span>
                          <span className="font-mono text-[10px] text-zinc-500 tabular-nums shrink-0">
                            {srcFileCount}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 text-[10px] text-zinc-500 truncate mt-0.5">
                          {src.type === 'windows' ? (
                            <Monitor className="w-3 h-3 shrink-0 text-[#2563EB]" />
                          ) : (
                            <Globe className="w-3 h-3 shrink-0 text-emerald-600" />
                          )}
                          <span className="uppercase font-mono">
                            {src.type}
                          </span>
                          <span>·</span>
                          <span className="truncate font-mono">
                            {src.location}
                          </span>
                        </div>
                      </button>
                    </div>

                    {isExpanded && srcSections.length > 0 && (
                      <div className="px-2.5 pb-2.5 pt-1 space-y-0.5 border-t border-zinc-200/70 bg-white">
                        {srcSections.map((sec) => {
                          const isSecActive =
                            selectedSourceId === src.id &&
                            selectedSection === sec;
                          const secCount = enabledFiles.filter(
                            (f) => f.sourceId === src.id && f.section === sec
                          ).length;

                          return (
                            <button
                              key={sec}
                              type="button"
                              onClick={() => {
                                setSelectedSourceId(src.id);
                                setSelectedSection(sec);
                              }}
                              className={`w-full px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                                isSecActive
                                  ? 'bg-[#2563EB]/10 text-[#2563EB] font-medium'
                                  : 'text-zinc-700 hover:bg-zinc-100'
                              }`}
                            >
                              <span className="inline-flex items-center gap-2 min-w-0">
                                <Folder
                                  className={`w-3.5 h-3.5 shrink-0 ${
                                    isSecActive
                                      ? 'text-[#2563EB]'
                                      : 'text-zinc-400'
                                  }`}
                                  aria-hidden="true"
                                />
                                <span className="truncate">{sec}</span>
                              </span>
                              <span className="font-mono text-[10px] text-zinc-400 tabular-nums">
                                {secCount}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-3 border-t border-zinc-200 text-[11px] text-zinc-500">
            Sources are registered under <span className="font-medium text-[#09090B]">Admin &gt; OneNote</span> (Windows &amp; HTTPS).
          </div>
        </aside>

        {/* PANE 2: Section Files / Pages */}
        <section
          aria-label="OneNote files list"
          className="lg:col-span-3 rounded-2xl bg-white border border-zinc-200 flex flex-col overflow-hidden"
        >
          <div className="px-4 py-3 border-b border-zinc-200 flex items-center justify-between gap-2 bg-[#FAFAFA]">
            <span className="text-xs font-semibold text-[#09090B] truncate">
              {selectedSection || activeSource?.name || 'All Files'}
            </span>
            <span className="font-mono text-[11px] text-zinc-500 tabular-nums shrink-0">
              {filteredFiles.length} files
            </span>
          </div>

          {filteredFiles.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-xs text-zinc-500 space-y-2">
              <FileText className="w-6 h-6 text-zinc-300" aria-hidden="true" />
              <p className="font-medium text-[#09090B]">No matching files</p>
              <p>Try clearing filters or create a new page in this notebook.</p>
            </div>
          ) : (
            <div className="divide-y divide-zinc-200 overflow-y-auto max-h-[600px]">
              {filteredFiles.map((file) => {
                const active = activeFile?.id === file.id;
                const parent = sourceMap.get(file.sourceId);
                const snippet = file.content
                  .replace(/^#+\s*/gm, '')
                  .replace(/\s+/g, ' ')
                  .trim()
                  .slice(0, 78);

                return (
                  <div
                    key={file.id}
                    className={`p-3.5 transition-colors flex items-start justify-between gap-2 ${
                      active
                        ? 'bg-[#2563EB]/8 border-l-2 border-l-[#2563EB]'
                        : 'hover:bg-zinc-50'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setSelectedFileId(file.id)}
                      className="flex-1 min-w-0 text-left space-y-1 cursor-pointer"
                    >
                      <div className="flex items-center gap-1.5 text-[10px] text-zinc-500">
                        <span className="font-mono font-medium px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-700">
                          {file.fileFormat}
                        </span>
                        <span className="truncate">{file.section}</span>
                        <span>·</span>
                        <span className="font-mono tabular-nums">
                          v{file.version}
                        </span>
                      </div>

                      <div
                        className={`text-xs font-semibold truncate ${
                          active ? 'text-[#2563EB]' : 'text-[#09090B]'
                        }`}
                      >
                        {file.title}
                      </div>

                      <div className="text-[11px] font-mono text-zinc-500 truncate">
                        {file.fileName}
                      </div>

                      <p className="text-[11px] text-zinc-600 line-clamp-2 leading-relaxed">
                        {snippet}
                      </p>

                      <div className="flex items-center gap-1.5 text-[10px] text-zinc-400 pt-0.5 tabular-nums">
                        <span>
                          {parent?.type === 'windows' ? 'Windows' : 'HTTPS'}
                        </span>
                        <span>·</span>
                        <span>{file.updatedAt}</span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleToggleStar(file.id)}
                      aria-label={
                        file.starred
                          ? `Unstar ${file.title}`
                          : `Star ${file.title}`
                      }
                      className={`p-1 rounded transition-colors cursor-pointer shrink-0 ${
                        file.starred
                          ? 'text-[#2563EB]'
                          : 'text-zinc-300 hover:text-zinc-600'
                      }`}
                    >
                      <Star
                        className={`w-3.5 h-3.5 ${
                          file.starred ? 'fill-current' : ''
                        }`}
                      />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* PANE 3: Active Note Canvas & Direct Updater */}
        <section
          aria-label="Active OneNote document workspace"
          className="lg:col-span-6 rounded-2xl bg-white border border-zinc-200 flex flex-col overflow-hidden"
        >
          {!activeFile || !activeSource ? (
            <div className="flex-1 flex flex-col items-center justify-center p-10 text-center text-xs text-zinc-500 space-y-2">
              <BookOpen className="w-7 h-7 text-zinc-300" aria-hidden="true" />
              <p className="text-sm font-medium text-[#09090B]">
                Select a OneNote file to view or update
              </p>
              <p>
                Choose any file from your configured Windows or HTTPS notebooks.
              </p>
            </div>
          ) : (
            <>
              {/* Source Address & Action Header */}
              <div className="px-5 py-3.5 border-b border-zinc-200 bg-[#FAFAFA] space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0 text-xs">
                    {activeSource.type === 'windows' ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-zinc-200 font-medium text-[#09090B]">
                        <Monitor
                          className="w-3 h-3 text-[#2563EB]"
                          aria-hidden="true"
                        />
                        <span>Windows</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-zinc-200 font-medium text-[#09090B]">
                        <Globe
                          className="w-3 h-3 text-emerald-600"
                          aria-hidden="true"
                        />
                        <span>HTTPS</span>
                      </span>
                    )}
                    <span className="font-mono text-[11px] text-zinc-600 truncate">
                      {activeFile.relativePath}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleCopyLocation(activeSource.location)}
                      title="Copy source address"
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded-md border border-zinc-200 bg-white text-zinc-700 hover:border-zinc-300 cursor-pointer"
                    >
                      {copiedPath ? (
                        <Check className="w-3 h-3 text-[#2563EB]" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                      <span>{copiedPath ? 'Copied' : 'Copy Path'}</span>
                    </button>

                    {activeSource.type === 'https' && (
                      <a
                        href={activeSource.location}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded-md border border-zinc-200 bg-white text-[#2563EB] hover:border-[#2563EB]"
                      >
                        <span>Open Link</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}

                    <button
                      type="button"
                      onClick={handleExportActiveNote}
                      title="Export note as Markdown"
                      className="p-1.5 rounded-md border border-zinc-200 bg-white text-zinc-600 hover:text-[#09090B] cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        onNavigate(
                          `/knowledge-hub/onenote/page/${encodeURIComponent(
                            activeFile.id
                          )}`
                        )
                      }
                      title="Open in full-page editor"
                      className="p-1.5 rounded-md border border-zinc-200 bg-white text-zinc-600 hover:text-[#2563EB] hover:border-[#2563EB] cursor-pointer"
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Editor Toolbar */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <div className="inline-flex p-0.5 rounded-lg bg-zinc-200/70 text-[11px]">
                      <button
                        type="button"
                        onClick={() => setViewMode('edit')}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                          viewMode === 'edit'
                            ? 'bg-white text-[#09090B] shadow-2xs'
                            : 'text-zinc-600'
                        }`}
                      >
                        <PencilLine className="w-3 h-3" />
                        <span>Edit</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setViewMode('preview')}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                          viewMode === 'preview'
                            ? 'bg-white text-[#09090B] shadow-2xs'
                            : 'text-zinc-600'
                        }`}
                      >
                        <Eye className="w-3 h-3" />
                        <span>Preview</span>
                      </button>
                    </div>

                    <div className="hidden sm:inline-flex items-center gap-1 pl-1">
                      <button
                        type="button"
                        onClick={() => appendSnippet('## Section Heading\n')}
                        title="Insert heading"
                        className="p-1.5 rounded-md border border-zinc-200 bg-white text-zinc-600 hover:text-[#09090B] cursor-pointer"
                      >
                        <Heading2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => appendSnippet('- [ ] Checklist item')}
                        title="Insert checklist item"
                        className="p-1.5 rounded-md border border-zinc-200 bg-white text-zinc-600 hover:text-[#09090B] cursor-pointer"
                      >
                        <CheckSquare className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => appendSnippet('```\n# command\n```')}
                        title="Insert code snippet"
                        className="p-1.5 rounded-md border border-zinc-200 bg-white text-zinc-600 hover:text-[#09090B] cursor-pointer"
                      >
                        <Code2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          appendSnippet(`> Updated: ${formatOneNoteTimestamp()}`)
                        }
                        title="Insert timestamp"
                        className="p-1.5 rounded-md border border-zinc-200 bg-white text-zinc-600 hover:text-[#09090B] cursor-pointer"
                      >
                        <Clock className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {savedNotice && !hasUnsavedChanges && (
                      <span className="text-[11px] font-mono text-emerald-700">
                        {savedNotice}
                      </span>
                    )}
                    {hasUnsavedChanges && (
                      <button
                        type="button"
                        onClick={() => {
                          setDraftTitle(activeFile.title);
                          setDraftSection(activeFile.section);
                          setIsCustomDraftSection(false);
                          setDraftTagsText(activeFile.tags.join(', '));
                          setDraftContent(activeFile.content);
                        }}
                        className="px-2.5 py-1.5 text-[11px] font-medium rounded-lg border border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-100 cursor-pointer"
                      >
                        Reset
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={handleSaveUpdate}
                      disabled={!hasUnsavedChanges}
                      className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                        hasUnsavedChanges
                          ? 'bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer'
                          : 'bg-zinc-100 text-zinc-400 border border-zinc-200 cursor-default'
                      }`}
                    >
                      <Save className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>
                        {hasUnsavedChanges ? 'Save Update' : `Saved · v${activeFile.version}`}
                      </span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Document Body */}
              <div className="flex-1 p-5 sm:p-6 space-y-4 overflow-y-auto">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <label
                        htmlFor="on-edit-section"
                        className="block text-[11px] font-medium text-zinc-500"
                      >
                        Section
                      </label>
                      {isCustomDraftSection && (
                        <button
                          type="button"
                          onClick={() => {
                            setIsCustomDraftSection(false);
                            setDraftSection(
                              activeFileSourceSections[0] ||
                                activeFile.section ||
                                'General Notes'
                            );
                          }}
                          className="text-[10px] font-medium text-[#2563EB] hover:underline cursor-pointer"
                        >
                          Select existing
                        </button>
                      )}
                    </div>
                    {isCustomDraftSection ? (
                      <input
                        id="on-edit-section"
                        type="text"
                        autoFocus
                        value={draftSection}
                        onChange={(e) => setDraftSection(e.target.value)}
                        placeholder="Enter new section name..."
                        className="w-full px-3 py-1.5 text-xs font-medium rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B] focus:outline-none focus:border-[#2563EB]"
                      />
                    ) : (
                      <select
                        id="on-edit-section"
                        value={draftSection}
                        onChange={(e) => {
                          if (e.target.value === '__new_section__') {
                            setIsCustomDraftSection(true);
                            setDraftSection('');
                          } else {
                            setDraftSection(e.target.value);
                          }
                        }}
                        className="w-full px-3 py-1.5 text-xs font-medium rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B] focus:outline-none focus:border-[#2563EB]"
                      >
                        {activeFileSourceSections.map((sec) => (
                          <option key={sec} value={sec}>
                            {sec}
                          </option>
                        ))}
                        <option value="__new_section__">+ New Section...</option>
                      </select>
                    )}
                  </div>
                  <div className="space-y-1">
                    <label
                      htmlFor="on-edit-tags"
                      className="block text-[11px] font-medium text-zinc-500"
                    >
                      Tags (comma separated)
                    </label>
                    <input
                      id="on-edit-tags"
                      type="text"
                      value={draftTagsText}
                      onChange={(e) => setDraftTagsText(e.target.value)}
                      placeholder="JBoss, Runbook, Prod"
                      className="w-full px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B] focus:outline-none focus:border-[#2563EB]"
                    />
                  </div>
                </div>

                <input
                  type="text"
                  value={draftTitle}
                  onChange={(e) => setDraftTitle(e.target.value)}
                  aria-label="Note title"
                  className="w-full font-display text-xl sm:text-2xl font-bold text-[#09090B] bg-transparent border-b border-zinc-200 pb-2 focus:outline-none focus:border-[#2563EB]"
                />

                {viewMode === 'edit' ? (
                  <textarea
                    rows={15}
                    value={draftContent}
                    onChange={(e) => setDraftContent(e.target.value)}
                    aria-label="OneNote document content"
                    className="w-full p-4 text-sm font-mono leading-relaxed rounded-xl bg-[#FAFAFA] border border-zinc-200 text-[#09090B] focus:outline-none focus:border-[#2563EB]"
                  />
                ) : (
                  <div className="p-5 rounded-xl bg-[#FAFAFA] border border-zinc-200 space-y-2.5 text-sm leading-relaxed text-[#09090B]">
                    {draftContent.split('\n').map((line, idx) => {
                      const trimmed = line.trim();
                      if (!trimmed) return <div key={idx} className="h-2" />;
                      if (trimmed.startsWith('# ')) {
                        return (
                          <h3
                            key={idx}
                            className="font-display text-lg font-bold text-[#09090B] pt-1"
                          >
                            {trimmed.slice(2)}
                          </h3>
                        );
                      }
                      if (trimmed.startsWith('## ')) {
                        return (
                          <h4
                            key={idx}
                            className="font-display text-base font-semibold text-[#09090B] pt-1"
                          >
                            {trimmed.slice(3)}
                          </h4>
                        );
                      }
                      if (
                        trimmed.startsWith('- [ ] ') ||
                        trimmed.startsWith('- [x] ')
                      ) {
                        const checked = trimmed.startsWith('- [x] ');
                        return (
                          <label
                            key={idx}
                            className="flex items-start gap-2.5 cursor-pointer py-0.5"
                          >
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => handleTogglePreviewCheckbox(idx)}
                              className="mt-1 rounded border-zinc-300 cursor-pointer"
                            />
                            <span
                              className={
                                checked
                                  ? 'line-through text-zinc-400'
                                  : 'text-[#09090B]'
                              }
                            >
                              {trimmed.slice(6)}
                            </span>
                          </label>
                        );
                      }
                      if (trimmed.startsWith('> ')) {
                        return (
                          <blockquote
                            key={idx}
                            className="pl-3 border-l-2 border-[#2563EB] text-xs font-mono text-zinc-600"
                          >
                            {trimmed.slice(2)}
                          </blockquote>
                        );
                      }
                      return (
                        <p key={idx} className="text-zinc-800 whitespace-pre-wrap">
                          {line}
                        </p>
                      );
                    })}
                  </div>
                )}

                <div className="pt-2 border-t border-zinc-200 flex flex-wrap items-center justify-between gap-2 text-[11px] text-zinc-500 tabular-nums">
                  <div className="inline-flex items-center gap-2">
                    <FileCode2 className="w-3.5 h-3.5 text-zinc-400" />
                    <span className="font-mono">{activeFile.fileName}</span>
                    <span>·</span>
                    <span>Updated by {activeFile.updatedBy}</span>
                  </div>
                  <span className="font-mono">
                    Last saved: {activeFile.updatedAt} · v{activeFile.version}
                  </span>
                </div>
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
};
