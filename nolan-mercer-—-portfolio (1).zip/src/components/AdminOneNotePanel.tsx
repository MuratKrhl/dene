import React, { useMemo, useRef, useState } from 'react';
import {
  ArrowUpRight,
  BookOpen,
  Check,
  FileText,
  FolderUp,
  Globe,
  Monitor,
  Pencil,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import {
  OneNoteFileItem,
  OneNoteSource,
  OneNoteSourceType,
  detectOneNoteFileFormat,
  formatOneNoteDate,
  formatOneNoteTimestamp,
  loadOneNoteFiles,
  loadOneNoteSources,
  saveOneNoteFiles,
  saveOneNoteSources,
} from '../services/oneNoteStore';

interface AdminOneNotePanelProps {
  onNavigate: (path: string) => void;
}

export const AdminOneNotePanel: React.FC<AdminOneNotePanelProps> = ({
  onNavigate,
}) => {
  const [sources, setSources] = useState<OneNoteSource[]>(() =>
    loadOneNoteSources()
  );
  const [files, setFiles] = useState<OneNoteFileItem[]>(() =>
    loadOneNoteFiles()
  );
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | OneNoteSourceType>(
    'all'
  );

  // Add/Edit Source Form
  const [showSourceForm, setShowSourceForm] = useState(false);
  const [editTarget, setEditTarget] = useState<OneNoteSource | null>(null);
  const [sourceType, setSourceType] = useState<OneNoteSourceType>('windows');
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [accent, setAccent] = useState<OneNoteSource['accent']>('cobalt');
  const [initialSection, setInitialSection] = useState('General Notes');
  const [initialFileTitle, setInitialFileTitle] = useState('');
  const [pickedFiles, setPickedFiles] = useState<File[]>([]);
  const [formError, setFormError] = useState('');
  const [statusNote, setStatusNote] = useState('');

  // Add extra file to existing source
  const [addFileSourceId, setAddFileSourceId] = useState<string | null>(null);
  const [newFileSection, setNewFileSection] = useState('General Notes');
  const [newFileName, setNewFileName] = useState('');
  const [newFileTitle, setNewFileTitle] = useState('');
  const [newFileContent, setNewFileContent] = useState('');

  const localFilesRef = useRef<HTMLInputElement | null>(null);

  const persistSources = (next: OneNoteSource[]) => {
    setSources(next);
    saveOneNoteSources(next);
  };

  const persistFiles = (next: OneNoteFileItem[]) => {
    setFiles(next);
    saveOneNoteFiles(next);
  };

  const resetForm = (target: OneNoteSource | null = null) => {
    setEditTarget(target);
    setSourceType(target?.type || 'windows');
    setName(target?.name || '');
    setLocation(target?.location || '');
    setDescription(target?.description || '');
    setAccent(target?.accent || 'cobalt');
    setInitialSection('General Notes');
    setInitialFileTitle('');
    setPickedFiles([]);
    setFormError('');
  };

  const openAddSource = () => {
    resetForm(null);
    setShowSourceForm(true);
    setStatusNote('');
  };

  const openEditSource = (src: OneNoteSource) => {
    resetForm(src);
    setShowSourceForm(true);
    setStatusNote('');
  };

  const handleLocalWindowsPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list || list.length === 0) return;
    const arr = Array.from(list);
    setPickedFiles(arr);
    if (!name.trim()) {
      const firstRel = (arr[0] as File & { webkitRelativePath?: string })
        .webkitRelativePath;
      const folderName = firstRel ? firstRel.split('/')[0] : 'Windows OneNote';
      setName(folderName);
    }
    if (!location.trim()) {
      const firstRel = (arr[0] as File & { webkitRelativePath?: string })
        .webkitRelativePath;
      const folderName = firstRel ? firstRel.split('/')[0] : 'OneNote';
      setLocation(`C:\\Users\\OneNote\\${folderName}`);
    }
    setFormError('');
  };

  const handleSaveSource = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    let cleanLoc = location.trim();

    if (!cleanName) {
      setFormError('Please enter a notebook display name.');
      return;
    }
    if (!cleanLoc) {
      setFormError(
        sourceType === 'windows'
          ? 'Please enter a Windows path (e.g. \\\\server\\share\\OneNote\\Notebook or C:\\OneNote\\...).'
          : 'Please enter an HTTPS URL (e.g. https://corp.sharepoint.com/...).'
      );
      return;
    }
    if (sourceType === 'https' && !/^https?:\/\//i.test(cleanLoc)) {
      cleanLoc = `https://${cleanLoc}`;
    }

    const sourceId = editTarget?.id || `on-src-${Date.now()}`;
    const draftSource: OneNoteSource = {
      id: sourceId,
      name: cleanName,
      type: sourceType,
      location: cleanLoc,
      description:
        description.trim() ||
        `${
          sourceType === 'windows' ? 'Windows UNC/Local' : 'HTTPS'
        } OneNote repository`,
      accent,
      status:
        pickedFiles.length > 0
          ? 'Local Mounted'
          : sourceType === 'windows'
            ? 'Synced'
            : 'Connected',
      lastSynced: formatOneNoteTimestamp(),
      enabled: editTarget ? editTarget.enabled : true,
    };

    const exists = sources.some((s) => s.id === sourceId);
    const nextSources = exists
      ? sources.map((s) => (s.id === sourceId ? draftSource : s))
      : [draftSource, ...sources];
    persistSources(nextSources);

    // Build files for this source if newly added or local files picked
    const newFilesForSource: OneNoteFileItem[] = [];
    const sep = sourceType === 'windows' ? '\\' : '/';
    const today = formatOneNoteDate();

    if (pickedFiles.length > 0) {
      for (let i = 0; i < pickedFiles.length; i++) {
        const f = pickedFiles[i];
        const rel =
          (f as File & { webkitRelativePath?: string }).webkitRelativePath ||
          f.name;
        const parts = rel.split('/');
        const section =
          parts.length >= 2 ? parts[parts.length - 2] : initialSection.trim() || 'Imported';
        const fmt = detectOneNoteFileFormat(f.name);
        let body = `# ${f.name}\n\nWindows path: ${cleanLoc}${sep}${f.name}\nImported from local folder.`;
        if (fmt === '.md' || fmt === '.txt') {
          try {
            const text = await f.text();
            if (text.trim()) body = text;
          } catch {
            // Keep fallback summary
          }
        }
        newFilesForSource.push({
          id: `on-file-${Date.now()}-${i}`,
          sourceId,
          section,
          fileName: f.name,
          title: f.name.replace(/\.[^.]+$/, ''),
          relativePath: `${cleanLoc}${sep}${rel.replace(/\//g, sep)}`,
          fileFormat: fmt,
          tags: ['Windows', section],
          starred: false,
          updatedAt: today,
          updatedBy: 'Admin',
          version: 1,
          content: body,
        });
      }
    } else if (!exists) {
      // Seed an editable notebook page at the configured Windows/HTTPS address
      const pageTitle =
        initialFileTitle.trim() || `${cleanName} — Index Notes`;
      const slugName = pageTitle
        .replace(/[^a-zA-Z0-9]+/g, '-')
        .replace(/^-|-$/g, '');
      const fileName = `${slugName || 'Notebook-Index'}.one`;
      const sec = initialSection.trim() || 'General Notes';

      let fetchedNoteBody = '';
      if (sourceType === 'https') {
        try {
          const resp = await fetch(cleanLoc);
          if (resp.ok) {
            const ct = resp.headers.get('content-type') || '';
            if (ct.includes('text/plain') || ct.includes('markdown')) {
              fetchedNoteBody = (await resp.text()).slice(0, 8000);
            }
          }
        } catch {
          // CORS or non-raw HTML endpoint; use clean structured template below
        }
      }

      newFilesForSource.push({
        id: `on-file-${Date.now()}-0`,
        sourceId,
        section: sec,
        fileName,
        title: pageTitle,
        relativePath: `${cleanLoc}${sep}${sec}${sep}${fileName}`,
        fileFormat: '.one',
        tags: [sourceType === 'windows' ? 'Windows' : 'HTTPS', sec],
        starred: false,
        updatedAt: today,
        updatedBy: 'Admin',
        version: 1,
        content:
          fetchedNoteBody ||
          `# ${pageTitle}\n\n- Source Address: ${cleanLoc}\n- Connection Type: ${
            sourceType === 'windows' ? 'Windows Share / Local' : 'HTTPS'
          }\n- [ ] Add runbook notes or update content directly from Knowledge Hub > OneNote.`,
      });
    }

    if (newFilesForSource.length > 0) {
      persistFiles([...newFilesForSource, ...files]);
    }

    setStatusNote(
      `${editTarget ? 'Updated' : 'Added'} ${
        sourceType === 'windows' ? 'Windows' : 'HTTPS'
      } OneNote source "${cleanName}"${
        newFilesForSource.length > 0
          ? ` (${newFilesForSource.length} file${
              newFilesForSource.length > 1 ? 's' : ''
            } indexed)`
          : ''
      }.`
    );
    setShowSourceForm(false);
    resetForm(null);
  };

  const handleToggleEnabled = (id: string) => {
    persistSources(
      sources.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s))
    );
  };

  const handleDeleteSource = (id: string) => {
    const target = sources.find((s) => s.id === id);
    persistSources(sources.filter((s) => s.id !== id));
    persistFiles(files.filter((f) => f.sourceId !== id));
    if (editTarget?.id === id) {
      setShowSourceForm(false);
      resetForm(null);
    }
    if (target) {
      setStatusNote(`Removed OneNote source "${target.name}".`);
    }
  };

  const handleAddFileToSource = (e: React.FormEvent, src: OneNoteSource) => {
    e.preventDefault();
    const title = newFileTitle.trim();
    if (!title) return;
    const rawFileName =
      newFileName.trim() ||
      `${title.replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-|-$/g, '') || 'Note'}.one`;
    const fileName = rawFileName.includes('.') ? rawFileName : `${rawFileName}.one`;
    const sec = newFileSection.trim() || 'General Notes';
    const sep = src.type === 'windows' ? '\\' : '/';

    const item: OneNoteFileItem = {
      id: `on-file-${Date.now()}`,
      sourceId: src.id,
      section: sec,
      fileName,
      title,
      relativePath: `${src.location}${sep}${sec}${sep}${fileName}`,
      fileFormat: detectOneNoteFileFormat(fileName),
      tags: [src.type === 'windows' ? 'Windows' : 'HTTPS', sec],
      starred: false,
      updatedAt: formatOneNoteDate(),
      updatedBy: 'Admin',
      version: 1,
      content:
        newFileContent.trim() ||
        `# ${title}\n\n- Source: ${src.location}\n- [ ] Document notes here.`,
    };

    persistFiles([item, ...files]);
    persistSources(
      sources.map((s) =>
        s.id === src.id ? { ...s, lastSynced: formatOneNoteTimestamp() } : s
      )
    );
    setAddFileSourceId(null);
    setNewFileTitle('');
    setNewFileName('');
    setNewFileContent('');
    setStatusNote(`Added "${fileName}" under ${src.name}.`);
  };

  const handleDeleteFile = (fileId: string) => {
    persistFiles(files.filter((f) => f.id !== fileId));
  };

  const filteredSources = useMemo(() => {
    const q = search.trim().toLowerCase();
    return sources.filter((src) => {
      if (typeFilter !== 'all' && src.type !== typeFilter) return false;
      if (!q) return true;
      return (
        src.name.toLowerCase().includes(q) ||
        src.location.toLowerCase().includes(q) ||
        src.description.toLowerCase().includes(q)
      );
    });
  }, [sources, typeFilter, search]);

  return (
    <section aria-label="OneNote Admin Management" className="space-y-5">
      {/* Toolbar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white border border-zinc-200 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#2563EB]" aria-hidden="true" />
            <h2 className="font-display text-lg font-semibold text-[#09090B]">
              OneNote Sources (Windows &amp; HTTPS)
            </h2>
            <span className="text-xs font-mono text-zinc-500 tabular-nums">
              · {sources.length} sources / {files.length} files
            </span>
          </div>
          <p className="text-xs text-zinc-600">
            Register Windows UNC/local paths or HTTPS SharePoint/OneDrive
            OneNote locations. All added files appear and can be updated inside
            Knowledge Hub &gt; OneNote.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex p-0.5 rounded-lg bg-zinc-100 border border-zinc-200 text-xs">
            {(
              [
                { key: 'all', label: 'All' },
                { key: 'windows', label: 'Windows' },
                { key: 'https', label: 'HTTPS' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.key}
                type="button"
                onClick={() => setTypeFilter(opt.key)}
                className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                  typeFilter === opt.key
                    ? 'bg-white text-[#09090B] shadow-xs'
                    : 'text-zinc-600'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-48">
            <Search
              className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search sources..."
              aria-label="Search OneNote sources"
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
            />
          </div>

          <button
            type="button"
            onClick={() => onNavigate('/knowledge-hub/onenote')}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 bg-[#FAFAFA] text-zinc-700 hover:border-zinc-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <span>Open OneNote</span>
            <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={openAddSource}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Add OneNote Source</span>
          </button>
        </div>
      </div>

      {statusNote && (
        <div
          role="status"
          className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center justify-between gap-2"
        >
          <span>{statusNote}</span>
          <button
            type="button"
            onClick={() => setStatusNote('')}
            aria-label="Dismiss status"
            className="p-1 text-emerald-700 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Add / Edit OneNote Source Form */}
      {showSourceForm && (
        <form
          onSubmit={handleSaveSource}
          className="p-6 rounded-2xl bg-white border border-zinc-200 space-y-5"
        >
          <div className="flex items-center justify-between border-b border-zinc-200 pb-3">
            <h3 className="font-display text-sm font-semibold text-[#09090B]">
              {editTarget
                ? `Edit OneNote Source — ${editTarget.name}`
                : 'Add OneNote Source (Windows or HTTPS)'}
            </h3>
            <button
              type="button"
              onClick={() => {
                setShowSourceForm(false);
                resetForm(null);
              }}
              aria-label="Close source form"
              className="p-1 text-zinc-400 hover:text-[#09090B] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => {
                setSourceType('windows');
                setFormError('');
              }}
              className={`p-3.5 rounded-xl border text-left transition-colors cursor-pointer flex items-start gap-3 ${
                sourceType === 'windows'
                  ? 'bg-[#2563EB]/8 border-[#2563EB] text-[#2563EB]'
                  : 'bg-[#FAFAFA] border-zinc-200 text-zinc-700 hover:border-zinc-300'
              }`}
            >
              <Monitor className="w-4 h-4 mt-0.5 shrink-0" />
              <div className="space-y-0.5 text-xs">
                <div className="font-semibold">Windows Path / Share</div>
                <div className="text-[11px] text-zinc-500 font-mono">
                  \\server\share\OneNote or C:\Users\...
                </div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                setSourceType('https');
                setFormError('');
              }}
              className={`p-3.5 rounded-xl border text-left transition-colors cursor-pointer flex items-start gap-3 ${
                sourceType === 'https'
                  ? 'bg-[#2563EB]/8 border-[#2563EB] text-[#2563EB]'
                  : 'bg-[#FAFAFA] border-zinc-200 text-zinc-700 hover:border-zinc-300'
              }`}
            >
              <Globe className="w-4 h-4 mt-0.5 shrink-0" />
              <div className="space-y-0.5 text-xs">
                <div className="font-semibold">HTTPS Web / SharePoint</div>
                <div className="text-[11px] text-zinc-500 font-mono">
                  https://tenant.sharepoint.com/...
                </div>
              </div>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
            <div className="sm:col-span-4 space-y-1">
              <label
                htmlFor="admin-on-name"
                className="block text-xs font-medium text-zinc-700"
              >
                Notebook Name *
              </label>
              <input
                id="admin-on-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Infrastructure Runbooks"
                className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
              />
            </div>

            <div className="sm:col-span-6 space-y-1">
              <label
                htmlFor="admin-on-loc"
                className="block text-xs font-medium text-zinc-700"
              >
                {sourceType === 'windows'
                  ? 'Windows UNC or Local Path *'
                  : 'HTTPS Address *'}
              </label>
              <input
                id="admin-on-loc"
                type="text"
                required
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder={
                  sourceType === 'windows'
                    ? '\\\\corp-fs01.internal\\engineering\\OneNote\\Runbooks'
                    : 'https://corp.sharepoint.com/sites/Engineering/OneNote'
                }
                className="w-full px-3 py-2 text-xs font-mono rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
              />
            </div>

            <div className="sm:col-span-2 space-y-1">
              <label
                htmlFor="admin-on-accent"
                className="block text-xs font-medium text-zinc-700"
              >
                Spine Color
              </label>
              <select
                id="admin-on-accent"
                value={accent}
                onChange={(e) =>
                  setAccent(e.target.value as OneNoteSource['accent'])
                }
                className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
              >
                <option value="cobalt">Cobalt</option>
                <option value="emerald">Emerald</option>
                <option value="amber">Amber</option>
                <option value="slate">Slate</option>
              </select>
            </div>
          </div>

          {sourceType === 'windows' && !editTarget && (
            <div className="p-4 rounded-xl bg-[#FAFAFA] border border-zinc-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="space-y-0.5">
                <div className="font-medium text-[#09090B]">
                  Optional: Pick Local Windows OneNote Files (.one, .onetoc2, .md, .txt)
                </div>
                <div className="text-[11px] text-zinc-500">
                  Import existing files directly from a Windows folder, or leave
                  empty to create an editable notebook at the UNC/path above.
                </div>
              </div>
              <div>
                <input
                  ref={localFilesRef}
                  type="file"
                  multiple
                  accept=".one,.onetoc2,.md,.txt"
                  onChange={handleLocalWindowsPick}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => localFilesRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-[#09090B] hover:border-[#2563EB] cursor-pointer whitespace-nowrap"
                >
                  <FolderUp className="w-3.5 h-3.5 text-[#2563EB]" />
                  <span>
                    {pickedFiles.length > 0
                      ? `${pickedFiles.length} file(s) selected`
                      : 'Select Files from Disk'}
                  </span>
                </button>
              </div>
            </div>
          )}

          {!editTarget && pickedFiles.length === 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label
                  htmlFor="admin-on-sec"
                  className="block text-xs font-medium text-zinc-700"
                >
                  Initial Section Name
                </label>
                <input
                  id="admin-on-sec"
                  type="text"
                  value={initialSection}
                  onChange={(e) => setInitialSection(e.target.value)}
                  placeholder="General Notes"
                  className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
                />
              </div>
              <div className="space-y-1">
                <label
                  htmlFor="admin-on-ftitle"
                  className="block text-xs font-medium text-zinc-700"
                >
                  Initial Page / File Title
                </label>
                <input
                  id="admin-on-ftitle"
                  type="text"
                  value={initialFileTitle}
                  onChange={(e) => setInitialFileTitle(e.target.value)}
                  placeholder="e.g. Architecture & Runbook Overview"
                  className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
                />
              </div>
            </div>
          )}

          <div className="space-y-1">
            <label
              htmlFor="admin-on-desc"
              className="block text-xs font-medium text-zinc-700"
            >
              Description
            </label>
            <input
              id="admin-on-desc"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Summary of notebooks and engineering docs in this path..."
              className="w-full px-3 py-2 text-xs rounded-lg bg-[#FAFAFA] border border-zinc-200 text-[#09090B]"
            />
          </div>

          {formError && (
            <p role="alert" className="text-xs font-medium text-red-600">
              {formError}
            </p>
          )}

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setShowSourceForm(false);
                resetForm(null);
              }}
              className="px-4 py-2 text-xs font-medium rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-100 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{editTarget ? 'Update Source' : 'Save OneNote Source'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Registered OneNote Sources & Their Files */}
      <div className="space-y-4">
        {filteredSources.length === 0 ? (
          <div className="py-12 rounded-2xl bg-white border border-zinc-200 text-center space-y-2 text-xs text-zinc-500">
            <p className="text-sm font-medium text-[#09090B]">
              No OneNote sources found
            </p>
            <p>Click Add OneNote Source to register a Windows or HTTPS location.</p>
          </div>
        ) : (
          filteredSources.map((src) => {
            const srcFiles = files.filter((f) => f.sourceId === src.id);
            const isAddingFile = addFileSourceId === src.id;

            return (
              <div
                key={src.id}
                className="rounded-2xl bg-white border border-zinc-200 overflow-hidden"
              >
                <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#FAFAFA] border-b border-zinc-200">
                  <div className="min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      {src.type === 'windows' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-zinc-200 font-medium text-[#2563EB]">
                          <Monitor className="w-3 h-3" />
                          <span>Windows</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-zinc-200 font-medium text-emerald-700">
                          <Globe className="w-3 h-3" />
                          <span>HTTPS</span>
                        </span>
                      )}
                      <span className="font-semibold text-[#09090B]">
                        {src.name}
                      </span>
                      <span className="text-zinc-400">·</span>
                      <span className="font-mono text-[11px] text-zinc-500 tabular-nums">
                        {srcFiles.length} files
                      </span>
                      <span className="text-zinc-400">·</span>
                      <span className="font-mono text-[11px] text-zinc-500">
                        {src.lastSynced}
                      </span>
                    </div>
                    <div className="font-mono text-[11px] text-zinc-600 truncate">
                      {src.location}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setAddFileSourceId(isAddingFile ? null : src.id);
                        setNewFileSection('General Notes');
                        setNewFileName('');
                        setNewFileTitle('');
                        setNewFileContent('');
                      }}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-medium rounded-md border border-zinc-200 bg-white text-[#2563EB] hover:border-[#2563EB] cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Add File</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleToggleEnabled(src.id)}
                      className="px-2.5 py-1.5 text-[11px] font-medium rounded-md border border-zinc-200 bg-white text-zinc-700 cursor-pointer"
                    >
                      {src.enabled ? 'Enabled' : 'Disabled'}
                    </button>

                    <button
                      type="button"
                      onClick={() => openEditSource(src)}
                      aria-label={`Edit ${src.name}`}
                      className="p-1.5 rounded-md border border-zinc-200 bg-white text-zinc-600 hover:border-[#2563EB] hover:text-[#2563EB] cursor-pointer"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDeleteSource(src.id)}
                      aria-label={`Delete ${src.name}`}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-zinc-200 bg-white text-zinc-600 hover:border-red-500 hover:text-red-600 text-[11px] font-medium cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" aria-hidden="true" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>

                {/* Quick Add File Drawer inside Source */}
                {isAddingFile && (
                  <form
                    onSubmit={(e) => handleAddFileToSource(e, src)}
                    className="p-4 bg-blue-50/40 border-b border-zinc-200 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end"
                  >
                    <div className="sm:col-span-3 space-y-1">
                      <label className="block text-[11px] font-medium text-zinc-600">
                        Section
                      </label>
                      <input
                        type="text"
                        value={newFileSection}
                        onChange={(e) => setNewFileSection(e.target.value)}
                        placeholder="General Notes"
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-white border border-zinc-200"
                      />
                    </div>
                    <div className="sm:col-span-4 space-y-1">
                      <label className="block text-[11px] font-medium text-zinc-600">
                        Page Title *
                      </label>
                      <input
                        type="text"
                        required
                        value={newFileTitle}
                        onChange={(e) => setNewFileTitle(e.target.value)}
                        placeholder="HAProxy Healthcheck Guide"
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg bg-white border border-zinc-200"
                      />
                    </div>
                    <div className="sm:col-span-3 space-y-1">
                      <label className="block text-[11px] font-medium text-zinc-600">
                        File Name (.one / .md)
                      </label>
                      <input
                        type="text"
                        value={newFileName}
                        onChange={(e) => setNewFileName(e.target.value)}
                        placeholder="HAProxy-Guide.one"
                        className="w-full px-2.5 py-1.5 text-xs font-mono rounded-lg bg-white border border-zinc-200"
                      />
                    </div>
                    <div className="sm:col-span-2 flex items-center gap-1.5">
                      <button
                        type="submit"
                        className="flex-1 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] text-white cursor-pointer"
                      >
                        Save File
                      </button>
                      <button
                        type="button"
                        onClick={() => setAddFileSourceId(null)}
                        className="p-1.5 rounded-lg border border-zinc-200 bg-white text-zinc-500 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="sm:col-span-12 space-y-1">
                      <label className="block text-[11px] font-medium text-zinc-600">
                        Initial Content (optional — editable in Knowledge Hub &gt; OneNote)
                      </label>
                      <textarea
                        rows={2}
                        value={newFileContent}
                        onChange={(e) => setNewFileContent(e.target.value)}
                        placeholder="Notes, CLI commands, or checklist items..."
                        className="w-full px-3 py-1.5 text-xs font-mono rounded-lg bg-white border border-zinc-200"
                      />
                    </div>
                  </form>
                )}

                {/* Files inside this source */}
                {srcFiles.length === 0 ? (
                  <div className="p-4 text-xs text-zinc-500">
                    No files indexed under this source yet. Click Add File above
                    or create a page in Knowledge Hub &gt; OneNote.
                  </div>
                ) : (
                  <div className="divide-y divide-zinc-200">
                    {srcFiles.map((file) => (
                      <div
                        key={file.id}
                        className="px-4 py-2.5 flex items-center justify-between gap-3 text-xs hover:bg-zinc-50/70"
                      >
                        <div className="min-w-0 flex items-center gap-2.5">
                          <FileText
                            className="w-3.5 h-3.5 text-[#2563EB] shrink-0"
                            aria-hidden="true"
                          />
                          <div className="min-w-0">
                            <div className="font-medium text-[#09090B] truncate">
                              {file.title}
                            </div>
                            <div className="text-[11px] font-mono text-zinc-500 truncate">
                              {file.section} · {file.fileName} · v{file.version} ({file.updatedAt})
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteFile(file.id)}
                          aria-label={`Remove ${file.fileName}`}
                          className="p-1.5 rounded-md text-zinc-400 hover:text-red-600 cursor-pointer shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </section>
  );
};
