import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  ArrowUpRight,
  Check,
  ChevronDown,
  Columns3,
  Copy,
  Cpu,
  Download,
  Globe,
  Layers,
  Network,
  Search,
  Server,
  ShieldCheck,
  SlidersHorizontal,
  Workflow,
  Zap,
} from 'lucide-react';
import {
  EnvironmentEntry,
  EnvironmentTabConfig,
  EnvironmentTabKey,
  loadEnvironmentEntries,
  toEntrySlug,
} from '../data/environmentData';

type SortField =
  | 'name'
  | 'code'
  | 'status'
  | 'capacityValue'
  | 'expiryDate'
  | 'updatedAt';
type SortDirection = 'asc' | 'desc';

type ColumnKey =
  | 'icon'
  | 'name'
  | 'code'
  | 'status'
  | 'endpoint'
  | 'capacity'
  | 'usage'
  | 'expiry'
  | 'updated'
  | 'owner';

const COLUMN_DEFS: Array<{ key: ColumnKey; label: string }> = [
  { key: 'icon', label: 'Type' },
  { key: 'name', label: 'Name' },
  { key: 'code', label: 'Asset Code' },
  { key: 'status', label: 'Status' },
  { key: 'endpoint', label: 'Endpoint' },
  { key: 'capacity', label: 'Capacity' },
  { key: 'usage', label: 'Usage' },
  { key: 'expiry', label: 'Cert / SLA' },
  { key: 'updated', label: 'Updated' },
  { key: 'owner', label: 'Owner' },
];

const DEFAULT_VISIBLE_COLUMNS: Record<ColumnKey, boolean> = {
  icon: true,
  name: true,
  code: true,
  status: true,
  endpoint: true,
  capacity: true,
  usage: true,
  expiry: true,
  updated: true,
  owner: true,
};

function getTabIcon(tab: EnvironmentTabKey) {
  switch (tab) {
    case 'sunucu':
      return Server;
    case 'uygulama':
      return Layers;
    case 'openshift':
      return Cpu;
    case 'reverse-proxy':
      return ShieldCheck;
    case 'provenir':
      return Workflow;
    case 'evam':
      return Zap;
    case 'powercurve':
      return Network;
    default:
      return Globe;
  }
}

function getStatusDotClass(status: EnvironmentEntry['status']): string {
  switch (status) {
    case 'Online':
    case 'Healthy':
    case 'Active':
      return 'bg-emerald-500';
    case 'Degraded':
      return 'bg-red-500';
    case 'Maintenance':
      return 'bg-amber-500';
    case 'Standby':
    default:
      return 'bg-zinc-400';
  }
}

interface EnvironmentTableProps {
  tabConfig: EnvironmentTabConfig;
  onNavigate: (path: string) => void;
}

interface SavedTableViewState {
  envFilter: string;
  statusFilter: string;
  searchQuery: string;
  alertsOnly: boolean;
  sortField: SortField;
  sortDir: SortDirection;
}

function loadSavedTableViewState(tabKey: EnvironmentTabKey): SavedTableViewState {
  try {
    const raw = sessionStorage.getItem(`mk-env-table-state-v1:${tabKey}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        envFilter: parsed.envFilter || 'all',
        statusFilter: parsed.statusFilter || 'all',
        searchQuery: parsed.searchQuery || '',
        alertsOnly: Boolean(parsed.alertsOnly),
        sortField: parsed.sortField || 'name',
        sortDir: parsed.sortDir === 'desc' ? 'desc' : 'asc',
      };
    }
  } catch {
    // Ignore storage errors
  }
  return {
    envFilter: 'all',
    statusFilter: 'all',
    searchQuery: '',
    alertsOnly: false,
    sortField: 'name',
    sortDir: 'asc',
  };
}

export const EnvironmentTable: React.FC<EnvironmentTableProps> = ({
  tabConfig,
  onNavigate,
}) => {
  const [entries, setEntries] = useState<EnvironmentEntry[]>(() =>
    loadEnvironmentEntries()
  );

  const initialView = useMemo(
    () => loadSavedTableViewState(tabConfig.key),
    [tabConfig.key]
  );

  const [envFilter, setEnvFilter] = useState<string>(initialView.envFilter);
  const [statusFilter, setStatusFilter] = useState<string>(
    initialView.statusFilter
  );
  const [searchQuery, setSearchQuery] = useState(initialView.searchQuery);
  const [alertsOnly, setAlertsOnly] = useState(initialView.alertsOnly);
  const [showAdditionalFilters, setShowAdditionalFilters] = useState(false);

  const [sortField, setSortField] = useState<SortField>(initialView.sortField);
  const [sortDir, setSortDir] = useState<SortDirection>(initialView.sortDir);

  const [visibleCols, setVisibleCols] = useState<Record<ColumnKey, boolean>>(
    DEFAULT_VISIBLE_COLUMNS
  );
  const [showColumnsMenu, setShowColumnsMenu] = useState(false);
  const columnsMenuRef = useRef<HTMLDivElement | null>(null);

  const [selectedIds, setSelectedIds] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    const restored = loadSavedTableViewState(tabConfig.key);
    setEnvFilter(restored.envFilter);
    setStatusFilter(restored.statusFilter);
    setSearchQuery(restored.searchQuery);
    setAlertsOnly(restored.alertsOnly);
    setSortField(restored.sortField);
    setSortDir(restored.sortDir);
    setSelectedIds({});
  }, [tabConfig.key]);

  useEffect(() => {
    try {
      sessionStorage.setItem(
        `mk-env-table-state-v1:${tabConfig.key}`,
        JSON.stringify({
          envFilter,
          statusFilter,
          searchQuery,
          alertsOnly,
          sortField,
          sortDir,
        })
      );
    } catch {
      // Ignore storage errors
    }
  }, [
    tabConfig.key,
    envFilter,
    statusFilter,
    searchQuery,
    alertsOnly,
    sortField,
    sortDir,
  ]);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (
        columnsMenuRef.current &&
        !columnsMenuRef.current.contains(e.target as Node)
      ) {
        setShowColumnsMenu(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const openEntryDetail = (item: EnvironmentEntry) => {
    onNavigate(`/environment/${item.tab}/${encodeURIComponent(toEntrySlug(item))}`);
  };

  const tabEntries = useMemo(
    () => entries.filter((e) => e.tab === tabConfig.key),
    [entries, tabConfig.key]
  );

  const filteredRows = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = tabEntries.filter((item) => {
      if (envFilter !== 'all' && item.env !== envFilter) return false;
      if (statusFilter !== 'all' && item.status !== statusFilter) return false;
      if (
        alertsOnly &&
        item.alertLevel !== 'warning' &&
        item.alertLevel !== 'critical'
      ) {
        return false;
      }
      if (!q) return true;
      return (
        item.name.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q) ||
        item.code.toLowerCase().includes(q) ||
        item.endpoint.toLowerCase().includes(q) ||
        item.owner.toLowerCase().includes(q) ||
        item.version.toLowerCase().includes(q) ||
        item.regionOrCluster.toLowerCase().includes(q)
      );
    });

    list.sort((a, b) => {
      let cmp = 0;
      if (sortField === 'capacityValue') {
        cmp = a.capacityValue - b.capacityValue;
      } else {
        cmp = String(a[sortField]).localeCompare(String(b[sortField]));
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return list;
  }, [
    tabEntries,
    envFilter,
    statusFilter,
    alertsOnly,
    searchQuery,
    sortField,
    sortDir,
  ]);

  const totalCapacitySum = useMemo(
    () => filteredRows.reduce((acc, row) => acc + (row.capacityValue || 0), 0),
    [filteredRows]
  );

  const selectedRows = useMemo(
    () => filteredRows.filter((r) => selectedIds[r.id]),
    [filteredRows, selectedIds]
  );

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return (
        <ArrowUpDown className="w-3 h-3 text-zinc-400 opacity-60 group-hover:opacity-100" />
      );
    }
    return sortDir === 'asc' ? (
      <ArrowDown className="w-3 h-3 text-[#2563EB] dark:text-blue-400" />
    ) : (
      <ArrowUp className="w-3 h-3 text-[#2563EB] dark:text-blue-400" />
    );
  };

  const handleCopyEndpoint = async (item: EnvironmentEntry) => {
    try {
      await navigator.clipboard.writeText(item.endpoint);
      setCopiedId(item.id);
      window.setTimeout(() => setCopiedId(null), 1500);
    } catch {
      setCopiedId(null);
    }
  };

  const handleExportCsv = () => {
    const rowsToExport = selectedRows.length > 0 ? selectedRows : filteredRows;
    const headers = [
      'Category',
      'Name',
      'Subtitle',
      'Code',
      'Environment',
      'Status',
      'Endpoint',
      'Capacity',
      'Usage',
      'Version',
      'Expiry',
      'Updated',
      'Owner',
      'Cluster/Region',
    ];
    const escapeCell = (val: string) =>
      `"${String(val || '').replace(/"/g, '""')}"`;

    const csvLines = [
      headers.map(escapeCell).join(','),
      ...rowsToExport.map((r) =>
        [
          tabConfig.label,
          r.name,
          r.subtitle,
          r.code,
          r.env,
          r.status,
          r.endpoint,
          r.capacity,
          r.usageOrLoad,
          r.version,
          r.expiryDate,
          r.updatedAt,
          r.owner,
          r.regionOrCluster,
        ]
          .map(escapeCell)
          .join(',')
      ),
    ];

    const blob = new Blob([csvLines.join('\n')], {
      type: 'text/csv;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `environment-${tabConfig.key}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const TabIcon = getTabIcon(tabConfig.key);

  const activeColCount =
    2 + // checkbox + actions
    COLUMN_DEFS.filter((c) => visibleCols[c.key]).length;

  return (
    <div className="space-y-4">
      {/* Table Controls Bar (Filter Bar + Columns / CSV Utility Strip) */}
      <div className="p-4 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Left: Selectors + Search */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="inline-flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
              <span>Environment</span>
              <select
                aria-label="Filter by environment"
                value={envFilter}
                onChange={(e) => setEnvFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-[#09090B] dark:text-[#FAFAFA] focus:outline-none focus:border-[#2563EB]"
              >
                <option value="all">All Zones</option>
                <option value="Prod">Prod</option>
                <option value="UAT">UAT</option>
                <option value="Pre-Prod">Pre-Prod</option>
                <option value="DR">DR</option>
                <option value="Test">Test</option>
              </select>
            </div>

            <div className="inline-flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
              <span>Status</span>
              <select
                aria-label="Filter by status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-[#09090B] dark:text-[#FAFAFA] focus:outline-none focus:border-[#2563EB]"
              >
                <option value="all">All Statuses</option>
                <option value="Online">Online</option>
                <option value="Healthy">Healthy</option>
                <option value="Active">Active</option>
                <option value="Degraded">Degraded</option>
                <option value="Maintenance">Maintenance</option>
                <option value="Standby">Standby</option>
              </select>
            </div>

            <div className="relative w-full sm:w-56">
              <Search
                className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={`Filter ${tabConfig.label.toLowerCase()}...`}
                aria-label={`Filter ${tabConfig.label} table`}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
              />
            </div>
          </div>

          {/* Right: Columns ▾, CSV, Additional Filters */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowAdditionalFilters((v) => !v)}
              aria-pressed={showAdditionalFilters}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
                showAdditionalFilters || alertsOnly
                  ? 'border-[#2563EB] bg-[#2563EB]/10 text-[#2563EB] dark:text-blue-400'
                  : 'border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Filters</span>
            </button>

            <div className="relative" ref={columnsMenuRef}>
              <button
                type="button"
                onClick={() => setShowColumnsMenu((v) => !v)}
                aria-expanded={showColumnsMenu}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Columns3 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Columns</span>
                <ChevronDown className="w-3 h-3 text-zinc-400" aria-hidden="true" />
              </button>

              {showColumnsMenu && (
                <div className="absolute right-0 top-10 z-30 w-52 p-3 rounded-xl bg-white dark:bg-[#141418] border border-zinc-200 dark:border-zinc-800 shadow-lg space-y-2 text-xs">
                  <div className="font-semibold text-[#09090B] dark:text-[#FAFAFA] pb-1 border-b border-zinc-100 dark:border-zinc-800">
                    Visible Columns
                  </div>
                  {COLUMN_DEFS.map((col) => (
                    <label
                      key={col.key}
                      className="flex items-center justify-between gap-2 py-0.5 cursor-pointer text-zinc-700 dark:text-zinc-300"
                    >
                      <span>{col.label}</span>
                      <input
                        type="checkbox"
                        checked={visibleCols[col.key]}
                        onChange={(e) =>
                          setVisibleCols((prev) => ({
                            ...prev,
                            [col.key]: e.target.checked,
                          }))
                        }
                        className="rounded border-zinc-300 dark:border-zinc-700 cursor-pointer"
                      />
                    </label>
                  ))}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors cursor-pointer whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              <span>CSV</span>
            </button>
          </div>
        </div>

        {/* Additional Filters Strip */}
        {showAdditionalFilters && (
          <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex flex-wrap items-center gap-4">
              <label className="inline-flex items-center gap-2 cursor-pointer text-zinc-700 dark:text-zinc-300">
                <input
                  type="checkbox"
                  checked={alertsOnly}
                  onChange={(e) => setAlertsOnly(e.target.checked)}
                  className="rounded border-zinc-300 dark:border-zinc-700 cursor-pointer"
                />
                <span>Show expiry &amp; SLA warnings only</span>
              </label>

              <span className="text-zinc-500 dark:text-zinc-400">
                {tabConfig.description}
              </span>
            </div>

            {(envFilter !== 'all' ||
              statusFilter !== 'all' ||
              alertsOnly ||
              searchQuery) && (
              <button
                type="button"
                onClick={() => {
                  setEnvFilter('all');
                  setStatusFilter('all');
                  setAlertsOnly(false);
                  setSearchQuery('');
                }}
                className="text-xs font-medium text-[#2563EB] dark:text-blue-400 hover:underline cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
        )}

        {/* Selected Bulk Action Bar */}
        {selectedRows.length > 0 && (
          <div className="p-2.5 rounded-xl bg-[#2563EB]/8 dark:bg-blue-500/10 border border-[#2563EB]/20 flex flex-wrap items-center justify-between gap-3 text-xs">
            <span className="font-medium text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
              {selectedRows.length} row{selectedRows.length > 1 ? 's' : ''} selected
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleExportCsv}
                className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-[#2563EB] text-white font-medium cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Export Selected CSV</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedIds({})}
                className="px-2.5 py-1 text-zinc-600 dark:text-zinc-400 hover:underline cursor-pointer"
              >
                Clear
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Main Hairline Data Table (Dribbble Table Structure, Astra Editorial Palette) */}
      <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400 align-bottom">
              <th className="w-9 pl-3.5 pr-1.5 py-3">
                <input
                  type="checkbox"
                  aria-label={`Select all ${tabConfig.label} entries`}
                  checked={
                    filteredRows.length > 0 &&
                    filteredRows.every((r) => selectedIds[r.id])
                  }
                  onChange={(e) => {
                    const checked = e.target.checked;
                    const next: Record<string, boolean> = {};
                    if (checked) {
                      filteredRows.forEach((r) => {
                        next[r.id] = true;
                      });
                    }
                    setSelectedIds(next);
                  }}
                  className="rounded border-zinc-300 dark:border-zinc-700 cursor-pointer"
                />
              </th>

              {visibleCols.icon && (
                <th className="w-11 px-2 py-3 whitespace-nowrap">Type</th>
              )}

              {visibleCols.name && (
                <th className="px-2.5 py-3 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => handleSort('name')}
                    className="group inline-flex items-center gap-1 hover:text-[#09090B] dark:hover:text-[#FAFAFA] cursor-pointer"
                  >
                    <span>Name</span>
                    {renderSortIcon('name')}
                  </button>
                </th>
              )}

              {visibleCols.code && (
                <th className="px-2.5 py-3 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => handleSort('code')}
                    className="group inline-flex items-center gap-1 hover:text-[#09090B] dark:hover:text-[#FAFAFA] cursor-pointer"
                  >
                    <span>Code</span>
                    {renderSortIcon('code')}
                  </button>
                </th>
              )}

              {visibleCols.status && (
                <th className="px-2.5 py-3 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => handleSort('status')}
                    className="group inline-flex items-center gap-1 hover:text-[#09090B] dark:hover:text-[#FAFAFA] cursor-pointer"
                  >
                    <span>Status</span>
                    {renderSortIcon('status')}
                  </button>
                </th>
              )}

              {visibleCols.endpoint && (
                <th className="px-2.5 py-3 whitespace-nowrap hidden md:table-cell">
                  Endpoint
                </th>
              )}

              {visibleCols.capacity && (
                <th className="px-2.5 py-3 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => handleSort('capacityValue')}
                    className="group text-left hover:text-[#09090B] dark:hover:text-[#FAFAFA] cursor-pointer"
                  >
                    <div className="inline-flex items-center gap-1">
                      <span>Capacity</span>
                      {renderSortIcon('capacityValue')}
                    </div>
                    <div className="font-mono text-[10px] font-normal text-zinc-400 tabular-nums">
                      ({totalCapacitySum.toLocaleString()} {tabConfig.capacitySummaryUnit})
                    </div>
                  </button>
                </th>
              )}

              {visibleCols.usage && (
                <th className="px-2.5 py-3 whitespace-nowrap hidden lg:table-cell">
                  <div>Load</div>
                  <div className="text-[10px] font-normal text-zinc-400">
                    {tabConfig.usageSublabel}
                  </div>
                </th>
              )}

              {visibleCols.expiry && (
                <th className="px-2.5 py-3 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => handleSort('expiryDate')}
                    className="group inline-flex items-center gap-1 hover:text-[#09090B] dark:hover:text-[#FAFAFA] cursor-pointer"
                  >
                    <span>{tabConfig.expiryLabel}</span>
                    {renderSortIcon('expiryDate')}
                  </button>
                </th>
              )}

              {visibleCols.updated && (
                <th className="px-2.5 py-3 whitespace-nowrap hidden xl:table-cell">
                  <button
                    type="button"
                    onClick={() => handleSort('updatedAt')}
                    className="group inline-flex items-center gap-1 hover:text-[#09090B] dark:hover:text-[#FAFAFA] cursor-pointer"
                  >
                    <span>Updated</span>
                    {renderSortIcon('updatedAt')}
                  </button>
                </th>
              )}

              {visibleCols.owner && (
                <th className="px-2.5 py-3 whitespace-nowrap hidden xl:table-cell">
                  Owner
                </th>
              )}

              <th className="pl-2 pr-3.5 py-3 text-right whitespace-nowrap">
                Actions
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800 text-xs">
            {filteredRows.length === 0 ? (
              <tr>
                <td
                  colSpan={activeColCount}
                  className="py-14 text-center text-zinc-500 dark:text-zinc-400"
                >
                  No entries match the current filters in {tabConfig.label}.
                </td>
              </tr>
            ) : (
              filteredRows.map((item) => {
                const isSelected = Boolean(selectedIds[item.id]);
                const detailUrl = `/environment/${item.tab}/${encodeURIComponent(
                  toEntrySlug(item)
                )}`;

                return (
                  <tr
                    key={item.id}
                    onClick={() => openEntryDetail(item)}
                    className={`group transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#2563EB]/5 dark:bg-blue-500/10'
                        : 'hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40'
                    }`}
                  >
                    <td
                      className="pl-3.5 pr-1.5 py-3"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        aria-label={`Select ${item.name}`}
                        onChange={(e) =>
                          setSelectedIds((prev) => ({
                            ...prev,
                            [item.id]: e.target.checked,
                          }))
                        }
                        className="rounded border-zinc-300 dark:border-zinc-700 cursor-pointer"
                      />
                    </td>

                    {visibleCols.icon && (
                      <td className="px-2 py-3">
                        <div className="w-8 h-8 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-center text-[#2563EB] dark:text-blue-400 shrink-0">
                          <TabIcon className="w-4 h-4" aria-hidden="true" />
                        </div>
                      </td>
                    )}

                    {visibleCols.name && (
                      <td className="px-2.5 py-3 max-w-[210px]">
                        <a
                          href={detailUrl}
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            openEntryDetail(item);
                          }}
                          className="block font-medium text-[#09090B] dark:text-[#FAFAFA] group-hover:text-[#2563EB] dark:group-hover:text-blue-400 hover:underline truncate transition-colors"
                        >
                          {item.name}
                        </a>
                        <div className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                          {item.subtitle}
                        </div>
                      </td>
                    )}

                    {visibleCols.code && (
                      <td className="px-2.5 py-3 font-mono text-[11px] text-zinc-700 dark:text-zinc-300 whitespace-nowrap">
                        {item.code}
                      </td>
                    )}

                    {visibleCols.status && (
                      <td className="px-2.5 py-3 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1.5 text-zinc-800 dark:text-zinc-200 tabular-nums">
                          <span
                            aria-hidden="true"
                            className={`w-1.5 h-1.5 rounded-full ${getStatusDotClass(
                              item.status
                            )}`}
                          />
                          <span>
                            {item.env} · {item.status}
                          </span>
                        </span>
                      </td>
                    )}

                    {visibleCols.endpoint && (
                      <td className="px-2.5 py-3 font-mono text-[11px] text-zinc-600 dark:text-zinc-400 max-w-[190px] truncate hidden md:table-cell">
                        {item.endpoint}
                      </td>
                    )}

                    {visibleCols.capacity && (
                      <td className="px-2.5 py-3 text-zinc-700 dark:text-zinc-300 tabular-nums whitespace-nowrap">
                        {item.capacity}
                      </td>
                    )}

                    {visibleCols.usage && (
                      <td className="px-2.5 py-3 font-mono text-[11px] text-zinc-700 dark:text-zinc-300 tabular-nums whitespace-nowrap hidden lg:table-cell">
                        {item.usageOrLoad}
                      </td>
                    )}

                    {visibleCols.expiry && (
                      <td className="px-2.5 py-3 whitespace-nowrap tabular-nums">
                        <span
                          title={item.alertNote || item.expiryDate}
                          className="inline-flex items-center gap-1.5 text-zinc-700 dark:text-zinc-300"
                        >
                          <span>{item.expiryDate}</span>
                          {item.alertLevel === 'warning' && (
                            <AlertTriangle
                              className="w-3.5 h-3.5 text-amber-500 shrink-0"
                              aria-label={item.alertNote || 'Warning'}
                            />
                          )}
                          {item.alertLevel === 'critical' && (
                            <AlertTriangle
                              className="w-3.5 h-3.5 text-red-600 dark:text-red-400 shrink-0"
                              aria-label={item.alertNote || 'Critical alert'}
                            />
                          )}
                        </span>
                      </td>
                    )}

                    {visibleCols.updated && (
                      <td className="px-2.5 py-3 text-zinc-600 dark:text-zinc-400 tabular-nums whitespace-nowrap hidden xl:table-cell">
                        {item.updatedAt}
                      </td>
                    )}

                    {visibleCols.owner && (
                      <td className="px-2.5 py-3 text-zinc-600 dark:text-zinc-400 whitespace-nowrap hidden xl:table-cell">
                        {item.owner}
                      </td>
                    )}

                    <td
                      className="pl-2 pr-3.5 py-3 text-right whitespace-nowrap"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="inline-flex items-center justify-end gap-0.5">
                        <button
                          type="button"
                          onClick={() => handleCopyEndpoint(item)}
                          aria-label={`Copy endpoint for ${item.name}`}
                          className="p-1.5 rounded-md text-zinc-400 hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors cursor-pointer"
                        >
                          {copiedId === item.id ? (
                            <Check className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>

                        <a
                          href={detailUrl}
                          onClick={(e) => {
                            e.preventDefault();
                            openEntryDetail(item);
                          }}
                          aria-label={`Open detail page for ${item.name}`}
                          className="p-1.5 rounded-md text-zinc-400 hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors"
                        >
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
