import React, { useEffect, useState } from 'react';
import { Layers } from 'lucide-react';

const HERO_SOURCE = '/assets/aistudio/image_b1cf329f.png';

/**
 * Flood-fills connected near-white outer background pixels from the image perimeter
 * to true alpha=0 transparency and cleans 1px bright anti-aliasing fringe so the
 * illustration sits natively on #FAFAFA / #09090B with zero rectangular edge.
 */
function knockOutOuterWhiteBackground(img: HTMLImageElement): string | null {
  const width = img.naturalWidth;
  const height = img.naturalHeight;
  if (!width || !height) return null;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return null;

  ctx.drawImage(img, 0, 0);
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;
  const total = width * height;

  const isOuterWhite = (idx: number): boolean => {
    const p = idx * 4;
    const a = data[p + 3];
    if (a < 16) return true;
    const r = data[p];
    const g = data[p + 1];
    const b = data[p + 2];
    const minC = Math.min(r, g, b);
    const maxC = Math.max(r, g, b);
    return minC >= 238 && maxC - minC <= 18;
  };

  const visited = new Uint8Array(total);
  const queue = new Int32Array(total);
  let head = 0;
  let tail = 0;

  const pushIfWhite = (idx: number) => {
    if (visited[idx]) return;
    if (isOuterWhite(idx)) {
      visited[idx] = 1;
      queue[tail++] = idx;
    }
  };

  for (let x = 0; x < width; x++) {
    pushIfWhite(x);
    pushIfWhite((height - 1) * width + x);
  }
  for (let y = 1; y < height - 1; y++) {
    pushIfWhite(y * width);
    pushIfWhite(y * width + (width - 1));
  }

  while (head < tail) {
    const idx = queue[head++];
    const x = idx % width;
    const y = (idx - x) / width;

    if (x > 0) pushIfWhite(idx - 1);
    if (x < width - 1) pushIfWhite(idx + 1);
    if (y > 0) pushIfWhite(idx - width);
    if (y < height - 1) pushIfWhite(idx + width);
  }

  // Zero out all connected background pixels
  for (let i = 0; i < total; i++) {
    if (visited[i]) {
      data[i * 4 + 3] = 0;
    }
  }

  // Smoothly de-fringe 1px anti-aliased edge pixels bordering the knocked-out background
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = y * width + x;
      if (visited[idx]) continue;

      const hasClearedNeighbor =
        visited[idx - 1] ||
        visited[idx + 1] ||
        visited[idx - width] ||
        visited[idx + width];

      if (!hasClearedNeighbor) continue;

      const p = idx * 4;
      const r = data[p];
      const g = data[p + 1];
      const b = data[p + 2];
      const minC = Math.min(r, g, b);
      const maxC = Math.max(r, g, b);

      // Neutral light-gray edge pixels transitioning to white background
      if (minC >= 205 && maxC - minC <= 18) {
        const lum = (r + g + b) / 3;
        const opacityFactor = Math.max(0, Math.min(1, (246 - lum) / 42));
        data[p + 3] = Math.round(data[p + 3] * opacityFactor);
      }
    }
  }

  ctx.putImageData(imageData, 0, 0);
  return canvas.toDataURL('image/png');
}

export const WorkspaceHeroVisual: React.FC = () => {
  const [hasError, setHasError] = useState(false);
  const [processedSrc, setProcessedSrc] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = HERO_SOURCE;

    img.onload = () => {
      if (cancelled) return;
      try {
        const cutout = knockOutOuterWhiteBackground(img);
        if (!cancelled && cutout) {
          setProcessedSrc(cutout);
        }
      } catch {
        // Fallback to raw image with blend mode if canvas extraction fails
      }
    };

    img.onerror = () => {
      if (!cancelled) setHasError(true);
    };

    return () => {
      cancelled = true;
    };
  }, []);

  if (hasError) {
    return (
      <div className="w-full aspect-[4/3] rounded-2xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex flex-col items-center justify-center p-8 text-center">
        <Layers className="w-7 h-7 text-zinc-400 mb-2" aria-hidden="true" />
        <span className="text-sm font-medium text-zinc-600 dark:text-zinc-400">
          Murat Krhl's WorkSpace
        </span>
      </div>
    );
  }

  return (
    <div
      onContextMenu={(e) => e.preventDefault()}
      className="relative w-full flex items-center justify-center bg-[#FAFAFA] select-none pointer-events-none"
    >
      <img
        src={processedSrc || HERO_SOURCE}
        alt="Murat Krhl's WorkSpace architectural illustration"
        referrerPolicy="no-referrer"
        draggable={false}
        onError={() => setHasError(true)}
        className="w-full max-w-[540px] h-auto object-contain mix-blend-multiply contrast-[1.04]"
      />
    </div>
  );
};
