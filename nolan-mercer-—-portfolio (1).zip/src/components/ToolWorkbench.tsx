import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  CheckCircle2,
  Copy,
  Play,
  RotateCcw,
} from 'lucide-react';
import { ToolCategoryConfig, ToolSlotItem } from '../data/toolsData';

interface ToolWorkbenchProps {
  category: ToolCategoryConfig;
  tool: ToolSlotItem;
  onBackToCategory: () => void;
}

function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <button
      type="button"
      onClick={handleCopy}
      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-[#09090B] dark:text-[#FAFAFA] hover:border-[#2563EB] transition-colors cursor-pointer whitespace-nowrap shrink-0"
    >
      {copied ? (
        <>
          <Check className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400" />
          <span>Copied</span>
        </>
      ) : (
        <>
          <Copy className="w-3.5 h-3.5" />
          <span>{label}</span>
        </>
      )}
    </button>
  );
}

/* 1. TLS & mTLS Chain Inspector */
const TlsChainTool: React.FC = () => {
  const [pemInput, setPemInput] = useState(
    `-----BEGIN CERTIFICATE-----\nMIIFazCCA1OgAwIBAgIRAIIQz7DSQONZRGPgu2OCiwAwDQYJKoZIhvcNAQELBQAw\nCN=edge-gw-prod-01.corp.internal\nO=Enterprise Middleware Platform\nValidTo=2027-02-18T23:59:59Z\nSAN=edge-gw-prod-01.corp.internal,api.corp.internal,mtls.corp.internal\n-----END CERTIFICATE-----`
  );

  const inspection = useMemo(() => {
    const hasBegin = pemInput.includes('-----BEGIN CERTIFICATE-----');
    const hasEnd = pemInput.includes('-----END CERTIFICATE-----');
    const lines = pemInput
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('-----'));
    const cnMatch = pemInput.match(/CN=([^\n]+)/);
    const sanMatch = pemInput.match(/SAN=([^\n]+)/);
    const validToMatch = pemInput.match(/ValidTo=([^\n]+)/);
    const bodyChars = lines.join('').length;

    let daysRemaining: number | null = null;
    if (validToMatch?.[1]) {
      const target = new Date(validToMatch[1].trim()).getTime();
      if (!Number.isNaN(target)) {
        daysRemaining = Math.ceil((target - Date.now()) / (1000 * 60 * 60 * 24));
      }
    }

    return {
      validEnvelope: hasBegin && hasEnd && lines.length > 0,
      cn: cnMatch?.[1]?.trim() || 'Detected from DER payload',
      sans: sanMatch?.[1]?.split(',').map((s) => s.trim()) || ['No explicit SAN hint'],
      validTo: validToMatch?.[1]?.trim() || 'Parse via OpenSSL',
      daysRemaining,
      estimatedBytes: Math.round((bodyChars * 3) / 4),
    };
  }, [pemInput]);

  return (
    <div className="space-y-5">
      <div className="space-y-1.5">
        <label className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
          Certificate PEM Block
        </label>
        <textarea
          rows={6}
          value={pemInput}
          onChange={(e) => setPemInput(e.target.value)}
          className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-zinc-100 focus:outline-none focus:border-[#2563EB]"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/70 border border-zinc-200 dark:border-zinc-800 space-y-1">
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Envelope Status</div>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#09090B] dark:text-[#FAFAFA]">
            {inspection.validEnvelope ? (
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            ) : (
              <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
            )}
            <span>{inspection.validEnvelope ? 'Valid PEM Structure' : 'Incomplete PEM'}</span>
          </div>
        </div>
        <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/70 border border-zinc-200 dark:border-zinc-800 space-y-1">
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Estimated DER Size</div>
          <div className="font-mono text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
            {inspection.estimatedBytes} bytes
          </div>
        </div>
        <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/70 border border-zinc-200 dark:border-zinc-800 space-y-1">
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">Expiry Window</div>
          <div className="font-mono text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
            {inspection.daysRemaining !== null ? `${inspection.daysRemaining} days` : inspection.validTo}
          </div>
        </div>
      </div>

      <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 text-xs font-mono text-zinc-200 space-y-1.5">
        <div>Subject CN: {inspection.cn}</div>
        <div>SAN Entries: {inspection.sans.join(' · ')}</div>
      </div>
    </div>
  );
};

/* 2. Nginx & HAProxy Config Validator */
const UpstreamValidatorTool: React.FC = () => {
  const [config, setConfig] = useState(
    `upstream provenir_prod_pool {\n  least_conn;\n  server 10.42.18.11:8443 max_fails=3 fail_timeout=15s;\n  server 10.42.18.12:8443 max_fails=3 fail_timeout=15s;\n  keepalive 64;\n}`
  );

  const checks = useMemo(() => {
    const results: Array<{ ok: boolean; msg: string }> = [];
    results.push({
      ok: /upstream\s+\w+\s*\{/.test(config) || /backend\s+\w+/.test(config),
      msg: 'Upstream or HAProxy backend block declaration found',
    });
    results.push({
      ok: /keepalive|option httpchk/.test(config),
      msg: 'Connection keepalive or active health check directive present',
    });
    results.push({
      ok: /max_fails|fall\s+\d+/.test(config),
      msg: 'Failure threshold (max_fails / fall) configured',
    });
    const openBraces = (config.match(/\{/g) || []).length;
    const closeBraces = (config.match(/\}/g) || []).length;
    results.push({
      ok: openBraces === closeBraces,
      msg: `Balanced braces (${openBraces} open / ${closeBraces} close)`,
    });
    return results;
  }, [config]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
          Upstream / Backend Snippet
        </span>
        <CopyButton text={config} label="Copy Config" />
      </div>
      <textarea
        rows={7}
        value={config}
        onChange={(e) => setConfig(e.target.value)}
        className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-zinc-100 focus:outline-none focus:border-[#2563EB]"
      />
      <div className="divide-y divide-zinc-200 dark:divide-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-800 overflow-hidden">
        {checks.map((c) => (
          <div
            key={c.msg}
            className="px-4 py-3 bg-[#FAFAFA] dark:bg-zinc-900/50 flex items-center gap-2.5 text-xs"
          >
            {c.ok ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
            )}
            <span className="text-[#09090B] dark:text-[#FAFAFA]">{c.msg}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

/* 3. HTTP Security Header & CORS Checker */
const HttpHeaderTool: React.FC = () => {
  const [rawHeaders, setRawHeaders] = useState(
    `Strict-Transport-Security: max-age=31536000; includeSubDomains\nX-Content-Type-Options: nosniff\nX-Frame-Options: DENY\nContent-Security-Policy: default-src 'self'\nReferrer-Policy: strict-origin-when-cross-origin`
  );

  const findings = useMemo(() => {
    const lower = rawHeaders.toLowerCase();
    const required = [
      { key: 'strict-transport-security', label: 'Strict-Transport-Security (HSTS)' },
      { key: 'content-security-policy', label: 'Content-Security-Policy (CSP)' },
      { key: 'x-content-type-options', label: 'X-Content-Type-Options' },
      { key: 'x-frame-options', label: 'X-Frame-Options' },
      { key: 'referrer-policy', label: 'Referrer-Policy' },
    ];
    return required.map((r) => ({
      ...r,
      present: lower.includes(r.key),
    }));
  }, [rawHeaders]);

  return (
    <div className="space-y-5">
      <textarea
        rows={6}
        value={rawHeaders}
        onChange={(e) => setRawHeaders(e.target.value)}
        placeholder="Paste HTTP response headers..."
        className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-zinc-100 focus:outline-none focus:border-[#2563EB]"
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {findings.map((f) => (
          <div
            key={f.key}
            className="p-3.5 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-2 text-xs"
          >
            <span className="font-medium text-[#09090B] dark:text-[#FAFAFA]">{f.label}</span>
            <span
              className={`font-mono text-[11px] ${
                f.present
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-red-600 dark:text-red-400'
              }`}
            >
              {f.present ? 'PASS' : 'MISSING'}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

/* 4. OpenShift Route & Ingress Builder */
const OcpRouteTool: React.FC = () => {
  const [name, setName] = useState('credit-decision-gw');
  const [ns, setNs] = useState('middleware-prod');
  const [host, setHost] = useState('credit-gw.apps.ocp-prod.corp');
  const [tls, setTls] = useState<'edge' | 'reencrypt' | 'passthrough'>('reencrypt');
  const [timeout, setTimeoutVal] = useState('30s');

  const yaml = `apiVersion: route.openshift.io/v1
kind: Route
metadata:
  name: ${name}
  namespace: ${ns}
  annotations:
    haproxy.router.openshift.io/timeout: ${timeout}
spec:
  host: ${host}
  to:
    kind: Service
    name: ${name}-svc
    weight: 100
  port:
    targetPort: 8443
  tls:
    termination: ${tls}
    insecureEdgeTerminationPolicy: Redirect`;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Route Name</span>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
          />
        </label>
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Namespace</span>
          <input
            type="text"
            value={ns}
            onChange={(e) => setNs(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
          />
        </label>
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">TLS Termination</span>
          <select
            value={tls}
            onChange={(e) => setTls(e.target.value as 'edge' | 'reencrypt' | 'passthrough')}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
          >
            <option value="edge">edge</option>
            <option value="reencrypt">reencrypt</option>
            <option value="passthrough">passthrough</option>
          </select>
        </label>
        <label className="sm:col-span-2 space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Route Host</span>
          <input
            type="text"
            value={host}
            onChange={(e) => setHost(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
          />
        </label>
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">HAProxy Timeout</span>
          <input
            type="text"
            value={timeout}
            onChange={(e) => setTimeoutVal(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
          />
        </label>
      </div>

      <div className="rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden">
        <div className="px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-400">
          <span>route.yaml</span>
          <CopyButton text={yaml} label="Copy YAML" />
        </div>
        <pre className="p-4 text-xs font-mono text-zinc-100 overflow-x-auto leading-relaxed">
          <code>{yaml}</code>
        </pre>
      </div>
    </div>
  );
};

/* 5. Pod Resource & LimitRange Calculator */
const PodQuotaTool: React.FC = () => {
  const [replicas, setReplicas] = useState(6);
  const [cpuReq, setCpuReq] = useState(500);
  const [cpuLim, setCpuLim] = useState(1500);
  const [memReq, setMemReq] = useState(1024);
  const [memLim, setMemLim] = useState(2048);

  const totalCpuReq = ((replicas * cpuReq) / 1000).toFixed(2);
  const totalCpuLim = ((replicas * cpuLim) / 1000).toFixed(2);
  const totalMemReq = ((replicas * memReq) / 1024).toFixed(2);
  const totalMemLim = ((replicas * memLim) / 1024).toFixed(2);

  const quotaYaml = `apiVersion: v1
kind: ResourceQuota
metadata:
  name: namespace-compute-quota
spec:
  hard:
    pods: "${replicas + 2}"
    requests.cpu: "${Math.ceil(Number(totalCpuReq))}000m"
    limits.cpu: "${Math.ceil(Number(totalCpuLim))}000m"
    requests.memory: "${Math.ceil(Number(totalMemReq))}Gi"
    limits.memory: "${Math.ceil(Number(totalMemLim))}Gi"`;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {[
          { label: 'Replicas', val: replicas, set: setReplicas },
          { label: 'CPU Req (m)', val: cpuReq, set: setCpuReq },
          { label: 'CPU Lim (m)', val: cpuLim, set: setCpuLim },
          { label: 'Mem Req (Mi)', val: memReq, set: setMemReq },
          { label: 'Mem Lim (Mi)', val: memLim, set: setMemLim },
        ].map((f) => (
          <label key={f.label} className="space-y-1 text-xs">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">{f.label}</span>
            <input
              type="number"
              min={1}
              value={f.val}
              onChange={(e) => f.set(Math.max(1, Number(e.target.value) || 1))}
              className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs tabular-nums"
            />
          </label>
        ))}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/70 border border-zinc-200 dark:border-zinc-800">
          <div className="text-[11px] text-zinc-500">Total CPU Req</div>
          <div className="font-mono text-lg font-bold tabular-nums">{totalCpuReq} cores</div>
        </div>
        <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/70 border border-zinc-200 dark:border-zinc-800">
          <div className="text-[11px] text-zinc-500">Total CPU Lim</div>
          <div className="font-mono text-lg font-bold tabular-nums">{totalCpuLim} cores</div>
        </div>
        <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/70 border border-zinc-200 dark:border-zinc-800">
          <div className="text-[11px] text-zinc-500">Total Mem Req</div>
          <div className="font-mono text-lg font-bold tabular-nums">{totalMemReq} GiB</div>
        </div>
        <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/70 border border-zinc-200 dark:border-zinc-800">
          <div className="text-[11px] text-zinc-500">Total Mem Lim</div>
          <div className="font-mono text-lg font-bold tabular-nums">{totalMemLim} GiB</div>
        </div>
      </div>

      <div className="rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden">
        <div className="px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-400">
          <span>resource-quota.yaml</span>
          <CopyButton text={quotaYaml} label="Copy YAML" />
        </div>
        <pre className="p-4 text-xs font-mono text-zinc-100 overflow-x-auto leading-relaxed">
          <code>{quotaYaml}</code>
        </pre>
      </div>
    </div>
  );
};

/* 6. Readiness & Liveness Probe Generator */
const ProbeGeneratorTool: React.FC = () => {
  const [profile, setProfile] = useState<'eap8' | 'spring' | 'nginx'>('eap8');
  const [path, setPath] = useState('/health/ready');
  const [port, setPort] = useState(9990);

  const handleProfile = (next: 'eap8' | 'spring' | 'nginx') => {
    setProfile(next);
    if (next === 'eap8') {
      setPath('/health/ready');
      setPort(9990);
    } else if (next === 'spring') {
      setPath('/actuator/health/readiness');
      setPort(8080);
    } else {
      setPath('/nginx_status');
      setPort(8080);
    }
  };

  const yaml = `readinessProbe:
  httpGet:
    path: ${path}
    port: ${port}
  initialDelaySeconds: ${profile === 'nginx' ? 5 : 25}
  periodSeconds: 10
  timeoutSeconds: 3
  failureThreshold: 3
livenessProbe:
  httpGet:
    path: ${profile === 'eap8' ? '/health/live' : path}
    port: ${port}
  initialDelaySeconds: ${profile === 'nginx' ? 10 : 45}
  periodSeconds: 15
  timeoutSeconds: 3
  failureThreshold: 3`;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Runtime Profile</span>
          <select
            value={profile}
            onChange={(e) => handleProfile(e.target.value as 'eap8' | 'spring' | 'nginx')}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
          >
            <option value="eap8">JBoss EAP 8 (MicroProfile)</option>
            <option value="spring">Spring Boot 3 Actuator</option>
            <option value="nginx">Nginx / Reverse Proxy</option>
          </select>
        </label>
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Endpoint Path</span>
          <input
            type="text"
            value={path}
            onChange={(e) => setPath(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
          />
        </label>
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Port</span>
          <input
            type="number"
            value={port}
            onChange={(e) => setPort(Number(e.target.value) || 8080)}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs tabular-nums"
          />
        </label>
      </div>

      <div className="rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden">
        <div className="px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-400">
          <span>probes.yaml</span>
          <CopyButton text={yaml} label="Copy YAML" />
        </div>
        <pre className="p-4 text-xs font-mono text-zinc-100 overflow-x-auto leading-relaxed">
          <code>{yaml}</code>
        </pre>
      </div>
    </div>
  );
};

/* 7. EAP 8 Elytron CLI & Credential Helper */
const ElytronCliTool: React.FC = () => {
  const [storeName, setStoreName] = useState('corp-cred-store');
  const [alias, setAlias] = useState('provenir-db-pass');
  const [domainName, setDomainName] = useState('CorpLdapDomain');

  const cli = `batch
/subsystem=elytron/credential-store=${storeName}:add(location="standalone/data/${storeName}.jceks", create=true, credential-reference={clear-text="CHANGE_MASTER_SECRET"})
/subsystem=elytron/credential-store=${storeName}:add-alias(alias="${alias}", secret-value="CHANGE_DB_SECRET")
/subsystem=elytron/security-domain=${domainName}:add(default-realm="LdapRealm", permission-mapper="default-permission-mapper", realms=[{realm="LdapRealm", role-decoder="groups-to-roles"}])
run-batch`;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Credential Store</span>
          <input
            type="text"
            value={storeName}
            onChange={(e) => setStoreName(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
          />
        </label>
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Secret Alias</span>
          <input
            type="text"
            value={alias}
            onChange={(e) => setAlias(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
          />
        </label>
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Security Domain</span>
          <input
            type="text"
            value={domainName}
            onChange={(e) => setDomainName(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
          />
        </label>
      </div>
      <div className="rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden">
        <div className="px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-400">
          <span>elytron-setup.cli</span>
          <CopyButton text={cli} label="Copy CLI" />
        </div>
        <pre className="p-4 text-xs font-mono text-zinc-100 overflow-x-auto leading-relaxed">
          <code>{cli}</code>
        </pre>
      </div>
    </div>
  );
};

/* 8. Jakarta EE 10 Namespace Mapper */
const JakartaMapperTool: React.FC = () => {
  const [source, setSource] = useState(
    `import javax.persistence.Entity;\nimport javax.persistence.Table;\nimport javax.servlet.http.HttpServletRequest;\nimport javax.ws.rs.POST;\nimport javax.inject.Inject;\nimport javax.validation.Valid;`
  );

  const converted = useMemo(() => {
    const replacements: Array<[RegExp, string]> = [
      [/javax\.persistence\./g, 'jakarta.persistence.'],
      [/javax\.servlet\./g, 'jakarta.servlet.'],
      [/javax\.ws\.rs\./g, 'jakarta.ws.rs.'],
      [/javax\.inject\./g, 'jakarta.inject.'],
      [/javax\.validation\./g, 'jakarta.validation.'],
      [/javax\.ejb\./g, 'jakarta.ejb.'],
      [/javax\.transaction\./g, 'jakarta.transaction.'],
      [/javax\.annotation\./g, 'jakarta.annotation.'],
      [/javax\.xml\.bind\./g, 'jakarta.xml.bind.'],
    ];
    let next = source;
    let count = 0;
    replacements.forEach(([regex, target]) => {
      const matches = next.match(regex);
      if (matches) count += matches.length;
      next = next.replace(regex, target);
    });
    return { output: next, count };
  }, [source]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
            Legacy EAP 7 (javax.*)
          </span>
          <textarea
            rows={7}
            value={source}
            onChange={(e) => setSource(e.target.value)}
            className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-zinc-100"
          />
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
              Jakarta EE 10 Output ({converted.count} mapped)
            </span>
            <CopyButton text={converted.output} label="Copy Output" />
          </div>
          <textarea
            rows={7}
            readOnly
            value={converted.output}
            className="w-full p-3.5 text-xs font-mono rounded-xl bg-zinc-950 border border-zinc-800 text-emerald-300"
          />
        </div>
      </div>
    </div>
  );
};

/* 9. JDBC & XA Datasource Pool Tuner */
const DatasourcePoolTool: React.FC = () => {
  const [threads, setThreads] = useState(120);
  const [avgQueryMs, setAvgQueryMs] = useState(18);
  const [dbType, setDbType] = useState<'PostgresDS' | 'OracleXADS'>('PostgresDS');

  const recommendedMax = Math.max(10, Math.min(200, Math.ceil((threads * avgQueryMs) / 100) + 10));
  const recommendedMin = Math.max(5, Math.floor(recommendedMax * 0.25));

  const xml = `<datasource jndi-name="java:jboss/datasources/${dbType}" pool-name="${dbType}Pool">
  <pool>
    <min-pool-size>${recommendedMin}</min-pool-size>
    <max-pool-size>${recommendedMax}</max-pool-size>
    <prefill>true</prefill>
  </pool>
  <timeout>
    <blocking-timeout-millis>5000</blocking-timeout-millis>
    <idle-timeout-minutes>10</idle-timeout-minutes>
  </timeout>
</datasource>`;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Datasource Target</span>
          <select
            value={dbType}
            onChange={(e) => setDbType(e.target.value as 'PostgresDS' | 'OracleXADS')}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
          >
            <option value="PostgresDS">PostgreSQL</option>
            <option value="OracleXADS">Oracle XA</option>
          </select>
        </label>
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Concurrent Workers</span>
          <input
            type="number"
            min={5}
            value={threads}
            onChange={(e) => setThreads(Math.max(1, Number(e.target.value) || 10))}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs tabular-nums"
          />
        </label>
        <label className="space-y-1 text-xs">
          <span className="font-medium text-zinc-700 dark:text-zinc-300">Avg Query (ms)</span>
          <input
            type="number"
            min={1}
            value={avgQueryMs}
            onChange={(e) => setAvgQueryMs(Math.max(1, Number(e.target.value) || 5))}
            className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs tabular-nums"
          />
        </label>
      </div>

      <div className="rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden">
        <div className="px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-400">
          <span>standalone-datasource.xml</span>
          <CopyButton text={xml} label="Copy XML" />
        </div>
        <pre className="p-4 text-xs font-mono text-zinc-100 overflow-x-auto leading-relaxed">
          <code>{xml}</code>
        </pre>
      </div>
    </div>
  );
};

/* 10. Decision Engines Payload Validator (Provenir / Evam / PowerCurve) */
const DecisionPayloadTool: React.FC<{ toolId: string }> = ({ toolId }) => {
  const defaultJson =
    toolId === 'evam-event-validator'
      ? `{\n  "eventName": "CARD_TXN_AUTH",\n  "actorId": "CUST-908421",\n  "timestamp": "2026-11-16T21:14:00Z",\n  "channel": "MOBILE_APP",\n  "amount": 4250.0\n}`
      : toolId === 'powercurve-response-inspector'
        ? `{\n  "strategyId": "SME_SCORING_V4",\n  "decisionOutcome": "APPROVE_WITH_LIMIT",\n  "score": 742,\n  "bureauLatencyMs": 148,\n  "ruleHits": ["INCOME_VERIFIED", "KKB_TIER_A"]\n}`
        : `{\n  "applicationId": "CR-2026-88412",\n  "customerSegment": "RETAIL",\n  "requestedAmount": 180000,\n  "currency": "TRY",\n  "bureauPull": true\n}`;

  const [payload, setPayload] = useState(defaultJson);

  const report = useMemo(() => {
    try {
      const parsed = JSON.parse(payload);
      const keys = Object.keys(parsed);
      return { valid: true, keys, error: '', pretty: JSON.stringify(parsed, null, 2) };
    } catch (err) {
      return {
        valid: false,
        keys: [] as string[],
        error: err instanceof Error ? err.message : 'Invalid JSON',
        pretty: '',
      };
    }
  }, [payload]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
          Schema Payload Input
        </span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => report.valid && setPayload(report.pretty)}
            disabled={!report.valid}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 disabled:opacity-40 text-white cursor-pointer"
          >
            <Play className="w-3 h-3" />
            <span>Validate & Format</span>
          </button>
          <CopyButton text={payload} label="Copy JSON" />
        </div>
      </div>

      <textarea
        rows={7}
        value={payload}
        onChange={(e) => setPayload(e.target.value)}
        className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-zinc-100"
      />

      {report.valid ? (
        <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="inline-flex items-center gap-1.5 font-medium text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span>Valid JSON Schema ({report.keys.length} root fields)</span>
          </span>
          <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400">
            Keys: {report.keys.join(', ')}
          </span>
        </div>
      ) : (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/60 text-xs text-red-700 dark:text-red-300">
          Syntax Error: {report.error}
        </div>
      )}
    </div>
  );
};

/* 11. JWT & OIDC Claims Inspector */
const JwtInspectorTool: React.FC = () => {
  const [token, setToken] = useState(
    'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJtdXJhdC5rcmhsIiwicm9sZSI6Im1pZGRsZXdhcmUtYWRtaW4iLCJpc3MiOiJzc28uY29ycC5pbnRlcm5hbCIsImV4cCI6MTc5NjA4MzIwMH0.signature'
  );

  const decoded = useMemo(() => {
    const parts = token.trim().split('.');
    if (parts.length < 2) return { error: 'Token must have header.payload segments' };
    try {
      const decodePart = (b64url: string) => {
        const padded = b64url.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(b64url.length / 4) * 4, '=');
        return JSON.parse(atob(padded));
      };
      return {
        header: JSON.stringify(decodePart(parts[0]), null, 2),
        payload: JSON.stringify(decodePart(parts[1]), null, 2),
        error: '',
      };
    } catch {
      return { error: 'Unable to Base64URL decode JWT segments' };
    }
  }, [token]);

  return (
    <div className="space-y-4">
      <textarea
        rows={3}
        value={token}
        onChange={(e) => setToken(e.target.value)}
        placeholder="Paste JWT Bearer token..."
        className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-zinc-100"
      />
      {decoded.error ? (
        <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/60 text-xs text-red-600 dark:text-red-300">
          {decoded.error}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-4 space-y-2">
            <div className="text-[11px] font-mono text-zinc-400">HEADER</div>
            <pre className="text-xs font-mono text-zinc-100 overflow-x-auto">{decoded.header}</pre>
          </div>
          <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-4 space-y-2">
            <div className="text-[11px] font-mono text-zinc-400">PAYLOAD CLAIMS</div>
            <pre className="text-xs font-mono text-blue-300 overflow-x-auto">{decoded.payload}</pre>
          </div>
        </div>
      )}
    </div>
  );
};

/* 12. PEM / Base64 Converter */
const Base64ConverterTool: React.FC = () => {
  const [plainText, setPlainText] = useState('jdbc:postgresql://pg-prod-01.corp:5432/creditdb');
  const [b64Text, setB64Text] = useState(
    'amRiYzpwb3N0Z3Jlc3FsOi8vcGctcHJvZC0wMS5jb3JwOjU0MzIvY3JlZGl0ZGI='
  );

  const handleEncode = () => {
    try {
      const bytes = new TextEncoder().encode(plainText);
      let binary = '';
      bytes.forEach((b) => {
        binary += String.fromCharCode(b);
      });
      setB64Text(btoa(binary));
    } catch {
      // ignore
    }
  };

  const handleDecode = () => {
    try {
      const binary = atob(b64Text.trim());
      const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
      setPlainText(new TextDecoder().decode(bytes));
    } catch {
      // ignore
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">Plain Text</span>
          <button
            type="button"
            onClick={handleEncode}
            className="px-3 py-1 text-xs font-medium rounded-lg bg-[#2563EB] text-white cursor-pointer"
          >
            Encode →
          </button>
        </div>
        <textarea
          rows={5}
          value={plainText}
          onChange={(e) => setPlainText(e.target.value)}
          className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800"
        />
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">Base64 Value</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDecode}
              className="px-3 py-1 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 cursor-pointer"
            >
              ← Decode
            </button>
            <CopyButton text={b64Text} />
          </div>
        </div>
        <textarea
          rows={5}
          value={b64Text}
          onChange={(e) => setB64Text(e.target.value)}
          className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800"
        />
      </div>
    </div>
  );
};

/* 13. Log Masking & Regex Audit Tester */
const LogMaskTesterTool: React.FC = () => {
  const [logLine, setLogLine] = useState(
    '2026-11-16 21:04:11 INFO CreditGateway - Application received for TCKN=12345678901 IBAN=TR330006100519786457841326 email=user@corp.com'
  );
  const [maskTckn, setMaskTckn] = useState(true);
  const [maskIban, setMaskIban] = useState(true);

  const masked = useMemo(() => {
    let out = logLine;
    if (maskTckn) {
      out = out.replace(/\b(\d{2})\d{7}(\d{2})\b/g, '$1*******$2');
    }
    if (maskIban) {
      out = out.replace(/\b(TR\d{2})\d{18}(\d{4})\b/g, '$1******************$2');
    }
    return out;
  }, [logLine, maskTckn, maskIban]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-4 text-xs">
        <label className="inline-flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={maskTckn}
            onChange={(e) => setMaskTckn(e.target.checked)}
            className="accent-[#2563EB]"
          />
          <span>Mask 11-digit TCKN</span>
        </label>
        <label className="inline-flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={maskIban}
            onChange={(e) => setMaskIban(e.target.checked)}
            className="accent-[#2563EB]"
          />
          <span>Mask TR IBAN</span>
        </label>
      </div>

      <textarea
        rows={4}
        value={logLine}
        onChange={(e) => setLogLine(e.target.value)}
        className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800"
      />

      <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-4 space-y-2">
        <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400">
          <span>REDACTED PREVIEW</span>
          <CopyButton text={masked} />
        </div>
        <pre className="text-xs font-mono text-emerald-300 whitespace-pre-wrap">{masked}</pre>
      </div>
    </div>
  );
};

/* 14. JSON / Config Formatter */
const ConfigFormatterTool: React.FC = () => {
  const [input, setInput] = useState(
    '{"service":"provenir-runtime","version":"8.7.0","cluster":"ocp-prod-eu1","tls":"TLSv1.3"}'
  );
  const [error, setError] = useState('');

  const handleFormat = (minify: boolean) => {
    try {
      const parsed = JSON.parse(input);
      setInput(minify ? JSON.stringify(parsed) : JSON.stringify(parsed, null, 2));
      setError('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Invalid JSON');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => handleFormat(false)}
          className="px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
        >
          Pretty Print
        </button>
        <button
          type="button"
          onClick={() => handleFormat(true)}
          className="px-3.5 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 cursor-pointer"
        >
          Minify
        </button>
        <CopyButton text={input} label="Copy" />
      </div>
      <textarea
        rows={7}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        className="w-full p-3.5 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800"
      />
      {error && (
        <p className="text-xs text-red-600 dark:text-red-400">Syntax Error: {error}</p>
      )}
    </div>
  );
};

/* 15. Environment Config Diff Viewer */
const EnvDiffTool: React.FC = () => {
  const [envA, setEnvA] = useState(
    `JAVA_OPTS=-Xms2g -Xmx4g\nSPRING_PROFILES_ACTIVE=uat\nDB_POOL_MAX=40\nLOG_LEVEL=DEBUG`
  );
  const [envB, setEnvB] = useState(
    `JAVA_OPTS=-Xms4g -Xmx8g\nSPRING_PROFILES_ACTIVE=prod\nDB_POOL_MAX=40\nTLS_STRICT=true`
  );

  const diffs = useMemo(() => {
    const parseMap = (raw: string) => {
      const m = new Map<string, string>();
      raw.split('\n').forEach((line) => {
        const idx = line.indexOf('=');
        if (idx > 0) {
          m.set(line.slice(0, idx).trim(), line.slice(idx + 1).trim());
        }
      });
      return m;
    };
    const mapA = parseMap(envA);
    const mapB = parseMap(envB);
    const allKeys = Array.from(new Set([...mapA.keys(), ...mapB.keys()]));
    return allKeys.map((k) => {
      const a = mapA.get(k);
      const b = mapB.get(k);
      const state =
        a === undefined ? 'Added in B' : b === undefined ? 'Only in A' : a === b ? 'Match' : 'Changed';
      return { key: k, a: a ?? '—', b: b ?? '—', state };
    });
  }, [envA, envB]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-1">
          <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">Environment A (UAT)</span>
          <textarea
            rows={5}
            value={envA}
            onChange={(e) => setEnvA(e.target.value)}
            className="w-full p-3 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800"
          />
        </div>
        <div className="space-y-1">
          <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">Environment B (Prod)</span>
          <textarea
            rows={5}
            value={envB}
            onChange={(e) => setEnvB(e.target.value)}
            className="w-full p-3 text-xs font-mono rounded-xl bg-[#FAFAFA] dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800"
          />
        </div>
      </div>

      <div className="rounded-xl border border-zinc-200 dark:border-zinc-800 overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-[#FAFAFA] dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 text-zinc-500">
              <th className="px-4 py-2.5">Key</th>
              <th className="px-4 py-2.5">UAT</th>
              <th className="px-4 py-2.5">Prod</th>
              <th className="px-4 py-2.5 text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800 font-mono text-[11px]">
            {diffs.map((d) => (
              <tr key={d.key}>
                <td className="px-4 py-2.5 font-semibold text-[#09090B] dark:text-[#FAFAFA]">{d.key}</td>
                <td className="px-4 py-2.5 text-zinc-600 dark:text-zinc-400">{d.a}</td>
                <td className="px-4 py-2.5 text-zinc-600 dark:text-zinc-400">{d.b}</td>
                <td
                  className={`px-4 py-2.5 text-right font-sans font-medium ${
                    d.state === 'Match'
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : d.state === 'Changed'
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-[#2563EB] dark:text-blue-400'
                  }`}
                >
                  {d.state}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

/* 16. Cron & Cutover Window Planner */
const CronPlannerTool: React.FC = () => {
  const [expr, setExpr] = useState('0 2 * * 0');

  const summary = useMemo(() => {
    const parts = expr.trim().split(/\s+/);
    if (parts.length !== 5) {
      return { valid: false, desc: 'Enter standard 5-field cron (min hour dom month dow)' };
    }
    const [min, hour, dom, mon, dow] = parts;
    return {
      valid: true,
      desc: `Runs at minute ${min}, hour ${hour} · day-of-month ${dom} · month ${mon} · day-of-week ${dow} (Europe/Istanbul)`,
    };
  }, [expr]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <input
          type="text"
          value={expr}
          onChange={(e) => setExpr(e.target.value)}
          className="px-3.5 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-sm w-56"
        />
        <button
          type="button"
          onClick={() => setExpr('0 2 * * 0')}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Weekly Maintenance</span>
        </button>
        <button
          type="button"
          onClick={() => setExpr('*/15 * * * *')}
          className="px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 cursor-pointer"
        >
          Every 15m
        </button>
      </div>
      <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 text-xs text-[#09090B] dark:text-[#FAFAFA]">
        {summary.desc}
      </div>
    </div>
  );
};

export const ToolWorkbench: React.FC<ToolWorkbenchProps> = ({
  category,
  tool,
  onBackToCategory,
}) => {
  const renderToolBody = () => {
    switch (tool.id) {
      case 'tls-chain-inspector':
        return <TlsChainTool />;
      case 'upstream-config-validator':
        return <UpstreamValidatorTool />;
      case 'http-header-analyzer':
        return <HttpHeaderTool />;
      case 'ocp-route-builder':
        return <OcpRouteTool />;
      case 'pod-quota-calculator':
        return <PodQuotaTool />;
      case 'probe-config-generator':
        return <ProbeGeneratorTool />;
      case 'elytron-credential-helper':
        return <ElytronCliTool />;
      case 'jakarta-namespace-checker':
        return <JakartaMapperTool />;
      case 'datasource-pool-tuner':
        return <DatasourcePoolTool />;
      case 'provenir-payload-tester':
      case 'evam-event-validator':
      case 'powercurve-response-inspector':
        return <DecisionPayloadTool key={tool.id} toolId={tool.id} />;
      case 'jwt-oidc-decoder':
        return <JwtInspectorTool />;
      case 'pem-base64-converter':
        return <Base64ConverterTool />;
      case 'log-pii-mask-tester':
        return <LogMaskTesterTool />;
      case 'config-schema-formatter':
        return <ConfigFormatterTool />;
      case 'env-config-diff':
        return <EnvDiffTool />;
      case 'cron-window-planner':
      default:
        return <CronPlannerTool />;
    }
  };

  return (
    <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-6 sm:p-8 space-y-6">
      <div className="pb-5 border-b border-zinc-200 dark:border-zinc-800 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
            <button
              type="button"
              onClick={onBackToCategory}
              className="inline-flex items-center gap-1 hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{category.label}</span>
            </button>
            <span aria-hidden="true">/</span>
            <span className="font-mono">{tool.scope}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">{tool.ioSpec}</span>
          </div>
          <h2 className="font-display text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
            {tool.name}
          </h2>
          <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed">
            {tool.description}
          </p>
        </div>
      </div>

      {renderToolBody()}
    </div>
  );
};
