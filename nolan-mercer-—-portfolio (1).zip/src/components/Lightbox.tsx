import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { ResilientImage } from './ResilientImage';

interface LightboxProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle: string;
  image?: string;
  alt: string;
}

export const Lightbox: React.FC<LightboxProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  image,
  alt,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${title} image preview`}
      className="fixed inset-0 z-50 bg-zinc-950/90 backdrop-blur-sm flex flex-col justify-between p-4 sm:p-8"
      onClick={onClose}
    >
      <div
        className="max-w-[1200px] w-full mx-auto flex items-center justify-between gap-4 text-white"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h3 className="font-display text-lg font-semibold tracking-tight">{title}</h3>
          <p className="text-xs text-zinc-400">{subtitle}</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close lightbox"
          className="inline-flex items-center justify-center w-11 h-11 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-200 hover:bg-zinc-800 hover:text-white transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#2563EB]"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div
        className="max-w-[1100px] w-full mx-auto my-auto aspect-[4/3] max-h-[75vh] rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-900"
        onClick={(e) => e.stopPropagation()}
      >
        <ResilientImage src={image} alt={alt} fallbackTitle={title} />
      </div>

      <div className="text-center text-xs text-zinc-400">
        Press ESC or click outside to close
      </div>
    </div>
  );
};
