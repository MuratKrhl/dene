import React, { useMemo, useState } from 'react';
import {
  Archive,
  Check,
  CheckCircle2,
  ExternalLink,
  Info,
  Play,
  Plus,
  RefreshCw,
  Search,
  Star,
  Trash2,
  Video as VideoIcon,
  X,
} from 'lucide-react';
import { TechSettings, TechVideo } from '../../types/technology';
import {
  MediaSourceDto,
  MediaSyncHistoryDto,
  YouTubeQuotaDto,
  createManualMediaVideo,
  deleteMediaVideo,
  patchMediaVideo,
  syncMediaByTypeApi,
  syncSingleMediaSourceApi,
  updateMediaSource,
} from '../../services/techMediaApi';
import {
  formatTechDate,
  formatTechTimestamp,
} from '../../services/technology/retentionEngine';
import { ResilientImage } from '../ResilientImage';

interface TechnologyVideosTabProps {
  videos: TechVideo[];
  sources: MediaSourceDto[];
  syncHistory: MediaSyncHistoryDto[];
  settings: TechSettings;
  youtubeApiConfigured: boolean;
  youtubeQuota: YouTubeQuotaDto | null;
  onDataChanged: () => Promise<void> | void;
}

type VideoSubTab =
  | 'discover'
  | 'latest'
  | 'channels'
  | 'playlists'
  | 'watched'
  | 'saved'
  | 'archive'
  | 'sources'
  | 'sync-history'
  | 'settings';

const SUB_TABS: Array<{ key: VideoSubTab; label: string }> = [
  { key: 'discover', label: 'Discover' },
  { key: 'latest', label: 'Latest' },
  { key: 'channels', label: 'Channels' },
  { key: 'playlists', label: 'Playlists' },
  { key: 'watched', label: 'Watched' },
  { key: 'saved', label: 'Saved' },
  { key: 'archive', label: 'Archive' },
  { key: 'sources', label: 'Sources' },
  { key: 'sync-history', label: 'Sync History' },
  { key: 'settings', label: 'Settings' },
];

export const TechnologyVideosTab: React.FC<TechnologyVideosTabProps> = ({
  videos,
  sources,
  syncHistory,
  settings,
  youtubeApiConfigured,
  youtubeQuota,
  onDataChanged,
}) => {
  const [subTab, setSubTab] = useState<VideoSubTab>('discover');
  const [search, setSearch] = useState('');
  const [channelFilter, setChannelFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncingId, setSyncingId] = useState<string | null>(null);
  const [showManualForm, setShowManualForm] = useState(false);
  const [manualTitle, setManualTitle] = useState('');
  const [manualChannel, setManualChannel] = useState('Red Hat');
  const [manualUrl, setManualUrl] = useState('');
  const [manualCategory, setManualCategory] = useState('Kubernetes');
  const [manualDuration, setManualDuration] = useState('');
  const [statusNotice, setStatusNotice] = useState<string | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [activeEmbedVideo, setActiveEmbedVideo] = useState<TechVideo | null>(null);

  const youtubeSources = useMemo(
    () => sources.filter((s) => s.contentType === 'youtube'),
    [sources]
  );

  const youtubeHistory = useMemo(
    () => syncHistory.filter((h) => h.contentType === 'youtube'),
    [syncHistory]
  );

  const uniqueChannels = useMemo(
    () => Array.from(new Set(videos.map((v) => v.channelName))).sort(),
    [videos]
  );

  const uniqueCategories = useMemo(
    () => Array.from(new Set(videos.map((v) => v.category))).sort(),
    [videos]
  );

  const filteredVideos = useMemo(() => {
    const q = search.trim().toLowerCase();
    return videos
      .filter((v) => {
        if (subTab === 'discover' || subTab === 'latest') {
          if (v.isArchived) return false;
        }
        if (subTab === 'watched' && !v.isWatched) return false;
        if (subTab === 'saved' && !v.isFavorite) return false;
        if (subTab === 'archive' && !v.isArchived) return false;
        if (channelFilter !== 'all' && v.channelName !== channelFilter)
          return false;
        if (categoryFilter !== 'all' && v.category !== categoryFilter)
          return false;
        if (q) {
          const hay = [v.title, v.description, v.channelName, v.category, ...v.tags]
            .join(' ')
            .toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort(
        (a, b) =>
          Date.parse(b.publishedAt || b.fetchedAt) -
          Date.parse(a.publishedAt || a.fetchedAt)
      );
  }, [categoryFilter, channelFilter, search, subTab, videos]);

  const playlists = useMemo(() => {
    const map = new Map<string, TechVideo[]>();
    for (const v of videos) {
      const key = v.playlistName || `${v.channelName} Uploads`;
      const arr = map.get(key) || [];
      arr.push(v);
      map.set(key, arr);
    }
    return Array.from(map.entries());
  }, [videos]);

  const handleSyncAllVideos = async () => {
    setIsSyncing(true);
    setStatusNotice(null);
    try {
      const outcome = await syncMediaByTypeApi('youtube');
      await onDataChanged();
      const newCount = outcome.results.reduce((s, r) => s + r.newItems, 0);
      setStatusNotice(
        outcome.skippedDueToLock
          ? 'YouTube senkronizasyonu zaten çalışıyor.'
          : `YouTube kaynakları senkronize edildi (${newCount} yeni video).`
      );
    } catch (err) {
      setStatusNotice(
        err instanceof Error ? err.message : 'YouTube senkronizasyonu başarısız.'
      );
    } finally {
      setIsSyncing(false);
    }
  };

  const handleAddManual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualTitle.trim() || !manualUrl.trim()) return;
    try {
      await createManualMediaVideo({
        title: manualTitle,
        channelName: manualChannel,
        videoUrl: manualUrl,
        category: manualCategory,
        duration: manualDuration,
      });
      setManualTitle('');
      setManualUrl('');
      setManualDuration('');
      setShowManualForm(false);
      await onDataChanged();
    } catch (err) {
      setStatusNotice(
        err instanceof Error ? err.message : 'Video eklenemedi.'
      );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 pb-3">
        <div className="flex flex-wrap items-center gap-1">
          {SUB_TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setSubTab(t.key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                subTab === t.key
                  ? 'bg-[#09090B] text-white'
                  : 'text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowManualForm((p) => !p)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-[#09090B] hover:bg-zinc-50 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Add Video</span>
          </button>
          <button
            type="button"
            onClick={handleSyncAllVideos}
            disabled={isSyncing}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 disabled:opacity-50 cursor-pointer whitespace-nowrap"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`}
              aria-hidden="true"
            />
            <span>
              {isSyncing ? 'Syncing YouTube...' : 'Sync YouTube Sources'}
            </span>
          </button>
        </div>
      </div>

      {/* Official YouTube Embed Player Modal */}
      {activeEmbedVideo && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={activeEmbedVideo.title}
          className="rounded-xl bg-white border border-zinc-300 p-4 space-y-3"
        >
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <p className="text-xs text-[#2563EB] font-medium">
                {activeEmbedVideo.channelName} · {activeEmbedVideo.category}
              </p>
              <h3 className="font-display text-base font-bold text-[#09090B]">
                {activeEmbedVideo.title}
              </h3>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <a
                href={activeEmbedVideo.videoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs rounded-lg border border-zinc-200 hover:bg-zinc-50 text-[#2563EB]"
              >
                <span>YouTube&apos;da Aç</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <button
                type="button"
                onClick={() => setActiveEmbedVideo(null)}
                aria-label="Close video player"
                className="p-1.5 rounded-lg border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {activeEmbedVideo.embedUrl ? (
            <div className="aspect-video w-full rounded-lg overflow-hidden bg-black">
              <iframe
                src={activeEmbedVideo.embedUrl}
                title={activeEmbedVideo.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          ) : (
            <p className="text-xs text-zinc-500">
              Bu video için embed URL bulunamadı; harici bağlantıyı açın.
            </p>
          )}
        </div>
      )}

      {/* YouTube Data API v3 & Quota Status */}
      <div className="rounded-xl bg-white border border-zinc-200 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="space-y-1">
          <p className="text-xs font-semibold text-[#09090B] flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-[#2563EB]" aria-hidden="true" />
            <span>
              YouTube Mode:{' '}
              {youtubeApiConfigured
                ? 'YouTube Data API v3 (Server YOUTUBE_API_KEY Active)'
                : 'Official YouTube Channel/Playlist Atom Feed (YOUTUBE_API_KEY not configured)'}
            </span>
          </p>
          <p className="text-[11px] text-zinc-500">
            {youtubeApiConfigured
              ? 'Channel ID, Playlist ID ve Video ID sorguları sunucu tarafında Data API v3 ile çekilir. Videolar indirilmez; resmi YouTube embed ile oynatılır.'
              : 'Channel ID ve Playlist ID kaynakları resmi YouTube Atom feed ile senkronize edilir; tekil Video ID ve video süresi bilgisi için sunucuda YOUTUBE_API_KEY gereklidir.'}
          </p>
        </div>
        {youtubeQuota && (
          <div className="text-[11px] font-mono tabular-nums text-zinc-500 shrink-0 sm:text-right">
            <div>
              Today: {youtubeQuota.requestsToday} req · ~
              {youtubeQuota.quotaUnitsEstimateToday} units
            </div>
            {youtubeQuota.quotaExceededUntil && (
              <div className="text-red-600">
                Quota cooldown until {formatTechTimestamp(youtubeQuota.quotaExceededUntil)}
              </div>
            )}
          </div>
        )}
      </div>

      {statusNotice && (
        <div className="rounded-lg bg-zinc-50 border border-zinc-200 px-4 py-2.5 text-xs text-zinc-800 flex items-center justify-between">
          <span>{statusNotice}</span>
          <button
            type="button"
            onClick={() => setStatusNotice(null)}
            className="font-medium underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {showManualForm && (
        <form
          onSubmit={handleAddManual}
          className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3"
        >
          <h3 className="font-display text-sm font-semibold text-[#09090B]">
            Add Verified YouTube or Engineering Video
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <input
              type="text"
              required
              value={manualTitle}
              onChange={(e) => setManualTitle(e.target.value)}
              placeholder="Video title"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              value={manualChannel}
              onChange={(e) => setManualChannel(e.target.value)}
              placeholder="Channel name"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="url"
              required
              value={manualUrl}
              onChange={(e) => setManualUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              value={manualCategory}
              onChange={(e) => setManualCategory(e.target.value)}
              placeholder="Category"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              value={manualDuration}
              onChange={(e) => setManualDuration(e.target.value)}
              placeholder="Duration (optional, e.g. 24:10)"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <div className="flex items-center gap-2">
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
              >
                Save Video
              </button>
              <button
                type="button"
                onClick={() => setShowManualForm(false)}
                className="px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </form>
      )}

      {subTab === 'channels' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {youtubeSources.map((src) => (
            <div
              key={src.id}
              className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-display text-sm font-semibold text-[#09090B]">
                    {src.name}
                  </h3>
                  <p className="text-[11px] text-zinc-500">
                    {src.category} · {src.youtubeTargetKind || 'channel'} ·{' '}
                    {src.verificationStatus}
                  </p>
                </div>
                <span className="text-xs font-mono tabular-nums text-zinc-600">
                  {src.collectedCount} videos
                </span>
              </div>
              <p className="text-xs text-zinc-600 line-clamp-2">
                {src.description}
              </p>
              <div className="flex items-center justify-between pt-2 border-t border-zinc-100 text-xs">
                <a
                  href={src.websiteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#2563EB] hover:underline inline-flex items-center gap-1"
                >
                  <span>Visit Channel</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <button
                  type="button"
                  onClick={async () => {
                    setSyncingId(src.id);
                    try {
                      await syncSingleMediaSourceApi(src.id);
                      await onDataChanged();
                    } finally {
                      setSyncingId(null);
                    }
                  }}
                  disabled={syncingId === src.id}
                  className="px-2.5 py-1 rounded border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                >
                  {syncingId === src.id ? 'Syncing...' : 'Sync'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {subTab === 'playlists' && (
        <div className="space-y-4">
          {playlists.length === 0 ? (
            <p className="text-sm text-zinc-500 bg-white rounded-xl border border-zinc-200 p-6 text-center">
              Sync YouTube channels or playlists first to populate playlist groups.
            </p>
          ) : (
            playlists.map(([plName, list]) => (
              <div
                key={plName}
                className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3"
              >
                <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                  <h3 className="font-display text-sm font-semibold text-[#09090B]">
                    {plName}
                  </h3>
                  <span className="text-xs font-mono tabular-nums text-zinc-500">
                    {list.length} items
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {list.slice(0, 6).map((v) => (
                    <button
                      key={v.id}
                      type="button"
                      onClick={() => setActiveEmbedVideo(v)}
                      className="text-left text-xs text-[#09090B] hover:text-[#2563EB] line-clamp-2 p-2 rounded border border-zinc-100 hover:border-zinc-200 cursor-pointer"
                    >
                      {v.title}
                    </button>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {subTab === 'sources' && (
        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
          {youtubeSources.map((src) => (
            <div
              key={src.id}
              className="px-5 py-3 flex flex-wrap items-center justify-between gap-4"
            >
              <div className="min-w-0 flex-1 space-y-0.5">
                <p className="text-sm font-medium text-[#09090B]">
                  {src.name}{' '}
                  <span className="text-xs font-normal text-zinc-500">
                    · {src.youtubeTargetKind || 'channel'} ·{' '}
                    {src.verificationStatus}
                  </span>
                </p>
                <p className="text-xs font-mono text-zinc-500 truncate">
                  {src.lastError || src.feedOrEndpoint}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    await updateMediaSource(src.id, { enabled: !src.enabled });
                    await onDataChanged();
                  }}
                  className={`px-2.5 py-1 text-xs rounded border cursor-pointer ${
                    src.enabled
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                      : 'border-zinc-200 bg-zinc-50 text-zinc-600'
                  }`}
                >
                  {src.enabled ? 'Enabled' : 'Disabled'}
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    setSyncingId(src.id);
                    try {
                      await syncSingleMediaSourceApi(src.id);
                      await onDataChanged();
                    } finally {
                      setSyncingId(null);
                    }
                  }}
                  className="px-2.5 py-1 text-xs rounded border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                >
                  {syncingId === src.id ? 'Syncing...' : 'Sync'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {subTab === 'sync-history' && (
        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
          {youtubeHistory.length === 0 ? (
            <p className="p-6 text-xs text-zinc-500 text-center">
              No YouTube sync runs recorded yet.
            </p>
          ) : (
            youtubeHistory.map((h) => (
              <div
                key={h.syncId}
                className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs"
              >
                <span className="font-medium text-[#09090B]">
                  {h.sourceName}
                </span>
                <span className="font-mono tabular-nums text-zinc-500">
                  {h.status} · {h.newItems} new · {h.duplicatesSkipped} dup ·{' '}
                  {formatTechTimestamp(h.finishedAt)}
                </span>
              </div>
            ))
          )}
        </div>
      )}

      {subTab === 'settings' && (
        <div className="rounded-xl bg-white border border-zinc-200 p-5 space-y-3 text-xs text-zinc-600">
          <h3 className="font-display text-sm font-semibold text-[#09090B]">
            YouTube Data API v3 &amp; Official Embed Policy
          </h3>
          <p>
            YouTube Data API v3 keys must ONLY be configured server-side via the{' '}
            <code className="font-mono bg-zinc-100 px-1 py-0.5 rounded">
              YOUTUBE_API_KEY
            </code>{' '}
            environment variable. Video files are never downloaded; playback uses official YouTube iframe embeds and direct watch links.
          </p>
          <p>
            Channel ID, Playlist ID, and Video ID targets are deduplicated on the backend by <code className="font-mono">videoId</code>. Active window: {settings.activeWindowDays} days.
          </p>
        </div>
      )}

      {(subTab === 'discover' ||
        subTab === 'latest' ||
        subTab === 'watched' ||
        subTab === 'saved' ||
        subTab === 'archive') && (
        <>
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[220px]">
              <Search
                className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2"
                aria-hidden="true"
              />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search videos, channels, tags..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
              />
            </div>

            <select
              aria-label="Filter by channel"
              value={channelFilter}
              onChange={(e) => setChannelFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            >
              <option value="all">All Channels</option>
              {uniqueChannels.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <select
              aria-label="Filter by category"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            >
              <option value="all">All Categories</option>
              {uniqueCategories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {filteredVideos.length === 0 ? (
            <div className="rounded-xl bg-white border border-zinc-200 p-8 text-center space-y-2">
              <VideoIcon
                className="w-7 h-7 text-zinc-400 mx-auto"
                aria-hidden="true"
              />
              <p className="text-sm font-medium text-[#09090B]">
                No videos in this view yet.
              </p>
              <p className="text-xs text-zinc-500">
                Click Sync YouTube Sources to fetch videos from verified Channel ID, Playlist ID, or Video ID sources.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredVideos.map((v) => (
                <article
                  key={v.id}
                  className="rounded-xl bg-white border border-zinc-200 overflow-hidden flex flex-col"
                >
                  <button
                    type="button"
                    onClick={() => setActiveEmbedVideo(v)}
                    className="aspect-video bg-zinc-100 relative overflow-hidden block w-full text-left group cursor-pointer"
                  >
                    <ResilientImage
                      src={v.thumbnailUrl || undefined}
                      alt={v.title}
                      fallbackTitle={v.channelName}
                    />
                    <span className="absolute inset-0 bg-black/0 group-hover:bg-black/25 transition-colors flex items-center justify-center">
                      <span className="w-10 h-10 rounded-full bg-black/75 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Play className="w-4 h-4 ml-0.5" />
                      </span>
                    </span>
                    {v.duration && (
                      <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-white text-[10px] font-mono tabular-nums">
                        {v.duration}
                      </span>
                    )}
                  </button>

                  <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                    <div className="space-y-1.5">
                      <p className="text-[11px] text-zinc-500 flex items-center gap-1.5 flex-wrap">
                        <span className="font-medium text-[#2563EB]">
                          {v.channelName}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{v.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">
                          {formatTechDate(v.publishedAt)}
                        </span>
                      </p>
                      <button
                        type="button"
                        onClick={() => setActiveEmbedVideo(v)}
                        className="text-left font-display text-sm font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-2 block cursor-pointer"
                      >
                        {v.title}
                      </button>
                    </div>

                    <div className="pt-3 border-t border-zinc-100 flex items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => setActiveEmbedVideo(v)}
                          className="inline-flex items-center gap-1 font-medium text-[#09090B] hover:text-[#2563EB] cursor-pointer"
                        >
                          <Play className="w-3 h-3" />
                          <span>Embed</span>
                        </button>
                        <a
                          href={v.videoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 font-medium text-[#2563EB] hover:underline"
                        >
                          <span>Watch</span>
                          <ExternalLink className="w-3 h-3" aria-hidden="true" />
                        </a>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={async () => {
                            await patchMediaVideo(v.id, {
                              isWatched: !v.isWatched,
                            });
                            await onDataChanged();
                          }}
                          aria-label={
                            v.isWatched ? 'Mark unwatched' : 'Mark watched'
                          }
                          className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                            v.isWatched ? 'text-emerald-600' : 'text-zinc-400'
                          }`}
                        >
                          {v.isWatched ? (
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          ) : (
                            <Check className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            await patchMediaVideo(v.id, {
                              isFavorite: !v.isFavorite,
                            });
                            await onDataChanged();
                          }}
                          aria-label="Toggle favorite video"
                          className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                            v.isFavorite ? 'text-amber-500' : 'text-zinc-400'
                          }`}
                        >
                          <Star
                            className="w-3.5 h-3.5"
                            fill={v.isFavorite ? 'currentColor' : 'none'}
                          />
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            await patchMediaVideo(v.id, {
                              isArchived: !v.isArchived,
                            });
                            await onDataChanged();
                          }}
                          aria-label={
                            v.isArchived ? 'Unarchive video' : 'Archive video'
                          }
                          className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                            v.isArchived ? 'text-amber-600' : 'text-zinc-400'
                          }`}
                        >
                          <Archive className="w-3.5 h-3.5" />
                        </button>
                        {pendingDeleteId === v.id ? (
                          <button
                            type="button"
                            onClick={async () => {
                              await deleteMediaVideo(v.id);
                              setPendingDeleteId(null);
                              await onDataChanged();
                            }}
                            className="px-2 py-0.5 text-[11px] bg-red-600 text-white rounded cursor-pointer"
                          >
                            Confirm
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setPendingDeleteId(v.id)}
                            aria-label="Delete video"
                            className="p-1.5 rounded hover:bg-zinc-100 text-zinc-400 hover:text-red-600 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};
