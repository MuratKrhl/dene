import React, { useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Download,
  ExternalLink,
  History,
  Plus,
  Search,
  Star,
  Trash2,
  Upload,
} from 'lucide-react';
import { githubProvider } from '../../github/engine';
import { GitHubRepository } from '../../github/types';
import { AggregatedArticle } from '../../types/article';
import { ArticleSource } from '../../types/articleSource';
import {
  LearningItem,
  PodcastEpisode,
  SecurityRecord,
  TechContentType,
  TechEvent,
  TechSettings,
  TechSource,
  TechSourceType,
  TechSyncHistoryEntry,
  TECH_SYNC_INTERVAL_OPTIONS,
  TechSyncIntervalHours,
  TechVideo,
  TechnologyBackupPayload,
} from '../../types/technology';
import {
  setArticleSourceEnabled,
  syncSingleArticleSource,
  toggleAggregatedArticleFavorite,
} from '../../services/articles/articleAggregator';
import {
  addCustomTechSource,
  deleteTechSourceDefinitionOnly,
  syncSingleTechnologySource,
  testTechFeedUrl,
  toggleEventFavorite,
  toggleLearningFavorite,
  togglePodcastEpisodeFavorite,
  toggleSecurityFavorite,
  toggleVideoFavorite,
  updateTechSource,
} from '../../services/technology/syncEngine';
import { techStorage } from '../../services/technology/techStorage';
import {
  formatTechDate,
  formatTechTimestamp,
} from '../../services/technology/retentionEngine';
import {
  MediaSourceDto,
  MediaStatusDto,
  MediaSyncHistoryDto,
  patchMediaEvent,
  patchMediaPodcastEpisode,
  patchMediaVideo,
} from '../../services/techMediaApi';
import { TechnologySourcesSharedTab } from './TechnologySourcesSharedTab';

// ===========================================================================
// 1. UNIFIED SAVED TAB (Articles, Videos, Podcasts, GitHub Repos, Learning, Security, Events)
// ===========================================================================
interface TechnologySavedTabProps {
  articles: AggregatedArticle[];
  videos: TechVideo[];
  episodes: PodcastEpisode[];
  learningItems: LearningItem[];
  securityRecords: SecurityRecord[];
  events: TechEvent[];
  githubRepos: GitHubRepository[];
  savedGithubRepoIds: number[];
  onDataChanged: () => void | Promise<void>;
  onNavigate: (path: string) => void;
}

type SavedFilterType = 'all' | TechContentType | 'repository';

export const TechnologySavedTab: React.FC<TechnologySavedTabProps> = ({
  articles,
  videos,
  episodes,
  learningItems,
  securityRecords,
  events,
  githubRepos,
  savedGithubRepoIds,
  onDataChanged,
  onNavigate,
}) => {
  const [typeFilter, setTypeFilter] = useState<SavedFilterType>('all');

  const unifiedSaved = useMemo(() => {
    const savedRepoSet = new Set(savedGithubRepoIds);
    const rows: Array<{
      id: string;
      type: Exclude<SavedFilterType, 'all'>;
      title: string;
      source: string;
      date: string | null;
      url: string;
      internalPath?: string;
      onUnfavorite: () => Promise<void>;
    }> = [];

    articles
      .filter((a) => a.isFavorite)
      .forEach((a) =>
        rows.push({
          id: `art-${a.id}`,
          type: 'article',
          title: a.title,
          source: a.sourceName,
          date: a.publishedAt,
          url: a.articleUrl,
          internalPath: `/journal/${encodeURIComponent(a.id)}`,
          onUnfavorite: async () => {
            await toggleAggregatedArticleFavorite(a.id);
          },
        })
      );

    videos
      .filter((v) => v.isFavorite)
      .forEach((v) =>
        rows.push({
          id: `vid-${v.id}`,
          type: 'video',
          title: v.title,
          source: v.channelName,
          date: v.publishedAt,
          url: v.videoUrl,
          onUnfavorite: async () => {
            if (v.id.startsWith('mvid-')) {
              await patchMediaVideo(v.id, { isFavorite: false });
            } else {
              await toggleVideoFavorite(v.id);
            }
          },
        })
      );

    episodes
      .filter((e) => e.isFavorite)
      .forEach((e) =>
        rows.push({
          id: `pod-${e.id}`,
          type: 'podcast',
          title: e.title,
          source: e.seriesTitle,
          date: e.publishedAt,
          url: e.episodeUrl,
          onUnfavorite: async () => {
            if (e.id.startsWith('mep-')) {
              await patchMediaPodcastEpisode(e.id, { isFavorite: false });
            } else {
              await togglePodcastEpisodeFavorite(e.id);
            }
          },
        })
      );

    githubRepos
      .filter((r) => savedRepoSet.has(r.id))
      .forEach((r) =>
        rows.push({
          id: `gh-${r.id}`,
          type: 'repository',
          title: r.fullName,
          source: r.language || 'GitHub',
          date: r.pushedAt || r.updatedAt,
          url: r.htmlUrl,
          internalPath: `/knowledge-hub/github/repositories/${encodeURIComponent(r.owner.login)}/${encodeURIComponent(r.name)}`,
          onUnfavorite: async () => {
            githubProvider.toggleSaveRepo(r.id);
          },
        })
      );

    learningItems
      .filter((l) => l.isFavorite)
      .forEach((l) =>
        rows.push({
          id: `learn-${l.id}`,
          type: 'learning',
          title: l.title,
          source: l.platform,
          date: l.publishedAt,
          url: l.url,
          onUnfavorite: async () => {
            await toggleLearningFavorite(l.id);
          },
        })
      );

    securityRecords
      .filter((s) => s.isFavorite)
      .forEach((s) =>
        rows.push({
          id: `sec-${s.id}`,
          type: 'security',
          title: s.title,
          source: s.source,
          date: s.publishedAt,
          url: s.url,
          onUnfavorite: async () => {
            await toggleSecurityFavorite(s.id);
          },
        })
      );

    events
      .filter((e) => e.isFavorite)
      .forEach((e) =>
        rows.push({
          id: `evt-${e.id}`,
          type: 'event',
          title: e.eventName,
          source: e.organizer,
          date: e.startDate || e.publishedAt,
          url: e.registrationUrl,
          onUnfavorite: async () => {
            if (e.id.startsWith('mevt-')) {
              await patchMediaEvent(e.id, { isFavorite: false });
            } else {
              await toggleEventFavorite(e.id);
            }
          },
        })
      );

    return rows
      .filter((r) => typeFilter === 'all' || r.type === typeFilter)
      .sort(
        (a, b) =>
          Date.parse(b.date || '') - Date.parse(a.date || '')
      );
  }, [
    articles,
    episodes,
    events,
    githubRepos,
    learningItems,
    savedGithubRepoIds,
    securityRecords,
    typeFilter,
    videos,
  ]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1">
          {(
            [
              ['all', 'All Saved'],
              ['article', 'Articles'],
              ['video', 'Videos'],
              ['podcast', 'Podcasts'],
              ['repository', 'Repositories'],
              ['learning', 'Documentation'],
              ['security', 'Security'],
              ['event', 'Conferences'],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setTypeFilter(key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                typeFilter === key
                  ? 'bg-[#09090B] text-white'
                  : 'text-zinc-600 hover:bg-zinc-100'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        <span className="text-xs font-mono tabular-nums text-zinc-500">
          {unifiedSaved.length} saved items
        </span>
      </div>

      {unifiedSaved.length === 0 ? (
        <div className="rounded-xl bg-white border border-zinc-200 p-8 text-center text-sm text-zinc-500">
          No saved favorites in this category yet. Star any article, video, podcast episode, course, security record, or event to collect it here.
        </div>
      ) : (
        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
          {unifiedSaved.map((row) => (
            <div
              key={row.id}
              className="p-4 flex items-center justify-between gap-4"
            >
              <div className="min-w-0 space-y-0.5">
                <p className="text-[11px] text-zinc-500 flex items-center gap-2">
                  <span className="capitalize font-medium text-[#2563EB]">
                    {row.type}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{row.source}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    {formatTechDate(row.date)}
                  </span>
                </p>
                {row.internalPath ? (
                  <button
                    type="button"
                    onClick={() => onNavigate(row.internalPath!)}
                    className="text-left text-sm font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-1 cursor-pointer"
                  >
                    {row.title}
                  </button>
                ) : (
                  <a
                    href={row.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-1 block"
                  >
                    {row.title}
                  </a>
                )}
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={async () => {
                    await row.onUnfavorite();
                    await onDataChanged();
                  }}
                  aria-label="Remove from saved"
                  className="p-1.5 rounded hover:bg-zinc-100 text-amber-500 cursor-pointer"
                >
                  <Star className="w-4 h-4" fill="currentColor" />
                </button>
                <a
                  href={row.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Open original"
                  className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500 hover:text-[#2563EB]"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ===========================================================================
// 2. CENTRAL SOURCE MANAGEMENT TAB (Grouped Registry + Error Inspector + Sync Logs)
// ===========================================================================
interface TechnologySourcesTabProps {
  articleSources: ArticleSource[];
  techSources: TechSource[];
  syncHistory: TechSyncHistoryEntry[];
  mediaSources?: MediaSourceDto[];
  mediaStatus?: MediaStatusDto | null;
  mediaSyncHistory?: MediaSyncHistoryDto[];
  initialShowHistory?: boolean;
  onClearHistory: () => Promise<void>;
  onDataChanged: () => void | Promise<void>;
  onMediaDataChanged?: () => Promise<void> | void;
}

export const TechnologySourcesTab: React.FC<TechnologySourcesTabProps> = ({
  articleSources,
  techSources,
  syncHistory,
  mediaSources = [],
  mediaStatus = null,
  mediaSyncHistory = [],
  initialShowHistory = false,
  onClearHistory,
  onDataChanged,
  onMediaDataChanged,
}) => {
  const [sourceDomain, setSourceDomain] = useState<'media' | 'registry'>('media');
  const [viewMode, setViewMode] = useState<'sources' | 'history'>(
    initialShowHistory ? 'history' : 'sources'
  );
  const [sourceQuery, setSourceQuery] = useState('');
  const [contentTypeFilter, setContentTypeFilter] = useState<'all' | TechContentType>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'error' | 'unsupported'>('all');
  const [syncingId, setSyncingId] = useState<string | null>(null);
  const [expandedErrorId, setExpandedErrorId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  const [name, setName] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [feedUrl, setFeedUrl] = useState('');
  const [sourceType, setSourceType] = useState<TechSourceType>('rss');
  const [contentType, setContentType] =
    useState<Exclude<TechContentType, 'article'>>('podcast');
  const [category, setCategory] = useState('Engineering');
  const [syncInterval, setSyncInterval] = useState(180);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const combinedRows = useMemo(() => {
    const q = sourceQuery.trim().toLowerCase();

    const aRows = articleSources.map((s) => ({
      id: s.id,
      kind: 'article-origin' as const,
      name: s.name,
      contentType: 'article' as TechContentType,
      sourceType: s.sourceType,
      category: s.sourceGroup === 'Medium' ? 'Medium Feeds' : 'Official Engineering Blogs',
      subCategory: s.sourceGroup,
      feedUrl: s.feedUrl,
      websiteUrl: s.websiteUrl,
      enabled: s.enabled,
      status: s.status,
      errorMessage: s.errorMessage,
      lastSuccessfulFetchAt: s.lastSuccessfulFetchAt,
      nextFetchAt: null as string | null,
      itemCount: s.lastArticleCount ?? 0,
      syncInterval: 180,
      isCanonical: true,
    }));

    const tGroupLabel = (ct: Exclude<TechContentType, 'article'>): string => {
      if (ct === 'video') return 'YouTube & Video Channels';
      if (ct === 'podcast') return 'Podcasts';
      if (ct === 'learning') return 'Technical Documentation & Learning';
      if (ct === 'security') return 'Security Advisories & CVEs';
      return 'Conferences & Events';
    };

    const tRows = techSources
      .filter(
        (s) => s.contentType === 'learning' || s.contentType === 'security'
      )
      .map((s) => ({
        id: s.id,
        kind: 'tech-origin' as const,
        name: s.name,
        contentType: s.contentType,
        sourceType: s.sourceType,
        category: tGroupLabel(s.contentType),
        subCategory: s.category,
        feedUrl: s.feedUrl,
        websiteUrl: s.websiteUrl,
        enabled: s.enabled,
        status: s.status,
        errorMessage: s.errorMessage,
        lastSuccessfulFetchAt: s.lastSuccessfulFetchAt,
        nextFetchAt: s.nextFetchAt,
        itemCount: s.itemCount,
        syncInterval: s.syncInterval,
        isCanonical: !s.id.startsWith('custom-'),
      }));

    return [...aRows, ...tRows].filter((r) => {
      if (contentTypeFilter !== 'all' && r.contentType !== contentTypeFilter)
        return false;
      if (statusFilter === 'active' && (!r.enabled || r.status === 'error' || r.sourceType === 'unsupported'))
        return false;
      if (statusFilter === 'error' && r.status !== 'error')
        return false;
      if (statusFilter === 'unsupported' && r.sourceType !== 'unsupported' && r.sourceType !== 'manual')
        return false;
      if (q) {
        const hay = [r.name, r.category, r.subCategory, r.feedUrl, r.websiteUrl]
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [articleSources, contentTypeFilter, sourceQuery, statusFilter, techSources]);

  const groupedRows = useMemo(() => {
    const groups = new Map<string, typeof combinedRows>();
    for (const row of combinedRows) {
      const arr = groups.get(row.category) || [];
      arr.push(row);
      groups.set(row.category, arr);
    }
    return Array.from(groups.entries());
  }, [combinedRows]);

  const handleCreateSource = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    await addCustomTechSource({
      name,
      description: `Custom ${contentType} source`,
      websiteUrl: websiteUrl || feedUrl,
      feedUrl,
      sourceType,
      contentType,
      category,
      tags: [category.toLowerCase(), contentType],
      syncInterval,
    });
    setName('');
    setWebsiteUrl('');
    setFeedUrl('');
    setTestResult(null);
    setShowAddForm(false);
    onDataChanged();
  };

  const nonMediaTechSourcesCount = useMemo(
    () =>
      techSources.filter(
        (s) => s.contentType === 'learning' || s.contentType === 'security'
      ).length,
    [techSources]
  );

  return (
    <div className="space-y-5">
      {/* Domain Switcher: Backend Shared Media Sources vs Articles/Learning/Security */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 pb-3">
        <div className="inline-flex rounded-lg border border-zinc-200 p-0.5 bg-zinc-100">
          <button
            type="button"
            onClick={() => setSourceDomain('media')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md cursor-pointer transition-colors ${
              sourceDomain === 'media'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            Media Sources: Podcasts · Events · YouTube ({mediaSources.length})
          </button>
          <button
            type="button"
            onClick={() => setSourceDomain('registry')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md cursor-pointer transition-colors ${
              sourceDomain === 'registry'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            Articles, Learning &amp; Security ({articleSources.length + nonMediaTechSourcesCount})
          </button>
        </div>
      </div>

      {sourceDomain === 'media' ? (
        <TechnologySourcesSharedTab
          sources={mediaSources}
          status={mediaStatus}
          history={mediaSyncHistory}
          initialShowHistory={initialShowHistory}
          onDataChanged={onMediaDataChanged || onDataChanged}
        />
      ) : (
        <>
      {/* Top Toolbar: View Switch (Registry vs Sync History) + Add Source */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex rounded-lg border border-zinc-200 p-0.5 bg-zinc-100">
          <button
            type="button"
            onClick={() => setViewMode('sources')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer transition-colors ${
              viewMode === 'sources'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            Source Registry ({articleSources.length + nonMediaTechSourcesCount})
          </button>
          <button
            type="button"
            onClick={() => setViewMode('history')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer transition-colors ${
              viewMode === 'history'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            <History className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Sync History ({syncHistory.length})</span>
          </button>
        </div>

        {viewMode === 'sources' && (
          <button
            type="button"
            onClick={() => setShowAddForm((p) => !p)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Add Source</span>
          </button>
        )}
      </div>

      {viewMode === 'history' ? (
        <TechnologySyncHistoryTab
          history={syncHistory}
          onClearHistory={onClearHistory}
        />
      ) : (
        <>
          {/* Source Search & Filters */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative flex-1 min-w-[220px]">
              <Search
                className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2"
                aria-hidden="true"
              />
              <input
                type="text"
                value={sourceQuery}
                onChange={(e) => setSourceQuery(e.target.value)}
                placeholder="Search sources by name, category, or feed URL..."
                aria-label="Search sources"
                className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
              />
            </div>

            <select
              aria-label="Filter sources by content type"
              value={contentTypeFilter}
              onChange={(e) =>
                setContentTypeFilter(e.target.value as 'all' | TechContentType)
              }
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            >
              <option value="all">All Types</option>
              <option value="article">Articles</option>
              <option value="video">Videos</option>
              <option value="podcast">Podcasts</option>
              <option value="learning">Documentation &amp; Learning</option>
              <option value="security">Security</option>
              <option value="event">Conferences</option>
            </select>

            <select
              aria-label="Filter sources by status"
              value={statusFilter}
              onChange={(e) =>
                setStatusFilter(
                  e.target.value as 'all' | 'active' | 'error' | 'unsupported'
                )
              }
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active &amp; Healthy</option>
              <option value="error">Failed / Error</option>
              <option value="unsupported">Manual / Portal Only</option>
            </select>
          </div>

          {showAddForm && (
            <form
              onSubmit={handleCreateSource}
              className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3"
            >
              <h3 className="font-display text-sm font-semibold text-[#09090B]">
                Register New Technology Source
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Source name"
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
                />
                <select
                  value={contentType}
                  onChange={(e) =>
                    setContentType(
                      e.target.value as Exclude<TechContentType, 'article'>
                    )
                  }
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
                >
                  <option value="podcast">Podcast</option>
                  <option value="video">Video</option>
                  <option value="learning">Learning / Docs</option>
                  <option value="security">Security</option>
                  <option value="event">Conference / Event</option>
                </select>
                <select
                  value={sourceType}
                  onChange={(e) => setSourceType(e.target.value as TechSourceType)}
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
                >
                  <option value="rss">RSS</option>
                  <option value="atom">Atom</option>
                  <option value="json-feed">JSON Feed</option>
                  <option value="official-api">Official API</option>
                  <option value="manual">Manual Portal</option>
                </select>
                <input
                  type="url"
                  value={feedUrl}
                  onChange={(e) => setFeedUrl(e.target.value)}
                  placeholder="Feed URL (https://...)"
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 sm:col-span-2"
                />
                <input
                  type="text"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="Category"
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
                />
                <input
                  type="url"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  placeholder="Website URL (optional)"
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
                />
                <select
                  value={syncInterval}
                  onChange={(e) => setSyncInterval(Number(e.target.value))}
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
                >
                  <option value={60}>Every 1h</option>
                  <option value={180}>Every 3h (Default)</option>
                  <option value={360}>Every 6h</option>
                  <option value={720}>Every 12h</option>
                  <option value={1440}>Every 24h</option>
                  <option value={0}>Manual only</option>
                </select>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      if (!feedUrl.trim()) return;
                      setTestResult('Testing feed URL...');
                      const res = await testTechFeedUrl(feedUrl.trim());
                      setTestResult(
                        res.ok
                          ? `OK (${res.durationMs}ms): ${res.message}`
                          : `Failed: ${res.message}`
                      );
                    }}
                    className="px-3 py-2 text-xs rounded-lg border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                  >
                    Test URL
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white cursor-pointer"
                  >
                    Save Source
                  </button>
                </div>
              </div>
              {testResult && (
                <p className="text-xs font-mono text-zinc-600">{testResult}</p>
              )}
            </form>
          )}

          {groupedRows.length === 0 ? (
            <div className="rounded-xl bg-white border border-zinc-200 p-8 text-center text-xs text-zinc-500">
              No sources match your current search or filter criteria.
            </div>
          ) : (
            <div className="space-y-5">
              {groupedRows.map(([groupName, rows]) => (
                <section
                  key={groupName}
                  className="rounded-xl bg-white border border-zinc-200 overflow-hidden"
                >
                  <div className="px-5 py-3 bg-[#FAFAFA] border-b border-zinc-200 flex items-center justify-between">
                    <h3 className="font-display text-xs font-semibold uppercase tracking-wider text-zinc-700">
                      {groupName}
                    </h3>
                    <span className="text-[11px] font-mono tabular-nums text-zinc-500">
                      {rows.length} sources
                    </span>
                  </div>

                  <div className="divide-y divide-zinc-100">
                    {rows.map((row) => {
                      const hasError = row.status === 'error' || Boolean(row.errorMessage);
                      const isExpanded = expandedErrorId === row.id;
                      return (
                        <div key={row.id} className="px-5 py-3.5 space-y-2">
                          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                            <div className="min-w-0 flex-1 space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-sm font-semibold text-[#09090B]">
                                  {row.name}
                                </span>
                                <span className="text-[11px] text-zinc-500">
                                  · {row.subCategory} · {row.sourceType.toUpperCase()}
                                </span>
                                <span
                                  className={`inline-flex items-center gap-1 text-[11px] font-medium ${
                                    row.status === 'error'
                                      ? 'text-red-600'
                                      : row.status === 'success'
                                        ? 'text-emerald-700'
                                        : 'text-zinc-500'
                                  }`}
                                >
                                  {row.status === 'error' && (
                                    <AlertCircle className="w-3 h-3" aria-hidden="true" />
                                  )}
                                  {row.status === 'success' && (
                                    <CheckCircle2 className="w-3 h-3" aria-hidden="true" />
                                  )}
                                  <span>
                                    {row.status === 'unsupported'
                                      ? 'Portal Only'
                                      : row.status}
                                  </span>
                                </span>
                              </div>

                              <p className="text-[11px] text-zinc-500 truncate font-mono tabular-nums">
                                {row.itemCount} items · Last sync:{' '}
                                {row.lastSuccessfulFetchAt
                                  ? formatTechTimestamp(row.lastSuccessfulFetchAt)
                                  : 'Never'}
                                {row.nextFetchAt
                                  ? ` · Next: ${formatTechTimestamp(row.nextFetchAt)}`
                                  : ''}
                              </p>
                            </div>

                            <div className="flex flex-wrap items-center gap-2 shrink-0">
                              {hasError && row.errorMessage && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    setExpandedErrorId(isExpanded ? null : row.id)
                                  }
                                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] rounded border border-zinc-200 text-zinc-600 hover:bg-zinc-50 cursor-pointer"
                                >
                                  {isExpanded ? (
                                    <ChevronDown className="w-3 h-3" />
                                  ) : (
                                    <ChevronRight className="w-3 h-3" />
                                  )}
                                  <span>Details</span>
                                </button>
                              )}

                              {row.kind === 'tech-origin' &&
                                row.sourceType !== 'unsupported' &&
                                row.sourceType !== 'manual' && (
                                  <select
                                    aria-label={`Sync interval for ${row.name}`}
                                    value={row.syncInterval}
                                    onChange={async (e) => {
                                      await updateTechSource(row.id, {
                                        syncInterval: Number(e.target.value),
                                      });
                                      onDataChanged();
                                    }}
                                    className="px-2 py-1 text-[11px] rounded border border-zinc-200 bg-white"
                                  >
                                    <option value={60}>1h</option>
                                    <option value={180}>3h</option>
                                    <option value={360}>6h</option>
                                    <option value={720}>12h</option>
                                    <option value={1440}>24h</option>
                                    <option value={0}>Manual</option>
                                  </select>
                                )}

                              {row.sourceType !== 'unsupported' &&
                                row.sourceType !== 'manual' && (
                                  <>
                                    <button
                                      type="button"
                                      onClick={async () => {
                                        if (row.kind === 'article-origin') {
                                          await setArticleSourceEnabled(
                                            row.id,
                                            !row.enabled
                                          );
                                        } else {
                                          await updateTechSource(row.id, {
                                            enabled: !row.enabled,
                                          });
                                        }
                                        onDataChanged();
                                      }}
                                      className={`px-2.5 py-1 text-xs rounded border cursor-pointer ${
                                        row.enabled
                                          ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                                          : 'border-zinc-200 bg-zinc-50 text-zinc-600'
                                      }`}
                                    >
                                      {row.enabled ? 'Enabled' : 'Disabled'}
                                    </button>

                                    <button
                                      type="button"
                                      disabled={syncingId === row.id}
                                      onClick={async () => {
                                        setSyncingId(row.id);
                                        try {
                                          if (row.kind === 'article-origin') {
                                            await syncSingleArticleSource(row.id);
                                          } else {
                                            await syncSingleTechnologySource(row.id);
                                          }
                                          onDataChanged();
                                        } finally {
                                          setSyncingId(null);
                                        }
                                      }}
                                      className="px-2.5 py-1 text-xs rounded border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                                    >
                                      {syncingId === row.id ? 'Syncing...' : 'Sync Now'}
                                    </button>
                                  </>
                                )}

                              {row.kind === 'tech-origin' && !row.isCanonical && (
                                pendingDeleteId === row.id ? (
                                  <button
                                    type="button"
                                    onClick={async () => {
                                      await deleteTechSourceDefinitionOnly(row.id);
                                      setPendingDeleteId(null);
                                      onDataChanged();
                                    }}
                                    className="px-2 py-1 text-xs bg-red-600 text-white rounded cursor-pointer"
                                  >
                                    Confirm Delete
                                  </button>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => setPendingDeleteId(row.id)}
                                    aria-label="Delete source definition"
                                    className="p-1.5 rounded hover:bg-zinc-100 text-zinc-400 hover:text-red-600 cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )
                              )}
                            </div>
                          </div>

                          {isExpanded && row.errorMessage && (
                            <div className="rounded-lg bg-zinc-50 border border-zinc-200 px-3 py-2 text-xs text-zinc-700 space-y-1">
                              <p className="font-mono text-[11px] break-all text-zinc-500">
                                URL: {row.feedUrl || row.websiteUrl}
                              </p>
                              <p className={row.status === 'error' ? 'text-red-700' : ''}>
                                {row.errorMessage}
                              </p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </section>
              ))}
            </div>
          )}
        </>
      )}
        </>
      )}
    </div>
  );
};

// ===========================================================================
// 3. UNIFIED SYNC HISTORY TAB
// ===========================================================================
interface TechnologySyncHistoryTabProps {
  history: TechSyncHistoryEntry[];
  onClearHistory: () => Promise<void>;
}

export const TechnologySyncHistoryTab: React.FC<
  TechnologySyncHistoryTabProps
> = ({ history, onClearHistory }) => {
  const [filterType, setFilterType] = useState<'all' | TechContentType>('all');

  const rows = useMemo(
    () =>
      history.filter(
        (h) => filterType === 'all' || h.contentType === filterType
      ),
    [filterType, history]
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1">
          {(
            [
              ['all', 'All Runs'],
              ['article', 'Articles'],
              ['video', 'Videos'],
              ['podcast', 'Podcasts'],
              ['learning', 'Learning'],
              ['security', 'Security'],
              ['event', 'Events'],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setFilterType(key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                filterType === key
                  ? 'bg-[#09090B] text-white'
                  : 'text-zinc-600 hover:bg-zinc-100'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {history.length > 0 && (
          <button
            type="button"
            onClick={onClearHistory}
            className="px-3 py-1.5 text-xs rounded-lg border border-zinc-200 hover:bg-zinc-50 text-zinc-600 cursor-pointer"
          >
            Clear History Log
          </button>
        )}
      </div>

      {rows.length === 0 ? (
        <div className="rounded-xl bg-white border border-zinc-200 p-8 text-center text-sm text-zinc-500">
          No synchronization runs recorded yet. Trigger Refresh All or sync any module.
        </div>
      ) : (
        <div className="rounded-xl bg-white border border-zinc-200 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-zinc-200 text-zinc-500">
                <th className="py-2.5 px-4 font-medium">Source</th>
                <th className="py-2.5 px-3 font-medium">Type</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 px-3 font-medium text-right">New</th>
                <th className="py-2.5 px-3 font-medium text-right">Dup</th>
                <th className="py-2.5 px-3 font-medium text-right">Updated</th>
                <th className="py-2.5 px-3 font-medium text-right">Errors</th>
                <th className="py-2.5 px-3 font-medium text-right">Duration</th>
                <th className="py-2.5 px-4 font-medium">Finished At</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 font-mono tabular-nums">
              {rows.map((h) => (
                <tr key={h.syncId} className="hover:bg-zinc-50/70">
                  <td className="py-2.5 px-4 font-sans font-medium text-[#09090B]">
                    <div>{h.sourceName}</div>
                    {h.errorMessage && (
                      <div className="text-[11px] text-red-600 font-normal">
                        {h.errorMessage}
                      </div>
                    )}
                  </td>
                  <td className="py-2.5 px-3 font-sans capitalize text-zinc-600">
                    {h.contentType}
                  </td>
                  <td className="py-2.5 px-3 font-sans">
                    <span
                      className={
                        h.status === 'success'
                          ? 'text-emerald-700 font-medium'
                          : h.status === 'error'
                            ? 'text-red-600 font-medium'
                            : 'text-zinc-500'
                      }
                    >
                      {h.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right">{h.newItems}</td>
                  <td className="py-2.5 px-3 text-right">{h.duplicates}</td>
                  <td className="py-2.5 px-3 text-right">{h.updatedItems}</td>
                  <td className="py-2.5 px-3 text-right">{h.errors}</td>
                  <td className="py-2.5 px-3 text-right">{h.durationMs}ms</td>
                  <td className="py-2.5 px-4 text-zinc-500">
                    {formatTechTimestamp(h.finishedAt)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ===========================================================================
// 4. SETTINGS, STORAGE, BACKUP & EXPORT TAB
// ===========================================================================
interface TechnologySettingsTabProps {
  settings: TechSettings;
  youtubeApiConfigured: boolean;
  nvdApiConfigured: boolean;
  onSaveSettings: (next: TechSettings) => Promise<void>;
  onDataChanged: () => void;
}

export const TechnologySettingsTab: React.FC<TechnologySettingsTabProps> = ({
  settings,
  youtubeApiConfigured,
  nvdApiConfigured,
  onSaveSettings,
  onDataChanged,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [backupMessage, setBackupMessage] = useState<string | null>(null);

  const storageInfo = useMemo(() => techStorage.estimateStorageBreakdown(), [settings]);

  const handleExportBackup = () => {
    const payload = techStorage.exportBackup();
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `workspace-technology-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setBackupMessage('Full Technology Center JSON backup exported.');
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as TechnologyBackupPayload;
      await techStorage.restoreBackup(parsed);
      setBackupMessage('Backup restored successfully.');
      onDataChanged();
    } catch (err) {
      setBackupMessage(
        err instanceof Error ? err.message : 'Failed to restore backup.'
      );
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sync & Retention Policy */}
        <section className="rounded-xl bg-white border border-zinc-200 p-5 space-y-4">
          <h3 className="font-display text-sm font-semibold text-[#09090B]">
            Synchronization &amp; Active Retention Window
          </h3>

          <label className="flex items-center justify-between p-3 rounded-lg border border-zinc-200 cursor-pointer">
            <div>
              <p className="text-xs font-medium text-[#09090B]">
                Global Automatic Sync (Browser-Open Scheduler)
              </p>
              <p className="text-[11px] text-zinc-500">
                Checks overdue sources on Workspace open and while active. Closed tabs require a backend cron worker.
              </p>
            </div>
            <input
              type="checkbox"
              checked={settings.globalAutoSync}
              onChange={(e) =>
                onSaveSettings({ ...settings, globalAutoSync: e.target.checked })
              }
            />
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 rounded-lg border border-zinc-200 space-y-1">
              <label className="block text-[11px] text-zinc-500">
                Default Sync Interval
              </label>
              <select
                value={settings.defaultSyncIntervalHours}
                onChange={(e) =>
                  onSaveSettings({
                    ...settings,
                    defaultSyncIntervalHours: Number(
                      e.target.value
                    ) as TechSyncIntervalHours,
                  })
                }
                className="w-full text-xs border border-zinc-200 rounded px-2 py-1.5 bg-white"
              >
                {TECH_SYNC_INTERVAL_OPTIONS.map((h) => (
                  <option key={h} value={h}>
                    {h === 0 ? 'Disabled' : `Every ${h} hour${h > 1 ? 's' : ''}`}
                  </option>
                ))}
              </select>
            </div>

            <div className="p-3 rounded-lg border border-zinc-200 space-y-1">
              <label className="block text-[11px] text-zinc-500">
                Active Latest Window (Archive never deletes)
              </label>
              <select
                value={settings.activeWindowDays}
                onChange={(e) =>
                  onSaveSettings({
                    ...settings,
                    activeWindowDays: Number(e.target.value),
                  })
                }
                className="w-full text-xs border border-zinc-200 rounded px-2 py-1.5 bg-white"
              >
                <option value={14}>14 Days</option>
                <option value={30}>30 Days (Default)</option>
                <option value={60}>60 Days</option>
                <option value={90}>90 Days</option>
              </select>
            </div>

            <div className="p-3 rounded-lg border border-zinc-200 space-y-1">
              <label className="block text-[11px] text-zinc-500">
                Feed Request Timeout
              </label>
              <select
                value={settings.requestTimeoutMs}
                onChange={(e) =>
                  onSaveSettings({
                    ...settings,
                    requestTimeoutMs: Number(e.target.value),
                  })
                }
                className="w-full text-xs border border-zinc-200 rounded px-2 py-1.5 bg-white"
              >
                <option value={10_000}>10 seconds</option>
                <option value={20_000}>20 seconds (Default)</option>
                <option value={30_000}>30 seconds</option>
              </select>
            </div>

            <div className="p-3 rounded-lg border border-zinc-200 space-y-1">
              <label className="block text-[11px] text-zinc-500">
                Transient Error Retry Count
              </label>
              <select
                value={settings.retryCount}
                onChange={(e) =>
                  onSaveSettings({
                    ...settings,
                    retryCount: Number(e.target.value) as 0 | 1,
                  })
                }
                className="w-full text-xs border border-zinc-200 rounded px-2 py-1.5 bg-white"
              >
                <option value={1}>1 Retry (Default)</option>
                <option value={0}>0 Retries</option>
              </select>
            </div>
          </div>
        </section>

        {/* Server API Status & Storage Usage */}
        <section className="rounded-xl bg-white border border-zinc-200 p-5 space-y-4">
          <h3 className="font-display text-sm font-semibold text-[#09090B]">
            Server API Configuration &amp; Storage Usage
          </h3>

          <div className="space-y-2 text-xs">
            <div className="p-3 rounded-lg border border-zinc-200 flex items-center justify-between">
              <div>
                <p className="font-medium text-[#09090B]">
                  YouTube Data API v3 (Server-Side)
                </p>
                <p className="text-[11px] text-zinc-500">
                  Configured via server environment variable YOUTUBE_API_KEY (never in frontend code).
                </p>
              </div>
              <span
                className={`font-mono text-[11px] font-medium ${
                  youtubeApiConfigured ? 'text-emerald-700' : 'text-amber-700'
                }`}
              >
                {youtubeApiConfigured ? 'Configured' : 'Atom Fallback'}
              </span>
            </div>

            <div className="p-3 rounded-lg border border-zinc-200 flex items-center justify-between">
              <div>
                <p className="font-medium text-[#09090B]">
                  NVD API v2 Optional Key (Server-Side)
                </p>
                <p className="text-[11px] text-zinc-500">
                  Public NVD CVE API 2.0 works without a key; NVD_API_KEY increases rate limits.
                </p>
              </div>
              <span className="font-mono text-[11px] text-zinc-600">
                {nvdApiConfigured ? 'Configured' : 'Public Tier'}
              </span>
            </div>
          </div>

          <div className="p-3 rounded-lg border border-zinc-200 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-[#09090B]">
                IndexedDB Technology Store Usage
              </span>
              <span className="font-mono tabular-nums text-zinc-600">
                {(storageInfo.totalBytes / 1024).toFixed(1)} KB
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono tabular-nums text-zinc-600">
              <span>Videos: {storageInfo.counts.videos}</span>
              <span>Shows: {storageInfo.counts.podcastSeries}</span>
              <span>Episodes: {storageInfo.counts.podcastEpisodes}</span>
              <span>Learning: {storageInfo.counts.learningItems}</span>
              <span>Security: {storageInfo.counts.securityRecords}</span>
              <span>Events: {storageInfo.counts.events}</span>
              <span>Sources: {storageInfo.counts.sources}</span>
              <span>History: {storageInfo.counts.syncHistory}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleExportBackup}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON Backup</span>
            </button>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Restore Backup</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="application/json"
              onChange={handleRestoreFile}
              className="hidden"
            />
          </div>
          {backupMessage && (
            <p className="text-xs text-emerald-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{backupMessage}</span>
            </p>
          )}
        </section>
      </div>
    </div>
  );
};
