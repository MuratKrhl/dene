import React, { useEffect, useState } from 'react';
import {
  Archive,
  ArchiveRestore,
  ArrowLeft,
  ArrowRight,
  Check,
  ExternalLink,
  Sparkles,
  Star,
} from 'lucide-react';
import { techKnowledgeHubApi } from '../../services/techKnowledgeHubApi';
import {
  SimilarArticleDto,
  TechHubArticleDto,
} from '../../types/techKnowledgeHub';

interface TechKnowledgeArticleDetailProps {
  articleId: string;
  geminiConfigured: boolean;
  cameFromArchive?: boolean;
  onBack: (toArchive?: boolean) => void;
  onOpenArticle: (articleId: string) => void;
  onSelectCategory: (categoryId: string) => void;
  onMetadataChanged: () => void;
}

function formatPublishedDate(iso: string | null): string {
  if (!iso) return 'Yayın tarihi belirtilmemiş';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return 'Yayın tarihi belirtilmemiş';
  return d.toLocaleDateString('tr-TR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });
}

export const TechKnowledgeArticleDetail: React.FC<
  TechKnowledgeArticleDetailProps
> = ({
  articleId,
  geminiConfigured,
  cameFromArchive = false,
  onBack,
  onOpenArticle,
  onSelectCategory,
  onMetadataChanged,
}) => {
  const [article, setArticle] = useState<TechHubArticleDto | null>(null);
  const [similarArticles, setSimilarArticles] = useState<SimilarArticleDto[]>(
    []
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [noteDraft, setNoteDraft] = useState('');
  const [savingNote, setSavingNote] = useState(false);
  const [noteSavedFeedback, setNoteSavedFeedback] = useState(false);
  const [summarizing, setSummarizing] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    setImageFailed(false);
    setNoteSavedFeedback(false);

    (async () => {
      try {
        const res = await techKnowledgeHubApi.getArticleDetail(articleId);
        if (!active) return;
        setArticle(res.article);
        setSimilarArticles(res.similarArticles);
        setNoteDraft(res.article.note || '');
        setLoading(false);

        if (!res.article.isRead) {
          await techKnowledgeHubApi.updateArticleState(res.article.id, {
            isRead: true,
          });
          if (!active) return;
          setArticle((prev) => (prev ? { ...prev, isRead: true } : prev));
        }
      } catch (err) {
        if (!active) return;
        setError(
          err instanceof Error
            ? err.message
            : 'Makale bulunamadı veya yüklenemedi.'
        );
        setLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [articleId]);

  if (loading) {
    return (
      <div className="rounded-xl bg-white border border-zinc-200 p-10 text-center text-xs text-zinc-500">
        Makale yükleniyor...
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="rounded-xl bg-white border border-zinc-200 p-10 text-center space-y-4">
        <h2 className="font-display text-lg font-bold text-[#09090B]">
          Makale bulunamadı
        </h2>
        <p className="text-xs text-zinc-600 max-w-md mx-auto">
          {error || 'İstenen makale kaydına ulaşılamadı.'}
        </p>
        <button
          type="button"
          onClick={() => onBack(cameFromArchive)}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Blog&apos;a Dön</span>
        </button>
      </div>
    );
  }

  const handleToggleRead = async () => {
    const res = await techKnowledgeHubApi.updateArticleState(article.id, {
      isRead: !article.isRead,
    });
    setArticle((prev) => (prev ? { ...prev, isRead: res.isRead } : prev));
  };

  const handleToggleFavorite = async () => {
    const res = await techKnowledgeHubApi.updateArticleState(article.id, {
      isFavorite: !article.isFavorite,
    });
    setArticle((prev) =>
      prev ? { ...prev, isFavorite: res.isFavorite } : prev
    );
    onMetadataChanged();
  };

  const handleToggleArchive = async () => {
    const res = await techKnowledgeHubApi.updateArticleState(article.id, {
      isArchived: !article.isArchived,
    });
    setArticle((prev) =>
      prev
        ? {
            ...prev,
            isArchived: res.isArchived,
            archivedAt: res.archivedAt,
          }
        : prev
    );
    onMetadataChanged();
  };

  const handleSaveNote = async () => {
    setSavingNote(true);
    setNoteSavedFeedback(false);
    try {
      await techKnowledgeHubApi.updateArticleState(article.id, {
        note: noteDraft,
      });
      setArticle((prev) => (prev ? { ...prev, note: noteDraft } : prev));
      setNoteSavedFeedback(true);
    } finally {
      setSavingNote(false);
    }
  };

  const handleSummarize = async () => {
    setSummarizing(true);
    try {
      await techKnowledgeHubApi.summarizeArticle(article.id);
      const refreshed = await techKnowledgeHubApi.getArticleDetail(article.id);
      setArticle(refreshed.article);
      setSimilarArticles(refreshed.similarArticles);
    } finally {
      setSummarizing(false);
    }
  };

  const previewParagraphs =
    article.contentPreview && article.contentPreview.length > 0
      ? article.contentPreview
      : article.description
        ? [article.description]
        : [];

  return (
    <article className="rounded-xl bg-white border border-zinc-200 p-6 sm:p-8 lg:p-10 space-y-8">
      {/* Top Navigation & Primary Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-5 border-b border-zinc-200">
        <button
          type="button"
          onClick={() => onBack(cameFromArchive || article.isArchived)}
          className="inline-flex items-center gap-2 text-xs font-medium text-zinc-600 hover:text-[#09090B] transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
          <span>
            {cameFromArchive || article.isArchived
              ? "Arşiv'e Dön"
              : "Blog'a Dön"}
          </span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => void handleToggleFavorite()}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
              article.isFavorite
                ? 'border-amber-300 bg-amber-50 text-amber-800'
                : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
            }`}
          >
            <Star
              className={`w-3.5 h-3.5 ${
                article.isFavorite ? 'fill-current text-amber-500' : ''
              }`}
              aria-hidden="true"
            />
            <span>
              {article.isFavorite ? 'Favorilerde' : 'Favoriye Ekle'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => void handleToggleRead()}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
              article.isRead
                ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
            }`}
          >
            <Check className="w-3.5 h-3.5" aria-hidden="true" />
            <span>
              {article.isRead ? 'Okundu' : 'Okundu Olarak İşaretle'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => void handleToggleArchive()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 transition-colors cursor-pointer whitespace-nowrap"
          >
            {article.isArchived ? (
              <>
                <ArchiveRestore className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Arşivden Çıkar (Restore)</span>
              </>
            ) : (
              <>
                <Archive className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Archive</span>
              </>
            )}
          </button>

          <a
            href={article.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors whitespace-nowrap"
          >
            <span>Orijinal Makaleyi Aç</span>
            <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
          </a>
        </div>
      </div>

      {/* Article Header */}
      <header className="space-y-4 max-w-[75ch]">
        <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
          <span className="font-semibold text-[#2563EB]">
            {article.sourceName}
          </span>
          {article.categories.length > 0 && (
            <>
              <span aria-hidden="true">·</span>
              <span className="font-medium text-[#09090B]">
                {article.categories.map((cat, idx) => (
                  <React.Fragment key={cat.id}>
                    {idx > 0 && ', '}
                    <button
                      type="button"
                      onClick={() => onSelectCategory(cat.id)}
                      className="hover:text-[#2563EB] hover:underline cursor-pointer"
                    >
                      {cat.name}
                    </button>
                  </React.Fragment>
                ))}
              </span>
            </>
          )}
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">
            {formatPublishedDate(article.publishedAt || article.fetchedAt)}
          </span>
          {article.isArchived && (
            <>
              <span aria-hidden="true">·</span>
              <span className="text-zinc-600 font-medium">Arşivde</span>
            </>
          )}
          {article.aiImportance && (
            <>
              <span aria-hidden="true">·</span>
              <span className="font-semibold text-[#09090B]">
                Önem: {article.aiImportance}
              </span>
            </>
          )}
        </div>

        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#09090B] leading-tight [text-wrap:balance]">
          {article.title}
        </h1>

        {article.author && (
          <p className="text-xs text-zinc-600">
            Yazar:{' '}
            <span className="font-semibold text-[#09090B]">
              {article.author}
            </span>
          </p>
        )}
      </header>

      {/* Article Cover Image (rendered only if RSS provided a valid image) */}
      {article.imageUrl && !imageFailed && (
        <div className="aspect-[16/9] w-full max-w-[820px] rounded-xl overflow-hidden border border-zinc-200 bg-zinc-100">
          <img
            src={article.imageUrl}
            alt={article.title}
            referrerPolicy="no-referrer"
            loading="lazy"
            decoding="async"
            onError={() => setImageFailed(true)}
            className="w-full h-full object-cover"
          />
        </div>
      )}

      {/* Turkish AI Summary & Key Technical Points */}
      {(article.aiSummaryTr || geminiConfigured) && (
        <section
          aria-label="Türkçe AI Özeti"
          className="rounded-xl bg-[#FAFAFA] border border-zinc-200 p-5 sm:p-6 space-y-4 max-w-[75ch]"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#09090B]">
              <Sparkles className="w-4 h-4 text-[#2563EB]" aria-hidden="true" />
              <span>Türkçe AI Özeti ve Teknik Önemli Noktalar</span>
            </div>

            {geminiConfigured && (
              <button
                type="button"
                disabled={summarizing}
                onClick={() => void handleSummarize()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-[#09090B] hover:border-[#2563EB] hover:text-[#2563EB] disabled:opacity-50 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                <span>
                  {summarizing
                    ? 'Özetleniyor...'
                    : article.aiSummaryTr
                      ? 'Özeti Yenile'
                      : 'Türkçe AI Özet Oluştur'}
                </span>
              </button>
            )}
          </div>

          {article.aiSummaryTr ? (
            <div className="space-y-4 text-sm text-zinc-700 leading-relaxed">
              <p>{article.aiSummaryTr}</p>

              {article.aiKeyPoints.length > 0 && (
                <div className="space-y-1.5">
                  <h2 className="text-xs font-semibold text-[#09090B]">
                    Teknik Önemli Noktalar
                  </h2>
                  <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm text-zinc-700">
                    {article.aiKeyPoints.map((pt, idx) => (
                      <li key={idx}>{pt}</li>
                    ))}
                  </ul>
                </div>
              )}

              {(article.aiTechnicalConcepts.length > 0 ||
                article.aiDomainRelevance.length > 0) && (
                <div className="pt-2 border-t border-zinc-200 flex flex-wrap gap-x-6 gap-y-1.5 text-xs text-zinc-600">
                  {article.aiTechnicalConcepts.length > 0 && (
                    <span>
                      <strong className="font-semibold text-[#09090B]">
                        Kavramlar:
                      </strong>{' '}
                      {article.aiTechnicalConcepts.join(', ')}
                    </span>
                  )}
                  {article.aiDomainRelevance.length > 0 && (
                    <span>
                      <strong className="font-semibold text-[#09090B]">
                        İlgili Alanlar:
                      </strong>{' '}
                      {article.aiDomainRelevance.join(', ')}
                    </span>
                  )}
                </div>
              )}
            </div>
          ) : (
            <p className="text-xs text-zinc-500">
              Bu makale için henüz Türkçe AI özeti oluşturulmadı. İsterseniz
              yukarıdaki butonla sunucu üzerinden özet üretebilirsiniz.
            </p>
          )}
        </section>
      )}

      {/* Safe Content Preview / RSS Excerpt */}
      <section aria-label="Makale içeriği" className="space-y-4 max-w-[70ch]">
        <h2 className="font-display text-sm font-semibold text-[#09090B]">
          İçerik Önizlemesi
        </h2>
        {previewParagraphs.length > 0 ? (
          <div className="space-y-4">
            {previewParagraphs.map((para, idx) => (
              <p
                key={idx}
                className="text-sm sm:text-[15px] text-zinc-700 leading-[1.75]"
              >
                {para}
              </p>
            ))}
          </div>
        ) : (
          <p className="text-sm text-zinc-500">
            Bu RSS kaynağında tam içerik metni paylaşılmamış; orijinal makaleyi
            açarak tam metni okuyabilirsiniz.
          </p>
        )}

        <div className="pt-3 flex flex-wrap items-center justify-between gap-3 border-t border-zinc-100">
          <a
            href={article.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-[#09090B] hover:bg-zinc-800 text-white transition-colors"
          >
            <span>Tam Makaleyi Kaynağında Oku ({article.sourceName})</span>
            <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
          </a>

          {article.tags.length > 0 && (
            <div className="text-[11px] font-mono text-zinc-500">
              Etiketler: {article.tags.join(' · ')}
            </div>
          )}
        </div>
      </section>

      {/* Personal Notes */}
      <section className="pt-6 border-t border-zinc-200 space-y-2.5 max-w-[70ch]">
        <label
          htmlFor="article-personal-note"
          className="block text-xs font-semibold text-[#09090B]"
        >
          Kişisel Notlar
        </label>
        <textarea
          id="article-personal-note"
          rows={3}
          value={noteDraft}
          onChange={(e) => {
            setNoteDraft(e.target.value);
            setNoteSavedFeedback(false);
          }}
          placeholder="Bu makale hakkında teknik notlarınızı buraya kaydedin..."
          className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-zinc-200 bg-[#FAFAFA] focus:bg-white focus:outline-none focus:border-[#2563EB]"
        />
        <div className="flex items-center justify-between gap-3">
          <span className="text-[11px] text-emerald-700">
            {noteSavedFeedback ? 'Not sunucuya kaydedildi.' : ''}
          </span>
          <button
            type="button"
            disabled={savingNote}
            onClick={() => void handleSaveNote()}
            className="px-4 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white hover:bg-zinc-50 text-[#09090B] cursor-pointer"
          >
            {savingNote ? 'Kaydediliyor...' : 'Notu Kaydet'}
          </button>
        </div>
      </section>

      {/* Related / Similar Articles */}
      {similarArticles.length > 0 && (
        <section className="pt-6 border-t border-zinc-200 space-y-3">
          <h2 className="font-display text-sm font-semibold text-[#09090B]">
            Benzer Makaleler
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {similarArticles.map((sim) => (
              <button
                key={sim.id}
                type="button"
                onClick={() => onOpenArticle(sim.id)}
                className="text-left p-4 rounded-xl border border-zinc-200 bg-[#FAFAFA] hover:bg-white hover:border-[#2563EB]/50 transition-colors cursor-pointer flex items-center justify-between gap-3"
              >
                <div className="min-w-0 space-y-1">
                  <p className="text-xs font-semibold text-[#09090B] line-clamp-1">
                    {sim.title}
                  </p>
                  <p className="text-[11px] text-zinc-500">
                    {sim.sourceName} · {formatPublishedDate(sim.publishedAt)}
                  </p>
                </div>
                <ArrowRight
                  className="w-3.5 h-3.5 text-zinc-400 shrink-0"
                  aria-hidden="true"
                />
              </button>
            ))}
          </div>
        </section>
      )}
    </article>
  );
};
