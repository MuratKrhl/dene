import React, { useMemo, useState } from 'react';
import {
  Archive,
  ArrowUpRight,
  Check,
  CheckCircle2,
  RefreshCw,
  Search,
  Star,
  Trash2,
} from 'lucide-react';
import {
  AggregatedArticle,
  ARTICLE_RETENTION_DAYS,
} from '../../types/article';
import {
  AggregationSyncConfig,
  AggregationSyncSummary,
  ArticleSource,
} from '../../types/articleSource';
import {
  deleteAggregatedArticleById,
  formatArticlePublishedDate,
  formatArticleSyncTimestamp,
  saveAggregationConfig,
  setAggregatedArticleRead,
  setArticleSourceEnabled,
  syncAllArticleSources,
  syncSingleArticleSource,
  toggleAggregatedArticleFavorite,
} from '../../services/articles/articleAggregator';
import { ResilientImage } from '../ResilientImage';

interface TechnologyArticlesTabProps {
  articles: AggregatedArticle[];
  sources: ArticleSource[];
  syncSummary: AggregationSyncSummary | null;
  syncConfig: AggregationSyncConfig;
  onArticlesUpdated: () => void;
  onNavigate: (path: string) => void;
}

type ArticlesSubTab =
  | 'discover'
  | 'latest'
  | 'featured'
  | 'saved'
  | 'archive'
  | 'sources'
  | 'settings'
  | 'sync-history';

const SUB_TABS: Array<{ key: ArticlesSubTab; label: string }> = [
  { key: 'discover', label: 'Discover' },
  { key: 'latest', label: 'Latest (30d)' },
  { key: 'featured', label: 'Featured' },
  { key: 'saved', label: 'Saved' },
  { key: 'archive', label: 'Archive' },
  { key: 'sources', label: 'Sources' },
  { key: 'settings', label: 'Settings' },
  { key: 'sync-history', label: 'Sync History' },
];

const PAGE_SIZE = 18;

export const TechnologyArticlesTab: React.FC<TechnologyArticlesTabProps> = ({
  articles,
  sources,
  syncSummary,
  syncConfig,
  onArticlesUpdated,
  onNavigate,
}) => {
  const [subTab, setSubTab] = useState<ArticlesSubTab>('discover');
  const [search, setSearch] = useState('');
  const [sourceFilter, setSourceFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [tagFilter, setTagFilter] = useState('all');
  const [authorFilter, setAuthorFilter] = useState('all');
  const [readFilter, setReadFilter] = useState<'all' | 'unread' | 'read'>('all');
  const [favoriteOnly, setFavoriteOnly] = useState(false);
  const [dateFrom, setDateFrom] = useState('');
  const [page, setPage] = useState(1);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncingSourceId, setSyncingSourceId] = useState<string | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const uniqueAuthors = useMemo(() => {
    const set = new Set<string>();
    for (const a of articles) {
      if (a.author) set.add(a.author);
    }
    return Array.from(set).sort().slice(0, 60);
  }, [articles]);

  const uniqueCategories = useMemo(() => {
    const set = new Set<string>();
    for (const a of articles) {
      for (const c of a.categories) set.add(c);
    }
    return Array.from(set).sort();
  }, [articles]);

  const uniqueTags = useMemo(() => {
    const set = new Set<string>();
    for (const a of articles) {
      for (const t of a.tags) set.add(t);
    }
    return Array.from(set).sort().slice(0, 80);
  }, [articles]);

  const filteredArticles = useMemo(() => {
    const q = search.trim().toLowerCase();
    const fromMs = dateFrom ? Date.parse(dateFrom) : NaN;

    return articles
      .filter((art) => {
        if (subTab === 'latest' && art.isArchived) return false;
        if (subTab === 'discover' && art.isArchived) return false;
        if (subTab === 'archive' && !art.isArchived) return false;
        if (subTab === 'saved' && !art.isFavorite) return false;
        if (subTab === 'featured' && !art.featured && !art.isFavorite) {
          // Featured prefers security advisories & multi-tag or high-priority releases
          if (art.contentType !== 'security-advisory' && art.matchedSourceIds.length < 2) {
            return false;
          }
        }
        if (sourceFilter !== 'all' && art.sourceId !== sourceFilter && !art.matchedSourceIds.includes(sourceFilter)) {
          return false;
        }
        if (
          categoryFilter !== 'all' &&
          art.category !== categoryFilter &&
          !art.categories.includes(categoryFilter)
        ) {
          return false;
        }
        if (tagFilter !== 'all' && !art.tags.includes(tagFilter)) return false;
        if (authorFilter !== 'all' && art.author !== authorFilter) return false;
        if (readFilter === 'unread' && art.isRead) return false;
        if (readFilter === 'read' && !art.isRead) return false;
        if (favoriteOnly && !art.isFavorite) return false;
        if (!Number.isNaN(fromMs)) {
          const artMs = Date.parse(art.publishedAt || art.fetchedAt);
          if (Number.isNaN(artMs) || artMs < fromMs) return false;
        }
        if (q) {
          const hay = [
            art.title,
            art.summary,
            art.author || '',
            art.sourceName,
            ...art.tags,
            ...art.categories,
          ]
            .join(' ')
            .toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort(
        (a, b) =>
          Date.parse(b.publishedAt || b.fetchedAt) -
          Date.parse(a.publishedAt || a.fetchedAt)
      );
  }, [
    articles,
    authorFilter,
    categoryFilter,
    dateFrom,
    favoriteOnly,
    readFilter,
    search,
    sourceFilter,
    subTab,
    tagFilter,
  ]);

  const totalPages = Math.max(1, Math.ceil(filteredArticles.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pagedArticles = filteredArticles.slice(
    (safePage - 1) * PAGE_SIZE,
    safePage * PAGE_SIZE
  );

  const handleSyncAll = async () => {
    setIsSyncing(true);
    try {
      await syncAllArticleSources();
      onArticlesUpdated();
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSyncOne = async (sourceId: string) => {
    setSyncingSourceId(sourceId);
    try {
      await syncSingleArticleSource(sourceId);
      onArticlesUpdated();
    } finally {
      setSyncingSourceId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 pb-3">
        <div className="flex flex-wrap items-center gap-1">
          {SUB_TABS.map((t) => {
            const active = subTab === t.key;
            return (
              <button
                key={t.key}
                type="button"
                onClick={() => {
                  setSubTab(t.key);
                  setPage(1);
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-[#09090B] text-white'
                    : 'text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100'
                }`}
              >
                {t.label}
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={handleSyncAll}
          disabled={isSyncing}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-[#09090B] hover:bg-zinc-50 disabled:opacity-50 cursor-pointer whitespace-nowrap shrink-0"
        >
          <RefreshCw
            className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`}
            aria-hidden="true"
          />
          <span>{isSyncing ? 'Syncing Feeds...' : 'Refresh Articles'}</span>
        </button>
      </div>

      {/* Sources / Settings / Sync History Views */}
      {subTab === 'sources' && (
        <div className="rounded-xl bg-white border border-zinc-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-zinc-100 flex items-center justify-between">
            <div>
              <h3 className="font-display text-sm font-semibold text-[#09090B]">
                Article RSS &amp; Atom Sources ({sources.length})
              </h3>
              <p className="text-xs text-zinc-500">
                Shared live with Knowledge Hub Blog. Medium RSS and official blogs remain preserved.
              </p>
            </div>
          </div>
          <div className="divide-y divide-zinc-100">
            {sources.map((src) => (
              <div
                key={src.id}
                className="px-5 py-3 flex flex-wrap items-center justify-between gap-4"
              >
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium text-[#09090B]">
                      {src.name}
                    </span>
                    <span className="text-[11px] text-zinc-500">
                      {src.sourceGroup} · {src.sourceType.toUpperCase()} ·{' '}
                      {src.status === 'unsupported'
                        ? 'Unsupported (No Official Feed)'
                        : src.status}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-500 truncate">
                    {src.errorMessage || src.feedUrl || src.websiteUrl}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {src.sourceType !== 'unsupported' && (
                    <>
                      <button
                        type="button"
                        onClick={async () => {
                          await setArticleSourceEnabled(src.id, !src.enabled);
                          onArticlesUpdated();
                        }}
                        className={`px-2.5 py-1 text-xs font-medium rounded border cursor-pointer ${
                          src.enabled
                            ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                            : 'border-zinc-200 bg-zinc-50 text-zinc-600'
                        }`}
                      >
                        {src.enabled ? 'Enabled' : 'Disabled'}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSyncOne(src.id)}
                        disabled={syncingSourceId === src.id}
                        className="px-2.5 py-1 text-xs font-medium rounded border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                      >
                        {syncingSourceId === src.id ? 'Syncing...' : 'Sync'}
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {subTab === 'settings' && (
        <div className="rounded-xl bg-white border border-zinc-200 p-5 space-y-4">
          <h3 className="font-display text-sm font-semibold text-[#09090B]">
            Article Collection Settings
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label className="flex items-center justify-between p-3 rounded-lg border border-zinc-200">
              <span className="text-xs font-medium text-[#09090B]">
                Automatic Sync (Default 3h)
              </span>
              <input
                type="checkbox"
                checked={syncConfig.autoSyncEnabled}
                onChange={async (e) => {
                  await saveAggregationConfig({
                    ...syncConfig,
                    autoSyncEnabled: e.target.checked,
                  });
                  onArticlesUpdated();
                }}
              />
            </label>
            <div className="p-3 rounded-lg border border-zinc-200 flex items-center justify-between">
              <span className="text-xs font-medium text-[#09090B]">
                Sync Interval
              </span>
              <select
                value={syncConfig.autoSyncIntervalHours}
                onChange={async (e) => {
                  await saveAggregationConfig({
                    ...syncConfig,
                    autoSyncIntervalHours: Number(e.target.value) as 1 | 3 | 6 | 12 | 24,
                  });
                  onArticlesUpdated();
                }}
                className="text-xs border border-zinc-200 rounded px-2 py-1 bg-white"
              >
                {[1, 3, 6, 12, 24].map((h) => (
                  <option key={h} value={h}>
                    Every {h}h
                  </option>
                ))}
              </select>
            </div>
          </div>
          <p className="text-xs text-zinc-500">
            Active retention window: {ARTICLE_RETENTION_DAYS} days. Articles older than {ARTICLE_RETENTION_DAYS} days move automatically to Archive and are never deleted.
          </p>
        </div>
      )}

      {subTab === 'sync-history' && (
        <div className="rounded-xl bg-white border border-zinc-200 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-sm font-semibold text-[#09090B]">
              Latest Article Feed Sync Summary
            </h3>
            <span className="text-xs font-mono text-zinc-500">
              {formatArticleSyncTimestamp(syncSummary?.syncedAt || null)}
            </span>
          </div>
          {!syncSummary ? (
            <p className="text-xs text-zinc-500">
              No sync summary recorded yet. Click Refresh Articles above.
            </p>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-zinc-700">{syncSummary.message}</p>
              <div className="divide-y divide-zinc-100 border border-zinc-200 rounded-lg">
                {syncSummary.reports.map((r) => (
                  <div
                    key={r.sourceId}
                    className="px-3 py-2 flex items-center justify-between text-xs gap-2"
                  >
                    <span className="font-medium text-[#09090B]">
                      {r.sourceName}
                    </span>
                    <span className="font-mono tabular-nums text-zinc-500">
                      {r.unsupported
                        ? 'Unsupported'
                        : r.ok
                          ? `${r.fetchedCount} fetched · ${r.newCount} new · ${r.duplicatesSkipped} skipped`
                          : `Error: ${r.errorMessage}`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Article Filters & Cards */}
      {subTab !== 'sources' &&
        subTab !== 'settings' &&
        subTab !== 'sync-history' && (
          <>
            <div className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="relative">
                  <Search
                    className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2"
                    aria-hidden="true"
                  />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => {
                      setSearch(e.target.value);
                      setPage(1);
                    }}
                    placeholder="Search title, author, source, tags..."
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white focus:outline-none focus:border-[#2563EB]"
                  />
                </div>

                <select
                  aria-label="Filter by source"
                  value={sourceFilter}
                  onChange={(e) => {
                    setSourceFilter(e.target.value);
                    setPage(1);
                  }}
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
                >
                  <option value="all">All Sources</option>
                  {sources.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>

                <select
                  aria-label="Filter by category"
                  value={categoryFilter}
                  onChange={(e) => {
                    setCategoryFilter(e.target.value);
                    setPage(1);
                  }}
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
                >
                  <option value="all">All Categories</option>
                  {uniqueCategories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>

                <select
                  aria-label="Filter by tag"
                  value={tagFilter}
                  onChange={(e) => {
                    setTagFilter(e.target.value);
                    setPage(1);
                  }}
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
                >
                  <option value="all">All Tags</option>
                  {uniqueTags.map((t) => (
                    <option key={t} value={t}>
                      #{t}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex flex-wrap items-center gap-3 text-xs">
                <select
                  aria-label="Filter by author"
                  value={authorFilter}
                  onChange={(e) => {
                    setAuthorFilter(e.target.value);
                    setPage(1);
                  }}
                  className="px-3 py-1.5 rounded-lg border border-zinc-200 bg-white"
                >
                  <option value="all">All Authors</option>
                  {uniqueAuthors.map((au) => (
                    <option key={au} value={au}>
                      {au}
                    </option>
                  ))}
                </select>

                <select
                  aria-label="Filter by read status"
                  value={readFilter}
                  onChange={(e) => {
                    setReadFilter(e.target.value as 'all' | 'unread' | 'read');
                    setPage(1);
                  }}
                  className="px-3 py-1.5 rounded-lg border border-zinc-200 bg-white"
                >
                  <option value="all">Read &amp; Unread</option>
                  <option value="unread">Unread Only</option>
                  <option value="read">Read Only</option>
                </select>

                <input
                  type="date"
                  aria-label="Published after date"
                  value={dateFrom}
                  onChange={(e) => {
                    setDateFrom(e.target.value);
                    setPage(1);
                  }}
                  className="px-3 py-1.5 rounded-lg border border-zinc-200 bg-white"
                />

                <button
                  type="button"
                  onClick={() => {
                    setFavoriteOnly((p) => !p);
                    setPage(1);
                  }}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border cursor-pointer ${
                    favoriteOnly
                      ? 'border-amber-300 bg-amber-50 text-amber-800'
                      : 'border-zinc-200 bg-white text-zinc-700'
                  }`}
                >
                  <Star className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Favorites Only</span>
                </button>

                <span className="ml-auto font-mono tabular-nums text-zinc-500">
                  {filteredArticles.length} articles
                </span>
              </div>
            </div>

            {pagedArticles.length === 0 ? (
              <div className="rounded-xl bg-white border border-zinc-200 p-8 text-center space-y-2">
                <p className="text-sm font-medium text-[#09090B]">
                  No articles match your current filters.
                </p>
                <p className="text-xs text-zinc-500">
                  Adjust filters or click Refresh Articles to pull latest RSS/Atom posts.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {pagedArticles.map((art) => (
                  <article
                    key={art.id}
                    className="rounded-xl bg-white border border-zinc-200 overflow-hidden flex flex-col"
                  >
                    <div className="h-40 bg-zinc-100 overflow-hidden">
                      <ResilientImage
                        src={art.imageUrl || undefined}
                        alt={art.title}
                        fallbackTitle={art.sourceName}
                      />
                    </div>
                    <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                      <div className="space-y-1.5">
                        <p className="text-[11px] text-zinc-500 flex items-center gap-1.5 flex-wrap">
                          <span className="font-medium text-[#2563EB]">
                            {art.sourceName}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{art.category}</span>
                          {art.isArchived && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-amber-700 font-medium">
                                Archived
                              </span>
                            </>
                          )}
                        </p>
                        <button
                          type="button"
                          onClick={() =>
                            onNavigate(`/journal/${encodeURIComponent(art.id)}`)
                          }
                          className="text-left font-display text-base font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-2 cursor-pointer"
                        >
                          {art.title}
                        </button>
                        {art.summary && (
                          <p className="text-xs text-zinc-600 line-clamp-2">
                            {art.summary}
                          </p>
                        )}
                      </div>

                      <div className="pt-3 border-t border-zinc-100 flex items-center justify-between gap-2 text-xs text-zinc-500">
                        <span className="truncate font-mono tabular-nums text-[11px]">
                          {art.author ? `${art.author} · ` : ''}
                          {formatArticlePublishedDate(art.publishedAt)}
                        </span>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={async () => {
                              await setAggregatedArticleRead(art.id, !art.isRead);
                              onArticlesUpdated();
                            }}
                            aria-label={art.isRead ? 'Mark unread' : 'Mark read'}
                            className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                              art.isRead ? 'text-emerald-600' : 'text-zinc-400'
                            }`}
                          >
                            {art.isRead ? (
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            ) : (
                              <Check className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              await toggleAggregatedArticleFavorite(art.id);
                              onArticlesUpdated();
                            }}
                            aria-label="Toggle favorite"
                            className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                              art.isFavorite ? 'text-amber-500' : 'text-zinc-400'
                            }`}
                          >
                            <Star
                              className="w-3.5 h-3.5"
                              fill={art.isFavorite ? 'currentColor' : 'none'}
                            />
                          </button>
                          {pendingDeleteId === art.id ? (
                            <button
                              type="button"
                              onClick={async () => {
                                await deleteAggregatedArticleById(art.id);
                                setPendingDeleteId(null);
                                onArticlesUpdated();
                              }}
                              className="px-2 py-0.5 text-[11px] font-medium bg-red-600 text-white rounded cursor-pointer"
                            >
                              Confirm
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setPendingDeleteId(art.id)}
                              aria-label="Delete article"
                              className="p-1.5 rounded hover:bg-zinc-100 text-zinc-400 hover:text-red-600 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <a
                            href={art.articleUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            aria-label="Open original article"
                            className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500 hover:text-[#2563EB]"
                          >
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            )}

            {totalPages > 1 && (
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  disabled={safePage <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  className="px-3 py-1.5 text-xs font-medium rounded border border-zinc-200 bg-white disabled:opacity-40 cursor-pointer"
                >
                  Previous
                </button>
                <span className="text-xs font-mono tabular-nums text-zinc-500">
                  Page {safePage} / {totalPages}
                </span>
                <button
                  type="button"
                  disabled={safePage >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  className="px-3 py-1.5 text-xs font-medium rounded border border-zinc-200 bg-white disabled:opacity-40 cursor-pointer"
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
    </div>
  );
};
