import React, { useEffect, useState } from 'react';
import { BookOpen } from 'lucide-react';

interface ArticleCoverMediaProps {
  imageUrl?: string | null;
  title: string;
  sourceName: string;
  categoryLabel?: string;
  className?: string;
}

const DOMAIN_ACCENTS: Record<string, string> = {
  Kubernetes: 'from-blue-50 via-zinc-50 to-slate-100 text-blue-700',
  OpenShift: 'from-red-50 via-zinc-50 to-slate-100 text-red-700',
  Security: 'from-amber-50 via-zinc-50 to-slate-100 text-amber-800',
  AWS: 'from-orange-50 via-zinc-50 to-slate-100 text-orange-800',
  Cloudflare: 'from-amber-50 via-stone-50 to-zinc-100 text-amber-700',
  AI: 'from-indigo-50 via-zinc-50 to-slate-100 text-indigo-700',
  Java: 'from-rose-50 via-zinc-50 to-slate-100 text-rose-700',
  GitHub: 'from-zinc-100 via-slate-50 to-zinc-200/70 text-zinc-800',
  Istio: 'from-sky-50 via-zinc-50 to-slate-100 text-sky-700',
  Elasticsearch: 'from-teal-50 via-zinc-50 to-slate-100 text-teal-800',
  DevOps: 'from-emerald-50 via-zinc-50 to-slate-100 text-emerald-800',
  Nginx: 'from-emerald-50 via-zinc-50 to-slate-100 text-emerald-700',
  Jenkins: 'from-slate-100 via-zinc-50 to-stone-100 text-slate-700',
};

export const ArticleCoverMedia: React.FC<ArticleCoverMediaProps> = ({
  imageUrl,
  title,
  sourceName,
  categoryLabel = 'Engineering',
  className = '',
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setImgFailed(false);
  }, [imageUrl]);

  if (imageUrl && !imgFailed) {
    return (
      <div
        className={`relative w-full h-full overflow-hidden bg-zinc-100 ${className}`}
      >
        <img
          src={imageUrl}
          alt={title}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
        />
      </div>
    );
  }

  const gradientClass =
    DOMAIN_ACCENTS[categoryLabel] ||
    'from-zinc-100 via-[#FAFAFA] to-slate-100 text-zinc-700';

  return (
    <div
      className={`relative w-full h-full overflow-hidden bg-gradient-to-br ${gradientClass} p-5 flex flex-col justify-between select-none ${className}`}
      role="img"
      aria-label={title}
    >
      <div
        aria-hidden="true"
        className="absolute inset-0 opacity-[0.22]"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(24,24,27,0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(24,24,27,0.08) 1px, transparent 1px)',
          backgroundSize: '24px 24px',
        }}
      />

      <div className="relative flex items-center justify-between gap-2 text-[11px] font-mono">
        <span className="font-semibold truncate">{categoryLabel}</span>
        <BookOpen className="w-4 h-4 opacity-60 shrink-0" aria-hidden="true" />
      </div>

      <div className="relative space-y-1">
        <p className="font-display text-sm font-semibold text-[#09090B] line-clamp-2 leading-snug">
          {title}
        </p>
        <p className="text-[11px] text-zinc-500 truncate">{sourceName}</p>
      </div>
    </div>
  );
};
