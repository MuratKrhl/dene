import React, { useMemo, useState } from 'react';
import {
  Archive,
  Check,
  CheckCircle2,
  ChevronLeft,
  ExternalLink,
  Headphones,
  Heart,
  Pause,
  Play,
  RefreshCw,
  Search,
  Star,
  Trash2,
} from 'lucide-react';
import { usePodcastPlayer } from '../../context/PodcastPlayerContext';
import {
  PodcastEpisode,
  PodcastSeries,
  TechSettings,
} from '../../types/technology';
import {
  MediaSourceDto,
  MediaSyncHistoryDto,
  deleteMediaPodcastEpisode,
  patchMediaPodcastEpisode,
  patchMediaPodcastSeries,
  syncMediaByTypeApi,
  syncSingleMediaSourceApi,
  updateMediaSource,
} from '../../services/techMediaApi';
import {
  formatTechDate,
  formatTechTimestamp,
} from '../../services/technology/retentionEngine';
import { ResilientImage } from '../ResilientImage';

interface TechnologyPodcastsTabProps {
  series: PodcastSeries[];
  episodes: PodcastEpisode[];
  sources: MediaSourceDto[];
  syncHistory: MediaSyncHistoryDto[];
  settings: TechSettings;
  selectedSeriesId: string | null;
  onSelectSeries: (seriesId: string | null) => void;
  onDataChanged: () => Promise<void> | void;
}

type PodcastSubTab =
  | 'discover'
  | 'all-podcasts'
  | 'episodes'
  | 'following'
  | 'continue-listening'
  | 'saved'
  | 'archive'
  | 'sources'
  | 'settings'
  | 'sync-history';

const SUB_TABS: Array<{ key: PodcastSubTab; label: string }> = [
  { key: 'discover', label: 'Discover' },
  { key: 'all-podcasts', label: 'All Podcasts' },
  { key: 'episodes', label: 'Episodes' },
  { key: 'following', label: 'Following' },
  { key: 'continue-listening', label: 'Continue Listening' },
  { key: 'saved', label: 'Saved' },
  { key: 'archive', label: 'Archive' },
  { key: 'sources', label: 'Sources' },
  { key: 'settings', label: 'Settings' },
  { key: 'sync-history', label: 'Sync History' },
];

export const TechnologyPodcastsTab: React.FC<TechnologyPodcastsTabProps> = ({
  series,
  episodes,
  sources,
  syncHistory,
  settings,
  selectedSeriesId,
  onSelectSeries,
  onDataChanged,
}) => {
  const { currentEpisode, isPlaying, playEpisode, togglePlayPause } =
    usePodcastPlayer();

  const [subTab, setSubTab] = useState<PodcastSubTab>('discover');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncingId, setSyncingId] = useState<string | null>(null);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const podcastSources = useMemo(
    () => sources.filter((s) => s.contentType === 'podcast'),
    [sources]
  );

  const podcastHistory = useMemo(
    () => syncHistory.filter((h) => h.contentType === 'podcast'),
    [syncHistory]
  );

  const categories = useMemo(
    () => Array.from(new Set(series.map((s) => s.category))).sort(),
    [series]
  );

  const activeSeriesDetail = useMemo(
    () => series.find((s) => s.id === selectedSeriesId) || null,
    [selectedSeriesId, series]
  );

  const seriesEpisodes = useMemo(() => {
    if (!activeSeriesDetail) return [];
    const q = search.trim().toLowerCase();
    return episodes
      .filter((e) => e.seriesId === activeSeriesDetail.id)
      .filter((e) => {
        if (!q) return true;
        return (
          e.title.toLowerCase().includes(q) ||
          e.description.toLowerCase().includes(q)
        );
      })
      .sort(
        (a, b) =>
          Date.parse(b.publishedAt || b.fetchedAt) -
          Date.parse(a.publishedAt || a.fetchedAt)
      );
  }, [activeSeriesDetail, episodes, search]);

  const activeEpisodes = useMemo(
    () =>
      episodes
        .filter((e) => !e.isArchived)
        .sort(
          (a, b) =>
            Date.parse(b.publishedAt || b.fetchedAt) -
            Date.parse(a.publishedAt || a.fetchedAt)
        ),
    [episodes]
  );

  const continueListening = useMemo(
    () =>
      episodes
        .filter((e) => e.playbackPosition > 5 && !e.isPlayed)
        .sort(
          (a, b) =>
            Date.parse(b.publishedAt || b.fetchedAt) -
            Date.parse(a.publishedAt || a.fetchedAt)
        ),
    [episodes]
  );

  const featuredEpisode = activeEpisodes[0] || null;
  const featuredSeries = useMemo(
    () =>
      featuredEpisode
        ? series.find((s) => s.id === featuredEpisode.seriesId) ||
          series[0] ||
          null
        : series[0] || null,
    [featuredEpisode, series]
  );

  const filteredSeries = useMemo(() => {
    const q = search.trim().toLowerCase();
    return series.filter((s) => {
      if (subTab === 'following' && !s.isFollowed) return false;
      if (categoryFilter !== 'all' && s.category !== categoryFilter) return false;
      if (q) {
        const hay = [s.title, s.description, s.publisher || '', s.category]
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [categoryFilter, search, series, subTab]);

  const filteredEpisodes = useMemo(() => {
    const q = search.trim().toLowerCase();
    return episodes
      .filter((ep) => {
        if (subTab === 'episodes' && ep.isArchived) return false;
        if (subTab === 'saved' && !ep.isFavorite) return false;
        if (subTab === 'archive' && !ep.isArchived) return false;
        if (subTab === 'continue-listening') {
          if (ep.playbackPosition <= 0 || ep.isPlayed) return false;
        }
        if (categoryFilter !== 'all' && ep.category !== categoryFilter)
          return false;
        if (q) {
          const hay = [ep.title, ep.description, ep.seriesTitle, ep.category]
            .join(' ')
            .toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort(
        (a, b) =>
          Date.parse(b.publishedAt || b.fetchedAt) -
          Date.parse(a.publishedAt || a.fetchedAt)
      );
  }, [categoryFilter, episodes, search, subTab]);

  const handleSyncPodcasts = async () => {
    setIsSyncing(true);
    setStatusNotice(null);
    try {
      const outcome = await syncMediaByTypeApi('podcast');
      await onDataChanged();
      if (outcome.skippedDueToLock) {
        setStatusNotice('Podcast senkronizasyonu zaten çalışıyor.');
      } else {
        const newItems = outcome.results.reduce((s, r) => s + r.newItems, 0);
        setStatusNotice(
          `Podcast kaynakları senkronize edildi (${newItems} yeni bölüm).`
        );
      }
    } catch (err) {
      setStatusNotice(
        err instanceof Error ? err.message : 'Podcast senkronizasyonu başarısız.'
      );
    } finally {
      setIsSyncing(false);
    }
  };

  const renderEpisodePlayBtn = (ep: PodcastEpisode, list: PodcastEpisode[]) => {
    const isCurrent = currentEpisode?.id === ep.id;
    return (
      <button
        type="button"
        onClick={() => (isCurrent ? togglePlayPause() : playEpisode(ep, list))}
        aria-label={isCurrent && isPlaying ? `Pause ${ep.title}` : `Play ${ep.title}`}
        className="w-9 h-9 rounded-full bg-[#09090B] text-white flex items-center justify-center hover:bg-zinc-800 shrink-0 cursor-pointer transition-colors"
      >
        {isCurrent && isPlaying ? (
          <Pause className="w-4 h-4" />
        ) : (
          <Play className="w-4 h-4 ml-0.5" />
        )}
      </button>
    );
  };

  // SERIES DETAIL VIEW
  if (activeSeriesDetail) {
    return (
      <div className="space-y-6">
        <button
          type="button"
          onClick={() => onSelectSeries(null)}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-600 hover:text-[#09090B] cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Podcasts</span>
        </button>

        <div className="rounded-2xl bg-white border border-zinc-200 p-6 flex flex-col md:flex-row gap-6 items-start">
          <div className="w-40 h-40 rounded-xl overflow-hidden border border-zinc-200 shrink-0 bg-zinc-100">
            <ResilientImage
              src={activeSeriesDetail.artworkUrl || undefined}
              alt={activeSeriesDetail.title}
              fallbackTitle={activeSeriesDetail.title}
            />
          </div>

          <div className="flex-1 space-y-3 min-w-0">
            <div className="space-y-1">
              <p className="text-xs font-medium text-[#2563EB]">
                {activeSeriesDetail.category} ·{' '}
                {activeSeriesDetail.publisher ||
                  activeSeriesDetail.author ||
                  'Podcast'}
              </p>
              <h2 className="font-display text-2xl font-bold text-[#09090B]">
                {activeSeriesDetail.title}
              </h2>
            </div>

            {activeSeriesDetail.description && (
              <p className="text-sm text-zinc-600 leading-relaxed">
                {activeSeriesDetail.description}
              </p>
            )}

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={async () => {
                  await patchMediaPodcastSeries(activeSeriesDetail.id, {
                    isFollowed: !activeSeriesDetail.isFollowed,
                  });
                  await onDataChanged();
                }}
                className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg border cursor-pointer ${
                  activeSeriesDetail.isFollowed
                    ? 'bg-[#09090B] text-white border-[#09090B]'
                    : 'bg-white text-[#09090B] border-zinc-200 hover:bg-zinc-50'
                }`}
              >
                <Heart
                  className="w-3.5 h-3.5"
                  fill={activeSeriesDetail.isFollowed ? 'currentColor' : 'none'}
                />
                <span>
                  {activeSeriesDetail.isFollowed ? 'Following' : 'Follow Podcast'}
                </span>
              </button>

              <a
                href={activeSeriesDetail.websiteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 hover:bg-zinc-50 text-zinc-700"
              >
                <span>Website</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <span className="text-xs font-mono tabular-nums text-zinc-500">
                {seriesEpisodes.length} episodes indexed
              </span>
            </div>
          </div>
        </div>

        <div className="relative max-w-md">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search episodes in this podcast..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
          />
        </div>

        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
          {seriesEpisodes.map((ep) => (
            <div
              key={ep.id}
              className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-3 min-w-0 flex-1">
                {renderEpisodePlayBtn(ep, seriesEpisodes)}
                <div className="min-w-0 space-y-1">
                  <p className="text-sm font-semibold text-[#09090B]">
                    {ep.title}
                  </p>
                  <p className="text-xs text-zinc-500 flex items-center gap-2 flex-wrap font-mono tabular-nums">
                    <span>{formatTechDate(ep.publishedAt)}</span>
                    {ep.duration && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span>{ep.duration}</span>
                      </>
                    )}
                    {ep.playbackPosition > 0 && !ep.isPlayed && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-[#2563EB]">
                          Resume {Math.floor(ep.playbackPosition / 60)}m
                        </span>
                      </>
                    )}
                  </p>
                  {ep.description && (
                    <p className="text-xs text-zinc-600 line-clamp-2">
                      {ep.description}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={async () => {
                    await patchMediaPodcastEpisode(ep.id, {
                      isPlayed: !ep.isPlayed,
                    });
                    await onDataChanged();
                  }}
                  aria-label="Toggle played"
                  className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                    ep.isPlayed ? 'text-emerald-600' : 'text-zinc-400'
                  }`}
                >
                  {ep.isPlayed ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : (
                    <Check className="w-4 h-4" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await patchMediaPodcastEpisode(ep.id, {
                      isFavorite: !ep.isFavorite,
                    });
                    await onDataChanged();
                  }}
                  aria-label="Save episode"
                  className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                    ep.isFavorite ? 'text-amber-500' : 'text-zinc-400'
                  }`}
                >
                  <Star
                    className="w-4 h-4"
                    fill={ep.isFavorite ? 'currentColor' : 'none'}
                  />
                </button>
                <a
                  href={ep.episodeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Open original episode"
                  className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500 hover:text-[#2563EB]"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 pb-3">
        <div className="flex flex-wrap items-center gap-1">
          {SUB_TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setSubTab(t.key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                subTab === t.key
                  ? 'bg-[#09090B] text-white'
                  : 'text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={handleSyncPodcasts}
          disabled={isSyncing}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 disabled:opacity-50 cursor-pointer whitespace-nowrap"
        >
          <RefreshCw
            className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`}
            aria-hidden="true"
          />
          <span>{isSyncing ? 'Syncing Podcasts...' : 'Sync Podcasts'}</span>
        </button>
      </div>

      {statusNotice && (
        <div className="rounded-lg bg-zinc-50 border border-zinc-200 px-4 py-2.5 text-xs text-zinc-800 flex items-center justify-between">
          <span>{statusNotice}</span>
          <button
            type="button"
            onClick={() => setStatusNotice(null)}
            className="underline font-medium cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {(subTab === 'discover' ||
        subTab === 'all-podcasts' ||
        subTab === 'episodes' ||
        subTab === 'following' ||
        subTab === 'saved' ||
        subTab === 'archive') && (
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search podcasts, publishers, or episodes..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            />
          </div>

          <select
            aria-label="Filter podcasts by category"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
          >
            <option value="all">All Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      )}

      {subTab === 'discover' && (
        <div className="space-y-8">
          {series.length === 0 ? (
            <div className="rounded-xl bg-white border border-zinc-200 p-10 text-center space-y-3">
              <Headphones className="w-8 h-8 text-zinc-400 mx-auto" />
              <h3 className="font-display text-base font-semibold text-[#09090B]">
                No Podcast Shows Synced Yet
              </h3>
              <p className="text-xs text-zinc-500 max-w-md mx-auto">
                Click Sync Podcasts to fetch verified RSS 2.0 / Atom podcast feeds from the backend collector.
              </p>
              <button
                type="button"
                onClick={handleSyncPodcasts}
                className="px-4 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
              >
                Sync Podcast Feeds Now
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                {featuredSeries && featuredEpisode && (
                  <div className="lg:col-span-7 rounded-2xl bg-white border border-zinc-200 p-6 flex flex-col sm:flex-row gap-5 items-center sm:items-stretch">
                    <div className="w-40 h-40 sm:w-44 sm:h-44 rounded-xl overflow-hidden border border-zinc-200 shrink-0 bg-zinc-100">
                      <ResilientImage
                        src={
                          featuredEpisode.artworkUrl ||
                          featuredSeries.artworkUrl ||
                          undefined
                        }
                        alt={featuredSeries.title}
                        fallbackTitle={featuredSeries.title}
                      />
                    </div>
                    <div className="flex-1 flex flex-col justify-between gap-3 min-w-0">
                      <div className="space-y-1.5">
                        <p className="text-xs font-medium text-[#2563EB]">
                          Featured Podcast · {featuredSeries.category} ·{' '}
                          {featuredSeries.publisher || featuredSeries.author || 'Publisher'}
                        </p>
                        <h2 className="font-display text-xl font-bold text-[#09090B] line-clamp-2">
                          {featuredEpisode.title}
                        </h2>
                        <p className="text-xs text-zinc-500">
                          {featuredSeries.title} ·{' '}
                          {formatTechDate(featuredEpisode.publishedAt)}
                          {featuredEpisode.duration
                            ? ` · ${featuredEpisode.duration}`
                            : ''}
                        </p>
                        {featuredEpisode.description && (
                          <p className="text-xs text-zinc-600 line-clamp-2">
                            {featuredEpisode.description}
                          </p>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            playEpisode(featuredEpisode, activeEpisodes)
                          }
                          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5" />
                          <span>Listen Episode</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onSelectSeries(featuredSeries.id)}
                          className="px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                        >
                          Open Show
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="lg:col-span-5 rounded-2xl bg-white border border-zinc-200 p-5 flex flex-col justify-between space-y-3">
                  <div className="flex items-center justify-between border-b border-zinc-100 pb-2.5">
                    <h3 className="font-display text-sm font-semibold text-[#09090B]">
                      Continue Listening
                    </h3>
                    <button
                      type="button"
                      onClick={() => setSubTab('continue-listening')}
                      className="text-xs text-[#2563EB] hover:underline cursor-pointer"
                    >
                      View All
                    </button>
                  </div>
                  {continueListening.length === 0 ? (
                    <p className="text-xs text-zinc-500 my-auto py-4">
                      Start playing any episode to track playback progress across pages.
                    </p>
                  ) : (
                    <div className="space-y-2.5">
                      {continueListening.slice(0, 3).map((ep) => (
                        <div
                          key={ep.id}
                          className="flex items-center gap-3 p-2 rounded-lg border border-zinc-100 hover:border-zinc-200"
                        >
                          {renderEpisodePlayBtn(ep, continueListening)}
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-semibold text-[#09090B] truncate">
                              {ep.title}
                            </p>
                            <p className="text-[11px] text-zinc-500 font-mono tabular-nums">
                              {ep.seriesTitle} · Resumes at{' '}
                              {Math.floor(ep.playbackPosition / 60)}m
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <section className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-base font-semibold text-[#09090B]">
                    Podcast Series
                  </h3>
                  <button
                    type="button"
                    onClick={() => setSubTab('all-podcasts')}
                    className="text-xs text-[#2563EB] hover:underline cursor-pointer"
                  >
                    Browse All Shows ({series.length})
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredSeries.map((show) => {
                    const latestEp = episodes.find(
                      (e) => e.seriesId === show.id
                    );
                    return (
                      <div
                        key={show.id}
                        className="rounded-xl bg-white border border-zinc-200 p-4 flex flex-col justify-between gap-4 hover:border-zinc-300 transition-colors"
                      >
                        <div className="flex items-start gap-3.5">
                          <button
                            type="button"
                            onClick={() => onSelectSeries(show.id)}
                            className="w-20 h-20 rounded-xl overflow-hidden border border-zinc-200 shrink-0 bg-zinc-100 cursor-pointer"
                          >
                            <ResilientImage
                              src={show.artworkUrl || undefined}
                              alt={show.title}
                              fallbackTitle={show.title}
                            />
                          </button>
                          <div className="min-w-0 flex-1 space-y-1">
                            <p className="text-[11px] text-[#2563EB] font-medium">
                              {show.category}
                            </p>
                            <button
                              type="button"
                              onClick={() => onSelectSeries(show.id)}
                              className="text-left font-display text-sm font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-2 cursor-pointer"
                            >
                              {show.title}
                            </button>
                            <p className="text-[11px] text-zinc-500 truncate">
                              {show.publisher || show.author || 'Engineering'}
                              {show.episodeCount > 0
                                ? ` · ${show.episodeCount} episodes`
                                : ''}
                            </p>
                          </div>
                        </div>

                        {latestEp && (
                          <p className="text-xs text-zinc-600 line-clamp-1 border-t border-zinc-100 pt-2.5">
                            Latest: {latestEp.title}
                          </p>
                        )}

                        <div className="flex items-center justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => onSelectSeries(show.id)}
                            className="text-xs font-medium text-[#09090B] hover:text-[#2563EB] cursor-pointer"
                          >
                            View Episodes
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              await patchMediaPodcastSeries(show.id, {
                                isFollowed: !show.isFollowed,
                              });
                              await onDataChanged();
                            }}
                            className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded-md border cursor-pointer ${
                              show.isFollowed
                                ? 'bg-[#09090B] text-white border-[#09090B]'
                                : 'border-zinc-200 text-zinc-700 hover:bg-zinc-50'
                            }`}
                          >
                            <Heart
                              className="w-3 h-3"
                              fill={show.isFollowed ? 'currentColor' : 'none'}
                            />
                            <span>{show.isFollowed ? 'Following' : 'Follow'}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>

              <section className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-base font-semibold text-[#09090B]">
                    Latest Episodes
                  </h3>
                  <button
                    type="button"
                    onClick={() => setSubTab('episodes')}
                    className="text-xs text-[#2563EB] hover:underline cursor-pointer"
                  >
                    All Episodes ({activeEpisodes.length})
                  </button>
                </div>

                <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
                  {activeEpisodes.slice(0, 10).map((ep) => (
                    <div
                      key={ep.id}
                      className="p-3.5 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        {renderEpisodePlayBtn(ep, activeEpisodes)}
                        <div className="w-10 h-10 rounded-lg overflow-hidden border border-zinc-200 shrink-0 bg-zinc-100 hidden sm:block">
                          <ResilientImage
                            src={ep.artworkUrl || undefined}
                            alt={ep.seriesTitle}
                            fallbackTitle={ep.seriesTitle.slice(0, 2)}
                          />
                        </div>
                        <div className="min-w-0 space-y-0.5">
                          <p className="text-xs sm:text-sm font-medium text-[#09090B] truncate">
                            {ep.title}
                          </p>
                          <p className="text-[11px] text-zinc-500 truncate font-mono tabular-nums">
                            {ep.seriesTitle}
                            {ep.publisher ? ` (${ep.publisher})` : ''} ·{' '}
                            {formatTechDate(ep.publishedAt)}
                            {ep.duration ? ` · ${ep.duration}` : ''}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={async () => {
                            await patchMediaPodcastEpisode(ep.id, {
                              isFavorite: !ep.isFavorite,
                            });
                            await onDataChanged();
                          }}
                          aria-label="Favorite episode"
                          className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                            ep.isFavorite ? 'text-amber-500' : 'text-zinc-400'
                          }`}
                        >
                          <Star
                            className="w-4 h-4"
                            fill={ep.isFavorite ? 'currentColor' : 'none'}
                          />
                        </button>
                        <a
                          href={ep.episodeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label="Open original episode"
                          className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500 hover:text-[#2563EB]"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            </>
          )}
        </div>
      )}

      {(subTab === 'all-podcasts' || subTab === 'following') && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSeries.length === 0 ? (
            <p className="col-span-full text-sm text-zinc-500 bg-white rounded-xl border border-zinc-200 p-8 text-center">
              {subTab === 'following'
                ? 'You are not following any podcasts yet.'
                : 'No podcast shows match your filter.'}
            </p>
          ) : (
            filteredSeries.map((show) => (
              <div
                key={show.id}
                className="rounded-xl bg-white border border-zinc-200 p-4 flex items-start gap-3.5"
              >
                <button
                  type="button"
                  onClick={() => onSelectSeries(show.id)}
                  className="w-16 h-16 rounded-lg overflow-hidden border border-zinc-200 shrink-0 bg-zinc-100 cursor-pointer"
                >
                  <ResilientImage
                    src={show.artworkUrl || undefined}
                    alt={show.title}
                    fallbackTitle={show.title}
                  />
                </button>
                <div className="min-w-0 flex-1 space-y-1">
                  <button
                    type="button"
                    onClick={() => onSelectSeries(show.id)}
                    className="text-left font-display text-sm font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-1 cursor-pointer"
                  >
                    {show.title}
                  </button>
                  <p className="text-[11px] text-zinc-500 truncate">
                    {show.category} · {show.episodeCount} episodes
                  </p>
                  <button
                    type="button"
                    onClick={async () => {
                      await patchMediaPodcastSeries(show.id, {
                        isFollowed: !show.isFollowed,
                      });
                      await onDataChanged();
                    }}
                    className="text-xs font-medium text-[#2563EB] hover:underline cursor-pointer"
                  >
                    {show.isFollowed ? 'Unfollow' : 'Follow'}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {(subTab === 'episodes' ||
        subTab === 'continue-listening' ||
        subTab === 'saved' ||
        subTab === 'archive') && (
        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
          {filteredEpisodes.length === 0 ? (
            <p className="p-8 text-xs text-zinc-500 text-center">
              No podcast episodes found in this section.
            </p>
          ) : (
            filteredEpisodes.map((ep) => (
              <div
                key={ep.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {renderEpisodePlayBtn(ep, filteredEpisodes)}
                  <div className="min-w-0 space-y-0.5">
                    <p className="text-sm font-medium text-[#09090B] truncate">
                      {ep.title}
                    </p>
                    <p className="text-[11px] text-zinc-500 font-mono tabular-nums truncate">
                      {ep.seriesTitle}
                      {ep.publisher ? ` · ${ep.publisher}` : ''} ·{' '}
                      {formatTechDate(ep.publishedAt)}
                      {ep.duration ? ` · ${ep.duration}` : ''}
                      {ep.playbackPosition > 0
                        ? ` · ${Math.floor(ep.playbackPosition / 60)}m played`
                        : ''}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={async () => {
                      await patchMediaPodcastEpisode(ep.id, {
                        isPlayed: !ep.isPlayed,
                      });
                      await onDataChanged();
                    }}
                    aria-label="Toggle played"
                    className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                      ep.isPlayed ? 'text-emerald-600' : 'text-zinc-400'
                    }`}
                  >
                    {ep.isPlayed ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await patchMediaPodcastEpisode(ep.id, {
                        isFavorite: !ep.isFavorite,
                      });
                      await onDataChanged();
                    }}
                    aria-label="Favorite episode"
                    className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                      ep.isFavorite ? 'text-amber-500' : 'text-zinc-400'
                    }`}
                  >
                    <Star
                      className="w-4 h-4"
                      fill={ep.isFavorite ? 'currentColor' : 'none'}
                    />
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await patchMediaPodcastEpisode(ep.id, {
                        isArchived: !ep.isArchived,
                      });
                      await onDataChanged();
                    }}
                    aria-label="Archive episode"
                    className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                      ep.isArchived ? 'text-amber-600' : 'text-zinc-400'
                    }`}
                  >
                    <Archive className="w-4 h-4" />
                  </button>
                  {pendingDeleteId === ep.id ? (
                    <button
                      type="button"
                      onClick={async () => {
                        await deleteMediaPodcastEpisode(ep.id);
                        setPendingDeleteId(null);
                        await onDataChanged();
                      }}
                      className="px-2 py-0.5 text-[11px] bg-red-600 text-white rounded cursor-pointer"
                    >
                      Confirm
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setPendingDeleteId(ep.id)}
                      aria-label="Delete episode"
                      className="p-1.5 rounded hover:bg-zinc-100 text-zinc-400 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                  <a
                    href={ep.episodeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Open original episode"
                    className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500 hover:text-[#2563EB]"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {subTab === 'sources' && (
        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
          {podcastSources.map((src) => (
            <div
              key={src.id}
              className="px-5 py-3 flex flex-wrap items-center justify-between gap-4"
            >
              <div className="min-w-0 flex-1 space-y-0.5">
                <p className="text-sm font-medium text-[#09090B]">
                  {src.name}{' '}
                  <span className="text-xs font-normal text-zinc-500">
                    · {src.verificationStatus} · {src.collectedCount} episodes
                  </span>
                </p>
                <p className="text-xs text-zinc-500 truncate">
                  {src.lastError || src.feedOrEndpoint}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      await updateMediaSource(src.id, { enabled: !src.enabled });
                      await onDataChanged();
                    } catch (err) {
                      setStatusNotice(
                        err instanceof Error ? err.message : 'Durum güncellenemedi.'
                      );
                    }
                  }}
                  className={`px-2.5 py-1 text-xs rounded border cursor-pointer ${
                    src.enabled
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                      : 'border-zinc-200 bg-zinc-50 text-zinc-600'
                  }`}
                >
                  {src.enabled ? 'Enabled' : 'Disabled'}
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    setSyncingId(src.id);
                    try {
                      await syncSingleMediaSourceApi(src.id);
                      await onDataChanged();
                    } finally {
                      setSyncingId(null);
                    }
                  }}
                  className="px-2.5 py-1 text-xs rounded border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                >
                  {syncingId === src.id ? 'Syncing...' : 'Sync'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {subTab === 'settings' && (
        <div className="rounded-xl bg-white border border-zinc-200 p-5 space-y-2 text-xs text-zinc-600">
          <h3 className="font-display text-sm font-semibold text-[#09090B]">
            Podcast Backend RSS Collection &amp; Playback Persistence
          </h3>
          <p>
            All RSS 2.0, Atom, and Apple Podcasts Lookup resolution runs on the backend server. A podcast source cannot be activated until its RSS/Atom feed passes live validation.
          </p>
          <p>
            Audio streams directly from the publisher&apos;s enclosure URL without downloading or re-hosting audio files. Active window: {settings.activeWindowDays} days.
          </p>
        </div>
      )}

      {subTab === 'sync-history' && (
        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
          {podcastHistory.length === 0 ? (
            <p className="p-6 text-xs text-zinc-500 text-center">
              No podcast sync runs recorded yet.
            </p>
          ) : (
            podcastHistory.map((h) => (
              <div
                key={h.syncId}
                className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs"
              >
                <span className="font-medium text-[#09090B]">
                  {h.sourceName}
                </span>
                <span className="font-mono tabular-nums text-zinc-500">
                  {h.status} · {h.newItems} new · {h.duplicatesSkipped} dup ·{' '}
                  {formatTechTimestamp(h.finishedAt)}
                </span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
