import React from 'react';
import {
  ExternalLink,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { usePodcastPlayer } from '../../context/PodcastPlayerContext';
import { ResilientImage } from '../ResilientImage';

function formatClock(totalSeconds: number): string {
  if (!Number.isFinite(totalSeconds) || totalSeconds < 0) return '0:00';
  const rounded = Math.floor(totalSeconds);
  const h = Math.floor(rounded / 3600);
  const m = Math.floor((rounded % 3600) / 60);
  const s = rounded % 60;
  if (h > 0) {
    return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
  return `${m}:${String(s).padStart(2, '0')}`;
}

const PLAYBACK_RATES = [0.75, 1, 1.25, 1.5, 2];

export const PodcastMiniPlayer: React.FC = () => {
  const {
    currentEpisode,
    isPlaying,
    currentTime,
    duration,
    volume,
    playbackRate,
    audioError,
    togglePlayPause,
    seekTo,
    setVolume,
    setPlaybackRate,
    playNext,
    playPrevious,
    closePlayer,
  } = usePodcastPlayer();

  if (!currentEpisode) return null;

  const effectiveDuration =
    duration > 0 ? duration : currentEpisode.durationSeconds || 0;

  return (
    <aside
      aria-label="Persistent Podcast Audio Player"
      className="fixed bottom-0 inset-x-0 z-50 bg-white/95 backdrop-blur-md border-t border-zinc-200 shadow-sm"
    >
      {audioError && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-1.5 text-xs text-amber-900 flex items-center justify-between gap-3 max-w-[1440px] mx-auto">
          <span className="truncate">{audioError}</span>
          <a
            href={currentEpisode.episodeUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 font-medium text-[#2563EB] hover:underline whitespace-nowrap shrink-0"
          >
            <span>Open Original Episode</span>
            <ExternalLink className="w-3 h-3" aria-hidden="true" />
          </a>
        </div>
      )}

      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Left: Artwork + Episode Metadata */}
        <div className="flex items-center gap-3 min-w-0 flex-1 max-w-sm">
          <div className="w-10 h-10 rounded-lg overflow-hidden border border-zinc-200 shrink-0 bg-zinc-100">
            <ResilientImage
              src={currentEpisode.artworkUrl || undefined}
              alt={currentEpisode.seriesTitle}
              fallbackTitle={currentEpisode.seriesTitle.slice(0, 2)}
            />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[#09090B] truncate">
              {currentEpisode.title}
            </p>
            <p className="text-[11px] text-zinc-500 truncate">
              {currentEpisode.seriesTitle}
            </p>
          </div>
        </div>

        {/* Center: Transport & Seek */}
        <div className="flex flex-col items-center gap-1 flex-1 max-w-md">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={playPrevious}
              aria-label="Previous episode"
              className="p-1.5 rounded-md text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100 transition-colors cursor-pointer"
            >
              <SkipBack className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={togglePlayPause}
              aria-label={isPlaying ? 'Pause episode' : 'Play episode'}
              className="w-8 h-8 rounded-full bg-[#09090B] text-white flex items-center justify-center hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              {isPlaying ? (
                <Pause className="w-4 h-4" />
              ) : (
                <Play className="w-4 h-4 ml-0.5" />
              )}
            </button>
            <button
              type="button"
              onClick={playNext}
              aria-label="Next episode"
              className="p-1.5 rounded-md text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100 transition-colors cursor-pointer"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>

          <div className="w-full flex items-center gap-2 text-[11px] font-mono tabular-nums text-zinc-500">
            <span className="w-11 text-right shrink-0">
              {formatClock(currentTime)}
            </span>
            <input
              type="range"
              aria-label="Seek episode timeline"
              min={0}
              max={effectiveDuration > 0 ? effectiveDuration : 100}
              value={Math.min(
                currentTime,
                effectiveDuration > 0 ? effectiveDuration : 100
              )}
              disabled={effectiveDuration <= 0}
              onChange={(e) => seekTo(Number(e.target.value))}
              className="w-full h-1 accent-[#2563EB] cursor-pointer"
            />
            <span className="w-11 shrink-0">
              {effectiveDuration > 0
                ? formatClock(effectiveDuration)
                : currentEpisode.duration || '--:--'}
            </span>
          </div>
        </div>

        {/* Right: Speed, Volume, Open Link, Close */}
        <div className="hidden md:flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => {
              const idx = PLAYBACK_RATES.indexOf(playbackRate);
              const next = PLAYBACK_RATES[(idx + 1) % PLAYBACK_RATES.length];
              setPlaybackRate(next);
            }}
            aria-label="Cycle playback speed"
            className="px-2 py-1 text-[11px] font-mono tabular-nums rounded border border-zinc-200 text-zinc-700 hover:bg-zinc-100 transition-colors cursor-pointer"
          >
            {playbackRate}x
          </button>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setVolume(volume > 0 ? 0 : 0.9)}
              aria-label={volume === 0 ? 'Unmute audio' : 'Mute audio'}
              className="p-1 text-zinc-600 hover:text-[#09090B] cursor-pointer"
            >
              {volume === 0 ? (
                <VolumeX className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <input
              type="range"
              aria-label="Audio volume"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="w-16 h-1 accent-[#2563EB] cursor-pointer"
            />
          </div>

          <a
            href={currentEpisode.episodeUrl}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Open original podcast episode"
            className="p-1.5 rounded-md text-zinc-500 hover:text-[#2563EB] hover:bg-zinc-100 transition-colors"
          >
            <ExternalLink className="w-4 h-4" />
          </a>

          <button
            type="button"
            onClick={closePlayer}
            aria-label="Close podcast player"
            className="p-1.5 rounded-md text-zinc-500 hover:text-[#09090B] hover:bg-zinc-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <button
          type="button"
          onClick={closePlayer}
          aria-label="Close podcast player"
          className="md:hidden p-1.5 rounded-md text-zinc-500 hover:text-[#09090B] cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
};
