import React from 'react';
import {
  BookMarked,
  BookOpen,
  Calendar,
  GitBranch,
  Globe,
  Headphones,
  ShieldAlert,
  Video,
} from 'lucide-react';
import { DiscoverSource } from '../../services/technology/discoverFeed';

interface SourceBadgeProps {
  sourceGroup: DiscoverSource;
  sourceName?: string;
  compact?: boolean;
}

const SOURCE_VISUALS: Record<
  DiscoverSource,
  {
    icon: React.ComponentType<{ className?: string; 'aria-hidden'?: boolean }>;
    toneClass: string;
  }
> = {
  Medium: {
    icon: BookOpen,
    toneClass: 'bg-zinc-100 text-zinc-800 border-zinc-200',
  },
  'Official Engineering Blogs': {
    icon: Globe,
    toneClass: 'bg-blue-50/80 text-blue-800 border-blue-200/80',
  },
  YouTube: {
    icon: Video,
    toneClass: 'bg-rose-50/70 text-rose-800 border-rose-200/80',
  },
  Podcasts: {
    icon: Headphones,
    toneClass: 'bg-violet-50/70 text-violet-800 border-violet-200/80',
  },
  GitHub: {
    icon: GitBranch,
    toneClass: 'bg-zinc-100 text-zinc-900 border-zinc-200',
  },
  'Security Advisories': {
    icon: ShieldAlert,
    toneClass: 'bg-amber-50/80 text-amber-900 border-amber-200/80',
  },
  Conferences: {
    icon: Calendar,
    toneClass: 'bg-emerald-50/70 text-emerald-800 border-emerald-200/80',
  },
  'Technical Documentation': {
    icon: BookMarked,
    toneClass: 'bg-sky-50/70 text-sky-800 border-sky-200/80',
  },
};

export const SourceBadge: React.FC<SourceBadgeProps> = ({
  sourceGroup,
  sourceName,
  compact = false,
}) => {
  const cfg = SOURCE_VISUALS[sourceGroup];
  const Icon = cfg.icon;
  const label = sourceName && !compact ? sourceName : sourceGroup;

  return (
    <span
      title={sourceName ? `${sourceGroup}: ${sourceName}` : sourceGroup}
      className={`inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-[11px] font-medium leading-tight max-w-[210px] ${cfg.toneClass}`}
    >
      <Icon className="w-3 h-3 shrink-0" aria-hidden={true} />
      <span className="truncate">{label}</span>
    </span>
  );
};
