import React, { useMemo, useState } from 'react';
import {
  Archive,
  BookOpen,
  ChevronDown,
  ChevronUp,
  History,
  PanelLeftClose,
  PanelLeftOpen,
  Rss,
  Search,
  SlidersHorizontal,
  Star,
  X,
} from 'lucide-react';
import {
  TechHubCategoryDto,
  TechHubStatusDto,
} from '../../types/techKnowledgeHub';

export type BlogSidebarSection =
  | 'articles'
  | 'favorites'
  | 'archive'
  | 'sources'
  | 'history';

interface BlogSidebarProps {
  activeSection: BlogSidebarSection;
  isArticleDetail: boolean;
  categories: TechHubCategoryDto[];
  selectedCategoryId: string;
  status: TechHubStatusDto | null;
  onSelectSection: (section: BlogSidebarSection) => void;
  onSelectCategory: (categoryId: string) => void;
}

export const BlogSidebar: React.FC<BlogSidebarProps> = ({
  activeSection,
  isArticleDetail,
  categories,
  selectedCategoryId,
  status,
  onSelectSection,
  onSelectCategory,
}) => {
  const [desktopCollapsed, setDesktopCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [categoriesOpen, setCategoriesOpen] = useState(true);
  const [categoryQuery, setCategoryQuery] = useState('');

  const filteredCategories = useMemo(() => {
    const q = categoryQuery.trim().toLowerCase();
    if (!q) return categories;
    return categories.filter((c) => c.name.toLowerCase().includes(q));
  }, [categories, categoryQuery]);

  const isArchiveView = activeSection === 'archive';

  const selectedCategoryName = useMemo(
    () =>
      categories.find((c) => c.id === selectedCategoryId)?.name ||
      'Tüm kategoriler',
    [categories, selectedCategoryId]
  );

  const navItems: Array<{
    key: BlogSidebarSection;
    label: string;
    count?: number;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    {
      key: 'articles',
      label: 'Tüm Makaleler',
      count: status?.totals.activeArticles,
      icon: BookOpen,
    },
    {
      key: 'favorites',
      label: 'Favoriler',
      count: status?.totals.favoriteArticles,
      icon: Star,
    },
    {
      key: 'archive',
      label: 'Archive',
      count: status?.totals.archivedArticles,
      icon: Archive,
    },
    {
      key: 'sources',
      label: 'Kaynak Yönetimi',
      count: status?.totals.sources,
      icon: Rss,
    },
    {
      key: 'history',
      label: 'Tarama Geçmişi',
      icon: History,
    },
  ];

  const handleNavClick = (sec: BlogSidebarSection) => {
    onSelectSection(sec);
    setMobileOpen(false);
  };

  const handleCategoryClick = (catId: string) => {
    onSelectCategory(catId);
    setMobileOpen(false);
  };

  const sidebarContent = (
    <div className="space-y-5">
      {/* Primary Views: Articles / Favorites / Archive / Sources / History */}
      <nav aria-label="Blog bölümleri" className="space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = !isArticleDetail && activeSection === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => handleNavClick(item.key)}
              className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-xs transition-colors cursor-pointer whitespace-nowrap ${
                active
                  ? 'bg-[#09090B] text-white font-semibold'
                  : 'text-zinc-700 hover:bg-zinc-50 hover:text-[#09090B] font-medium'
              }`}
            >
              <span className="inline-flex items-center gap-2 min-w-0">
                <Icon
                  className={`w-3.5 h-3.5 shrink-0 ${
                    active ? 'text-white' : 'text-zinc-500'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </span>
              {typeof item.count === 'number' && (
                <span
                  className={`font-mono text-[11px] tabular-nums shrink-0 ${
                    active ? 'text-zinc-300' : 'text-zinc-400'
                  }`}
                >
                  {item.count}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Collapsible / Dropdown Categories with Inline Search */}
      <div className="pt-4 border-t border-zinc-200 space-y-2.5">
        <button
          type="button"
          onClick={() => setCategoriesOpen((prev) => !prev)}
          aria-expanded={categoriesOpen}
          className="w-full flex items-center justify-between text-xs font-semibold text-[#09090B] hover:text-[#2563EB] transition-colors cursor-pointer"
        >
          <span>Kategoriler ({categories.length})</span>
          {categoriesOpen ? (
            <ChevronUp className="w-4 h-4 text-zinc-400" aria-hidden="true" />
          ) : (
            <ChevronDown className="w-4 h-4 text-zinc-400" aria-hidden="true" />
          )}
        </button>

        {!categoriesOpen && selectedCategoryId && (
          <div className="px-2.5 py-1.5 rounded-lg bg-blue-50/70 text-[11px] font-medium text-[#2563EB] flex items-center justify-between">
            <span className="truncate">{selectedCategoryName}</span>
            <button
              type="button"
              onClick={() => handleCategoryClick('')}
              aria-label="Kategori filtresini temizle"
              className="text-zinc-500 hover:text-[#09090B] cursor-pointer"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}

        {categoriesOpen && (
          <div className="space-y-2">
            <div className="relative">
              <Search
                className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="text"
                value={categoryQuery}
                onChange={(e) => setCategoryQuery(e.target.value)}
                placeholder="Kategori ara..."
                aria-label="Kategori ara"
                className="w-full pl-8 pr-7 py-1.5 text-xs rounded-lg border border-zinc-200 bg-[#FAFAFA] text-[#09090B] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB] focus:bg-white transition-colors"
              />
              {categoryQuery && (
                <button
                  type="button"
                  onClick={() => setCategoryQuery('')}
                  aria-label="Kategori aramasını temizle"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-[#09090B] cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            <div
              role="listbox"
              aria-label="Kategoriler"
              className="space-y-0.5 max-h-[360px] overflow-y-auto pr-0.5"
            >
              {!categoryQuery.trim() && (
                <button
                  type="button"
                  role="option"
                  aria-selected={!selectedCategoryId}
                  onClick={() => handleCategoryClick('')}
                  className={`w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer whitespace-nowrap ${
                    !selectedCategoryId
                      ? 'bg-blue-50 text-[#2563EB] font-semibold'
                      : 'text-zinc-700 hover:bg-zinc-50 hover:text-[#09090B] font-medium'
                  }`}
                >
                  <span className="truncate">Tüm kategoriler</span>
                  <span
                    className={`font-mono text-[11px] tabular-nums ${
                      !selectedCategoryId ? 'text-[#2563EB]' : 'text-zinc-400'
                    }`}
                  >
                    {isArchiveView
                      ? status?.totals.archivedArticles ?? 0
                      : status?.totals.activeArticles ?? 0}
                  </span>
                </button>
              )}

              {filteredCategories.length === 0 ? (
                <p className="px-2.5 py-3 text-center text-xs text-zinc-500">
                  Kategori bulunamadı.
                </p>
              ) : (
                filteredCategories.map((cat) => {
                  const isActive = selectedCategoryId === cat.id;
                  const count = isArchiveView
                    ? cat.archivedArticleCount
                    : cat.activeArticleCount;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      role="option"
                      aria-selected={isActive}
                      onClick={() => handleCategoryClick(cat.id)}
                      className={`w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer whitespace-nowrap ${
                        isActive
                          ? 'bg-blue-50 text-[#2563EB] font-semibold'
                          : 'text-zinc-600 hover:bg-zinc-50 hover:text-[#09090B] font-medium'
                      }`}
                    >
                      <span className="truncate">{cat.name}</span>
                      <span
                        className={`font-mono text-[11px] tabular-nums ${
                          isActive ? 'text-[#2563EB]' : 'text-zinc-400'
                        }`}
                      >
                        {count}
                      </span>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <aside
      aria-label="Blog navigasyon ve kategoriler"
      className={`w-full shrink-0 lg:sticky lg:top-20 transition-[width] duration-200 ${
        desktopCollapsed ? 'lg:w-[58px]' : 'lg:w-[264px]'
      }`}
    >
      {/* Mobile / Tablet Collapsible Filter Drawer Header */}
      <div className="lg:hidden rounded-xl bg-white border border-zinc-200 overflow-hidden">
        <button
          type="button"
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-expanded={mobileOpen}
          className="w-full px-4 py-3 flex items-center justify-between gap-3 text-left cursor-pointer"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <SlidersHorizontal
              className="w-4 h-4 text-[#2563EB] shrink-0"
              aria-hidden="true"
            />
            <div className="min-w-0">
              <div className="text-xs font-semibold text-[#09090B]">
                Blog Menüsü &amp; Kategoriler
              </div>
              <div className="text-[11px] text-zinc-500 truncate">
                {selectedCategoryName}
              </div>
            </div>
          </div>
          {mobileOpen ? (
            <ChevronUp className="w-4 h-4 text-zinc-400 shrink-0" />
          ) : (
            <ChevronDown className="w-4 h-4 text-zinc-400 shrink-0" />
          )}
        </button>

        {mobileOpen && (
          <div className="px-4 pb-4 pt-2 border-t border-zinc-100">
            {sidebarContent}
          </div>
        )}
      </div>

      {/* Desktop Fixed / Collapsible Sidebar */}
      <div className="hidden lg:block rounded-xl bg-white border border-zinc-200 p-4">
        {desktopCollapsed ? (
          <div className="flex flex-col items-center gap-3">
            <button
              type="button"
              onClick={() => setDesktopCollapsed(false)}
              title="Blog sidebar'ı genişlet"
              aria-label="Blog sidebar'ı genişlet"
              className="p-2 rounded-lg text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100 transition-colors cursor-pointer"
            >
              <PanelLeftOpen className="w-4 h-4" aria-hidden="true" />
            </button>

            <div className="w-full border-t border-zinc-100 pt-2 flex flex-col items-center gap-1.5">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = !isArticleDetail && activeSection === item.key;
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => handleNavClick(item.key)}
                    title={item.label}
                    aria-label={item.label}
                    className={`p-2 rounded-lg transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#09090B] text-white'
                        : 'text-zinc-600 hover:bg-zinc-100 hover:text-[#09090B]'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="space-y-5">
            {/* Sidebar Brand / Title + Collapse Toggle */}
            <div className="pb-3 border-b border-zinc-100 flex items-start justify-between gap-2">
              <div className="space-y-0.5 min-w-0">
                <h2 className="font-display text-base font-bold text-[#09090B]">
                  Blog
                </h2>
                <p className="text-[11px] text-zinc-500 truncate">
                  {categories.length} kategori · Kalıcı RSS arşivi
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDesktopCollapsed(true)}
                title="Sidebar'ı daralt"
                aria-label="Sidebar'ı daralt"
                className="p-1.5 rounded-lg text-zinc-400 hover:text-[#09090B] hover:bg-zinc-100 transition-colors cursor-pointer shrink-0"
              >
                <PanelLeftClose className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>

            {sidebarContent}
          </div>
        )}
      </div>
    </aside>
  );
};
