import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Check, ChevronDown, Search, X } from 'lucide-react';
import { TechHubCategoryDto } from '../../types/techKnowledgeHub';

interface SearchableCategoryDropdownProps {
  categories: TechHubCategoryDto[];
  selectedCategoryId: string;
  onSelect: (categoryId: string) => void;
  archivedMode?: boolean;
}

export const SearchableCategoryDropdown: React.FC<SearchableCategoryDropdownProps> = ({
  categories,
  selectedCategoryId,
  onSelect,
  archivedMode = false,
}) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(() => inputRef.current?.focus(), 20);
    const onOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const onEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onOutside);
    document.addEventListener('keydown', onEsc);
    return () => {
      window.clearTimeout(timer);
      document.removeEventListener('mousedown', onOutside);
      document.removeEventListener('keydown', onEsc);
    };
  }, [open]);

  const selectedCategory = useMemo(
    () => categories.find((c) => c.id === selectedCategoryId) || null,
    [categories, selectedCategoryId]
  );

  const filteredCategories = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return categories;
    return categories.filter((c) => c.name.toLowerCase().includes(q));
  }, [categories, query]);

  return (
    <div ref={containerRef} className="relative min-w-[210px]">
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        aria-expanded={open}
        aria-haspopup="listbox"
        className={`w-full inline-flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
          selectedCategory
            ? 'border-[#2563EB]/40 bg-blue-50/50 text-[#09090B]'
            : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
        }`}
      >
        <span className="truncate">
          {selectedCategory ? selectedCategory.name : 'Tüm Kategoriler'}
        </span>
        <ChevronDown
          className={`w-3.5 h-3.5 text-zinc-400 shrink-0 transition-transform ${
            open ? 'rotate-180' : ''
          }`}
          aria-hidden="true"
        />
      </button>

      {open && (
        <div
          role="listbox"
          aria-label="Kategoriler"
          className="absolute left-0 mt-1.5 w-72 rounded-xl bg-white border border-zinc-200 shadow-lg z-40 overflow-hidden"
        >
          <div className="p-2 border-b border-zinc-100 bg-[#FAFAFA]">
            <div className="relative">
              <Search
                className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Kategori ara..."
                aria-label="Kategori ara"
                className="w-full pl-8 pr-7 py-1.5 text-xs rounded-lg border border-zinc-200 bg-white text-[#09090B] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  aria-label="Aramayı temizle"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-[#09090B] cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          <div className="max-h-64 overflow-y-auto py-1">
            {!query.trim() && (
              <button
                type="button"
                role="option"
                aria-selected={!selectedCategoryId}
                onClick={() => {
                  onSelect('');
                  setOpen(false);
                }}
                className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-zinc-50 cursor-pointer ${
                  !selectedCategoryId
                    ? 'font-semibold text-[#2563EB] bg-blue-50/40'
                    : 'text-zinc-700'
                }`}
              >
                <span>Tüm Kategoriler</span>
                {!selectedCategoryId && <Check className="w-3.5 h-3.5" />}
              </button>
            )}

            {filteredCategories.length === 0 ? (
              <p className="px-3 py-4 text-center text-xs text-zinc-500">
                Kategori bulunamadı.
              </p>
            ) : (
              filteredCategories.map((cat) => {
                const isSelected = selectedCategoryId === cat.id;
                const count = archivedMode
                  ? cat.archivedArticleCount
                  : cat.activeArticleCount;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    role="option"
                    aria-selected={isSelected}
                    onClick={() => {
                      onSelect(cat.id);
                      setOpen(false);
                      setQuery('');
                    }}
                    className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between gap-2 hover:bg-zinc-50 cursor-pointer ${
                      isSelected
                        ? 'font-semibold text-[#2563EB] bg-blue-50/40'
                        : 'text-zinc-700'
                    }`}
                  >
                    <span className="truncate">{cat.name}</span>
                    <span className="inline-flex items-center gap-1.5 shrink-0">
                      <span className="text-[11px] font-mono tabular-nums text-zinc-400">
                        {count}
                      </span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-[#2563EB]" />}
                    </span>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
