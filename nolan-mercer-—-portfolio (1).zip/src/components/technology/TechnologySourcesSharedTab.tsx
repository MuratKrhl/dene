import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Edit3,
  ExternalLink,
  History,
  Plus,
  RefreshCw,
  RotateCcw,
  Search,
  ShieldAlert,
  Trash2,
  Wifi,
} from 'lucide-react';
import {
  MediaContentType,
  MediaSourceDto,
  MediaStatusDto,
  MediaSyncHistoryDto,
  TestMediaSourceResponse,
  clearMediaSyncHistory,
  createMediaSource,
  deleteMediaSource,
  patchMediaScheduler,
  retryFailedMediaSourcesApi,
  syncMediaByTypeApi,
  syncSingleMediaSourceApi,
  testExistingMediaSource,
  testMediaSourceInput,
  updateMediaSource,
} from '../../services/techMediaApi';
import { formatTechTimestamp } from '../../services/technology/retentionEngine';

interface TechnologySourcesSharedTabProps {
  sources: MediaSourceDto[];
  status: MediaStatusDto | null;
  history: MediaSyncHistoryDto[];
  initialShowHistory?: boolean;
  onDataChanged: () => Promise<void> | void;
}

const CATEGORY_PRESETS = [
  'Kubernetes',
  'OpenShift',
  'AWS',
  'Cloudflare',
  'GitHub',
  'Security',
  'Java',
  'AI',
  'DevOps',
  'Istio',
  'Elasticsearch',
  'Nginx',
  'Jenkins',
];

const TYPE_LABEL: Record<MediaContentType, string> = {
  podcast: 'Podcasts',
  event: 'Events',
  youtube: 'YouTube',
};

export const TechnologySourcesSharedTab: React.FC<
  TechnologySourcesSharedTabProps
> = ({
  sources,
  status,
  history,
  initialShowHistory = false,
  onDataChanged,
}) => {
  const [viewMode, setViewMode] = useState<'sources' | 'history'>(
    initialShowHistory ? 'history' : 'sources'
  );
  const [contentFilter, setContentFilter] = useState<'all' | MediaContentType>(
    'all'
  );
  const [verifyFilter, setVerifyFilter] = useState<
    'all' | 'verified' | 'unverified' | 'error'
  >('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [busySourceId, setBusySourceId] = useState<string | null>(null);
  const [busyTypeSync, setBusyTypeSync] = useState<MediaContentType | 'all' | null>(
    null
  );
  const [isRetryingFailed, setIsRetryingFailed] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{
    tone: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  // Add / Edit Form state
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formType, setFormType] = useState<MediaContentType>('podcast');
  const [formWebsiteUrl, setFormWebsiteUrl] = useState('');
  const [formEndpoint, setFormEndpoint] = useState('');
  const [formCategory, setFormCategory] = useState('Kubernetes');
  const [formCategoriesText, setFormCategoriesText] = useState('Kubernetes');
  const [formInterval, setFormInterval] = useState<number>(3);
  const [formEnabled, setFormEnabled] = useState(true);
  const [isTestingForm, setIsTestingForm] = useState(false);
  const [isSavingForm, setIsSavingForm] = useState(false);
  const [formTestResult, setFormTestResult] =
    useState<TestMediaSourceResponse | null>(null);

  const openCreateForm = () => {
    setEditingId(null);
    setFormName('');
    setFormType('podcast');
    setFormWebsiteUrl('');
    setFormEndpoint('');
    setFormCategory('Kubernetes');
    setFormCategoriesText('Kubernetes');
    setFormInterval(3);
    setFormEnabled(true);
    setFormTestResult(null);
    setShowForm(true);
  };

  const openEditForm = (src: MediaSourceDto) => {
    setEditingId(src.id);
    setFormName(src.name);
    setFormType(src.contentType);
    setFormWebsiteUrl(src.websiteUrl);
    setFormEndpoint(src.feedOrEndpoint);
    setFormCategory(src.category);
    setFormCategoriesText((src.categories || [src.category]).join(', '));
    setFormInterval(src.syncIntervalHours);
    setFormEnabled(src.enabled);
    setFormTestResult(null);
    setShowForm(true);
  };

  const filteredSources = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return sources.filter((s) => {
      if (contentFilter !== 'all' && s.contentType !== contentFilter) return false;
      if (
        verifyFilter === 'verified' &&
        s.verificationStatus !== 'verified'
      ) {
        return false;
      }
      if (
        verifyFilter === 'unverified' &&
        s.verificationStatus !== 'unverified'
      ) {
        return false;
      }
      if (
        verifyFilter === 'error' &&
        s.verificationStatus !== 'error' &&
        !s.lastError
      ) {
        return false;
      }
      if (q) {
        const hay = [
          s.name,
          s.contentType,
          s.sourceType,
          s.category,
          ...(s.categories || []),
          s.feedOrEndpoint,
          s.websiteUrl,
        ]
          .join(' ')
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [contentFilter, searchQuery, sources, verifyFilter]);

  const filteredHistory = useMemo(
    () =>
      history.filter(
        (h) => contentFilter === 'all' || h.contentType === contentFilter
      ),
    [contentFilter, history]
  );

  const failedSourcesCount = useMemo(
    () =>
      sources.filter(
        (s) =>
          s.enabled &&
          (s.verificationStatus === 'error' || Boolean(s.lastError))
      ).length,
    [sources]
  );

  const handleTestFormConnection = async () => {
    if (!formEndpoint.trim()) {
      setFeedback({
        tone: 'error',
        text: 'Test için RSS, iCal, API veya YouTube URL/ID girin.',
      });
      return;
    }
    setIsTestingForm(true);
    setFormTestResult(null);
    try {
      const res = await testMediaSourceInput({
        contentType: formType,
        feedOrEndpoint: formEndpoint.trim(),
        websiteUrl: formWebsiteUrl.trim() || undefined,
        name: formName.trim() || undefined,
        category: formCategory,
        excludeId: editingId || undefined,
      });
      setFormTestResult(res);
      if (res.ok) {
        if (!formName.trim() && res.resolvedName) setFormName(res.resolvedName);
        if (!formWebsiteUrl.trim() && res.websiteUrl) {
          setFormWebsiteUrl(res.websiteUrl);
        }
        if (res.feedOrEndpoint && res.feedOrEndpoint !== formEndpoint.trim()) {
          setFormEndpoint(res.feedOrEndpoint);
        }
      }
    } catch (err) {
      setFeedback({
        tone: 'error',
        text: err instanceof Error ? err.message : 'Bağlantı testi başarısız.',
      });
    } finally {
      setIsTestingForm(false);
    }
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;
    setIsSavingForm(true);
    setFeedback(null);

    const parsedCats = formCategoriesText
      .split(',')
      .map((c) => c.trim())
      .filter(Boolean);
    const categories = parsedCats.length > 0 ? parsedCats : [formCategory];

    try {
      if (editingId) {
        await updateMediaSource(editingId, {
          name: formName.trim(),
          websiteUrl: formWebsiteUrl.trim(),
          feedOrEndpoint: formEndpoint.trim(),
          category: categories[0] || formCategory,
          categories,
          syncIntervalHours: formInterval,
          enabled: formEnabled,
        });
        setFeedback({
          tone: 'success',
          text: `"${formName.trim()}" kaynağı güncellendi.`,
        });
      } else {
        await createMediaSource({
          name: formName.trim(),
          contentType: formType,
          websiteUrl: formWebsiteUrl.trim(),
          feedOrEndpoint: formEndpoint.trim(),
          category: categories[0] || formCategory,
          categories,
          syncIntervalHours: formInterval,
          enabled: formEnabled,
        });
        setFeedback({
          tone: 'success',
          text: `"${formName.trim()}" kaynağı doğrulandı ve eklendi.`,
        });
      }
      setShowForm(false);
      setEditingId(null);
      await onDataChanged();
    } catch (err) {
      setFeedback({
        tone: 'error',
        text: err instanceof Error ? err.message : 'Kaynak kaydedilemedi.',
      });
    } finally {
      setIsSavingForm(false);
    }
  };

  const handleSyncType = async (ct: MediaContentType | 'all') => {
    setBusyTypeSync(ct);
    setFeedback(null);
    try {
      const outcome = await syncMediaByTypeApi(ct);
      await onDataChanged();
      if (outcome.skippedDueToLock) {
        setFeedback({
          tone: 'info',
          text: 'Seçilen içerik türü için zaten aktif bir senkronizasyon çalışıyor.',
        });
      } else {
        const okCount = outcome.results.filter((r) => r.status === 'success').length;
        const errCount = outcome.results.filter((r) => r.status === 'error').length;
        const newItems = outcome.results.reduce((s, r) => s + r.newItems, 0);
        setFeedback({
          tone: errCount > 0 ? 'error' : 'success',
          text: `${ct === 'all' ? 'Tüm medya kaynakları' : TYPE_LABEL[ct]} senkronize edildi: ${okCount} başarılı, ${errCount} hata, ${newItems} yeni kayıt.`,
        });
      }
    } catch (err) {
      setFeedback({
        tone: 'error',
        text: err instanceof Error ? err.message : 'Senkronizasyon başarısız.',
      });
    } finally {
      setBusyTypeSync(null);
    }
  };

  const handleRetryFailed = async () => {
    setIsRetryingFailed(true);
    setFeedback(null);
    try {
      const res = await retryFailedMediaSourcesApi(
        contentFilter === 'all' ? undefined : contentFilter
      );
      await onDataChanged();
      const recovered = res.results.filter((r) => r.status === 'success').length;
      setFeedback({
        tone: res.results.some((r) => r.status === 'error') ? 'error' : 'success',
        text:
          res.results.length === 0
            ? 'Tekrar denenecek hatalı kaynak bulunamadı.'
            : `${res.results.length} hatalı kaynak tekrar denendi (${recovered} kurtarıldı).`,
      });
    } finally {
      setIsRetryingFailed(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Independent Per-Content-Type Scheduling Panel */}
      {status && (
        <section
          aria-label="Independent media sync schedules"
          className="grid grid-cols-1 md:grid-cols-3 gap-3"
        >
          {(['podcast', 'event', 'youtube'] as MediaContentType[]).map((ct) => {
            const sched = status.scheduler[ct];
            const isLocked = status.activeTypeLocks.includes(ct) || busyTypeSync === ct;
            return (
              <div
                key={ct}
                className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <h3 className="font-display text-sm font-semibold text-[#09090B]">
                      {TYPE_LABEL[ct]} Scheduler
                    </h3>
                    <p className="text-[11px] font-mono tabular-nums text-zinc-500">
                      Last success:{' '}
                      {sched.lastSuccessfulSyncAt
                        ? formatTechTimestamp(sched.lastSuccessfulSyncAt)
                        : 'Never'}
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={isLocked}
                    onClick={() => handleSyncType(ct)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 hover:bg-zinc-50 disabled:opacity-50 cursor-pointer"
                  >
                    <RefreshCw
                      className={`w-3 h-3 ${isLocked ? 'animate-spin' : ''}`}
                      aria-hidden="true"
                    />
                    <span>{isLocked ? 'Syncing...' : 'Sync Now'}</span>
                  </button>
                </div>

                <div className="flex items-center justify-between gap-2 pt-2 border-t border-zinc-100 text-xs">
                  <label className="inline-flex items-center gap-2 text-zinc-600 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={sched.autoSyncEnabled}
                      onChange={async (e) => {
                        await patchMediaScheduler({
                          [ct]: { autoSyncEnabled: e.target.checked },
                        });
                        await onDataChanged();
                      }}
                    />
                    <span>Auto-sync</span>
                  </label>

                  <select
                    aria-label={`${TYPE_LABEL[ct]} sync interval`}
                    value={sched.intervalHours}
                    onChange={async (e) => {
                      await patchMediaScheduler({
                        [ct]: { intervalHours: Number(e.target.value) },
                      });
                      await onDataChanged();
                    }}
                    className="px-2 py-1 text-xs rounded border border-zinc-200 bg-white font-mono"
                  >
                    <option value={1}>Every 1h</option>
                    <option value={3}>Every 3h (Default)</option>
                    <option value={6}>Every 6h</option>
                    <option value={12}>Every 12h</option>
                    <option value={24}>Every 24h</option>
                    <option value={0}>Manual only</option>
                  </select>
                </div>
              </div>
            );
          })}
        </section>
      )}

      {/* Toolbar: Registry vs History + Global Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex rounded-lg border border-zinc-200 p-0.5 bg-zinc-100">
          <button
            type="button"
            onClick={() => setViewMode('sources')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer transition-colors ${
              viewMode === 'sources'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            Media Sources ({sources.length})
          </button>
          <button
            type="button"
            onClick={() => setViewMode('history')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer transition-colors ${
              viewMode === 'history'
                ? 'bg-white text-[#09090B] shadow-xs'
                : 'text-zinc-600 hover:text-[#09090B]'
            }`}
          >
            <History className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Sync History ({history.length})</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {failedSourcesCount > 0 && (
            <button
              type="button"
              disabled={isRetryingFailed}
              onClick={handleRetryFailed}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-amber-300 bg-amber-50 text-amber-900 hover:bg-amber-100 disabled:opacity-50 cursor-pointer"
            >
              <RotateCcw
                className={`w-3.5 h-3.5 ${isRetryingFailed ? 'animate-spin' : ''}`}
                aria-hidden="true"
              />
              <span>Retry Failed ({failedSourcesCount})</span>
            </button>
          )}
          <button
            type="button"
            disabled={busyTypeSync !== null}
            onClick={() => handleSyncType('all')}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-[#09090B] hover:bg-zinc-50 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${busyTypeSync === 'all' ? 'animate-spin' : ''}`}
              aria-hidden="true"
            />
            <span>{busyTypeSync === 'all' ? 'Syncing All...' : 'Sync All Media'}</span>
          </button>
          <button
            type="button"
            onClick={openCreateForm}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Add Media Source</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`rounded-lg px-4 py-2.5 text-xs flex items-center justify-between gap-3 border ${
            feedback.tone === 'error'
              ? 'bg-red-50 border-red-200 text-red-900'
              : feedback.tone === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-zinc-50 border-zinc-200 text-zinc-800'
          }`}
        >
          <span>{feedback.text}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="underline font-medium cursor-pointer shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Add / Edit Source Modal/Drawer */}
      {showForm && (
        <form
          onSubmit={handleSubmitForm}
          className="rounded-xl bg-white border border-zinc-200 p-5 space-y-4"
        >
          <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
            <div>
              <h3 className="font-display text-sm font-semibold text-[#09090B]">
                {editingId ? 'Edit Media Source' : 'Add & Verify New Media Source'}
              </h3>
              <p className="text-[11px] text-zinc-500">
                Podcasts (RSS 2.0 / Atom / Apple Podcasts URL), Events (iCal .ics / Official API / RSS), or YouTube (Channel ID, Playlist ID, Video ID, or URL).
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="text-xs text-zinc-500 hover:text-[#09090B] cursor-pointer"
            >
              Close
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Source Name *
              </label>
              <input
                type="text"
                required
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                placeholder="e.g. CNCF Community Events"
                className="w-full px-3 py-2 text-xs rounded-lg border border-zinc-200"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Content Type *
              </label>
              <select
                disabled={Boolean(editingId)}
                value={formType}
                onChange={(e) => {
                  setFormType(e.target.value as MediaContentType);
                  setFormTestResult(null);
                }}
                className="w-full px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white disabled:bg-zinc-50"
              >
                <option value="podcast">Podcast</option>
                <option value="event">Event</option>
                <option value="youtube">YouTube</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Sync Frequency
              </label>
              <select
                value={formInterval}
                onChange={(e) => setFormInterval(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
              >
                <option value={1}>Every 1 hour</option>
                <option value={3}>Every 3 hours (Default)</option>
                <option value={6}>Every 6 hours</option>
                <option value={12}>Every 12 hours</option>
                <option value={24}>Every 24 hours</option>
                <option value={0}>Manual only</option>
              </select>
            </div>

            <div className="space-y-1 sm:col-span-2">
              <label className="block text-[11px] font-medium text-zinc-600">
                {formType === 'youtube'
                  ? 'Channel ID (UC...), Playlist ID (PL...), Video ID, or YouTube URL'
                  : formType === 'podcast'
                    ? 'RSS 2.0 / Atom Feed URL or Apple Podcasts URL'
                    : 'Official Events API, iCal (.ics), or RSS/Atom URL'}
              </label>
              <input
                type="text"
                value={formEndpoint}
                onChange={(e) => {
                  setFormEndpoint(e.target.value);
                  setFormTestResult(null);
                }}
                placeholder={
                  formType === 'youtube'
                    ? 'UCp6NUFV9mSEK6RxUiEVymVg or https://www.youtube.com/@RedHat'
                    : formType === 'podcast'
                      ? 'https://kubernetespodcast.com/feeds/audio.xml'
                      : 'https://community.cncf.io/api/event/?status=Live&page_size=20'
                }
                className="w-full px-3 py-2 text-xs rounded-lg border border-zinc-200 font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-[11px] font-medium text-zinc-600">
                Website URL
              </label>
              <input
                type="url"
                value={formWebsiteUrl}
                onChange={(e) => setFormWebsiteUrl(e.target.value)}
                placeholder="https://..."
                className="w-full px-3 py-2 text-xs rounded-lg border border-zinc-200"
              />
            </div>

            <div className="space-y-1 sm:col-span-2">
              <label className="block text-[11px] font-medium text-zinc-600">
                Category Mapping (comma-separated)
              </label>
              <input
                type="text"
                value={formCategoriesText}
                onChange={(e) => setFormCategoriesText(e.target.value)}
                list="media-category-presets"
                placeholder="Kubernetes, OpenShift, DevOps"
                className="w-full px-3 py-2 text-xs rounded-lg border border-zinc-200"
              />
              <datalist id="media-category-presets">
                {CATEGORY_PRESETS.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>

            <div className="flex items-end pb-1">
              <label className="inline-flex items-center gap-2 text-xs text-zinc-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formEnabled}
                  onChange={(e) => setFormEnabled(e.target.checked)}
                />
                <span>Enable after live verification</span>
              </label>
            </div>
          </div>

          {formTestResult && (
            <div
              className={`rounded-lg border px-4 py-3 text-xs space-y-1.5 ${
                formTestResult.ok && !formTestResult.duplicateSource
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                  : 'bg-amber-50 border-amber-200 text-amber-950'
              }`}
            >
              <div className="flex items-center justify-between gap-2 font-medium">
                <span>
                  {formTestResult.ok
                    ? `Verified (${formTestResult.detectedSourceType.toUpperCase()} · ${formTestResult.itemCount} items · ${formTestResult.durationMs}ms)`
                    : `Validation Failed: ${formTestResult.error}`}
                </span>
                {formTestResult.httpStatus && (
                  <span className="font-mono text-[11px]">
                    HTTP {formTestResult.httpStatus}
                  </span>
                )}
              </div>
              {formTestResult.duplicateSource && (
                <p className="text-red-700 font-medium">
                  Duplicate detected: Already registered as &ldquo;
                  {formTestResult.duplicateSource.name}&rdquo; (
                  {formTestResult.duplicateSource.feedOrEndpoint}).
                </p>
              )}
              {formTestResult.warning && (
                <p className="text-amber-800">{formTestResult.warning}</p>
              )}
              {formTestResult.sampleTitles.length > 0 && (
                <p className="text-[11px] text-zinc-600 truncate">
                  Samples: {formTestResult.sampleTitles.join(' · ')}
                </p>
              )}
            </div>
          )}

          <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-zinc-100">
            <button
              type="button"
              disabled={isTestingForm}
              onClick={handleTestFormConnection}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 hover:bg-zinc-50 disabled:opacity-50 cursor-pointer"
            >
              <Wifi className="w-3.5 h-3.5" aria-hidden="true" />
              <span>
                {isTestingForm ? 'Testing...' : 'Test Connection & Validate'}
              </span>
            </button>
            <button
              type="submit"
              disabled={isSavingForm || Boolean(formTestResult?.duplicateSource)}
              className="px-4 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 disabled:opacity-50 cursor-pointer"
            >
              {isSavingForm
                ? 'Validating & Saving...'
                : editingId
                  ? 'Save Changes'
                  : 'Validate & Save Source'}
            </button>
          </div>
        </form>
      )}

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2.5">
        {viewMode === 'sources' && (
          <div className="relative flex-1 min-w-[220px]">
            <Search
              className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2"
              aria-hidden="true"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search sources by name, URL, YouTube ID, or category..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            />
          </div>
        )}

        <select
          aria-label="Filter by content type"
          value={contentFilter}
          onChange={(e) =>
            setContentFilter(e.target.value as 'all' | MediaContentType)
          }
          className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
        >
          <option value="all">All Media Types</option>
          <option value="podcast">Podcasts</option>
          <option value="event">Events</option>
          <option value="youtube">YouTube</option>
        </select>

        {viewMode === 'sources' && (
          <select
            aria-label="Filter by verification status"
            value={verifyFilter}
            onChange={(e) =>
              setVerifyFilter(
                e.target.value as 'all' | 'verified' | 'unverified' | 'error'
              )
            }
            className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
          >
            <option value="all">All Verification States</option>
            <option value="verified">Verified</option>
            <option value="unverified">Unverified / Portal Only</option>
            <option value="error">Failed / Error</option>
          </select>
        )}

        {viewMode === 'history' && history.length > 0 && (
          <button
            type="button"
            onClick={async () => {
              await clearMediaSyncHistory();
              await onDataChanged();
            }}
            className="ml-auto px-3 py-1.5 text-xs rounded-lg border border-zinc-200 hover:bg-zinc-50 text-zinc-600 cursor-pointer"
          >
            Clear Media History
          </button>
        )}
      </div>

      {/* SOURCE LIST OR SYNC HISTORY */}
      {viewMode === 'history' ? (
        <div className="rounded-xl bg-white border border-zinc-200 overflow-x-auto">
          {filteredHistory.length === 0 ? (
            <p className="p-8 text-xs text-zinc-500 text-center">
              No media sync history recorded yet.
            </p>
          ) : (
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-200 text-zinc-500">
                  <th className="py-2.5 px-4 font-medium">Source</th>
                  <th className="py-2.5 px-3 font-medium">Type</th>
                  <th className="py-2.5 px-3 font-medium">Trigger</th>
                  <th className="py-2.5 px-3 font-medium">Status</th>
                  <th className="py-2.5 px-3 font-medium text-right">New</th>
                  <th className="py-2.5 px-3 font-medium text-right">Dup</th>
                  <th className="py-2.5 px-3 font-medium text-right">Updated</th>
                  <th className="py-2.5 px-3 font-medium text-right">Duration</th>
                  <th className="py-2.5 px-4 font-medium">Finished At</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 font-mono tabular-nums">
                {filteredHistory.map((h) => (
                  <tr key={h.syncId} className="hover:bg-zinc-50/60">
                    <td className="py-2.5 px-4 font-sans font-medium text-[#09090B]">
                      <div>{h.sourceName}</div>
                      {h.errorMessage && (
                        <div className="text-[11px] font-normal text-red-600">
                          {h.errorMessage}
                        </div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-sans capitalize text-zinc-600">
                      {h.contentType}
                    </td>
                    <td className="py-2.5 px-3 font-sans capitalize text-zinc-500">
                      {h.trigger}
                    </td>
                    <td className="py-2.5 px-3 font-sans">
                      <span
                        className={
                          h.status === 'success'
                            ? 'text-emerald-700 font-medium'
                            : h.status === 'error'
                              ? 'text-red-600 font-medium'
                              : 'text-amber-700'
                        }
                      >
                        {h.status}
                        {h.httpStatus ? ` (${h.httpStatus})` : ''}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">{h.newItems}</td>
                    <td className="py-2.5 px-3 text-right">
                      {h.duplicatesSkipped}
                    </td>
                    <td className="py-2.5 px-3 text-right">{h.updatedItems}</td>
                    <td className="py-2.5 px-3 text-right">{h.durationMs}ms</td>
                    <td className="py-2.5 px-4 text-zinc-500">
                      {formatTechTimestamp(h.finishedAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      ) : filteredSources.length === 0 ? (
        <div className="rounded-xl bg-white border border-zinc-200 p-8 text-center text-xs text-zinc-500">
          No media sources match your current filter criteria.
        </div>
      ) : (
        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
          {filteredSources.map((src) => {
            const isBusy = busySourceId === src.id;
            return (
              <div key={src.id} className="p-4 space-y-2.5">
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
                  <div className="min-w-0 flex-1 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-[#09090B]">
                        {src.name}
                      </span>
                      <span className="text-[11px] font-medium text-[#2563EB] uppercase">
                        {src.contentType} · {src.sourceType}
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 text-[11px] font-medium ${
                          src.verificationStatus === 'verified'
                            ? 'text-emerald-700'
                            : src.verificationStatus === 'error'
                              ? 'text-red-600'
                              : 'text-amber-700'
                        }`}
                      >
                        {src.verificationStatus === 'verified' ? (
                          <CheckCircle2 className="w-3 h-3" aria-hidden="true" />
                        ) : src.verificationStatus === 'error' ? (
                          <AlertCircle className="w-3 h-3" aria-hidden="true" />
                        ) : (
                          <ShieldAlert className="w-3 h-3" aria-hidden="true" />
                        )}
                        <span className="capitalize">
                          {src.verificationStatus}
                        </span>
                      </span>
                      <span className="text-[11px] text-zinc-500">
                        · Categories: {(src.categories || [src.category]).join(', ')}
                      </span>
                    </div>

                    <p className="text-[11px] font-mono text-zinc-500 break-all">
                      Endpoint:{' '}
                      {src.feedOrEndpoint || 'Not configured (manual portal)'}
                      {src.websiteUrl && (
                        <>
                          {' · '}
                          <a
                            href={src.websiteUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#2563EB] hover:underline inline-flex items-center gap-0.5 font-sans"
                          >
                            <span>Website</span>
                            <ExternalLink className="w-2.5 h-2.5" />
                          </a>
                        </>
                      )}
                    </p>

                    <p className="text-[11px] font-mono tabular-nums text-zinc-500 flex flex-wrap items-center gap-x-3 gap-y-1">
                      <span>Collected: {src.collectedCount}</span>
                      <span>
                        Freq:{' '}
                        {src.syncIntervalHours > 0
                          ? `Every ${src.syncIntervalHours}h`
                          : 'Manual'}
                      </span>
                      <span>
                        Last success:{' '}
                        {src.lastSuccessfulSyncAt
                          ? formatTechTimestamp(src.lastSuccessfulSyncAt)
                          : 'Never'}
                      </span>
                      <span>
                        Last attempt:{' '}
                        {src.lastAttemptedSyncAt
                          ? formatTechTimestamp(src.lastAttemptedSyncAt)
                          : 'Never'}
                      </span>
                      {src.nextSyncAt && src.enabled && (
                        <span className="inline-flex items-center gap-1">
                          <Clock className="w-3 h-3" aria-hidden="true" />
                          Next: {formatTechTimestamp(src.nextSyncAt)}
                        </span>
                      )}
                    </p>

                    {(src.lastError || src.verificationNote) && (
                      <p
                        className={`text-[11px] ${
                          src.lastError
                            ? 'text-red-600'
                            : src.verificationStatus === 'unverified'
                              ? 'text-amber-700'
                              : 'text-zinc-500'
                        }`}
                      >
                        {src.lastError || src.verificationNote}
                      </p>
                    )}
                  </div>

                  {/* Per-Source Actions */}
                  <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={async () => {
                        setBusySourceId(src.id);
                        setFeedback(null);
                        try {
                          const test = await testExistingMediaSource(src.id);
                          await onDataChanged();
                          setFeedback({
                            tone: test.ok ? 'success' : 'error',
                            text: test.ok
                              ? `"${src.name}" doğrulandı (${test.itemCount} kayıt).`
                              : `"${src.name}" doğrulaması başarısız: ${test.error}`,
                          });
                        } finally {
                          setBusySourceId(null);
                        }
                      }}
                      className="px-2.5 py-1 text-xs rounded-md border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                    >
                      Validate
                    </button>

                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={async () => {
                        setBusySourceId(src.id);
                        setFeedback(null);
                        try {
                          const res = await syncSingleMediaSourceApi(src.id);
                          await onDataChanged();
                          setFeedback({
                            tone:
                              res.result.status === 'success'
                                ? 'success'
                                : 'error',
                            text: `"${src.name}": ${res.result.newItems} yeni, ${res.result.duplicatesSkipped} tekrar.`,
                          });
                        } catch (err) {
                          setFeedback({
                            tone: 'error',
                            text:
                              err instanceof Error
                                ? err.message
                                : 'Senkronizasyon hatası.',
                          });
                        } finally {
                          setBusySourceId(null);
                        }
                      }}
                      className="px-2.5 py-1 text-xs rounded-md border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                    >
                      {isBusy ? 'Working...' : 'Sync Now'}
                    </button>

                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={async () => {
                        setFeedback(null);
                        try {
                          await updateMediaSource(src.id, {
                            enabled: !src.enabled,
                          });
                          await onDataChanged();
                        } catch (err) {
                          setFeedback({
                            tone: 'error',
                            text:
                              err instanceof Error
                                ? err.message
                                : 'Durum değiştirilemedi.',
                          });
                        }
                      }}
                      className={`px-2.5 py-1 text-xs rounded-md border cursor-pointer ${
                        src.enabled
                          ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                          : 'border-zinc-200 bg-zinc-50 text-zinc-600'
                      }`}
                    >
                      {src.enabled ? 'Enabled' : 'Disabled'}
                    </button>

                    <button
                      type="button"
                      onClick={() => openEditForm(src)}
                      aria-label={`Edit ${src.name}`}
                      className="p-1.5 rounded-md hover:bg-zinc-100 text-zinc-500 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    {pendingDeleteId === src.id ? (
                      <button
                        type="button"
                        onClick={async () => {
                          await deleteMediaSource(src.id);
                          setPendingDeleteId(null);
                          await onDataChanged();
                        }}
                        className="px-2 py-1 text-xs bg-red-600 text-white rounded cursor-pointer"
                      >
                        Confirm
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setPendingDeleteId(src.id)}
                        aria-label={`Delete ${src.name}`}
                        className="p-1.5 rounded-md hover:bg-zinc-100 text-zinc-400 hover:text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
