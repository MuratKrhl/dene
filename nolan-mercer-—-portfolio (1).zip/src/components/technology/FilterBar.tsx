import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronDown,
  LayoutGrid,
  List,
  Search,
  X,
} from 'lucide-react';
import {
  DISCOVER_CONTENT_TYPES,
  DISCOVER_SOURCES,
  DISCOVER_TECHNOLOGIES,
  DiscoverContentType,
  DiscoverDateRange,
  DiscoverFilterState,
  DiscoverSortOption,
  DiscoverSource,
  DiscoverTechnology,
  DiscoverViewMode,
} from '../../services/technology/discoverFeed';

interface FilterBarProps {
  filter: DiscoverFilterState;
  totalMatches: number;
  onChange: (next: DiscoverFilterState) => void;
  onClearAll: () => void;
  rightActions?: React.ReactNode;
}

interface MultiSelectDropdownProps<T extends string> {
  label: string;
  options: readonly T[];
  selected: T[];
  onToggle: (value: T) => void;
}

function MultiSelectDropdown<T extends string>({
  label,
  options,
  selected,
  onToggle,
}: MultiSelectDropdownProps<T>) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleOutside = (e: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleEsc);
    };
  }, [open]);

  const activeCount = selected.length;

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((p) => !p)}
        aria-expanded={open}
        aria-haspopup="listbox"
        className={`inline-flex items-center justify-between gap-2 px-3 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
          activeCount > 0
            ? 'border-[#2563EB]/50 bg-blue-50/50 text-[#09090B]'
            : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
        }`}
      >
        <span>
          {label}
          {activeCount > 0 ? ` (${activeCount})` : ''}
        </span>
        <ChevronDown
          className={`w-3.5 h-3.5 text-zinc-400 transition-transform ${
            open ? 'rotate-180' : ''
          }`}
          aria-hidden="true"
        />
      </button>

      {open && (
        <div
          role="listbox"
          aria-label={label}
          aria-multiselectable="true"
          className="absolute left-0 mt-1.5 w-64 max-h-72 overflow-y-auto rounded-xl bg-white border border-zinc-200 shadow-lg py-1.5 z-40"
        >
          {options.map((option) => {
            const checked = selected.includes(option);
            return (
              <label
                key={option}
                className="flex items-center gap-2.5 px-3 py-1.5 text-xs text-zinc-700 hover:bg-zinc-50 cursor-pointer select-none"
              >
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => onToggle(option)}
                  className="rounded border-zinc-300 text-[#2563EB] focus:ring-[#2563EB]"
                />
                <span className={checked ? 'font-semibold text-[#09090B]' : ''}>
                  {option}
                </span>
              </label>
            );
          })}
        </div>
      )}
    </div>
  );
}

function toggleValue<T extends string>(list: T[], val: T): T[] {
  return list.includes(val) ? list.filter((x) => x !== val) : [...list, val];
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filter,
  totalMatches,
  onChange,
  onClearAll,
  rightActions,
}) => {
  const hasActiveFilters =
    filter.sources.length > 0 ||
    filter.contentTypes.length > 0 ||
    filter.technologies.length > 0 ||
    filter.dateRange !== '30d' ||
    filter.searchQuery.trim().length > 0;

  return (
    <section
      aria-label="Content filters"
      className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3"
    >
      {/* Row 1: Search + Date Range + Sort + View Mode + Contextual Actions */}
      <div className="flex flex-col md:flex-row md:items-center gap-2.5">
        <div className="relative flex-1 min-w-[220px]">
          <Search
            className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2"
            aria-hidden="true"
          />
          <input
            type="text"
            value={filter.searchQuery}
            onChange={(e) =>
              onChange({ ...filter, searchQuery: e.target.value, page: 1 })
            }
            placeholder="Search across titles, sources, CVEs, repositories, technologies..."
            aria-label="Filter content by keyword"
            className="w-full pl-9 pr-8 py-2 text-xs rounded-lg border border-zinc-200 bg-[#FAFAFA] focus:bg-white focus:outline-none focus:border-[#2563EB]"
          />
          {filter.searchQuery && (
            <button
              type="button"
              onClick={() => onChange({ ...filter, searchQuery: '', page: 1 })}
              aria-label="Clear search query"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 rounded hover:bg-zinc-200 text-zinc-500 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <select
            aria-label="Date range filter"
            value={filter.dateRange}
            onChange={(e) =>
              onChange({
                ...filter,
                dateRange: e.target.value as DiscoverDateRange,
                page: 1,
              })
            }
            className="px-2.5 py-2 text-xs rounded-lg border border-zinc-200 bg-white text-zinc-700"
          >
            <option value="30d">Last 30 days</option>
            <option value="7d">Last 7 days</option>
            <option value="90d">Last 90 days</option>
            <option value="all">All dates</option>
            <option value="archive">Archived (&gt;30d)</option>
          </select>

          <select
            aria-label="Sort results"
            value={filter.sort}
            onChange={(e) =>
              onChange({
                ...filter,
                sort: e.target.value as DiscoverSortOption,
                page: 1,
              })
            }
            className="px-2.5 py-2 text-xs rounded-lg border border-zinc-200 bg-white text-zinc-700"
          >
            <option value="latest">Latest</option>
            <option value="relevance">Relevance</option>
          </select>

          <div
            role="group"
            aria-label="Layout view mode"
            className="inline-flex rounded-lg border border-zinc-200 p-0.5 bg-[#FAFAFA]"
          >
            {(
              [
                ['list', List, 'List view'],
                ['grid', LayoutGrid, 'Grid view'],
              ] as const
            ).map(([mode, Icon, label]) => {
              const active = filter.viewMode === mode;
              return (
                <button
                  key={mode}
                  type="button"
                  onClick={() =>
                    onChange({ ...filter, viewMode: mode as DiscoverViewMode })
                  }
                  aria-label={label}
                  aria-pressed={active}
                  className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                    active
                      ? 'bg-white text-[#09090B] shadow-xs'
                      : 'text-zinc-500 hover:text-[#09090B]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              );
            })}
          </div>

          {rightActions}
        </div>
      </div>

      {/* Row 2: 3-Layer Multi-Filter Controls (Source, Content Type, Technology) + Result Count */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-zinc-100">
        <div className="flex flex-wrap items-center gap-2">
          <MultiSelectDropdown<DiscoverSource>
            label="Source"
            options={DISCOVER_SOURCES}
            selected={filter.sources}
            onToggle={(val) =>
              onChange({
                ...filter,
                sources: toggleValue(filter.sources, val),
                page: 1,
              })
            }
          />

          <MultiSelectDropdown<DiscoverContentType>
            label="Content Type"
            options={DISCOVER_CONTENT_TYPES}
            selected={filter.contentTypes}
            onToggle={(val) =>
              onChange({
                ...filter,
                contentTypes: toggleValue(filter.contentTypes, val),
                page: 1,
              })
            }
          />

          <MultiSelectDropdown<DiscoverTechnology>
            label="Technology"
            options={DISCOVER_TECHNOLOGIES}
            selected={filter.technologies}
            onToggle={(val) =>
              onChange({
                ...filter,
                technologies: toggleValue(filter.technologies, val),
                page: 1,
              })
            }
          />

          {hasActiveFilters && (
            <button
              type="button"
              onClick={onClearAll}
              className="px-2.5 py-1.5 text-xs font-medium text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100 rounded-lg cursor-pointer transition-colors"
            >
              Clear All
            </button>
          )}
        </div>

        <span className="text-xs font-mono tabular-nums text-zinc-500">
          {totalMatches.toLocaleString()} items
        </span>
      </div>

      {/* Active Removable Filter Chips */}
      {(filter.sources.length > 0 ||
        filter.contentTypes.length > 0 ||
        filter.technologies.length > 0) && (
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {filter.sources.map((src) => (
            <button
              key={`src-${src}`}
              type="button"
              onClick={() =>
                onChange({
                  ...filter,
                  sources: filter.sources.filter((x) => x !== src),
                  page: 1,
                })
              }
              className="inline-flex items-center gap-1 rounded-md border border-zinc-200 bg-zinc-50 px-2 py-0.5 text-[11px] text-zinc-700 hover:bg-zinc-100 cursor-pointer"
            >
              <span className="text-zinc-400">Source:</span>
              <span className="font-medium text-[#09090B]">{src}</span>
              <X className="w-3 h-3 text-zinc-400" aria-hidden="true" />
            </button>
          ))}
          {filter.contentTypes.map((ct) => (
            <button
              key={`ct-${ct}`}
              type="button"
              onClick={() =>
                onChange({
                  ...filter,
                  contentTypes: filter.contentTypes.filter((x) => x !== ct),
                  page: 1,
                })
              }
              className="inline-flex items-center gap-1 rounded-md border border-zinc-200 bg-zinc-50 px-2 py-0.5 text-[11px] text-zinc-700 hover:bg-zinc-100 cursor-pointer"
            >
              <span className="text-zinc-400">Type:</span>
              <span className="font-medium text-[#09090B]">{ct}</span>
              <X className="w-3 h-3 text-zinc-400" aria-hidden="true" />
            </button>
          ))}
          {filter.technologies.map((tech) => (
            <button
              key={`tech-${tech}`}
              type="button"
              onClick={() =>
                onChange({
                  ...filter,
                  technologies: filter.technologies.filter((x) => x !== tech),
                  page: 1,
                })
              }
              className="inline-flex items-center gap-1 rounded-md border border-blue-200 bg-blue-50/50 px-2 py-0.5 text-[11px] text-blue-900 hover:bg-blue-100/70 cursor-pointer"
            >
              <span className="text-blue-600">Tech:</span>
              <span className="font-medium">{tech}</span>
              <X className="w-3 h-3 text-blue-500" aria-hidden="true" />
            </button>
          ))}
        </div>
      )}
    </section>
  );
};
