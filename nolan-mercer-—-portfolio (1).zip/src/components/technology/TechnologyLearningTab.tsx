import React, { useMemo, useState } from 'react';
import {
  BookOpen,
  ExternalLink,
  Plus,
  RefreshCw,
  Search,
  Star,
  Trash2,
} from 'lucide-react';
import {
  LearningContentKind,
  LearningItem,
  LearningProgressStatus,
  TechSource,
} from '../../types/technology';
import {
  addManualLearningItem,
  deleteLearningItemById,
  setLearningItemStatus,
  syncTechnologyByContentType,
  toggleLearningFavorite,
} from '../../services/technology/syncEngine';
import { formatTechDate } from '../../services/technology/retentionEngine';

interface TechnologyLearningTabProps {
  items: LearningItem[];
  sources: TechSource[];
  onDataChanged: () => void;
}

type LearningSubTab =
  | 'all'
  | 'course'
  | 'tutorial'
  | 'lab'
  | 'learning-path'
  | 'documentation'
  | 'saved'
  | 'archive';

const SUB_TABS: Array<{ key: LearningSubTab; label: string }> = [
  { key: 'all', label: 'All Learning' },
  { key: 'course', label: 'Courses' },
  { key: 'tutorial', label: 'Tutorials' },
  { key: 'lab', label: 'Labs' },
  { key: 'learning-path', label: 'Learning Paths' },
  { key: 'documentation', label: 'Documentation' },
  { key: 'saved', label: 'Saved' },
  { key: 'archive', label: 'Archive' },
];

export const TechnologyLearningTab: React.FC<TechnologyLearningTabProps> = ({
  items,
  sources,
  onDataChanged,
}) => {
  const [subTab, setSubTab] = useState<LearningSubTab>('all');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | LearningProgressStatus>('all');
  const [isSyncing, setIsSyncing] = useState(false);
  const [showManual, setShowManual] = useState(false);

  const [title, setTitle] = useState('');
  const [platform, setPlatform] = useState('Red Hat Learning');
  const [url, setUrl] = useState('');
  const [category, setCategory] = useState('OpenShift');
  const [kind, setKind] = useState<LearningContentKind>('lab');
  const [level, setLevel] = useState('Intermediate');
  const [duration, setDuration] = useState('');
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const learningSources = useMemo(
    () => sources.filter((s) => s.contentType === 'learning'),
    [sources]
  );

  const unsupportedPortals = useMemo(
    () => learningSources.filter((s) => s.sourceType === 'unsupported'),
    [learningSources]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return items
      .filter((item) => {
        if (subTab === 'archive') {
          if (!item.isArchived) return false;
        } else {
          if (item.isArchived && subTab !== 'saved') return false;
          if (subTab === 'saved' && !item.isFavorite) return false;
          if (
            subTab !== 'all' &&
            subTab !== 'saved' &&
            item.contentType !== subTab
          ) {
            return false;
          }
        }
        if (statusFilter !== 'all' && item.learningStatus !== statusFilter)
          return false;
        if (q) {
          const hay = [
            item.title,
            item.description,
            item.platform,
            item.category,
            ...item.tags,
          ]
            .join(' ')
            .toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort(
        (a, b) =>
          Date.parse(b.publishedAt || b.fetchedAt) -
          Date.parse(a.publishedAt || a.fetchedAt)
      );
  }, [items, search, statusFilter, subTab]);

  const handleSync = async () => {
    setIsSyncing(true);
    try {
      await syncTechnologyByContentType('learning');
      onDataChanged();
    } finally {
      setIsSyncing(false);
    }
  };

  const handleAddManual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !url.trim()) return;
    await addManualLearningItem({
      title,
      platform,
      url,
      category,
      contentType: kind,
      level,
      duration,
    });
    setTitle('');
    setUrl('');
    setDuration('');
    setShowManual(false);
    onDataChanged();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 pb-3">
        <div className="flex flex-wrap items-center gap-1">
          {SUB_TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setSubTab(t.key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                subTab === t.key
                  ? 'bg-[#09090B] text-white'
                  : 'text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowManual((p) => !p)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white hover:bg-zinc-50 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Course / Lab</span>
          </button>
          <button
            type="button"
            onClick={handleSync}
            disabled={isSyncing}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`}
            />
            <span>{isSyncing ? 'Syncing...' : 'Sync Learning Feeds'}</span>
          </button>
        </div>
      </div>

      {/* Unsupported interactive lab portals */}
      {unsupportedPortals.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {unsupportedPortals.map((portal) => (
            <div
              key={portal.id}
              className="rounded-xl bg-white border border-zinc-200 p-4 flex items-start justify-between gap-3"
            >
              <div className="space-y-1">
                <p className="text-xs font-semibold text-[#09090B]">
                  {portal.name} · Manual Portal
                </p>
                <p className="text-[11px] text-zinc-500">
                  {portal.errorMessage}
                </p>
              </div>
              <a
                href={portal.websiteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 hover:bg-zinc-50 text-[#2563EB] shrink-0 whitespace-nowrap"
              >
                <span>Open Portal</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          ))}
        </div>
      )}

      {showManual && (
        <form
          onSubmit={handleAddManual}
          className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3"
        >
          <h3 className="font-display text-sm font-semibold text-[#09090B]">
            Add Manual Course, Lab, or Documentation
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Title (e.g. DO280 OpenShift Administration)"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              value={platform}
              onChange={(e) => setPlatform(e.target.value)}
              placeholder="Platform (e.g. Red Hat Learning / Killercoda)"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="url"
              required
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://..."
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <select
              value={kind}
              onChange={(e) => setKind(e.target.value as LearningContentKind)}
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            >
              <option value="course">Course</option>
              <option value="tutorial">Tutorial</option>
              <option value="lab">Lab</option>
              <option value="learning-path">Learning Path</option>
              <option value="documentation">Documentation</option>
            </select>
            <input
              type="text"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              placeholder="Category"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              value={level}
              onChange={(e) => setLevel(e.target.value)}
              placeholder="Level (Beginner / Intermediate / Advanced)"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              placeholder="Duration (optional, e.g. 4h)"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <div className="flex items-center gap-2">
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white cursor-pointer"
              >
                Save Item
              </button>
              <button
                type="button"
                onClick={() => setShowManual(false)}
                className="px-3 py-2 text-xs rounded-lg border border-zinc-200 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Search & Progress Filter */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search courses, labs, tutorials..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
          />
        </div>
        <select
          aria-label="Filter by learning progress"
          value={statusFilter}
          onChange={(e) =>
            setStatusFilter(e.target.value as 'all' | LearningProgressStatus)
          }
          className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
        >
          <option value="all">All Statuses</option>
          <option value="not-started">Not Started</option>
          <option value="in-progress">In Progress</option>
          <option value="completed">Completed</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl bg-white border border-zinc-200 p-8 text-center space-y-2">
          <BookOpen className="w-7 h-7 text-zinc-400 mx-auto" />
          <p className="text-sm font-medium text-[#09090B]">
            No learning items match this view.
          </p>
          <p className="text-xs text-zinc-500">
            Click Sync Learning Feeds for freeCodeCamp, KodeKloud, and TechWorld with Nana, or add Red Hat Learning / Killercoda labs manually.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((item) => (
            <article
              key={item.id}
              className="rounded-xl bg-white border border-zinc-200 p-4 flex flex-col justify-between gap-3"
            >
              <div className="space-y-1.5">
                <p className="text-[11px] text-zinc-500 flex items-center gap-1.5 flex-wrap">
                  <span className="font-medium text-[#2563EB]">
                    {item.platform}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="capitalize">{item.contentType.replace('-', ' ')}</span>
                  {item.level && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>{item.level}</span>
                    </>
                  )}
                  {item.duration && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{item.duration}</span>
                    </>
                  )}
                </p>
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-display text-sm font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-2 block"
                >
                  {item.title}
                </a>
                {item.description && (
                  <p className="text-xs text-zinc-600 line-clamp-2">
                    {item.description}
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-zinc-100 flex items-center justify-between gap-2">
                <select
                  aria-label={`Progress for ${item.title}`}
                  value={item.learningStatus}
                  onChange={async (e) => {
                    await setLearningItemStatus(
                      item.id,
                      e.target.value as LearningProgressStatus
                    );
                    onDataChanged();
                  }}
                  className={`px-2 py-1 text-[11px] font-medium rounded border cursor-pointer ${
                    item.learningStatus === 'completed'
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                      : item.learningStatus === 'in-progress'
                        ? 'border-blue-200 bg-blue-50 text-[#2563EB]'
                        : 'border-zinc-200 bg-white text-zinc-700'
                  }`}
                >
                  <option value="not-started">Not Started</option>
                  <option value="in-progress">In Progress</option>
                  <option value="completed">Completed</option>
                </select>

                <div className="flex items-center gap-1">
                  <span className="text-[11px] font-mono tabular-nums text-zinc-400 mr-1">
                    {formatTechDate(item.publishedAt)}
                  </span>
                  <button
                    type="button"
                    onClick={async () => {
                      await toggleLearningFavorite(item.id);
                      onDataChanged();
                    }}
                    aria-label="Favorite learning item"
                    className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                      item.isFavorite ? 'text-amber-500' : 'text-zinc-400'
                    }`}
                  >
                    <Star
                      className="w-3.5 h-3.5"
                      fill={item.isFavorite ? 'currentColor' : 'none'}
                    />
                  </button>
                  {pendingDeleteId === item.id ? (
                    <button
                      type="button"
                      onClick={async () => {
                        await deleteLearningItemById(item.id);
                        setPendingDeleteId(null);
                        onDataChanged();
                      }}
                      className="px-2 py-0.5 text-[11px] bg-red-600 text-white rounded cursor-pointer"
                    >
                      Confirm
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setPendingDeleteId(item.id)}
                      aria-label="Delete learning item"
                      className="p-1.5 rounded hover:bg-zinc-100 text-zinc-400 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
};
