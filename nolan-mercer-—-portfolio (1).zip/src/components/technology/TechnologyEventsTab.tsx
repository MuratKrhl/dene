import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Calendar,
  Clock,
  ExternalLink,
  Globe,
  MapPin,
  Plus,
  RefreshCw,
  Search,
  Star,
  Trash2,
} from 'lucide-react';
import {
  TechEvent,
  TechEventAttendanceMode,
  TechEventType,
} from '../../types/technology';
import {
  MediaSourceDto,
  createManualMediaEvent,
  deleteMediaEvent,
  patchMediaEvent,
  syncMediaByTypeApi,
} from '../../services/techMediaApi';
import { formatTechDate } from '../../services/technology/retentionEngine';

interface TechnologyEventsTabProps {
  events: TechEvent[];
  sources: MediaSourceDto[];
  onDataChanged: () => Promise<void> | void;
}

type EventsSubTab =
  | 'upcoming'
  | 'conferences'
  | 'webinars'
  | 'unverified'
  | 'past'
  | 'saved';

const SUB_TABS: Array<{ key: EventsSubTab; label: string }> = [
  { key: 'upcoming', label: 'Upcoming & Active' },
  { key: 'conferences', label: 'Conferences' },
  { key: 'webinars', label: 'Webinars' },
  { key: 'unverified', label: 'Unverified' },
  { key: 'past', label: 'Past Events' },
  { key: 'saved', label: 'Saved' },
];

export const TechnologyEventsTab: React.FC<TechnologyEventsTabProps> = ({
  events,
  sources,
  onDataChanged,
}) => {
  const [subTab, setSubTab] = useState<EventsSubTab>('upcoming');
  const [search, setSearch] = useState('');
  const [attendanceFilter, setAttendanceFilter] = useState<
    'all' | TechEventAttendanceMode
  >('all');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncNotice, setSyncNotice] = useState<string | null>(null);
  const [showManual, setShowManual] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const [eventName, setEventName] = useState('');
  const [organizer, setOrganizer] = useState('CNCF / Red Hat');
  const [startDate, setStartDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endDate, setEndDate] = useState('');
  const [timezone, setTimezone] = useState('UTC');
  const [attendanceMode, setAttendanceMode] =
    useState<TechEventAttendanceMode>('online');
  const [location, setLocation] = useState('');
  const [eventType, setEventType] = useState<TechEventType>('conference');
  const [registrationUrl, setRegistrationUrl] = useState('');
  const [description, setDescription] = useState('');

  const manualPortals = useMemo(
    () =>
      sources.filter(
        (s) =>
          s.contentType === 'event' &&
          (s.sourceType === 'manual' ||
            s.sourceType === 'unsupported' ||
            s.verificationStatus === 'unverified')
      ),
    [sources]
  );

  const counts = useMemo(
    () => ({
      upcoming: events.filter(
        (e) =>
          !e.isArchived &&
          e.status !== 'past' &&
          e.verificationStatus !== 'unverified' &&
          e.status !== 'unverified'
      ).length,
      unverified: events.filter(
        (e) => e.verificationStatus === 'unverified' || e.status === 'unverified'
      ).length,
      past: events.filter((e) => e.status === 'past' || e.isArchived).length,
    }),
    [events]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return events
      .filter((e) => {
        if (subTab === 'saved' && !e.isFavorite) return false;
        if (subTab === 'past' && e.status !== 'past' && !e.isArchived)
          return false;
        if (
          subTab === 'unverified' &&
          e.verificationStatus !== 'unverified' &&
          e.status !== 'unverified'
        ) {
          return false;
        }
        if (
          subTab === 'upcoming' &&
          (e.status === 'past' ||
            e.isArchived ||
            e.verificationStatus === 'unverified' ||
            e.status === 'unverified')
        ) {
          return false;
        }
        if (
          subTab === 'conferences' &&
          e.eventType !== 'conference' &&
          e.eventType !== 'summit'
        ) {
          return false;
        }
        if (subTab === 'webinars' && e.eventType !== 'webinar') return false;
        if (
          attendanceFilter !== 'all' &&
          (e.attendanceMode || 'unknown') !== attendanceFilter
        ) {
          return false;
        }
        if (q) {
          const hay = [
            e.eventName,
            e.organizer,
            e.location || '',
            e.description,
            e.timezone || '',
          ]
            .join(' ')
            .toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => {
        const aMs = Date.parse(a.startDate || a.publishedAt || a.fetchedAt) || 0;
        const bMs = Date.parse(b.startDate || b.publishedAt || b.fetchedAt) || 0;
        return subTab === 'upcoming' ? aMs - bMs : bMs - aMs;
      });
  }, [attendanceFilter, events, search, subTab]);

  const handleSync = async () => {
    setIsSyncing(true);
    setSyncNotice(null);
    try {
      const outcome = await syncMediaByTypeApi('event');
      await onDataChanged();
      const newCount = outcome.results.reduce((s, r) => s + r.newItems, 0);
      setSyncNotice(
        outcome.skippedDueToLock
          ? 'Etkinlik senkronizasyonu zaten çalışıyor.'
          : `Etkinlik kaynakları senkronize edildi (${newCount} yeni etkinlik). Geçmiş etkinlikler otomatik Past Events alanına taşındı.`
      );
    } catch (err) {
      setSyncNotice(
        err instanceof Error ? err.message : 'Etkinlik senkronizasyonu başarısız.'
      );
    } finally {
      setIsSyncing(false);
    }
  };

  const handleAddManual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventName.trim()) return;
    try {
      await createManualMediaEvent({
        eventName,
        organizer,
        startDate: startDate || undefined,
        startTime: startTime || undefined,
        endDate: endDate || undefined,
        timezone: timezone || undefined,
        attendanceMode,
        location: location || undefined,
        eventType,
        registrationUrl,
        description,
      });
      setEventName('');
      setStartDate('');
      setStartTime('');
      setEndDate('');
      setLocation('');
      setRegistrationUrl('');
      setDescription('');
      setShowManual(false);
      await onDataChanged();
    } catch (err) {
      setSyncNotice(
        err instanceof Error ? err.message : 'Etkinlik kaydedilemedi.'
      );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 pb-3">
        <div className="flex flex-wrap items-center gap-1">
          {SUB_TABS.map((t) => {
            const countSuffix =
              t.key === 'upcoming'
                ? ` (${counts.upcoming})`
                : t.key === 'unverified' && counts.unverified > 0
                  ? ` (${counts.unverified})`
                  : t.key === 'past' && counts.past > 0
                    ? ` (${counts.past})`
                    : '';
            return (
              <button
                key={t.key}
                type="button"
                onClick={() => setSubTab(t.key)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  subTab === t.key
                    ? 'bg-[#09090B] text-white'
                    : 'text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100'
                }`}
              >
                {t.label}
                {countSuffix}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowManual((p) => !p)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 bg-white hover:bg-zinc-50 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Event</span>
          </button>
          <button
            type="button"
            onClick={handleSync}
            disabled={isSyncing}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`}
            />
            <span>{isSyncing ? 'Syncing...' : 'Sync Event Sources'}</span>
          </button>
        </div>
      </div>

      {syncNotice && (
        <div className="rounded-lg bg-zinc-50 border border-zinc-200 px-4 py-2.5 text-xs text-zinc-800 flex items-center justify-between gap-2">
          <span>{syncNotice}</span>
          <button
            type="button"
            onClick={() => setSyncNotice(null)}
            className="underline font-medium cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {manualPortals.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {manualPortals.map((portal) => (
            <div
              key={portal.id}
              className="rounded-xl bg-white border border-zinc-200 p-4 flex items-start justify-between gap-3"
            >
              <div className="space-y-1">
                <p className="text-xs font-semibold text-[#09090B]">
                  {portal.name} · Portal Only (Unverified)
                </p>
                <p className="text-[11px] text-zinc-500 leading-relaxed">
                  {portal.verificationNote || portal.description}
                </p>
              </div>
              {portal.websiteUrl && (
                <a
                  href={portal.websiteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-medium text-[#2563EB] hover:underline shrink-0"
                >
                  <span>Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          ))}
        </div>
      )}

      {showManual && (
        <form
          onSubmit={handleAddManual}
          className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3"
        >
          <h3 className="font-display text-sm font-semibold text-[#09090B]">
            Add Event (Events missing date or registration URL are marked Unverified)
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <input
              type="text"
              required
              value={eventName}
              onChange={(e) => setEventName(e.target.value)}
              placeholder="Event name *"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              required
              value={organizer}
              onChange={(e) => setOrganizer(e.target.value)}
              placeholder="Organizer (e.g. CNCF / AWS / Red Hat)"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <select
              value={eventType}
              onChange={(e) => setEventType(e.target.value as TechEventType)}
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            >
              <option value="conference">Conference</option>
              <option value="webinar">Webinar</option>
              <option value="summit">Summit</option>
              <option value="meetup">Meetup</option>
            </select>
            <input
              type="date"
              aria-label="Start date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              placeholder="Time (e.g. 14:00)"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              value={timezone}
              onChange={(e) => setTimezone(e.target.value)}
              placeholder="Timezone (e.g. UTC, Europe/Istanbul)"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <select
              aria-label="Attendance mode"
              value={attendanceMode}
              onChange={(e) =>
                setAttendanceMode(e.target.value as TechEventAttendanceMode)
              }
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            >
              <option value="online">Online</option>
              <option value="physical">Physical</option>
              <option value="hybrid">Hybrid</option>
            </select>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Location (Virtual / City)"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="date"
              aria-label="End date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="url"
              value={registrationUrl}
              onChange={(e) => setRegistrationUrl(e.target.value)}
              placeholder="Registration / Official URL"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200 sm:col-span-2"
            />
            <div className="flex items-center gap-2">
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white cursor-pointer"
              >
                Save Event
              </button>
              <button
                type="button"
                onClick={() => setShowManual(false)}
                className="px-3 py-2 text-xs rounded-lg border border-zinc-200 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Agenda or description..."
            rows={2}
            className="w-full px-3 py-2 text-xs rounded-lg border border-zinc-200"
          />
        </form>
      )}

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px] max-w-md">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search events, organizers, locations..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
          />
        </div>

        <select
          aria-label="Filter by attendance mode"
          value={attendanceFilter}
          onChange={(e) =>
            setAttendanceFilter(e.target.value as 'all' | TechEventAttendanceMode)
          }
          className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
        >
          <option value="all">All Formats</option>
          <option value="online">Online</option>
          <option value="physical">Physical</option>
          <option value="hybrid">Hybrid</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl bg-white border border-zinc-200 p-8 text-center space-y-2">
          <Calendar className="w-7 h-7 text-zinc-400 mx-auto" />
          <p className="text-sm font-medium text-[#09090B]">
            No events recorded in this section.
          </p>
          <p className="text-xs text-zinc-500">
            Sync CNCF Community API, iCal (.ics), or official event feeds. Dates and registration links are never fabricated.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((evt) => {
            const isUnverified =
              evt.verificationStatus === 'unverified' || evt.status === 'unverified';
            return (
              <article
                key={evt.id}
                className="rounded-xl bg-white border border-zinc-200 p-4 flex flex-col justify-between gap-3"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2 text-[11px] text-zinc-500">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-medium text-[#2563EB]">
                        {evt.organizer}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{evt.eventType}</span>
                      {evt.attendanceMode && evt.attendanceMode !== 'unknown' && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="capitalize inline-flex items-center gap-1">
                            <Globe className="w-3 h-3" />
                            {evt.attendanceMode}
                          </span>
                        </>
                      )}
                    </div>

                    <span
                      className={`text-[11px] font-medium capitalize shrink-0 ${
                        isUnverified
                          ? 'text-amber-700 inline-flex items-center gap-1'
                          : evt.status === 'past'
                            ? 'text-zinc-500'
                            : 'text-emerald-700'
                      }`}
                    >
                      {isUnverified && (
                        <AlertTriangle className="w-3 h-3" aria-hidden="true" />
                      )}
                      {isUnverified ? 'Unverified' : evt.status}
                    </span>
                  </div>

                  <a
                    href={evt.registrationUrl || evt.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-display text-base font-semibold text-[#09090B] hover:text-[#2563EB] block"
                  >
                    {evt.eventName}
                  </a>

                  {evt.description && (
                    <p className="text-xs text-zinc-600 line-clamp-2">
                      {evt.description}
                    </p>
                  )}

                  {isUnverified && evt.verificationNote && (
                    <p className="text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded px-2.5 py-1.5">
                      {evt.verificationNote}
                    </p>
                  )}
                </div>

                <div className="pt-3 border-t border-zinc-100 flex items-center justify-between gap-2 text-xs text-zinc-500">
                  <div className="flex items-center gap-3 flex-wrap font-mono tabular-nums text-[11px]">
                    <span className="inline-flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {evt.startDate
                        ? `${formatTechDate(evt.startDate)}${evt.endDate ? ` – ${formatTechDate(evt.endDate)}` : ''}`
                        : 'Tarih doğrulanmadı'}
                    </span>
                    {evt.startTime && (
                      <span className="inline-flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {evt.startTime}
                      </span>
                    )}
                    {evt.location && (
                      <span className="inline-flex items-center gap-1 font-sans">
                        <MapPin className="w-3 h-3" />
                        {evt.location}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={async () => {
                        await patchMediaEvent(evt.id, {
                          isFavorite: !evt.isFavorite,
                        });
                        await onDataChanged();
                      }}
                      aria-label="Save event"
                      className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                        evt.isFavorite ? 'text-amber-500' : 'text-zinc-400'
                      }`}
                    >
                      <Star
                        className="w-3.5 h-3.5"
                        fill={evt.isFavorite ? 'currentColor' : 'none'}
                      />
                    </button>
                    {pendingDeleteId === evt.id ? (
                      <button
                        type="button"
                        onClick={async () => {
                          await deleteMediaEvent(evt.id);
                          setPendingDeleteId(null);
                          await onDataChanged();
                        }}
                        className="px-2 py-0.5 text-[11px] bg-red-600 text-white rounded cursor-pointer"
                      >
                        Confirm
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setPendingDeleteId(evt.id)}
                        aria-label="Delete event"
                        className="p-1.5 rounded hover:bg-zinc-100 text-zinc-400 hover:text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <a
                      href={evt.registrationUrl || evt.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label="Open registration or source URL"
                      className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500 hover:text-[#2563EB]"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
