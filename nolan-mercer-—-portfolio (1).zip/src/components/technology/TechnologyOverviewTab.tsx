import React, { useMemo } from 'react';
import {
  ArrowUpRight,
  ExternalLink,
  FileText,
  GitBranch,
  Play,
  ShieldAlert,
  Sparkles,
  Star,
} from 'lucide-react';
import { GitHubRepository } from '../../github/types';
import { loadOneNoteFiles } from '../../services/oneNoteStore';
import {
  buildPersonalizedRecommendations,
  buildUnifiedDiscoverFeed,
  filterAndSortUnifiedFeed,
  DEFAULT_DISCOVER_FILTER,
  UnifiedFeedItem,
} from '../../services/technology/discoverFeed';
import { formatTechDate } from '../../services/technology/retentionEngine';
import { usePodcastPlayer } from '../../context/PodcastPlayerContext';
import { AggregatedArticle } from '../../types/article';
import { ArticleSource } from '../../types/articleSource';
import {
  LearningItem,
  PodcastEpisode,
  PodcastSeries,
  SecurityRecord,
  TechEvent,
  TechSource,
  TechSubTab,
  TechVideo,
} from '../../types/technology';
import { MediaSourceDto } from '../../services/techMediaApi';
import { SourceBadge } from './SourceBadge';

interface TechnologyOverviewTabProps {
  articles: AggregatedArticle[];
  articleSources: ArticleSource[];
  techSources: TechSource[];
  mediaSources?: MediaSourceDto[];
  videos: TechVideo[];
  podcastSeries: PodcastSeries[];
  podcastEpisodes: PodcastEpisode[];
  learningItems: LearningItem[];
  securityRecords: SecurityRecord[];
  events: TechEvent[];
  githubRepos: GitHubRepository[];
  savedGithubRepoIds: number[];
  onSelectSubTab: (tab: TechSubTab, discoverQuery?: string) => void;
  onNavigate: (path: string) => void;
}

export const TechnologyOverviewTab: React.FC<TechnologyOverviewTabProps> = ({
  articles,
  articleSources,
  techSources,
  mediaSources = [],
  videos,
  podcastSeries,
  podcastEpisodes,
  learningItems,
  securityRecords,
  events,
  githubRepos,
  savedGithubRepoIds,
  onSelectSubTab,
  onNavigate,
}) => {
  const { playEpisode } = usePodcastPlayer();

  const recentOneNotes = useMemo(() => loadOneNoteFiles().slice(0, 4), []);

  const topGithubRepos = useMemo(
    () =>
      githubRepos
        .slice()
        .sort((a, b) => b.stargazersCount - a.stargazersCount)
        .slice(0, 4),
    [githubRepos]
  );

  const unifiedItems = useMemo(
    () =>
      buildUnifiedDiscoverFeed({
        articles,
        videos,
        podcastEpisodes,
        githubRepos,
        savedGithubRepoIds,
        learningItems,
        securityRecords,
        events,
      }),
    [
      articles,
      events,
      githubRepos,
      learningItems,
      podcastEpisodes,
      savedGithubRepoIds,
      securityRecords,
      videos,
    ]
  );

  const recent30dItems = useMemo(
    () =>
      filterAndSortUnifiedFeed(unifiedItems, {
        ...DEFAULT_DISCOVER_FILTER,
        dateRange: '30d',
      }),
    [unifiedItems]
  );

  const kpis = useMemo(() => {
    const nonMediaTechSources = techSources.filter(
      (s) => s.contentType === 'learning' || s.contentType === 'security'
    );

    const activeSourcesCount =
      articleSources.filter((s) => s.enabled && s.sourceType !== 'unsupported')
        .length +
      nonMediaTechSources.filter(
        (s) =>
          s.enabled &&
          s.sourceType !== 'unsupported' &&
          s.sourceType !== 'manual'
      ).length +
      mediaSources.filter(
        (s) =>
          s.enabled &&
          s.verificationStatus === 'verified' &&
          s.sourceType !== 'unsupported' &&
          s.sourceType !== 'manual'
      ).length;

    const failedSourcesCount =
      articleSources.filter(
        (s) => s.enabled && s.status === 'error' && s.sourceType !== 'unsupported'
      ).length +
      nonMediaTechSources.filter(
        (s) =>
          s.enabled &&
          s.status === 'error' &&
          s.sourceType !== 'unsupported' &&
          s.sourceType !== 'manual'
      ).length +
      mediaSources.filter(
        (s) =>
          s.enabled &&
          (s.verificationStatus === 'error' || Boolean(s.lastError))
      ).length;

    return {
      totalContent: unifiedItems.length,
      newContent30d: recent30dItems.length,
      activeSources: activeSourcesCount,
      failedSources: failedSourcesCount,
    };
  }, [
    articleSources,
    mediaSources,
    recent30dItems.length,
    techSources,
    unifiedItems.length,
  ]);

  // Pick 1 featured spotlight item (preferring fresh Official Blog, Article, or Podcast)
  const featuredItem = useMemo<UnifiedFeedItem | null>(() => {
    const preferred = recent30dItems.find(
      (i) =>
        !i.isConsumed &&
        (i.sourceGroup === 'Official Engineering Blogs' ||
          i.sourceGroup === 'Medium' ||
          i.sourceGroup === 'Podcasts' ||
          i.sourceGroup === 'YouTube')
    );
    return preferred || recent30dItems[0] || unifiedItems[0] || null;
  }, [recent30dItems, unifiedItems]);

  // Latest Updates: 6 diverse recent items excluding the featured spotlight
  const latestUpdates = useMemo(() => {
    const pool = recent30dItems.filter((i) => i.id !== featuredItem?.id);
    const picked: UnifiedFeedItem[] = [];
    const perSourceCount = new Map<string, number>();

    for (const item of pool) {
      const count = perSourceCount.get(item.sourceGroup) || 0;
      if (count >= 2 && pool.length > 8) continue;
      picked.push(item);
      perSourceCount.set(item.sourceGroup, count + 1);
      if (picked.length >= 6) break;
    }
    if (picked.length < 6) {
      for (const item of pool) {
        if (!picked.some((p) => p.id === item.id)) {
          picked.push(item);
          if (picked.length >= 6) break;
        }
      }
    }
    return picked;
  }, [featuredItem?.id, recent30dItems]);

  const recommendations = useMemo(
    () => buildPersonalizedRecommendations(unifiedItems, podcastSeries, 4),
    [podcastSeries, unifiedItems]
  );

  const securityHighlights = useMemo(
    () =>
      securityRecords
        .filter((s) => !s.isArchived)
        .slice()
        .sort(
          (a, b) =>
            Date.parse(b.publishedAt || b.fetchedAt) -
            Date.parse(a.publishedAt || a.fetchedAt)
        )
        .slice(0, 4),
    [securityRecords]
  );

  const openFeedItem = (item: UnifiedFeedItem) => {
    if (item.internalPath) {
      onNavigate(item.internalPath);
    } else if (item.kind === 'podcast' && item.podcastEpisode) {
      playEpisode(item.podcastEpisode, podcastEpisodes);
    } else {
      window.open(item.url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="space-y-6">
      {/* Strictly 4 Equal-Weight KPIs */}
      <section
        aria-label="Technology Hub summary metrics"
        className="grid grid-cols-2 lg:grid-cols-4 gap-4"
      >
        <button
          type="button"
          onClick={() => onSelectSubTab('discover', '?range=all')}
          className="text-left rounded-xl bg-white border border-zinc-200 px-5 py-4 hover:border-zinc-300 transition-colors cursor-pointer"
        >
          <p className="text-xs font-medium text-zinc-500">Total Content</p>
          <p className="mt-1.5 text-2xl font-bold font-mono tabular-nums text-[#09090B]">
            {kpis.totalContent.toLocaleString()}
          </p>
          <p className="mt-1 text-[11px] text-zinc-400">
            Indexed across all streams
          </p>
        </button>

        <button
          type="button"
          onClick={() => onSelectSubTab('discover', '?range=30d')}
          className="text-left rounded-xl bg-white border border-zinc-200 px-5 py-4 hover:border-zinc-300 transition-colors cursor-pointer"
        >
          <p className="text-xs font-medium text-zinc-500">New Content (30d)</p>
          <p className="mt-1.5 text-2xl font-bold font-mono tabular-nums text-[#09090B]">
            {kpis.newContent30d.toLocaleString()}
          </p>
          <p className="mt-1 text-[11px] text-zinc-400">
            Active rolling 30-day window
          </p>
        </button>

        <button
          type="button"
          onClick={() => onSelectSubTab('sources')}
          className="text-left rounded-xl bg-white border border-zinc-200 px-5 py-4 hover:border-zinc-300 transition-colors cursor-pointer"
        >
          <p className="text-xs font-medium text-zinc-500">Active Sources</p>
          <p className="mt-1.5 text-2xl font-bold font-mono tabular-nums text-[#09090B]">
            {kpis.activeSources}
          </p>
          <p className="mt-1 text-[11px] text-zinc-400">
            Enabled live feeds &amp; APIs
          </p>
        </button>

        <button
          type="button"
          onClick={() => onSelectSubTab('sources')}
          className="text-left rounded-xl bg-white border border-zinc-200 px-5 py-4 hover:border-zinc-300 transition-colors cursor-pointer"
        >
          <p className="text-xs font-medium text-zinc-500">Failed Sources</p>
          <p
            className={`mt-1.5 text-2xl font-bold font-mono tabular-nums ${
              kpis.failedSources > 0 ? 'text-red-600' : 'text-[#09090B]'
            }`}
          >
            {kpis.failedSources}
          </p>
          <p className="mt-1 text-[11px] text-zinc-400">
            {kpis.failedSources > 0
              ? 'Inspect errors in Sources'
              : 'All enabled feeds nominal'}
          </p>
        </button>
      </section>

      {/* Balanced 2-Column Executive Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Main Column: Featured Intelligence, Latest Updates, Personalized Recommendations */}
        <div className="lg:col-span-8 space-y-6">
          {/* Featured Intelligence */}
          <section className="rounded-xl bg-white border border-zinc-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <h2 className="font-display text-sm font-semibold text-[#09090B]">
                Featured Intelligence
              </h2>
              <button
                type="button"
                onClick={() => onSelectSubTab('discover')}
                className="inline-flex items-center gap-1 text-xs font-medium text-[#2563EB] hover:underline cursor-pointer"
              >
                <span>Open Discover</span>
                <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>

            {!featuredItem ? (
              <p className="text-xs text-zinc-500 py-3">
                No intelligence items indexed yet. Click Refresh All above to sync your active sources.
              </p>
            ) : (
              <div className="space-y-3 pt-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <SourceBadge
                    sourceGroup={featuredItem.sourceGroup}
                    sourceName={featuredItem.sourceName}
                  />
                  <span className="text-[11px] font-medium text-[#2563EB]">
                    {featuredItem.contentType}
                  </span>
                  <span className="text-zinc-300" aria-hidden="true">
                    ·
                  </span>
                  <span className="text-[11px] font-mono tabular-nums text-zinc-500">
                    {formatTechDate(
                      featuredItem.publishedAt || featuredItem.fetchedAt
                    )}
                  </span>
                </div>

                {featuredItem.internalPath ? (
                  <button
                    type="button"
                    onClick={() => onNavigate(featuredItem.internalPath!)}
                    className="text-left font-display text-lg font-bold text-[#09090B] hover:text-[#2563EB] transition-colors cursor-pointer block"
                  >
                    {featuredItem.title}
                  </button>
                ) : (
                  <a
                    href={featuredItem.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-display text-lg font-bold text-[#09090B] hover:text-[#2563EB] transition-colors block"
                  >
                    {featuredItem.title}
                  </a>
                )}

                {featuredItem.description && (
                  <p className="text-xs sm:text-sm text-zinc-600 line-clamp-2 leading-relaxed">
                    {featuredItem.description}
                  </p>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {featuredItem.technologies.slice(0, 3).map((tech) => (
                      <button
                        key={tech}
                        type="button"
                        onClick={() =>
                          onSelectSubTab(
                            'discover',
                            `?tech=${encodeURIComponent(tech)}`
                          )
                        }
                        className="rounded border border-zinc-200 bg-zinc-50 px-2 py-0.5 text-[11px] font-medium text-zinc-700 hover:bg-zinc-100 cursor-pointer"
                      >
                        {tech}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2">
                    {featuredItem.kind === 'podcast' &&
                      featuredItem.podcastEpisode && (
                        <button
                          type="button"
                          onClick={() =>
                            playEpisode(
                              featuredItem.podcastEpisode!,
                              podcastEpisodes
                            )
                          }
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Listen Episode</span>
                        </button>
                      )}
                    {featuredItem.internalPath ? (
                      <button
                        type="button"
                        onClick={() => onNavigate(featuredItem.internalPath!)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#2563EB] hover:underline cursor-pointer"
                      >
                        <span>Read Detail</span>
                        <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    ) : (
                      <a
                        href={featuredItem.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#2563EB] hover:underline"
                      >
                        <span>Open Source</span>
                        <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            )}
          </section>

          {/* Latest Updates */}
          <section className="rounded-xl bg-white border border-zinc-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div>
                <h2 className="font-display text-sm font-semibold text-[#09090B]">
                  Latest Updates
                </h2>
                <p className="text-[11px] text-zinc-500">
                  Cross-source engineering activity from the last 30 days
                </p>
              </div>
              <button
                type="button"
                onClick={() => onSelectSubTab('discover')}
                className="inline-flex items-center gap-1 text-xs font-medium text-[#2563EB] hover:underline cursor-pointer whitespace-nowrap"
              >
                <span>View All</span>
                <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>

            {latestUpdates.length === 0 ? (
              <p className="text-xs text-zinc-500 py-3">
                No recent updates synced yet.
              </p>
            ) : (
              <div className="divide-y divide-zinc-100">
                {latestUpdates.map((item) => (
                  <div
                    key={item.id}
                    className="py-3 flex items-start justify-between gap-4"
                  >
                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <SourceBadge
                          sourceGroup={item.sourceGroup}
                          sourceName={item.sourceName}
                        />
                        <span className="text-[11px] text-zinc-500">
                          {item.contentType}
                        </span>
                        <span className="text-zinc-300" aria-hidden="true">
                          ·
                        </span>
                        <span className="text-[11px] font-mono tabular-nums text-zinc-500">
                          {formatTechDate(item.publishedAt || item.fetchedAt)}
                        </span>
                      </div>

                      {item.internalPath || item.kind === 'podcast' ? (
                        <button
                          type="button"
                          onClick={() => openFeedItem(item)}
                          className="text-left text-sm font-medium text-[#09090B] hover:text-[#2563EB] line-clamp-1 cursor-pointer block"
                        >
                          {item.title}
                        </button>
                      ) : (
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm font-medium text-[#09090B] hover:text-[#2563EB] line-clamp-1 block"
                        >
                          {item.title}
                        </a>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => openFeedItem(item)}
                      aria-label={`Open ${item.title}`}
                      className="p-1.5 rounded-md text-zinc-400 hover:text-[#2563EB] hover:bg-zinc-50 shrink-0 cursor-pointer"
                    >
                      <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Personalized Recommendations */}
          <section className="rounded-xl bg-white border border-zinc-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#2563EB]" aria-hidden="true" />
                <div>
                  <h2 className="font-display text-sm font-semibold text-[#09090B]">
                    Personalized Recommendations
                  </h2>
                  <p className="text-[11px] text-zinc-500">
                    {recommendations.matchedTopics.length > 0
                      ? `Based on your saved & followed topics: ${recommendations.matchedTopics.join(', ')}`
                      : 'Curated unread highlights across your active engineering sources'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onSelectSubTab('discover')}
                className="text-xs font-medium text-[#2563EB] hover:underline cursor-pointer whitespace-nowrap"
              >
                Explore Feed
              </button>
            </div>

            {recommendations.items.length === 0 ? (
              <p className="text-xs text-zinc-500 py-3">
                Save or read items in Discover to refine personalized stack recommendations.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {recommendations.items.map((item) => (
                  <div
                    key={item.id}
                    className="rounded-lg border border-zinc-200 p-3.5 flex flex-col justify-between gap-2.5 hover:border-zinc-300 transition-colors"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <SourceBadge
                          sourceGroup={item.sourceGroup}
                          compact={true}
                        />
                        <span className="text-[11px] font-mono tabular-nums text-zinc-500">
                          {formatTechDate(item.publishedAt || item.fetchedAt)}
                        </span>
                      </div>
                      {item.internalPath ? (
                        <button
                          type="button"
                          onClick={() => onNavigate(item.internalPath!)}
                          className="text-left text-xs font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-2 cursor-pointer"
                        >
                          {item.title}
                        </button>
                      ) : (
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-2 block"
                        >
                          {item.title}
                        </a>
                      )}
                    </div>

                    <div className="flex items-center justify-between gap-2 text-[11px] text-zinc-500">
                      <span className="truncate">{item.sourceName}</span>
                      <span className="text-[#2563EB] shrink-0">
                        {item.technologies[0] || item.contentType}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        {/* Right Column: Security Highlights, Trending GitHub Projects, Recent Notes */}
        <div className="lg:col-span-4 space-y-6">
          {/* Security Highlights */}
          <section className="rounded-xl bg-white border border-zinc-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center gap-2">
                <ShieldAlert
                  className="w-4 h-4 text-red-600"
                  aria-hidden="true"
                />
                <h2 className="font-display text-sm font-semibold text-[#09090B]">
                  Security Highlights
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onSelectSubTab('security')}
                className="text-xs font-medium text-[#2563EB] hover:underline cursor-pointer"
              >
                Security Hub
              </button>
            </div>

            {securityHighlights.length === 0 ? (
              <p className="text-xs text-zinc-500 py-2">
                No security advisories synced yet.
              </p>
            ) : (
              <div className="divide-y divide-zinc-100">
                {securityHighlights.map((sec) => (
                  <button
                    key={sec.id}
                    type="button"
                    onClick={() => onSelectSubTab('security')}
                    className="w-full py-2.5 text-left hover:bg-zinc-50 px-1.5 -mx-1.5 rounded transition-colors cursor-pointer space-y-1"
                  >
                    <p className="text-xs font-semibold text-[#09090B] line-clamp-1">
                      {sec.cveId ? `${sec.cveId} — ${sec.title}` : sec.title}
                    </p>
                    <p className="text-[11px] text-zinc-500 flex items-center gap-1.5">
                      <span className="truncate">{sec.source}</span>
                      {sec.severity && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono font-medium text-red-600 shrink-0">
                            {sec.severity}
                            {sec.cvss !== null ? ` (${sec.cvss})` : ''}
                          </span>
                        </>
                      )}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </section>

          {/* Trending GitHub Projects */}
          <section className="rounded-xl bg-white border border-zinc-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center gap-2">
                <GitBranch
                  className="w-4 h-4 text-[#2563EB]"
                  aria-hidden="true"
                />
                <h2 className="font-display text-sm font-semibold text-[#09090B]">
                  Trending GitHub Projects
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('/knowledge-hub/github/trending')}
                className="text-xs font-medium text-[#2563EB] hover:underline cursor-pointer"
              >
                GitHub Explorer
              </button>
            </div>

            {topGithubRepos.length === 0 ? (
              <p className="text-xs text-zinc-500 py-2">
                No repositories cached yet. Sync categories in GitHub Explorer.
              </p>
            ) : (
              <div className="divide-y divide-zinc-100">
                {topGithubRepos.map((repo) => (
                  <button
                    key={repo.id}
                    type="button"
                    onClick={() =>
                      onNavigate(
                        `/knowledge-hub/github/repositories/${encodeURIComponent(repo.owner.login)}/${encodeURIComponent(repo.name)}`
                      )
                    }
                    className="w-full py-2.5 text-left hover:bg-zinc-50 px-1.5 -mx-1.5 rounded transition-colors cursor-pointer flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-[#09090B] truncate">
                        {repo.fullName}
                      </p>
                      <p className="text-[11px] text-zinc-500 truncate">
                        {repo.language || 'Repository'}
                      </p>
                    </div>
                    <span className="inline-flex items-center gap-1 text-[11px] font-mono tabular-nums text-zinc-600 shrink-0">
                      <Star className="w-3 h-3 text-amber-500" aria-hidden="true" />
                      {repo.stargazersCount.toLocaleString()}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </section>

          {/* Recent Notes */}
          <section className="rounded-xl bg-white border border-zinc-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-100 pb-3">
              <div className="flex items-center gap-2">
                <FileText
                  className="w-4 h-4 text-[#2563EB]"
                  aria-hidden="true"
                />
                <h2 className="font-display text-sm font-semibold text-[#09090B]">
                  Recent Notes
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('/knowledge-hub/onenote')}
                className="text-xs font-medium text-[#2563EB] hover:underline cursor-pointer"
              >
                Open OneNote
              </button>
            </div>

            {recentOneNotes.length === 0 ? (
              <p className="text-xs text-zinc-500 py-2">
                No recent notes available yet.
              </p>
            ) : (
              <div className="divide-y divide-zinc-100">
                {recentOneNotes.map((note) => (
                  <button
                    key={note.id}
                    type="button"
                    onClick={() =>
                      onNavigate(
                        `/knowledge-hub/onenote/page/${encodeURIComponent(note.id)}`
                      )
                    }
                    className="w-full py-2.5 text-left hover:bg-zinc-50 px-1.5 -mx-1.5 rounded transition-colors cursor-pointer space-y-0.5"
                  >
                    <p className="text-xs font-semibold text-[#09090B] line-clamp-1">
                      {note.title}
                    </p>
                    <p className="text-[11px] text-zinc-500">
                      {note.section} · {note.updatedAt}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
