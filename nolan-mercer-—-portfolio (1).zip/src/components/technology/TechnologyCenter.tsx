import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  RefreshCw,
  RotateCcw,
  Search,
  X,
} from 'lucide-react';
import { githubProvider } from '../../github/engine';
import { GitHubRepository } from '../../github/types';
import { AggregatedArticle } from '../../types/article';
import {
  AggregationSyncSummary,
  ArticleSource,
} from '../../types/articleSource';
import {
  LearningItem,
  PodcastEpisode,
  PodcastSeries,
  SecurityRecord,
  TechEvent,
  TechSettings,
  TechSource,
  TechSubTab,
  TechSyncHistoryEntry,
  TechVideo,
} from '../../types/technology';
import {
  getAggregatedArticlesSync,
  getAggregationConfigSync,
  getAggregationSummarySync,
  getArticleSourcesSync,
  initializeArticleAggregation,
  syncAllArticleSources,
} from '../../services/articles/articleAggregator';
import { isAggregationSyncDue } from '../../services/articles/syncScheduler';
import {
  buildUnifiedDiscoverFeed,
  filterAndSortUnifiedFeed,
  DEFAULT_DISCOVER_FILTER,
  UnifiedFeedItem,
} from '../../services/technology/discoverFeed';
import {
  getTechTransportAdapter,
  initializeTechnologyCenter,
  retryFailedTechnologySources,
  syncAllTechnologySources,
  syncDueTechnologySources,
} from '../../services/technology/syncEngine';
import { techStorage } from '../../services/technology/techStorage';
import {
  formatTechDate,
  formatTechTimestamp,
} from '../../services/technology/retentionEngine';
import {
  MediaSourceDto,
  MediaStatusDto,
  MediaSyncHistoryDto,
  YouTubeQuotaDto,
  fetchMediaEvents,
  fetchMediaPodcasts,
  fetchMediaSources,
  fetchMediaStatus,
  fetchMediaSyncHistory,
  fetchMediaVideos,
  retryFailedMediaSourcesApi,
  syncMediaByTypeApi,
} from '../../services/techMediaApi';
import { SourceBadge } from './SourceBadge';
import { TechnologyDiscoverTab } from './TechnologyDiscoverTab';
import { TechnologyEventsTab } from './TechnologyEventsTab';
import { TechnologyOverviewTab } from './TechnologyOverviewTab';
import { TechnologyPodcastsTab } from './TechnologyPodcastsTab';
import { TechnologySecurityTab } from './TechnologySecurityTab';
import { TechnologyVideosTab } from './TechnologyVideosTab';
import {
  TechnologySavedTab,
  TechnologySettingsTab,
  TechnologySourcesTab,
} from './TechnologyGovernanceTabs';
import { TechKnowledgeHubView } from './TechKnowledgeHubView';

interface TechnologyCenterProps {
  onNavigate: (path: string) => void;
  initialSubTab?: TechSubTab;
  hubSection?: 'articles' | 'favorites' | 'archive' | 'sources' | 'history' | 'article';
  hubArticleId?: string;
  initialPodcastSeriesId?: string | null;
  initialLegacyPreset?: string;
  initialShowSyncHistory?: boolean;
}

const TECH_TABS: Array<{ key: TechSubTab; label: string }> = [
  { key: 'overview', label: 'Overview' },
  { key: 'podcasts', label: 'Podcasts' },
  { key: 'videos', label: 'YouTube' },
  { key: 'events', label: 'Events' },
  { key: 'knowledge-hub', label: 'Knowledge Hub' },
  { key: 'discover', label: 'Discover' },
  { key: 'sources', label: 'Sources' },
  { key: 'security', label: 'Security' },
  { key: 'saved', label: 'Saved' },
  { key: 'settings', label: 'Settings' },
];

export const TechnologyCenter: React.FC<TechnologyCenterProps> = ({
  onNavigate,
  initialSubTab = 'overview',
  hubSection = 'articles',
  hubArticleId,
  initialPodcastSeriesId = null,
  initialLegacyPreset,
  initialShowSyncHistory = false,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<TechSubTab>(initialSubTab);
  const [selectedSeriesId, setSelectedSeriesId] = useState<string | null>(
    initialPodcastSeriesId
  );
  const [urlQuerySyncKey, setUrlQuerySyncKey] = useState<string>(
    () => window.location.search
  );

  // Article store state (shared non-destructively with Blog)
  const [articles, setArticles] = useState<AggregatedArticle[]>(() =>
    getAggregatedArticlesSync()
  );
  const [articleSources, setArticleSources] = useState<ArticleSource[]>(() =>
    getArticleSourcesSync()
  );
  const [articleSyncSummary, setArticleSyncSummary] =
    useState<AggregationSyncSummary | null>(() => getAggregationSummarySync());

  // Local Technology Intelligence store state (Learning, Security, Settings)
  const [techSources, setTechSources] = useState<TechSource[]>(() =>
    techStorage.getSources()
  );
  const [learningItems, setLearningItems] = useState<LearningItem[]>(() =>
    techStorage.getLearningItems()
  );
  const [securityRecords, setSecurityRecords] = useState<SecurityRecord[]>(() =>
    techStorage.getSecurityRecords()
  );
  const [syncHistory, setSyncHistory] = useState<TechSyncHistoryEntry[]>(() =>
    techStorage.getSyncHistory()
  );
  const [settings, setSettings] = useState<TechSettings>(() =>
    techStorage.getSettings()
  );

  // Backend /api/tech-media state (Podcasts, Events, YouTube + Shared Source Management)
  const [mediaSources, setMediaSources] = useState<MediaSourceDto[]>([]);
  const [mediaStatus, setMediaStatus] = useState<MediaStatusDto | null>(null);
  const [mediaSyncHistory, setMediaSyncHistory] = useState<MediaSyncHistoryDto[]>([]);
  const [mediaSeries, setMediaSeries] = useState<PodcastSeries[]>([]);
  const [mediaEpisodes, setMediaEpisodes] = useState<PodcastEpisode[]>([]);
  const [mediaEvents, setMediaEvents] = useState<TechEvent[]>([]);
  const [mediaVideos, setMediaVideos] = useState<TechVideo[]>([]);
  const [youtubeQuota, setYoutubeQuota] = useState<YouTubeQuotaDto | null>(null);

  // GitHub Explorer snapshots (shared non-destructively)
  const [githubRepos, setGithubRepos] = useState<GitHubRepository[]>(() =>
    githubProvider.getRepositories()
  );
  const [savedGithubRepoIds, setSavedGithubRepoIds] = useState<number[]>(() =>
    githubProvider.getSavedRepoIds()
  );

  // Server capability flags
  const [youtubeApiConfigured, setYoutubeApiConfigured] = useState(false);
  const [nvdApiConfigured, setNvdApiConfigured] = useState(false);

  // UI operational state
  const [isReady, setIsReady] = useState(false);
  const [isRefreshingAll, setIsRefreshingAll] = useState(false);
  const [isRetryingFailed, setIsRetryingFailed] = useState(false);
  const [syncStatusBanner, setSyncStatusBanner] = useState<{
    tone: 'info' | 'warning';
    text: string;
  } | null>(null);
  const [globalQuery, setGlobalQuery] = useState('');

  const autoSyncTriggeredRef = useRef(false);

  useEffect(() => {
    setActiveSubTab(initialSubTab);
  }, [initialSubTab]);

  useEffect(() => {
    setSelectedSeriesId(initialPodcastSeriesId);
  }, [initialPodcastSeriesId]);

  useEffect(() => {
    const onPop = () => setUrlQuerySyncKey(window.location.search);
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const refreshLocalSnapshots = useCallback(() => {
    setArticles(getAggregatedArticlesSync());
    setArticleSources(getArticleSourcesSync());
    setArticleSyncSummary(getAggregationSummarySync());

    setTechSources(techStorage.getSources());
    setLearningItems(techStorage.getLearningItems());
    setSecurityRecords(techStorage.getSecurityRecords());
    setSyncHistory(techStorage.getSyncHistory());
    setSettings(techStorage.getSettings());

    setGithubRepos(githubProvider.getRepositories());
    setSavedGithubRepoIds(githubProvider.getSavedRepoIds());
  }, []);

  const refreshMediaSnapshots = useCallback(async () => {
    const [sourcesRes, statusRes, historyRes, podcastsRes, eventsRes, videosRes] =
      await Promise.allSettled([
        fetchMediaSources(),
        fetchMediaStatus(),
        fetchMediaSyncHistory(),
        fetchMediaPodcasts(),
        fetchMediaEvents(),
        fetchMediaVideos(),
      ]);

    if (sourcesRes.status === 'fulfilled') setMediaSources(sourcesRes.value);
    if (statusRes.status === 'fulfilled') {
      setMediaStatus(statusRes.value);
      setYoutubeApiConfigured(statusRes.value.youtubeApiConfigured);
      setYoutubeQuota(statusRes.value.youtubeQuota);
    }
    if (historyRes.status === 'fulfilled') setMediaSyncHistory(historyRes.value);
    if (podcastsRes.status === 'fulfilled') {
      setMediaSeries(podcastsRes.value.series);
      setMediaEpisodes(podcastsRes.value.episodes);
    }
    if (eventsRes.status === 'fulfilled') setMediaEvents(eventsRes.value);
    if (videosRes.status === 'fulfilled') {
      setMediaVideos(videosRes.value.videos);
      setYoutubeApiConfigured(videosRes.value.youtubeApiConfigured);
      setYoutubeQuota(videosRes.value.youtubeQuota);
    }
  }, []);

  const refreshAllSnapshots = useCallback(async () => {
    refreshLocalSnapshots();
    await refreshMediaSnapshots();
  }, [refreshLocalSnapshots, refreshMediaSnapshots]);

  const runDueAutoSync = useCallback(async () => {
    const currentSettings = techStorage.getSettings();
    const tasks: Array<Promise<unknown>> = [];

    if (currentSettings.globalAutoSync) {
      tasks.push(syncDueTechnologySources());
    }
    const currentArtSummary = getAggregationSummarySync();
    const currentArtConfig = getAggregationConfigSync();
    if (isAggregationSyncDue(currentArtSummary, currentArtConfig)) {
      tasks.push(syncAllArticleSources());
    }

    if (tasks.length > 0) {
      await Promise.allSettled(tasks);
    }
    await refreshAllSnapshots();
  }, [refreshAllSnapshots]);

  // Initial load + server health probe + overdue auto-sync
  useEffect(() => {
    let active = true;
    (async () => {
      await Promise.all([
        initializeArticleAggregation(),
        initializeTechnologyCenter(),
        refreshMediaSnapshots(),
      ]);
      if (!active) return;
      refreshLocalSnapshots();
      setIsReady(true);

      const health = await getTechTransportAdapter().checkHealth();
      if (active) {
        setNvdApiConfigured(health.nvdApiConfigured);
      }

      if (!autoSyncTriggeredRef.current) {
        autoSyncTriggeredRef.current = true;
        await runDueAutoSync();
      }
    })();
    return () => {
      active = false;
    };
  }, [refreshLocalSnapshots, refreshMediaSnapshots, runDueAutoSync]);

  // Periodic background check while Workspace tab stays open
  useEffect(() => {
    const interval = setInterval(() => {
      void runDueAutoSync();
    }, 5 * 60_000);
    return () => clearInterval(interval);
  }, [runDueAutoSync]);

  const handleSelectSubTab = useCallback(
    (tab: TechSubTab, discoverQuery?: string) => {
      setActiveSubTab(tab);
      setSelectedSeriesId(null);
      if (tab === 'discover') {
        const suffix = discoverQuery || '';
        setUrlQuerySyncKey(suffix);
        onNavigate(`/knowledge-hub/technology/discover${suffix}`);
        return;
      }
      onNavigate(
        tab === 'overview'
          ? '/knowledge-hub/technology'
          : `/knowledge-hub/technology/${tab}`
      );
    },
    [onNavigate]
  );

  const handleSelectPodcastSeries = useCallback(
    (seriesId: string | null) => {
      setSelectedSeriesId(seriesId);
      setActiveSubTab('podcasts');
      if (seriesId) {
        onNavigate(
          `/knowledge-hub/technology/podcasts/${encodeURIComponent(seriesId)}`
        );
      } else {
        onNavigate('/knowledge-hub/technology/podcasts');
      }
    },
    [onNavigate]
  );

  const failedSourcesCount = useMemo(() => {
    const localNonMediaFailed = techSources.filter(
      (s) =>
        (s.contentType === 'learning' || s.contentType === 'security') &&
        s.enabled &&
        s.status === 'error' &&
        s.sourceType !== 'unsupported' &&
        s.sourceType !== 'manual'
    ).length;

    const articleFailed = articleSources.filter(
      (s) =>
        s.enabled && s.status === 'error' && s.sourceType !== 'unsupported'
    ).length;

    const mediaFailed = mediaSources.filter(
      (s) =>
        s.enabled &&
        (s.verificationStatus === 'error' || Boolean(s.lastError))
    ).length;

    return localNonMediaFailed + articleFailed + mediaFailed;
  }, [articleSources, mediaSources, techSources]);

  const lastSuccessfulSync = useMemo(() => {
    const candidates = [
      settings.lastSuccessfulSyncAt,
      articleSyncSummary?.lastSuccessfulSyncAt,
      mediaStatus?.scheduler?.podcast?.lastSuccessfulSyncAt,
      mediaStatus?.scheduler?.event?.lastSuccessfulSyncAt,
      mediaStatus?.scheduler?.youtube?.lastSuccessfulSyncAt,
    ]
      .filter((x): x is string => Boolean(x))
      .sort((a, b) => Date.parse(b) - Date.parse(a));
    return candidates[0] || null;
  }, [
    articleSyncSummary?.lastSuccessfulSyncAt,
    mediaStatus?.scheduler,
    settings.lastSuccessfulSyncAt,
  ]);

  const handleRefreshAll = async () => {
    setIsRefreshingAll(true);
    setSyncStatusBanner(null);
    try {
      const [mediaOutcome, techOutcome] = await Promise.allSettled([
        syncMediaByTypeApi('all'),
        syncAllTechnologySources(true),
      ]);
      await refreshAllSnapshots();

      const techResults =
        techOutcome.status === 'fulfilled' ? techOutcome.value : [];
      const mediaResults =
        mediaOutcome.status === 'fulfilled' ? mediaOutcome.value.results : [];

      const succeeded =
        techResults.filter((r) => r.status === 'success').length +
        mediaResults.filter((r) => r.status === 'success').length;
      const errors =
        techResults.filter(
          (r) => r.status === 'error' || r.status === 'partial'
        ).length +
        mediaResults.filter(
          (r) => r.status === 'error' || r.status === 'partial'
        ).length +
        (mediaOutcome.status === 'rejected' ? 1 : 0);
      const totalNew =
        techResults.reduce((sum, r) => sum + r.newItems, 0) +
        mediaResults.reduce((sum, r) => sum + r.newItems, 0);

      setSyncStatusBanner({
        tone: errors > 0 ? 'warning' : 'info',
        text:
          errors > 0
            ? `Sync completed with partial errors: ${succeeded} succeeded, ${errors} reported errors (${totalNew} new items).`
            : `All active sources synced (${totalNew} new items indexed).`,
      });
    } finally {
      setIsRefreshingAll(false);
    }
  };

  const handleRetryFailed = async () => {
    setIsRetryingFailed(true);
    try {
      const [mediaOutcome, techOutcome] = await Promise.allSettled([
        retryFailedMediaSourcesApi(),
        retryFailedTechnologySources(),
      ]);
      await refreshAllSnapshots();

      const techResults =
        techOutcome.status === 'fulfilled' ? techOutcome.value : [];
      const mediaResults =
        mediaOutcome.status === 'fulfilled' ? mediaOutcome.value.results : [];
      const totalCount = techResults.length + mediaResults.length;
      const recovered =
        techResults.filter((r) => r.status === 'success').length +
        mediaResults.filter((r) => r.status === 'success').length;
      const anyError =
        techResults.some((r) => r.status === 'error') ||
        mediaResults.some((r) => r.status === 'error');

      setSyncStatusBanner({
        tone: anyError ? 'warning' : 'info',
        text:
          totalCount === 0
            ? 'No failed Technology feeds pending retry.'
            : `Retried ${totalCount} failed sources (${recovered} recovered).`,
      });
    } finally {
      setIsRetryingFailed(false);
    }
  };

  const unifiedFeed = useMemo(
    () =>
      buildUnifiedDiscoverFeed({
        articles,
        videos: mediaVideos,
        podcastEpisodes: mediaEpisodes,
        githubRepos,
        savedGithubRepoIds,
        learningItems,
        securityRecords,
        events: mediaEvents,
      }),
    [
      articles,
      githubRepos,
      learningItems,
      mediaEpisodes,
      mediaEvents,
      mediaVideos,
      savedGithubRepoIds,
      securityRecords,
    ]
  );

  const globalSearchHits = useMemo<UnifiedFeedItem[]>(() => {
    const q = globalQuery.trim();
    if (q.length < 2) return [];
    return filterAndSortUnifiedFeed(unifiedFeed, {
      ...DEFAULT_DISCOVER_FILTER,
      dateRange: 'all',
      sort: 'relevance',
      searchQuery: q,
    }).slice(0, 12);
  }, [globalQuery, unifiedFeed]);

  const handleGlobalSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = globalQuery.trim();
    if (!q) return;
    setGlobalQuery('');
    handleSelectSubTab('discover', `?q=${encodeURIComponent(q)}&sort=relevance`);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Clean SaaS Header: Title, Global Search, Refresh & Sync Status */}
      <div className="rounded-xl bg-white border border-zinc-200 p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display text-xl sm:text-2xl font-bold text-[#09090B]">
              Technology Hub
            </h2>
            <p className="text-xs text-zinc-500">
              Engineering intelligence across Medium, official engineering blogs, YouTube, podcasts, GitHub, CVEs, documentation, and conferences.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <span className="text-[11px] font-mono tabular-nums text-zinc-500">
              {lastSuccessfulSync
                ? `Last synced ${formatTechTimestamp(lastSuccessfulSync)}`
                : 'Not synced yet'}
            </span>

            {failedSourcesCount > 0 && (
              <button
                type="button"
                onClick={handleRetryFailed}
                disabled={isRetryingFailed || isRefreshingAll}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-amber-300 bg-amber-50 text-amber-900 hover:bg-amber-100 disabled:opacity-50 cursor-pointer"
              >
                <RotateCcw
                  className={`w-3.5 h-3.5 ${isRetryingFailed ? 'animate-spin' : ''}`}
                  aria-hidden="true"
                />
                <span>
                  {isRetryingFailed
                    ? 'Retrying...'
                    : `Retry Failed (${failedSourcesCount})`}
                </span>
              </button>
            )}

            <button
              type="button"
              onClick={handleRefreshAll}
              disabled={isRefreshingAll}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${isRefreshingAll ? 'animate-spin' : ''}`}
                aria-hidden="true"
              />
              <span>{isRefreshingAll ? 'Syncing...' : 'Refresh'}</span>
            </button>
          </div>
        </div>

        {/* Global Search Input */}
        <form onSubmit={handleGlobalSearchSubmit} className="relative">
          <Search
            className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2"
            aria-hidden="true"
          />
          <input
            type="text"
            value={globalQuery}
            onChange={(e) => setGlobalQuery(e.target.value)}
            placeholder="Global search across all sources, CVEs, GitHub repositories, videos, podcasts, and events (Enter to open in Discover)..."
            aria-label="Global Technology Search"
            className="w-full pl-10 pr-9 py-2.5 text-xs rounded-lg border border-zinc-200 bg-[#FAFAFA] focus:bg-white focus:outline-none focus:border-[#2563EB]"
          />
          {globalQuery && (
            <button
              type="button"
              onClick={() => setGlobalQuery('')}
              aria-label="Clear global search"
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded hover:bg-zinc-200 text-zinc-500 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </form>

        {globalQuery.trim().length >= 2 && (
          <div className="rounded-xl border border-zinc-200 bg-[#FAFAFA] max-h-80 overflow-y-auto divide-y divide-zinc-200">
            <div className="px-4 py-2 bg-white text-[11px] font-medium text-zinc-500 flex items-center justify-between sticky top-0">
              <span>Top matches ({globalSearchHits.length})</span>
              <button
                type="button"
                onClick={() => {
                  const q = globalQuery.trim();
                  setGlobalQuery('');
                  handleSelectSubTab(
                    'discover',
                    `?q=${encodeURIComponent(q)}&sort=relevance`
                  );
                }}
                className="text-[#2563EB] hover:underline cursor-pointer"
              >
                Open all results in Discover
              </button>
            </div>
            {globalSearchHits.length === 0 ? (
              <p className="p-4 text-xs text-zinc-500 text-center">
                No records found matching &ldquo;{globalQuery}&rdquo;.
              </p>
            ) : (
              globalSearchHits.map((hit) => (
                <button
                  key={hit.id}
                  type="button"
                  onClick={() => {
                    setGlobalQuery('');
                    if (hit.internalPath) {
                      onNavigate(hit.internalPath);
                    } else if (hit.kind === 'podcast' && hit.podcastSeriesId) {
                      handleSelectPodcastSeries(hit.podcastSeriesId);
                    } else if (hit.kind === 'security') {
                      handleSelectSubTab('security');
                    } else {
                      window.open(hit.url, '_blank', 'noopener,noreferrer');
                    }
                  }}
                  className="w-full px-4 py-2.5 text-left hover:bg-white transition-colors flex items-center justify-between gap-3 cursor-pointer"
                >
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <SourceBadge
                        sourceGroup={hit.sourceGroup}
                        sourceName={hit.sourceName}
                      />
                      <span className="text-[11px] text-zinc-500">
                        {hit.contentType}
                      </span>
                      <span className="text-[11px] font-mono tabular-nums text-zinc-400">
                        {formatTechDate(hit.publishedAt || hit.fetchedAt)}
                      </span>
                    </div>
                    <p className="text-xs font-semibold text-[#09090B] truncate">
                      {hit.title}
                    </p>
                  </div>
                  <ArrowUpRight className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                </button>
              ))
            )}
          </div>
        )}

        {syncStatusBanner && (
          <div
            className={`rounded-lg px-4 py-2.5 text-xs flex items-center justify-between gap-3 border ${
              syncStatusBanner.tone === 'warning'
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-zinc-50 border-zinc-200 text-zinc-800'
            }`}
          >
            <span className="flex items-center gap-2">
              {syncStatusBanner.tone === 'warning' && (
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              )}
              <span>{syncStatusBanner.text}</span>
            </span>
            <button
              type="button"
              onClick={() => setSyncStatusBanner(null)}
              className="underline font-medium cursor-pointer shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* Technology Sub-Navigation */}
      <nav
        aria-label="Technology Hub navigation"
        className="flex items-center gap-1 overflow-x-auto pb-1 border-b border-zinc-200"
      >
        {TECH_TABS.map((t) => {
          const active = activeSubTab === t.key;
          return (
            <button
              key={t.key}
              type="button"
              onClick={() => handleSelectSubTab(t.key)}
              className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                active
                  ? 'bg-[#09090B] text-white'
                  : 'text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100'
              }`}
            >
              {t.label}
              {t.key === 'sources' && failedSourcesCount > 0 && (
                <span className="ml-1.5 text-[10px] font-mono text-red-500">
                  ({failedSourcesCount})
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Active Sub-Tab Body */}
      {!isReady ? (
        <div className="rounded-xl bg-white border border-zinc-200 p-10 text-center text-xs text-zinc-500">
          Initializing Technology Hub stores...
        </div>
      ) : (
        <>
          {activeSubTab === 'overview' && (
            <TechnologyOverviewTab
              articles={articles}
              articleSources={articleSources}
              techSources={techSources}
              mediaSources={mediaSources}
              videos={mediaVideos}
              podcastSeries={mediaSeries}
              podcastEpisodes={mediaEpisodes}
              learningItems={learningItems}
              securityRecords={securityRecords}
              events={mediaEvents}
              githubRepos={githubRepos}
              savedGithubRepoIds={savedGithubRepoIds}
              onSelectSubTab={handleSelectSubTab}
              onNavigate={onNavigate}
            />
          )}

          {activeSubTab === 'podcasts' && (
            <TechnologyPodcastsTab
              series={mediaSeries}
              episodes={mediaEpisodes}
              sources={mediaSources}
              syncHistory={mediaSyncHistory}
              settings={settings}
              selectedSeriesId={selectedSeriesId}
              onSelectSeries={handleSelectPodcastSeries}
              onDataChanged={refreshMediaSnapshots}
            />
          )}

          {activeSubTab === 'videos' && (
            <TechnologyVideosTab
              videos={mediaVideos}
              sources={mediaSources}
              syncHistory={mediaSyncHistory}
              settings={settings}
              youtubeApiConfigured={youtubeApiConfigured}
              youtubeQuota={youtubeQuota}
              onDataChanged={refreshMediaSnapshots}
            />
          )}

          {activeSubTab === 'events' && (
            <TechnologyEventsTab
              events={mediaEvents}
              sources={mediaSources}
              onDataChanged={refreshMediaSnapshots}
            />
          )}

          {activeSubTab === 'knowledge-hub' && (
            <TechKnowledgeHubView
              section={hubSection}
              articleId={hubArticleId}
              onNavigate={onNavigate}
            />
          )}

          {activeSubTab === 'discover' && (
            <TechnologyDiscoverTab
              articles={articles}
              videos={mediaVideos}
              podcastSeries={mediaSeries}
              podcastEpisodes={mediaEpisodes}
              learningItems={learningItems}
              securityRecords={securityRecords}
              events={mediaEvents}
              githubRepos={githubRepos}
              savedGithubRepoIds={savedGithubRepoIds}
              legacyPreset={initialLegacyPreset}
              urlQuerySyncKey={urlQuerySyncKey}
              selectedSeriesId={selectedSeriesId}
              onSelectSeries={handleSelectPodcastSeries}
              onDataChanged={refreshAllSnapshots}
              onNavigate={onNavigate}
              onRetrySync={handleRefreshAll}
            />
          )}

          {activeSubTab === 'sources' && (
            <TechnologySourcesTab
              articleSources={articleSources}
              techSources={techSources}
              syncHistory={syncHistory}
              mediaSources={mediaSources}
              mediaStatus={mediaStatus}
              mediaSyncHistory={mediaSyncHistory}
              initialShowHistory={initialShowSyncHistory}
              onClearHistory={async () => {
                await techStorage.clearSyncHistory();
                refreshLocalSnapshots();
              }}
              onDataChanged={refreshLocalSnapshots}
              onMediaDataChanged={refreshMediaSnapshots}
            />
          )}

          {activeSubTab === 'security' && (
            <TechnologySecurityTab
              records={securityRecords}
              onDataChanged={refreshLocalSnapshots}
            />
          )}

          {activeSubTab === 'saved' && (
            <TechnologySavedTab
              articles={articles}
              videos={mediaVideos}
              episodes={mediaEpisodes}
              learningItems={learningItems}
              securityRecords={securityRecords}
              events={mediaEvents}
              githubRepos={githubRepos}
              savedGithubRepoIds={savedGithubRepoIds}
              onDataChanged={refreshAllSnapshots}
              onNavigate={onNavigate}
            />
          )}

          {activeSubTab === 'settings' && (
            <TechnologySettingsTab
              settings={settings}
              youtubeApiConfigured={youtubeApiConfigured}
              nvdApiConfigured={nvdApiConfigured}
              onSaveSettings={async (next) => {
                await techStorage.saveSettings(next);
                refreshLocalSnapshots();
              }}
              onDataChanged={refreshLocalSnapshots}
            />
          )}
        </>
      )}
    </div>
  );
};
