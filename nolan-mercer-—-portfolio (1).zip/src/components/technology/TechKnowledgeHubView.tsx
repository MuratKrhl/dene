import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  Archive,
  ArchiveRestore,
  ArrowRight,
  CheckCircle2,
  Compass,
  ExternalLink,
  Info,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Star,
  Trash2,
  X,
} from 'lucide-react';
import { techKnowledgeHubApi } from '../../services/techKnowledgeHubApi';
import {
  TechHubArticleDto,
  TechHubCategoryDto,
  TechHubDiscoveryResult,
  TechHubScanHistoryDto,
  TechHubSourceDto,
  TechHubStatusDto,
} from '../../types/techKnowledgeHub';
import { ArticleCoverMedia } from './ArticleCoverMedia';
import { BlogSidebar, BlogSidebarSection } from './BlogSidebar';
import { TechKnowledgeArticleDetail } from './TechKnowledgeArticleDetail';

export type TechHubSection =
  | 'articles'
  | 'favorites'
  | 'archive'
  | 'sources'
  | 'history'
  | 'article';

interface TechKnowledgeHubViewProps {
  section?: TechHubSection;
  articleId?: string;
  onNavigate?: (path: string) => void;
}

const PAGE_SIZE = 20;

const SECTION_PATH_MAP: Record<BlogSidebarSection, string> = {
  articles: '/workspace/blog',
  favorites: '/workspace/blog/favorites',
  archive: '/workspace/blog/archive',
  sources: '/workspace/blog/sources',
  history: '/workspace/blog/history',
};

function formatDateDisplay(iso: string | null): string {
  if (!iso) return 'Bilinmiyor';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return 'Bilinmiyor';
  return d.toLocaleDateString('tr-TR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

function formatTimestampDisplay(iso: string | null): string {
  if (!iso) return 'Henüz taranmadı';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return 'Henüz taranmadı';
  return d.toLocaleString('tr-TR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export const TechKnowledgeHubView: React.FC<TechKnowledgeHubViewProps> = ({
  section = 'articles',
  articleId,
  onNavigate,
}) => {
  // Fallback local navigation state if rendered without router callback
  const [localSection, setLocalSection] = useState<TechHubSection>(section);
  const [localArticleId, setLocalArticleId] = useState<string | undefined>(
    articleId
  );

  useEffect(() => {
    setLocalSection(section);
  }, [section]);

  useEffect(() => {
    setLocalArticleId(articleId);
  }, [articleId]);

  const activeViewSection = onNavigate ? section : localSection;
  const activeArticleId = onNavigate ? articleId : localArticleId;
  const isArticleDetail =
    activeViewSection === 'article' && Boolean(activeArticleId);

  const lastListSectionRef = useRef<'articles' | 'favorites' | 'archive'>(
    'articles'
  );
  useEffect(() => {
    if (
      activeViewSection === 'articles' ||
      activeViewSection === 'favorites' ||
      activeViewSection === 'archive'
    ) {
      lastListSectionRef.current = activeViewSection;
    }
  }, [activeViewSection]);

  const sidebarSection: BlogSidebarSection =
    activeViewSection === 'article'
      ? lastListSectionRef.current
      : activeViewSection;

  // Backend data
  const [categories, setCategories] = useState<TechHubCategoryDto[]>([]);
  const [sources, setSources] = useState<TechHubSourceDto[]>([]);
  const [status, setStatus] = useState<TechHubStatusDto | null>(null);
  const [articles, setArticles] = useState<TechHubArticleDto[]>([]);
  const [pagination, setPagination] = useState({
    total: 0,
    page: 1,
    pageSize: PAGE_SIZE,
    totalPages: 1,
  });
  const [scanHistory, setScanHistory] = useState<TechHubScanHistoryDto[]>([]);

  // Feed filters
  const [selectedCategoryId, setSelectedCategoryId] = useState('');
  const [selectedSourceId, setSelectedSourceId] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest' | 'important'>(
    'newest'
  );
  const [page, setPage] = useState(1);

  // Operational state
  const [loading, setLoading] = useState(true);
  const [articlesLoading, setArticlesLoading] = useState(false);
  const [scanningAll, setScanningAll] = useState(false);
  const [bannerMessage, setBannerMessage] = useState<{
    tone: 'info' | 'warning';
    text: string;
  } | null>(null);

  // Source Management state
  const [sourceQuery, setSourceQuery] = useState('');
  const [sourceStatusFilter, setSourceStatusFilter] = useState<
    'all' | 'verified' | 'unverified' | 'error'
  >('all');
  const [busySourceId, setBusySourceId] = useState<string | null>(null);
  const [showSourceForm, setShowSourceForm] = useState(false);
  const [editingSourceId, setEditingSourceId] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formSiteUrl, setFormSiteUrl] = useState('');
  const [formFeedUrl, setFormFeedUrl] = useState('');
  const [formCategoryIds, setFormCategoryIds] = useState<string[]>([]);
  const [formKeywordFilter, setFormKeywordFilter] = useState('');
  const [discoveryResult, setDiscoveryResult] =
    useState<TechHubDiscoveryResult | null>(null);
  const [testMessage, setTestMessage] = useState<string | null>(null);
  const [discovering, setDiscovering] = useState(false);
  const [testingFeed, setTestingFeed] = useState(false);
  const [pendingDeleteSourceId, setPendingDeleteSourceId] = useState<
    string | null
  >(null);

  const navigateToSection = useCallback(
    (target: BlogSidebarSection) => {
      setPage(1);
      if (onNavigate) {
        onNavigate(SECTION_PATH_MAP[target]);
      } else {
        setLocalSection(target);
        setLocalArticleId(undefined);
      }
    },
    [onNavigate]
  );

  const navigateToArticle = useCallback(
    (targetId: string, fromArchive?: boolean) => {
      if (fromArchive) {
        lastListSectionRef.current = 'archive';
      }
      if (onNavigate) {
        onNavigate(`/workspace/blog/article/${encodeURIComponent(targetId)}`);
      } else {
        setLocalArticleId(targetId);
        setLocalSection('article');
      }
    },
    [onNavigate]
  );

  const handleSelectCategory = useCallback(
    (categoryId: string) => {
      setSelectedCategoryId(categoryId);
      setPage(1);
      if (
        activeViewSection === 'article' ||
        activeViewSection === 'sources' ||
        activeViewSection === 'history'
      ) {
        const fallbackTarget =
          lastListSectionRef.current === 'archive'
            ? 'archive'
            : lastListSectionRef.current === 'favorites'
              ? 'favorites'
              : 'articles';
        navigateToSection(fallbackTarget);
      }
    },
    [activeViewSection, navigateToSection]
  );

  const loadMetadata = useCallback(async () => {
    const [catRes, srcRes, stRes] = await Promise.all([
      techKnowledgeHubApi.getCategories(),
      techKnowledgeHubApi.getSources(),
      techKnowledgeHubApi.getStatus(),
    ]);
    setCategories(catRes.categories);
    setSources(srcRes.sources);
    setStatus(stRes);
  }, []);

  const isFeedView =
    activeViewSection === 'articles' ||
    activeViewSection === 'favorites' ||
    activeViewSection === 'archive';

  const loadArticles = useCallback(async () => {
    if (!isFeedView) return;
    setArticlesLoading(true);
    try {
      const res = await techKnowledgeHubApi.getArticles({
        categoryId: selectedCategoryId || undefined,
        sourceId: selectedSourceId || undefined,
        archived: activeViewSection === 'archive',
        unreadOnly,
        favoritesOnly: activeViewSection === 'favorites',
        from: fromDate || undefined,
        to: toDate || undefined,
        q: searchQuery.trim() || undefined,
        sort: sortOrder,
        page,
        pageSize: PAGE_SIZE,
      });
      setArticles(res.items);
      setPagination(res.pagination);
    } finally {
      setArticlesLoading(false);
    }
  }, [
    activeViewSection,
    fromDate,
    isFeedView,
    page,
    searchQuery,
    selectedCategoryId,
    selectedSourceId,
    sortOrder,
    toDate,
    unreadOnly,
  ]);

  const loadHistory = useCallback(async () => {
    const res = await techKnowledgeHubApi.getScanHistory();
    setScanHistory(res.history);
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        await loadMetadata();
        if (active) setLoading(false);
      } catch (err) {
        if (active) {
          setLoading(false);
          setBannerMessage({
            tone: 'warning',
            text:
              err instanceof Error
                ? err.message
                : 'Backend Knowledge Hub yüklenemedi.',
          });
        }
      }
    })();
    return () => {
      active = false;
    };
  }, [loadMetadata]);

  useEffect(() => {
    if (isFeedView) {
      void loadArticles();
    } else if (activeViewSection === 'history') {
      void loadHistory();
    }
  }, [activeViewSection, isFeedView, loadArticles, loadHistory]);

  const handleScanAll = async () => {
    if (scanningAll) return;
    setScanningAll(true);
    setBannerMessage(null);
    try {
      const res = await techKnowledgeHubApi.scanAll();
      await Promise.all([loadMetadata(), loadArticles(), loadHistory()]);
      if (res.alreadyRunning) {
        setBannerMessage({
          tone: 'info',
          text: 'Backend taraması zaten devam ediyor; tamamlandığında liste güncellenecek.',
        });
      } else {
        setBannerMessage({
          tone: res.failed > 0 ? 'warning' : 'info',
          text: `Tarama tamamlandı: ${res.succeeded}/${res.scannedSources} kaynak başarılı, +${res.newAdded} yeni makale eklendi (${res.duplicatesSkipped} duplicate atlandı).`,
        });
      }
    } catch (err) {
      setBannerMessage({
        tone: 'warning',
        text: err instanceof Error ? err.message : 'Tarama başlatılamadı.',
      });
    } finally {
      setScanningAll(false);
    }
  };

  const handleToggleState = async (
    article: TechHubArticleDto,
    patch: { isRead?: boolean; isFavorite?: boolean; isArchived?: boolean }
  ) => {
    try {
      const res = await techKnowledgeHubApi.updateArticleState(article.id, patch);
      if (typeof patch.isArchived === 'boolean') {
        await Promise.all([loadMetadata(), loadArticles()]);
      } else if (
        typeof patch.isFavorite === 'boolean' &&
        activeViewSection === 'favorites' &&
        !res.isFavorite
      ) {
        await Promise.all([loadMetadata(), loadArticles()]);
      } else {
        setArticles((prev) =>
          prev.map((a) =>
            a.id === article.id
              ? { ...a, isRead: res.isRead, isFavorite: res.isFavorite }
              : a
          )
        );
        if (typeof patch.isFavorite === 'boolean') {
          void loadMetadata();
        }
      }
    } catch (err) {
      setBannerMessage({
        tone: 'warning',
        text:
          err instanceof Error
            ? err.message
            : 'Makale durumu güncellenemedi.',
      });
    }
  };

  const resetSourceForm = () => {
    setEditingSourceId(null);
    setFormName('');
    setFormSiteUrl('');
    setFormFeedUrl('');
    setFormCategoryIds([]);
    setFormKeywordFilter('');
    setDiscoveryResult(null);
    setTestMessage(null);
  };

  const openEditSource = (src: TechHubSourceDto) => {
    setEditingSourceId(src.id);
    setFormName(src.name);
    setFormSiteUrl(src.siteUrl);
    setFormFeedUrl(src.feedUrl);
    setFormCategoryIds(src.categoryIds);
    setFormKeywordFilter((src.keywordFilter || []).join(', '));
    setDiscoveryResult(null);
    setTestMessage(null);
    setShowSourceForm(true);
  };

  const handleSaveSource = async (e: React.FormEvent) => {
    e.preventDefault();
    const keywords = formKeywordFilter
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    try {
      if (editingSourceId) {
        await techKnowledgeHubApi.updateSource(editingSourceId, {
          name: formName,
          siteUrl: formSiteUrl,
          feedUrl: formFeedUrl,
          categoryIds: formCategoryIds,
          keywordFilter: keywords.length > 0 ? keywords : null,
        });
      } else {
        await techKnowledgeHubApi.createSource({
          name: formName,
          siteUrl: formSiteUrl,
          feedUrl: formFeedUrl,
          categoryIds: formCategoryIds,
          keywordFilter: keywords.length > 0 ? keywords : null,
        });
      }
      await loadMetadata();
      resetSourceForm();
      setShowSourceForm(false);
    } catch (err) {
      setTestMessage(
        err instanceof Error ? err.message : 'Kaynak kaydedilemedi.'
      );
    }
  };

  const handleAutoDiscover = async () => {
    const target = formSiteUrl.trim() || formFeedUrl.trim();
    if (!target) return;
    setDiscovering(true);
    setTestMessage(null);
    try {
      const res = await techKnowledgeHubApi.discoverFeeds(target);
      setDiscoveryResult(res);
      if (res.candidates.length > 0 && !formFeedUrl.trim()) {
        setFormFeedUrl(res.candidates[0].url);
      }
    } catch (err) {
      setTestMessage(
        err instanceof Error ? err.message : 'Otomatik keşif başarısız.'
      );
    } finally {
      setDiscovering(false);
    }
  };

  const handleTestFormFeed = async () => {
    if (!formFeedUrl.trim()) return;
    setTestingFeed(true);
    try {
      const res = await techKnowledgeHubApi.testFeedUrl(formFeedUrl.trim());
      setTestMessage(
        res.ok
          ? `Doğrulandı (${res.feedType.toUpperCase()}, HTTP ${res.httpStatus}, ${res.itemCount} kayıt)`
          : `Doğrulanamadı: ${res.error}`
      );
    } catch (err) {
      setTestMessage(err instanceof Error ? err.message : 'Test başarısız.');
    } finally {
      setTestingFeed(false);
    }
  };

  const filteredSources = useMemo(() => {
    const q = sourceQuery.trim().toLowerCase();
    return sources.filter((s) => {
      if (
        sourceStatusFilter !== 'all' &&
        s.validationStatus !== sourceStatusFilter
      ) {
        return false;
      }
      if (!q) return true;
      return (
        s.name.toLowerCase().includes(q) ||
        s.feedUrl.toLowerCase().includes(q) ||
        s.siteUrl.toLowerCase().includes(q) ||
        s.categoryNames.some((c) => c.toLowerCase().includes(q))
      );
    });
  }, [sourceQuery, sourceStatusFilter, sources]);

  const activeFiltersCount = useMemo(() => {
    let n = 0;
    if (selectedCategoryId) n++;
    if (selectedSourceId) n++;
    if (fromDate) n++;
    if (toDate) n++;
    if (unreadOnly) n++;
    if (searchQuery.trim()) n++;
    if (sortOrder !== 'newest') n++;
    return n;
  }, [
    fromDate,
    searchQuery,
    selectedCategoryId,
    selectedSourceId,
    sortOrder,
    toDate,
    unreadOnly,
  ]);

  const clearArticleFilters = () => {
    setSelectedCategoryId('');
    setSelectedSourceId('');
    setFromDate('');
    setToDate('');
    setUnreadOnly(false);
    setSearchQuery('');
    setSortOrder('newest');
    setPage(1);
  };

  const selectedCategoryName = useMemo(
    () => categories.find((c) => c.id === selectedCategoryId)?.name || '',
    [categories, selectedCategoryId]
  );

  if (loading) {
    return (
      <div className="rounded-xl bg-white border border-zinc-200 p-10 text-center text-xs text-zinc-500">
        Technology Knowledge Hub yükleniyor...
      </div>
    );
  }

  const pageHeading =
    activeViewSection === 'archive'
      ? 'Arşivlenen Makaleler'
      : activeViewSection === 'favorites'
        ? 'Favori Makaleler'
        : activeViewSection === 'sources'
          ? 'RSS Kaynak Yönetimi'
          : activeViewSection === 'history'
            ? 'Tarama Geçmişi'
            : selectedCategoryName
              ? `${selectedCategoryName} Makaleleri`
              : 'Tüm Makaleler';

  const pageDescription =
    activeViewSection === 'archive'
      ? 'Arşive kaldırılan teknik makaleler kalıcı olarak saklanır; tarih, kategori ve kaynak üzerinden arayabilir veya geri yükleyebilirsiniz.'
      : activeViewSection === 'favorites'
        ? 'Yıldızladığınız ve referans olarak ayırdığınız teknik makaleler.'
        : activeViewSection === 'sources'
          ? 'Doğrulanmış RSS/Atom kaynaklarını yönetin, yeni kaynak keşfedin ve zamanlayıcı ayarlarını düzenleyin.'
          : activeViewSection === 'history'
            ? 'Sunucu taraflı RSS/Atom taramalarının zamanlama, HTTP durum ve duplicate sonuçları.'
            : 'Kubernetes, OpenShift, Security, AWS, Java ve AI odaklı RSS/Atom kaynaklarından toplanan teknik makaleler.';

  return (
    <div className="flex flex-col lg:flex-row items-start gap-6 lg:gap-8">
      {/* Left Fixed-Width Blog Sidebar */}
      <BlogSidebar
        activeSection={sidebarSection}
        isArticleDetail={isArticleDetail}
        categories={categories}
        selectedCategoryId={selectedCategoryId}
        status={status}
        onSelectSection={navigateToSection}
        onSelectCategory={handleSelectCategory}
      />

      {/* Right Main Content Area */}
      <div className="flex-1 min-w-0 w-full space-y-6">
        {bannerMessage && (
          <div
            className={`rounded-xl px-4 py-3 text-xs flex items-center justify-between gap-3 border ${
              bannerMessage.tone === 'warning'
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-white border-zinc-200 text-zinc-700'
            }`}
          >
            <span>{bannerMessage.text}</span>
            <button
              type="button"
              onClick={() => setBannerMessage(null)}
              className="text-xs underline cursor-pointer shrink-0"
            >
              Kapat
            </button>
          </div>
        )}

        {/* FULL-PAGE ARTICLE DETAIL VIEW (NO MODAL/POPUP) */}
        {isArticleDetail && activeArticleId ? (
          <TechKnowledgeArticleDetail
            articleId={activeArticleId}
            geminiConfigured={Boolean(status?.geminiConfigured)}
            cameFromArchive={lastListSectionRef.current === 'archive'}
            onBack={(toArchive) =>
              navigateToSection(toArchive ? 'archive' : 'articles')
            }
            onOpenArticle={(nextId) =>
              navigateToArticle(
                nextId,
                lastListSectionRef.current === 'archive'
              )
            }
            onSelectCategory={(cid) => {
              setSelectedCategoryId(cid);
              setPage(1);
              navigateToSection('articles');
            }}
            onMetadataChanged={() => void loadMetadata()}
          />
        ) : null}

        {/* ARTICLES / FAVORITES / ARCHIVE FEED */}
        {!isArticleDetail && isFeedView && (
          <div className="space-y-6">
            {/* Editorial Feed Header + Search & Filter Bar */}
            <div className="rounded-xl bg-white border border-zinc-200 p-5 sm:p-6 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="space-y-1 max-w-2xl">
                  <h2 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-[#09090B]">
                    {pageHeading}
                  </h2>
                  <p className="text-xs sm:text-sm text-zinc-600 leading-relaxed">
                    {pageDescription}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3 shrink-0">
                  <span className="text-[11px] font-mono tabular-nums text-zinc-500">
                    Son tarama:{' '}
                    <strong className="text-[#09090B] font-medium">
                      {formatTimestampDisplay(
                        status?.scheduler.lastSuccessfulGlobalScanAt || null
                      )}
                    </strong>
                  </span>
                  <button
                    type="button"
                    onClick={() => void handleScanAll()}
                    disabled={scanningAll}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 disabled:opacity-60 text-white transition-colors cursor-pointer"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${
                        scanningAll ? 'animate-spin' : ''
                      }`}
                      aria-hidden="true"
                    />
                    <span>{scanningAll ? 'Taranıyor...' : 'Şimdi Tara'}</span>
                  </button>
                </div>
              </div>

              {/* Search, Source Filter, Sort */}
              <div className="flex flex-wrap items-center gap-2.5">
                <div className="relative flex-1 min-w-[220px]">
                  <Search
                    className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setPage(1);
                    }}
                    placeholder="Başlık, özet, yazar veya etiket ara..."
                    aria-label="Makalelerde ara"
                    className="w-full pl-9 pr-8 py-2 text-xs rounded-lg border border-zinc-200 bg-[#FAFAFA] focus:bg-white focus:outline-none focus:border-[#2563EB]"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('');
                        setPage(1);
                      }}
                      aria-label="Aramayı temizle"
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-[#09090B] cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <select
                  aria-label="Kaynağa göre filtrele"
                  value={selectedSourceId}
                  onChange={(e) => {
                    setSelectedSourceId(e.target.value);
                    setPage(1);
                  }}
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white text-zinc-700 max-w-[210px]"
                >
                  <option value="">Tüm Kaynaklar</option>
                  {sources
                    .filter((s) => s.totalFetched > 0 || s.enabled)
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.totalFetched})
                      </option>
                    ))}
                </select>

                <select
                  aria-label="Sıralama"
                  value={sortOrder}
                  onChange={(e) => {
                    setSortOrder(
                      e.target.value as 'newest' | 'oldest' | 'important'
                    );
                    setPage(1);
                  }}
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white text-zinc-700"
                >
                  <option value="newest">En yeni</option>
                  <option value="oldest">En eski</option>
                  <option value="important">Önemli</option>
                </select>
              </div>

              {/* Secondary Filter Row (Unread, Date Range in Archive, Result Count) */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-zinc-100">
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      setUnreadOnly((v) => !v);
                      setPage(1);
                    }}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg border cursor-pointer transition-colors ${
                      unreadOnly
                        ? 'border-[#2563EB]/40 bg-blue-50 text-[#2563EB]'
                        : 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50'
                    }`}
                  >
                    Okunmamışlar
                  </button>

                  {activeViewSection === 'archive' && (
                    <>
                      <label className="inline-flex items-center gap-1.5 text-xs text-zinc-600">
                        <span>Başlangıç:</span>
                        <input
                          type="date"
                          value={fromDate}
                          onChange={(e) => {
                            setFromDate(e.target.value);
                            setPage(1);
                          }}
                          className="px-2.5 py-1 text-xs rounded-lg border border-zinc-200 bg-white"
                        />
                      </label>
                      <label className="inline-flex items-center gap-1.5 text-xs text-zinc-600">
                        <span>Bitiş:</span>
                        <input
                          type="date"
                          value={toDate}
                          onChange={(e) => {
                            setToDate(e.target.value);
                            setPage(1);
                          }}
                          className="px-2.5 py-1 text-xs rounded-lg border border-zinc-200 bg-white"
                        />
                      </label>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-3 text-xs text-zinc-500">
                  <span className="font-mono tabular-nums">
                    {pagination.total} makale
                  </span>
                  {activeFiltersCount > 0 && (
                    <button
                      type="button"
                      onClick={clearArticleFilters}
                      className="text-[#2563EB] hover:underline cursor-pointer font-medium"
                    >
                      Filtreleri Temizle ({activeFiltersCount})
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Editorial Article Cards Grid */}
            {articlesLoading && articles.length === 0 ? (
              <div className="rounded-xl bg-white border border-zinc-200 p-12 text-center text-xs text-zinc-500">
                Makaleler yükleniyor...
              </div>
            ) : articles.length === 0 ? (
              <div className="rounded-xl bg-white border border-zinc-200 p-12 text-center space-y-2">
                <p className="text-sm font-semibold text-[#09090B]">
                  {activeViewSection === 'archive'
                    ? 'Arşivde eşleşen makale bulunamadı.'
                    : activeViewSection === 'favorites'
                      ? 'Favorilere eklenmiş makale bulunmuyor.'
                      : 'Seçili filtrelere uygun makale bulunamadı.'}
                </p>
                <p className="text-xs text-zinc-500 max-w-md mx-auto">
                  {activeViewSection === 'archive'
                    ? 'Makale kartlarından veya detay sayfasından arşive taşıdığınız içerikler kalıcı olarak burada görüntülenir.'
                    : activeViewSection === 'favorites'
                      ? 'İlginizi çeken makalelerdeki yıldız simgesine basarak favorilerinize ekleyebilirsiniz.'
                      : 'Yeni içerik çekmek için "Şimdi Tara" butonunu kullanabilir veya sol menüden kategori filtresini temizleyebilirsiniz.'}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {articles.map((art) => {
                  const categoryNames = art.categories
                    .map((c) => c.name)
                    .join(', ');
                  return (
                    <article
                      key={art.id}
                      className="rounded-xl bg-white border border-zinc-200 overflow-hidden flex flex-col justify-between transition-colors hover:border-zinc-300 group"
                    >
                      <div>
                        {/* Cover Image or Clean Domain Fallback */}
                        <button
                          type="button"
                          onClick={() =>
                            navigateToArticle(
                              art.id,
                              activeViewSection === 'archive'
                            )
                          }
                          aria-label={`${art.title} makalesini oku`}
                          className="block w-full aspect-[16/9] overflow-hidden border-b border-zinc-100 text-left cursor-pointer"
                        >
                          <ArticleCoverMedia
                            imageUrl={art.imageUrl}
                            title={art.title}
                            sourceName={art.sourceName}
                            categoryLabel={
                              art.categories[0]?.name || 'Engineering'
                            }
                          />
                        </button>

                        {/* Editorial Content Body */}
                        <div className="p-5 sm:p-6 space-y-3">
                          {/* Zero-Pill Unboxed Metadata Line */}
                          <div className="flex items-center justify-between gap-2 text-xs text-zinc-500">
                            <div className="flex items-center flex-wrap gap-x-1.5 gap-y-0.5 min-w-0">
                              <span className="font-semibold text-[#2563EB] truncate">
                                {art.sourceName}
                              </span>
                              {categoryNames && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="font-medium text-zinc-700 truncate">
                                    {categoryNames}
                                  </span>
                                </>
                              )}
                              <span aria-hidden="true">·</span>
                              <span className="font-mono tabular-nums whitespace-nowrap">
                                {formatDateDisplay(
                                  art.publishedAt || art.fetchedAt
                                )}
                              </span>
                            </div>

                            {!art.isRead && (
                              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#2563EB] shrink-0">
                                <span
                                  className="w-1.5 h-1.5 rounded-full bg-[#2563EB]"
                                  aria-hidden="true"
                                />
                                <span>Yeni</span>
                              </span>
                            )}
                          </div>

                          {/* Clickable Article Title */}
                          <button
                            type="button"
                            onClick={() =>
                              navigateToArticle(
                                art.id,
                                activeViewSection === 'archive'
                              )
                            }
                            className="text-left block w-full cursor-pointer"
                          >
                            <h3 className="font-display text-base sm:text-lg font-semibold text-[#09090B] group-hover:text-[#2563EB] transition-colors leading-snug line-clamp-2">
                              {art.title}
                            </h3>
                          </button>

                          {/* Excerpt / Turkish AI Summary */}
                          <p className="text-xs sm:text-sm text-zinc-600 leading-relaxed line-clamp-3">
                            {art.aiSummaryTr ? (
                              <>
                                <span className="font-semibold text-[#2563EB] mr-1">
                                  AI Özet:
                                </span>
                                {art.aiSummaryTr}
                              </>
                            ) : (
                              art.description ||
                              'Bu makale için RSS özeti paylaşılmamış.'
                            )}
                          </p>
                        </div>
                      </div>

                      {/* Card Action Bar */}
                      <div className="px-5 sm:px-6 py-3.5 border-t border-zinc-100 flex items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              void handleToggleState(art, {
                                isRead: !art.isRead,
                              })
                            }
                            className={`px-2.5 py-1 text-[11px] font-medium rounded-lg border transition-colors cursor-pointer ${
                              art.isRead
                                ? 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50'
                                : 'border-[#2563EB]/30 bg-blue-50 text-[#2563EB]'
                            }`}
                          >
                            {art.isRead ? 'Okundu' : 'Okundu İşaretle'}
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              void handleToggleState(art, {
                                isFavorite: !art.isFavorite,
                              })
                            }
                            aria-label={
                              art.isFavorite
                                ? 'Favorilerden çıkar'
                                : 'Favoriye ekle'
                            }
                            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                              art.isFavorite
                                ? 'border-amber-200 bg-amber-50 text-amber-500'
                                : 'border-zinc-200 bg-white text-zinc-400 hover:text-amber-500'
                            }`}
                          >
                            <Star
                              className="w-3.5 h-3.5"
                              fill={art.isFavorite ? 'currentColor' : 'none'}
                              aria-hidden="true"
                            />
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              void handleToggleState(art, {
                                isArchived: !art.isArchived,
                              })
                            }
                            title={
                              art.isArchived
                                ? 'Arşivden çıkar ve aktif akışa döndür'
                                : 'Arşive taşı'
                            }
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded-lg border border-zinc-200 bg-white text-zinc-600 hover:border-zinc-300 hover:text-[#09090B] transition-colors cursor-pointer"
                          >
                            {art.isArchived ? (
                              <>
                                <ArchiveRestore
                                  className="w-3 h-3"
                                  aria-hidden="true"
                                />
                                <span>Geri Yükle</span>
                              </>
                            ) : (
                              <>
                                <Archive
                                  className="w-3 h-3"
                                  aria-hidden="true"
                                />
                                <span>Archive</span>
                              </>
                            )}
                          </button>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() =>
                              navigateToArticle(
                                art.id,
                                activeViewSection === 'archive'
                              )
                            }
                            className="inline-flex items-center gap-1 text-xs font-medium text-[#09090B] hover:text-[#2563EB] transition-colors cursor-pointer"
                          >
                            <span>Oku</span>
                            <ArrowRight
                              className="w-3.5 h-3.5"
                              aria-hidden="true"
                            />
                          </button>
                          <a
                            href={art.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            aria-label={`${art.title} orijinal kaynağını yeni sekmede aç`}
                            title="Orijinal kaynağı yeni sekmede aç"
                            className="p-1.5 rounded-lg border border-zinc-200 text-zinc-500 hover:text-[#09090B] hover:border-zinc-300 transition-colors"
                          >
                            <ExternalLink
                              className="w-3.5 h-3.5"
                              aria-hidden="true"
                            />
                          </a>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}

            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex items-center justify-between rounded-xl bg-white border border-zinc-200 px-5 py-3.5 text-xs">
                <span className="font-mono tabular-nums text-zinc-500">
                  Sayfa {pagination.page} / {pagination.totalPages} (Toplam{' '}
                  {pagination.total})
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={pagination.page <= 1}
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    className="px-3.5 py-1.5 rounded-lg border border-zinc-200 bg-white hover:bg-zinc-50 disabled:opacity-40 cursor-pointer"
                  >
                    Önceki
                  </button>
                  <button
                    type="button"
                    disabled={pagination.page >= pagination.totalPages}
                    onClick={() =>
                      setPage((p) => Math.min(pagination.totalPages, p + 1))
                    }
                    className="px-3.5 py-1.5 rounded-lg border border-zinc-200 bg-white hover:bg-zinc-50 disabled:opacity-40 cursor-pointer"
                  >
                    Sonraki
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* SOURCE MANAGEMENT VIEW */}
        {!isArticleDetail && activeViewSection === 'sources' && (
          <div className="space-y-4">
            <div className="rounded-xl bg-white border border-zinc-200 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h2 className="font-display text-lg sm:text-xl font-bold text-[#09090B]">
                  {pageHeading}
                </h2>
                <p className="text-xs text-zinc-600">{pageDescription}</p>
              </div>
              <button
                type="button"
                onClick={() => void handleScanAll()}
                disabled={scanningAll}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 disabled:opacity-60 text-white transition-colors cursor-pointer shrink-0"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${scanningAll ? 'animate-spin' : ''}`}
                  aria-hidden="true"
                />
                <span>{scanningAll ? 'Taranıyor...' : 'Tümünü Tara'}</span>
              </button>
            </div>

            {/* Scheduler + Optional AI Configuration */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="rounded-xl bg-white border border-zinc-200 p-4 space-y-2.5">
                <h3 className="font-display text-xs font-semibold uppercase tracking-wider text-zinc-700">
                  Backend Otomatik RSS Tarama Zamanlayıcısı
                </h3>
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={status?.scheduler.autoSyncEnabled ?? true}
                      onChange={async (e) => {
                        const updated = await techKnowledgeHubApi.updateConfig({
                          scheduler: { autoSyncEnabled: e.target.checked },
                        });
                        setStatus((prev) =>
                          prev ? { ...prev, scheduler: updated.scheduler } : prev
                        );
                      }}
                    />
                    <span>Otomatik arka plan taraması aktif</span>
                  </label>

                  <select
                    aria-label="Tarama aralığı"
                    value={status?.scheduler.intervalHours ?? 3}
                    onChange={async (e) => {
                      const updated = await techKnowledgeHubApi.updateConfig({
                        scheduler: { intervalHours: Number(e.target.value) },
                      });
                      setStatus((prev) =>
                        prev ? { ...prev, scheduler: updated.scheduler } : prev
                      );
                    }}
                    className="px-2.5 py-1 text-xs rounded-lg border border-zinc-200 bg-white"
                  >
                    {[1, 3, 6, 12, 24].map((h) => (
                      <option key={h} value={h}>
                        Her {h} saat{h === 3 ? ' (Varsayılan)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="rounded-xl bg-white border border-zinc-200 p-4 space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-xs font-semibold uppercase tracking-wider text-zinc-700">
                    Opsiyonel AI Analiz &amp; Türkçe Özetleme
                  </h3>
                  <span
                    className={`text-[11px] font-medium px-2 py-0.5 rounded border ${
                      status?.geminiConfigured
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-zinc-100 text-zinc-600 border-zinc-200'
                    }`}
                  >
                    {status?.geminiConfigured
                      ? 'Sunucu AI Hazır'
                      : 'Sunucu Ortam Değişkeni Yok'}
                  </span>
                </div>
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={status?.aiConfig.autoSummarizeOnScan ?? false}
                      disabled={!status?.geminiConfigured}
                      onChange={async (e) => {
                        const updated = await techKnowledgeHubApi.updateConfig({
                          aiConfig: { autoSummarizeOnScan: e.target.checked },
                        });
                        setStatus((prev) =>
                          prev ? { ...prev, aiConfig: updated.aiConfig } : prev
                        );
                      }}
                    />
                    <span>Yeni makaleleri tarama sırasında otomatik özetle</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Source Filter & Add Button */}
            <div className="rounded-xl bg-white border border-zinc-200 p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2.5 flex-1">
                <div className="relative flex-1 min-w-[220px]">
                  <Search
                    className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2"
                    aria-hidden="true"
                  />
                  <input
                    type="text"
                    value={sourceQuery}
                    onChange={(e) => setSourceQuery(e.target.value)}
                    placeholder="Kaynak adı, URL veya kategori ara..."
                    className="w-full pl-8 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-[#FAFAFA] focus:bg-white"
                  />
                </div>

                <select
                  value={sourceStatusFilter}
                  onChange={(e) =>
                    setSourceStatusFilter(
                      e.target.value as
                        | 'all'
                        | 'verified'
                        | 'unverified'
                        | 'error'
                    )
                  }
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
                >
                  <option value="all">Tüm Durumlar ({sources.length})</option>
                  <option value="verified">Doğrulanmış RSS/Atom</option>
                  <option value="unverified">Doğrulanmamış / Pasif</option>
                  <option value="error">Hata Verenler</option>
                </select>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (showSourceForm) {
                    resetSourceForm();
                    setShowSourceForm(false);
                  } else {
                    resetSourceForm();
                    setShowSourceForm(true);
                  }
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{showSourceForm ? 'Formu Kapat' : 'Yeni Kaynak Ekle'}</span>
              </button>
            </div>

            {/* Add / Edit Source + Auto-Discover Form */}
            {showSourceForm && (
              <form
                onSubmit={handleSaveSource}
                className="rounded-xl bg-white border border-zinc-200 p-5 space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-sm font-semibold text-[#09090B]">
                    {editingSourceId
                      ? 'Kaynağı Düzenle'
                      : 'Yeni RSS / Atom Kaynağı Ekle'}
                  </h3>
                  {editingSourceId && (
                    <button
                      type="button"
                      onClick={() => {
                        resetSourceForm();
                        setShowSourceForm(false);
                      }}
                      className="text-xs text-zinc-500 hover:text-[#09090B] cursor-pointer"
                    >
                      İptal
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="Kaynak adı (örn: F5 NGINX Blog)"
                    className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
                  />
                  <input
                    type="text"
                    value={formKeywordFilter}
                    onChange={(e) => setFormKeywordFilter(e.target.value)}
                    placeholder="Anahtar kelime filtresi (opsiyonel, virgüllü)"
                    className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
                  />
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={formSiteUrl}
                      onChange={(e) => setFormSiteUrl(e.target.value)}
                      placeholder="Site URL (https://...)"
                      className="flex-1 px-3 py-2 text-xs rounded-lg border border-zinc-200"
                    />
                    <button
                      type="button"
                      disabled={discovering}
                      onClick={() => void handleAutoDiscover()}
                      className="inline-flex items-center gap-1 px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-[#FAFAFA] hover:bg-zinc-100 cursor-pointer shrink-0"
                    >
                      <Compass className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{discovering ? 'Aranıyor...' : 'RSS Keşfet'}</span>
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={formFeedUrl}
                      onChange={(e) => setFormFeedUrl(e.target.value)}
                      placeholder="RSS / Atom URL (https://...)"
                      className="flex-1 px-3 py-2 text-xs rounded-lg border border-zinc-200"
                    />
                    <button
                      type="button"
                      disabled={testingFeed || !formFeedUrl.trim()}
                      onClick={() => void handleTestFormFeed()}
                      className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-[#FAFAFA] hover:bg-zinc-100 cursor-pointer shrink-0"
                    >
                      {testingFeed ? 'Test...' : 'RSS Test Et'}
                    </button>
                  </div>
                </div>

                {discoveryResult && (
                  <div className="rounded-lg bg-[#FAFAFA] border border-zinc-200 p-3 text-xs space-y-2">
                    <p className="font-medium text-[#09090B]">
                      {discoveryResult.note}
                    </p>
                    {discoveryResult.candidates.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {discoveryResult.candidates.map((c) => (
                          <button
                            key={c.url}
                            type="button"
                            onClick={() => setFormFeedUrl(c.url)}
                            className="px-2.5 py-1 rounded border border-[#2563EB]/30 bg-blue-50 text-[#2563EB] text-[11px] cursor-pointer"
                          >
                            Kullan: {c.url} ({c.feedType.toUpperCase()},{' '}
                            {c.itemCount})
                          </button>
                        ))}
                      </div>
                    )}
                    {discoveryResult.sitemapUrl && (
                      <p className="text-[11px] text-zinc-500 font-mono">
                        Sitemap bulundu: {discoveryResult.sitemapUrl}
                      </p>
                    )}
                  </div>
                )}

                {testMessage && (
                  <p className="text-xs font-mono text-zinc-700">
                    {testMessage}
                  </p>
                )}

                <div className="space-y-1.5">
                  <span className="block text-xs font-medium text-[#09090B]">
                    Bağlı Kategoriler (Çoklu Seçim)
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {categories.map((cat) => {
                      const selected = formCategoryIds.includes(cat.id);
                      return (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() =>
                            setFormCategoryIds((prev) =>
                              prev.includes(cat.id)
                                ? prev.filter((id) => id !== cat.id)
                                : [...prev, cat.id]
                            )
                          }
                          className={`px-2.5 py-1 text-[11px] rounded-md border cursor-pointer transition-colors ${
                            selected
                              ? 'border-[#2563EB] bg-blue-50 text-[#2563EB] font-medium'
                              : 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50'
                          }`}
                        >
                          {cat.name}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] text-white hover:bg-blue-700 cursor-pointer"
                  >
                    {editingSourceId
                      ? 'Değişiklikleri Kaydet'
                      : 'Kaynağı Kaydet'}
                  </button>
                </div>
              </form>
            )}

            {/* Sources Table */}
            <div className="rounded-xl bg-white border border-zinc-200 overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-[#FAFAFA] border-b border-zinc-200 text-[11px] text-zinc-500">
                  <tr>
                    <th className="py-2.5 px-3 font-medium">Durum</th>
                    <th className="py-2.5 px-3 font-medium">
                      Kaynak &amp; Site
                    </th>
                    <th className="py-2.5 px-3 font-medium">RSS / Atom URL</th>
                    <th className="py-2.5 px-3 font-medium">Kategoriler</th>
                    <th className="py-2.5 px-3 font-medium">
                      Doğrulama / HTTP
                    </th>
                    <th className="py-2.5 px-3 font-medium text-right">
                      Makale
                    </th>
                    <th className="py-2.5 px-3 font-medium">Son Tarama</th>
                    <th className="py-2.5 px-3 font-medium text-right">
                      İşlem
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100">
                  {filteredSources.map((src) => {
                    const isBusy = busySourceId === src.id;
                    const canEnable =
                      Boolean(src.feedUrl) &&
                      src.validationStatus !== 'unverified';
                    return (
                      <tr
                        key={src.id}
                        className="hover:bg-zinc-50/70 align-top"
                      >
                        <td className="py-3 px-3 whitespace-nowrap">
                          <button
                            type="button"
                            disabled={!canEnable || isBusy}
                            onClick={async () => {
                              setBusySourceId(src.id);
                              try {
                                await techKnowledgeHubApi.updateSource(src.id, {
                                  enabled: !src.enabled,
                                });
                                await loadMetadata();
                              } finally {
                                setBusySourceId(null);
                              }
                            }}
                            className={`px-2 py-0.5 rounded border text-[11px] font-medium ${
                              !canEnable
                                ? 'border-zinc-200 bg-zinc-100 text-zinc-400 cursor-not-allowed'
                                : src.enabled
                                  ? 'border-emerald-200 bg-emerald-50 text-emerald-700 cursor-pointer'
                                  : 'border-zinc-200 bg-white text-zinc-600 cursor-pointer'
                            }`}
                          >
                            {src.enabled ? 'Aktif' : 'Pasif'}
                          </button>
                        </td>

                        <td className="py-3 px-3 min-w-[180px]">
                          <div className="font-semibold text-[#09090B]">
                            {src.name}
                          </div>
                          <a
                            href={src.siteUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[11px] text-zinc-500 hover:text-[#2563EB] truncate block max-w-[220px]"
                          >
                            {src.siteUrl}
                          </a>
                          {src.keywordFilter &&
                            src.keywordFilter.length > 0 && (
                              <span className="inline-block mt-1 px-1.5 py-0.5 rounded bg-blue-50 text-[#2563EB] text-[10px] font-mono">
                                Filtre: {src.keywordFilter.join(', ')}
                              </span>
                            )}
                        </td>

                        <td className="py-3 px-3 font-mono text-[11px] text-zinc-600 max-w-[230px]">
                          {src.feedUrl ? (
                            <span className="break-all line-clamp-2">
                              {src.feedUrl}
                            </span>
                          ) : (
                            <span className="text-zinc-400 italic">
                              RSS/Atom URL tanımlı değil
                            </span>
                          )}
                        </td>

                        <td className="py-3 px-3 min-w-[160px]">
                          <div className="text-[11px] text-zinc-700">
                            {src.categoryNames.join(', ')}
                          </div>
                        </td>

                        <td className="py-3 px-3 min-w-[180px]">
                          <div className="flex items-center gap-1.5">
                            {src.validationStatus === 'verified' && (
                              <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>
                                  Verified ({src.feedType.toUpperCase()})
                                </span>
                              </span>
                            )}
                            {src.validationStatus === 'unverified' && (
                              <span className="inline-flex items-center gap-1 text-zinc-600 font-medium">
                                <Info className="w-3.5 h-3.5" />
                                <span>Unverified</span>
                              </span>
                            )}
                            {src.validationStatus === 'error' && (
                              <span className="inline-flex items-center gap-1 text-red-600 font-medium">
                                <AlertCircle className="w-3.5 h-3.5" />
                                <span>Error</span>
                              </span>
                            )}
                            {src.lastHttpStatus && (
                              <span className="font-mono text-[10px] text-zinc-400">
                                HTTP {src.lastHttpStatus}
                              </span>
                            )}
                          </div>
                          {(src.lastError || src.validationNote) && (
                            <p className="text-[11px] text-zinc-500 mt-0.5 line-clamp-2">
                              {src.lastError || src.validationNote}
                            </p>
                          )}
                        </td>

                        <td className="py-3 px-3 text-right font-mono tabular-nums text-zinc-700">
                          {src.totalFetched}
                        </td>

                        <td className="py-3 px-3 font-mono text-[11px] text-zinc-500 whitespace-nowrap">
                          <div>{formatTimestampDisplay(src.lastScanAt)}</div>
                          {src.lastSuccessAt && (
                            <div className="text-[10px] text-emerald-700">
                              Başarılı:{' '}
                              {formatTimestampDisplay(src.lastSuccessAt)}
                            </div>
                          )}
                        </td>

                        <td className="py-3 px-3 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={async () => {
                                setBusySourceId(src.id);
                                try {
                                  const res =
                                    await techKnowledgeHubApi.testSource(
                                      src.id
                                    );
                                  await loadMetadata();
                                  setBannerMessage({
                                    tone: res.ok ? 'info' : 'warning',
                                    text: res.ok
                                      ? `${src.name}: RSS doğrulandı (HTTP ${res.httpStatus}, ${res.itemCount} kayıt).`
                                      : `${src.name}: ${
                                          res.error || 'RSS bulunamadı.'
                                        }`,
                                  });
                                } finally {
                                  setBusySourceId(null);
                                }
                              }}
                              className="px-2 py-1 text-[11px] rounded border border-zinc-200 hover:bg-zinc-50 cursor-pointer"
                            >
                              Test Et
                            </button>

                            <button
                              type="button"
                              disabled={isBusy || !canEnable}
                              onClick={async () => {
                                setBusySourceId(src.id);
                                try {
                                  const res =
                                    await techKnowledgeHubApi.scanSource(
                                      src.id
                                    );
                                  await loadMetadata();
                                  setBannerMessage({
                                    tone: res.ok ? 'info' : 'warning',
                                    text: res.ok
                                      ? `${src.name} tarandı: +${res.newAdded} yeni makale.`
                                      : `${src.name}: ${res.error}`,
                                  });
                                } finally {
                                  setBusySourceId(null);
                                }
                              }}
                              className="px-2 py-1 text-[11px] rounded border border-zinc-200 hover:border-[#2563EB] hover:text-[#2563EB] disabled:opacity-40 cursor-pointer"
                            >
                              Tara
                            </button>

                            <button
                              type="button"
                              onClick={() => openEditSource(src)}
                              aria-label={`Düzenle ${src.name}`}
                              className="p-1.5 rounded border border-zinc-200 text-zinc-600 hover:text-[#09090B] cursor-pointer"
                            >
                              <Pencil className="w-3 h-3" />
                            </button>

                            {pendingDeleteSourceId === src.id ? (
                              <button
                                type="button"
                                onClick={async () => {
                                  await techKnowledgeHubApi.deleteSource(
                                    src.id
                                  );
                                  setPendingDeleteSourceId(null);
                                  await loadMetadata();
                                }}
                                className="px-2 py-1 text-[11px] rounded bg-red-600 text-white cursor-pointer"
                              >
                                Sil
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setPendingDeleteSourceId(src.id)}
                                aria-label={`Sil ${src.name}`}
                                className="p-1.5 rounded border border-zinc-200 text-zinc-400 hover:text-red-600 cursor-pointer"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SCAN HISTORY VIEW */}
        {!isArticleDetail && activeViewSection === 'history' && (
          <div className="space-y-4">
            <div className="rounded-xl bg-white border border-zinc-200 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h2 className="font-display text-lg sm:text-xl font-bold text-[#09090B]">
                  {pageHeading}
                </h2>
                <p className="text-xs text-zinc-600">{pageDescription}</p>
              </div>
              <button
                type="button"
                onClick={() => void handleScanAll()}
                disabled={scanningAll}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 disabled:opacity-60 text-white transition-colors cursor-pointer shrink-0"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${scanningAll ? 'animate-spin' : ''}`}
                  aria-hidden="true"
                />
                <span>{scanningAll ? 'Taranıyor...' : 'Şimdi Tara'}</span>
              </button>
            </div>

            <div className="rounded-xl bg-white border border-zinc-200 overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-[#FAFAFA] border-b border-zinc-200 text-[11px] text-zinc-500">
                  <tr>
                    <th className="py-2.5 px-4 font-medium">Kaynak</th>
                    <th className="py-2.5 px-3 font-medium">Tetikleyici</th>
                    <th className="py-2.5 px-3 font-medium">Durum</th>
                    <th className="py-2.5 px-3 font-medium text-right">HTTP</th>
                    <th className="py-2.5 px-3 font-medium text-right">
                      Bulunan
                    </th>
                    <th className="py-2.5 px-3 font-medium text-right">Yeni</th>
                    <th className="py-2.5 px-3 font-medium text-right">
                      Duplicate
                    </th>
                    <th className="py-2.5 px-3 font-medium text-right">Süre</th>
                    <th className="py-2.5 px-4 font-medium">Bitiş</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 font-mono tabular-nums">
                  {scanHistory.length === 0 ? (
                    <tr>
                      <td
                        colSpan={9}
                        className="py-8 text-center font-sans text-zinc-500"
                      >
                        Henüz tarama kaydı bulunmuyor.
                      </td>
                    </tr>
                  ) : (
                    scanHistory.map((h) => (
                      <tr key={h.id} className="hover:bg-zinc-50/70">
                        <td className="py-2.5 px-4 font-sans font-medium text-[#09090B]">
                          <div>{h.sourceName}</div>
                          {h.errorMessage && (
                            <div className="text-[11px] text-red-600 font-normal">
                              {h.errorMessage}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 font-sans capitalize text-zinc-600">
                          {h.trigger}
                        </td>
                        <td className="py-2.5 px-3 font-sans">
                          <span
                            className={
                              h.status === 'success' ||
                              h.status === 'not_modified'
                                ? 'text-emerald-700 font-medium'
                                : h.status === 'error'
                                  ? 'text-red-600 font-medium'
                                  : 'text-zinc-500'
                            }
                          >
                            {h.status}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          {h.httpStatus ?? '—'}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          {h.itemsFound}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          +{h.newAdded}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          {h.duplicatesSkipped}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          {h.durationMs}ms
                        </td>
                        <td className="py-2.5 px-4 text-zinc-500">
                          {formatTimestampDisplay(h.finishedAt)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
