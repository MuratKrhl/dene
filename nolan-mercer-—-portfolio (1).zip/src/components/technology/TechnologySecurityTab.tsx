import React, { useMemo, useState } from 'react';
import {
  Check,
  CheckCircle2,
  ExternalLink,
  RefreshCw,
  Search,
  ShieldAlert,
  Star,
  Trash2,
  X,
} from 'lucide-react';
import {
  SecurityRecord,
  SecurityRecordKind,
  SecuritySeverity,
} from '../../types/technology';
import {
  deleteSecurityRecordById,
  syncTechnologyByContentType,
  toggleSecurityFavorite,
  toggleSecurityRead,
} from '../../services/technology/syncEngine';
import { formatTechDate } from '../../services/technology/retentionEngine';

interface TechnologySecurityTabProps {
  records: SecurityRecord[];
  onDataChanged: () => void;
}

type SecuritySubTab =
  | 'all'
  | SecurityRecordKind
  | 'saved'
  | 'archive';

const SUB_TABS: Array<{ key: SecuritySubTab; label: string }> = [
  { key: 'all', label: 'All Security' },
  { key: 'cve', label: 'CVE Records' },
  { key: 'security-advisory', label: 'Advisories' },
  { key: 'exploit', label: 'Exploits / KEV' },
  { key: 'malware', label: 'Malware' },
  { key: 'vulnerability-news', label: 'Vulnerability News' },
  { key: 'security-research', label: 'Research' },
  { key: 'saved', label: 'Saved' },
  { key: 'archive', label: 'Archive' },
];

function severityTextClass(sev: SecuritySeverity | null): string {
  if (sev === 'CRITICAL') return 'text-red-700 font-bold';
  if (sev === 'HIGH') return 'text-red-600 font-semibold';
  if (sev === 'MEDIUM') return 'text-amber-700 font-semibold';
  if (sev === 'LOW') return 'text-zinc-600 font-medium';
  return 'text-zinc-500';
}

export const TechnologySecurityTab: React.FC<TechnologySecurityTabProps> = ({
  records,
  onDataChanged,
}) => {
  const [subTab, setSubTab] = useState<SecuritySubTab>('all');
  const [search, setSearch] = useState('');
  const [severityFilter, setSeverityFilter] = useState<'all' | SecuritySeverity>(
    'all'
  );
  const [sourceFilter, setSourceFilter] = useState('all');
  const [selectedRecord, setSelectedRecord] = useState<SecurityRecord | null>(
    null
  );
  const [isSyncing, setIsSyncing] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const uniqueSources = useMemo(
    () => Array.from(new Set(records.map((r) => r.source))).sort(),
    [records]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return records
      .filter((r) => {
        if (subTab === 'archive') {
          if (!r.isArchived) return false;
        } else if (subTab === 'saved') {
          if (!r.isFavorite) return false;
        } else {
          if (r.isArchived) return false;
          if (subTab !== 'all' && r.contentType !== subTab) return false;
        }
        if (severityFilter !== 'all' && r.severity !== severityFilter)
          return false;
        if (sourceFilter !== 'all' && r.source !== sourceFilter) return false;
        if (q) {
          const hay = [
            r.cveId || '',
            r.title,
            r.description,
            r.source,
            ...r.affectedProducts,
            ...r.tags,
          ]
            .join(' ')
            .toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort(
        (a, b) =>
          Date.parse(b.publishedAt || b.fetchedAt) -
          Date.parse(a.publishedAt || a.fetchedAt)
      );
  }, [records, search, severityFilter, sourceFilter, subTab]);

  const handleSync = async () => {
    setIsSyncing(true);
    try {
      await syncTechnologyByContentType('security');
      onDataChanged();
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 pb-3">
        <div className="flex flex-wrap items-center gap-1">
          {SUB_TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setSubTab(t.key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                subTab === t.key
                  ? 'bg-[#09090B] text-white'
                  : 'text-zinc-600 hover:text-[#09090B] hover:bg-zinc-100'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={handleSync}
          disabled={isSyncing}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 disabled:opacity-50 cursor-pointer whitespace-nowrap"
        >
          <RefreshCw
            className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`}
          />
          <span>{isSyncing ? 'Syncing Intel...' : 'Sync Security Feeds'}</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search CVE ID, affected package, advisory, description..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
          />
        </div>

        <select
          aria-label="Filter by severity"
          value={severityFilter}
          onChange={(e) =>
            setSeverityFilter(e.target.value as 'all' | SecuritySeverity)
          }
          className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
        >
          <option value="all">All Severities</option>
          <option value="CRITICAL">CRITICAL</option>
          <option value="HIGH">HIGH</option>
          <option value="MEDIUM">MEDIUM</option>
          <option value="LOW">LOW</option>
        </select>

        <select
          aria-label="Filter by security source"
          value={sourceFilter}
          onChange={(e) => setSourceFilter(e.target.value)}
          className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
        >
          <option value="all">All Sources</option>
          {uniqueSources.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {/* Structured Security List + Optional Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div
          className={`${
            selectedRecord ? 'lg:col-span-7' : 'lg:col-span-12'
          } rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100`}
        >
          {filtered.length === 0 ? (
            <div className="p-8 text-center space-y-2">
              <ShieldAlert className="w-7 h-7 text-zinc-400 mx-auto" />
              <p className="text-sm font-medium text-[#09090B]">
                No security intelligence records match this view.
              </p>
              <p className="text-xs text-zinc-500">
                Click Sync Security Feeds to fetch NVD CVEs, CISA KEV, CISA Advisories, Red Hat Security Data, The Hacker News, BleepingComputer, and SecurityWeek.
              </p>
            </div>
          ) : (
            filtered.map((rec) => (
              <div
                key={rec.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-zinc-50/70 transition-colors"
              >
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap text-[11px] font-mono tabular-nums">
                    {rec.cveId && (
                      <span className="font-semibold text-[#09090B]">
                        {rec.cveId}
                      </span>
                    )}
                    <span className="text-[#2563EB] font-sans font-medium">
                      {rec.source}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="capitalize font-sans text-zinc-500">
                      {rec.contentType.replace('-', ' ')}
                    </span>
                    {rec.severity && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className={severityTextClass(rec.severity)}>
                          {rec.severity}
                          {rec.cvss !== null ? ` (CVSS ${rec.cvss})` : ''}
                        </span>
                      </>
                    )}
                    <span aria-hidden="true">·</span>
                    <span className="text-zinc-500">
                      {formatTechDate(rec.publishedAt)}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedRecord(rec)}
                    className="text-left text-sm font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-2 cursor-pointer"
                  >
                    {rec.title}
                  </button>

                  {rec.affectedProducts.length > 0 && (
                    <p className="text-[11px] text-zinc-500 truncate">
                      Affected: {rec.affectedProducts.slice(0, 3).join(', ')}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={async () => {
                      await toggleSecurityRead(rec.id);
                      onDataChanged();
                    }}
                    aria-label={rec.isRead ? 'Mark unread' : 'Mark read'}
                    className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                      rec.isRead ? 'text-emerald-600' : 'text-zinc-400'
                    }`}
                  >
                    {rec.isRead ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await toggleSecurityFavorite(rec.id);
                      onDataChanged();
                    }}
                    aria-label="Favorite security record"
                    className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                      rec.isFavorite ? 'text-amber-500' : 'text-zinc-400'
                    }`}
                  >
                    <Star
                      className="w-4 h-4"
                      fill={rec.isFavorite ? 'currentColor' : 'none'}
                    />
                  </button>
                  {pendingDeleteId === rec.id ? (
                    <button
                      type="button"
                      onClick={async () => {
                        await deleteSecurityRecordById(rec.id);
                        if (selectedRecord?.id === rec.id)
                          setSelectedRecord(null);
                        setPendingDeleteId(null);
                        onDataChanged();
                      }}
                      className="px-2 py-0.5 text-[11px] bg-red-600 text-white rounded cursor-pointer"
                    >
                      Confirm
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setPendingDeleteId(rec.id)}
                      aria-label="Delete record"
                      className="p-1.5 rounded hover:bg-zinc-100 text-zinc-400 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                  <a
                    href={rec.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Open security source"
                    className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500 hover:text-[#2563EB]"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Structured Detail Inspector */}
        {selectedRecord && (
          <aside className="lg:col-span-5 rounded-xl bg-white border border-zinc-200 p-5 space-y-4 sticky top-20">
            <div className="flex items-start justify-between gap-3 border-b border-zinc-100 pb-3">
              <div>
                <p className="text-xs font-mono text-[#2563EB]">
                  {selectedRecord.cveId ||
                    selectedRecord.contentType.toUpperCase()}
                </p>
                <h3 className="font-display text-base font-bold text-[#09090B]">
                  {selectedRecord.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                aria-label="Close detail"
                className="p-1 rounded hover:bg-zinc-100 text-zinc-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <dl className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <dt className="text-zinc-500">Source</dt>
                <dd className="font-medium text-[#09090B]">
                  {selectedRecord.source}
                </dd>
              </div>
              <div>
                <dt className="text-zinc-500">Status</dt>
                <dd className="font-medium text-[#09090B]">
                  {selectedRecord.status}
                </dd>
              </div>
              <div>
                <dt className="text-zinc-500">Published</dt>
                <dd className="font-mono tabular-nums text-[#09090B]">
                  {formatTechDate(selectedRecord.publishedAt)}
                </dd>
              </div>
              <div>
                <dt className="text-zinc-500">Last Modified</dt>
                <dd className="font-mono tabular-nums text-[#09090B]">
                  {selectedRecord.modifiedAt
                    ? formatTechDate(selectedRecord.modifiedAt)
                    : 'Not reported'}
                </dd>
              </div>
              <div>
                <dt className="text-zinc-500">CVSS Score</dt>
                <dd className="font-mono tabular-nums text-[#09090B]">
                  {selectedRecord.cvss !== null
                    ? selectedRecord.cvss
                    : 'Not provided by feed'}
                </dd>
              </div>
              <div>
                <dt className="text-zinc-500">Severity</dt>
                <dd className={severityTextClass(selectedRecord.severity)}>
                  {selectedRecord.severity || 'Not rated'}
                </dd>
              </div>
            </dl>

            <div className="space-y-1">
              <p className="text-xs font-semibold text-[#09090B]">
                Description
              </p>
              <p className="text-xs text-zinc-600 leading-relaxed">
                {selectedRecord.description || 'No description provided in feed.'}
              </p>
            </div>

            {selectedRecord.affectedProducts.length > 0 && (
              <div className="space-y-1">
                <p className="text-xs font-semibold text-[#09090B]">
                  Affected Products / Packages
                </p>
                <ul className="text-xs font-mono text-zinc-600 space-y-1 list-disc list-inside">
                  {selectedRecord.affectedProducts.map((p) => (
                    <li key={p} className="truncate">
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {selectedRecord.references.length > 0 && (
              <div className="space-y-1">
                <p className="text-xs font-semibold text-[#09090B]">
                  References
                </p>
                <div className="space-y-1">
                  {selectedRecord.references.map((refUrl) => (
                    <a
                      key={refUrl}
                      href={refUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-xs text-[#2563EB] hover:underline truncate"
                    >
                      {refUrl}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </aside>
        )}
      </div>
    </div>
  );
};
