import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  CheckCircle2,
  ChevronLeft,
  ExternalLink,
  Headphones,
  Heart,
  Pause,
  Play,
  Plus,
  Search,
  Star,
  X,
} from 'lucide-react';
import { usePodcastPlayer } from '../../context/PodcastPlayerContext';
import { githubProvider } from '../../github/engine';
import { GitHubRepository } from '../../github/types';
import {
  setAggregatedArticleRead,
  toggleAggregatedArticleFavorite,
} from '../../services/articles/articleAggregator';
import {
  buildUnifiedDiscoverFeed,
  DEFAULT_DISCOVER_FILTER,
  DiscoverFilterState,
  filterAndSortUnifiedFeed,
  parseDiscoverFilterFromSearch,
  serializeDiscoverFilterToSearch,
  UnifiedFeedItem,
} from '../../services/technology/discoverFeed';
import { formatTechDate } from '../../services/technology/retentionEngine';
import {
  addManualEvent,
  addManualLearningItem,
  addManualVideo,
  setLearningItemStatus,
  toggleEventFavorite,
  toggleLearningFavorite,
  togglePodcastEpisodeFavorite,
  togglePodcastEpisodePlayed,
  togglePodcastSeriesFollow,
  toggleSecurityFavorite,
  toggleSecurityRead,
  toggleVideoFavorite,
  toggleVideoWatched,
} from '../../services/technology/syncEngine';
import {
  createManualMediaEvent,
  createManualMediaVideo,
  patchMediaEvent,
  patchMediaPodcastEpisode,
  patchMediaPodcastSeries,
  patchMediaVideo,
} from '../../services/techMediaApi';
import { AggregatedArticle } from '../../types/article';
import {
  LearningContentKind,
  LearningItem,
  LearningProgressStatus,
  PodcastEpisode,
  PodcastSeries,
  SecurityRecord,
  TechEvent,
  TechEventType,
  TechVideo,
} from '../../types/technology';
import { ResilientImage } from '../ResilientImage';
import { ContentFeed } from './ContentFeed';
import { FilterBar } from './FilterBar';

interface TechnologyDiscoverTabProps {
  articles: AggregatedArticle[];
  videos: TechVideo[];
  podcastSeries: PodcastSeries[];
  podcastEpisodes: PodcastEpisode[];
  learningItems: LearningItem[];
  securityRecords: SecurityRecord[];
  events: TechEvent[];
  githubRepos: GitHubRepository[];
  savedGithubRepoIds: number[];
  legacyPreset?: string;
  urlQuerySyncKey?: string;
  selectedSeriesId: string | null;
  onSelectSeries: (seriesId: string | null) => void;
  onDataChanged: () => void | Promise<void>;
  onNavigate: (path: string) => void;
  onRetrySync?: () => void;
}

type ManualResourceKind = 'video' | 'learning' | 'event';

export const TechnologyDiscoverTab: React.FC<TechnologyDiscoverTabProps> = ({
  articles,
  videos,
  podcastSeries,
  podcastEpisodes,
  learningItems,
  securityRecords,
  events,
  githubRepos,
  savedGithubRepoIds,
  legacyPreset,
  urlQuerySyncKey,
  selectedSeriesId,
  onSelectSeries,
  onDataChanged,
  onNavigate,
  onRetrySync,
}) => {
  const { currentEpisode, isPlaying, playEpisode, togglePlayPause } =
    usePodcastPlayer();

  const [filter, setFilter] = useState<DiscoverFilterState>(() =>
    parseDiscoverFilterFromSearch(window.location.search, legacyPreset)
  );
  const [showPodcastDrawer, setShowPodcastDrawer] = useState(false);
  const [showAddDrawer, setShowAddDrawer] = useState(false);
  const [manualKind, setManualKind] = useState<ManualResourceKind>('video');
  const [seriesSearch, setSeriesSearch] = useState('');

  // Manual form fields
  const [mTitle, setMTitle] = useState('');
  const [mOrg, setMOrg] = useState('Red Hat TV');
  const [mUrl, setMUrl] = useState('');
  const [mCategory, setMCategory] = useState('OpenShift');
  const [mDuration, setMDuration] = useState('');
  const [mLearningKind, setMLearningKind] =
    useState<LearningContentKind>('lab');
  const [mEventType, setMEventType] = useState<TechEventType>('conference');
  const [mStartDate, setMStartDate] = useState('');
  const [mLocation, setMLocation] = useState('');

  // Re-sync filter state when URL query changes from external navigation (Global Search, Overview links, popstate)
  useEffect(() => {
    setFilter(parseDiscoverFilterFromSearch(window.location.search, legacyPreset));
  }, [legacyPreset, urlQuerySyncKey]);

  const updateFilterAndUrl = (next: DiscoverFilterState) => {
    setFilter(next);
    const nextSearch = serializeDiscoverFilterToSearch(next);
    const target = `/knowledge-hub/technology/discover${nextSearch}`;
    if (window.location.pathname + window.location.search !== target) {
      window.history.replaceState({ fromWorkspaceApp: true }, '', target);
    }
  };

  const handleClearAll = () => {
    updateFilterAndUrl({
      ...DEFAULT_DISCOVER_FILTER,
      viewMode: filter.viewMode,
    });
  };

  const unifiedItems = useMemo(
    () =>
      buildUnifiedDiscoverFeed({
        articles,
        videos,
        podcastEpisodes,
        githubRepos,
        savedGithubRepoIds,
        learningItems,
        securityRecords,
        events,
      }),
    [
      articles,
      events,
      githubRepos,
      learningItems,
      podcastEpisodes,
      savedGithubRepoIds,
      securityRecords,
      videos,
    ]
  );

  const filteredItems = useMemo(
    () => filterAndSortUnifiedFeed(unifiedItems, filter),
    [filter, unifiedItems]
  );

  const continueListening = useMemo(
    () =>
      podcastEpisodes
        .filter((e) => e.playbackPosition > 5 && !e.isPlayed)
        .sort(
          (a, b) =>
            Date.parse(b.publishedAt || b.fetchedAt) -
            Date.parse(a.publishedAt || a.fetchedAt)
        )
        .slice(0, 4),
    [podcastEpisodes]
  );

  const activeSeriesDetail = useMemo(
    () => podcastSeries.find((s) => s.id === selectedSeriesId) || null,
    [podcastSeries, selectedSeriesId]
  );

  const seriesEpisodes = useMemo(() => {
    if (!activeSeriesDetail) return [];
    const q = seriesSearch.trim().toLowerCase();
    return podcastEpisodes
      .filter((e) => e.seriesId === activeSeriesDetail.id)
      .filter((e) => {
        if (!q) return true;
        return (
          e.title.toLowerCase().includes(q) ||
          e.description.toLowerCase().includes(q)
        );
      })
      .sort(
        (a, b) =>
          Date.parse(b.publishedAt || b.fetchedAt) -
          Date.parse(a.publishedAt || a.fetchedAt)
      );
  }, [activeSeriesDetail, podcastEpisodes, seriesSearch]);

  const handleToggleFavorite = async (item: UnifiedFeedItem) => {
    if (item.kind === 'article') {
      await toggleAggregatedArticleFavorite(item.originalId);
    } else if (item.kind === 'video') {
      if (item.originalId.startsWith('mvid-')) {
        await patchMediaVideo(item.originalId, { isFavorite: !item.isFavorite });
      } else {
        await toggleVideoFavorite(item.originalId);
      }
    } else if (item.kind === 'podcast') {
      if (item.originalId.startsWith('mep-')) {
        await patchMediaPodcastEpisode(item.originalId, {
          isFavorite: !item.isFavorite,
        });
      } else {
        await togglePodcastEpisodeFavorite(item.originalId);
      }
    } else if (item.kind === 'github' && item.githubRepo) {
      githubProvider.toggleSaveRepo(item.githubRepo.id);
    } else if (item.kind === 'learning') {
      await toggleLearningFavorite(item.originalId);
    } else if (item.kind === 'security') {
      await toggleSecurityFavorite(item.originalId);
    } else if (item.kind === 'event') {
      if (item.originalId.startsWith('mevt-')) {
        await patchMediaEvent(item.originalId, { isFavorite: !item.isFavorite });
      } else {
        await toggleEventFavorite(item.originalId);
      }
    }
    await onDataChanged();
  };

  const handleToggleConsumed = async (item: UnifiedFeedItem) => {
    if (item.kind === 'article') {
      await setAggregatedArticleRead(item.originalId, !item.isConsumed);
    } else if (item.kind === 'video') {
      if (item.originalId.startsWith('mvid-')) {
        await patchMediaVideo(item.originalId, { isWatched: !item.isConsumed });
      } else {
        await toggleVideoWatched(item.originalId);
      }
    } else if (item.kind === 'podcast') {
      if (item.originalId.startsWith('mep-')) {
        await patchMediaPodcastEpisode(item.originalId, {
          isPlayed: !item.isConsumed,
        });
      } else {
        await togglePodcastEpisodePlayed(item.originalId);
      }
    } else if (item.kind === 'security') {
      await toggleSecurityRead(item.originalId);
    }
    await onDataChanged();
  };

  const handleLearningStatusChange = async (
    itemId: string,
    status: LearningProgressStatus
  ) => {
    await setLearningItemStatus(itemId, status);
    await onDataChanged();
  };

  const handleAddManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mTitle.trim() || !mUrl.trim()) return;

    if (manualKind === 'video') {
      await createManualMediaVideo({
        title: mTitle,
        channelName: mOrg || 'Red Hat TV',
        videoUrl: mUrl,
        category: mCategory || 'Red Hat',
        duration: mDuration,
      }).catch(() =>
        addManualVideo({
          title: mTitle,
          channelName: mOrg || 'Red Hat TV',
          videoUrl: mUrl,
          category: mCategory || 'Red Hat',
          duration: mDuration,
        })
      );
    } else if (manualKind === 'learning') {
      await addManualLearningItem({
        title: mTitle,
        platform: mOrg || 'Red Hat Learning',
        url: mUrl,
        category: mCategory || 'OpenShift',
        contentType: mLearningKind,
        duration: mDuration,
      });
    } else {
      await createManualMediaEvent({
        eventName: mTitle,
        organizer: mOrg || 'Red Hat Summit',
        startDate: mStartDate || undefined,
        location: mLocation || undefined,
        eventType: mEventType,
        registrationUrl: mUrl,
      }).catch(() =>
        addManualEvent({
          eventName: mTitle,
          organizer: mOrg || 'Red Hat Summit',
          startDate: mStartDate || undefined,
          location: mLocation || undefined,
          eventType: mEventType,
          registrationUrl: mUrl,
        })
      );
    }

    setMTitle('');
    setMUrl('');
    setMDuration('');
    setMStartDate('');
    setMLocation('');
    setShowAddDrawer(false);
    await onDataChanged();
  };

  // Podcast Show Detail View (Preserved seamlessly inside Discover)
  if (activeSeriesDetail) {
    return (
      <div className="space-y-6">
        <button
          type="button"
          onClick={() => onSelectSeries(null)}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-600 hover:text-[#09090B] cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to Discover</span>
        </button>

        <div className="rounded-2xl bg-white border border-zinc-200 p-6 flex flex-col md:flex-row gap-6 items-start">
          <div className="w-36 h-36 rounded-xl overflow-hidden border border-zinc-200 shrink-0 bg-zinc-100">
            <ResilientImage
              src={activeSeriesDetail.artworkUrl || undefined}
              alt={activeSeriesDetail.title}
              fallbackTitle={activeSeriesDetail.title}
            />
          </div>

          <div className="flex-1 space-y-3 min-w-0">
            <div className="space-y-1">
              <p className="text-xs font-medium text-[#2563EB]">
                {activeSeriesDetail.category} ·{' '}
                {activeSeriesDetail.publisher ||
                  activeSeriesDetail.author ||
                  'Podcast'}
              </p>
              <h2 className="font-display text-2xl font-bold text-[#09090B]">
                {activeSeriesDetail.title}
              </h2>
            </div>

            {activeSeriesDetail.description && (
              <p className="text-sm text-zinc-600 leading-relaxed">
                {activeSeriesDetail.description}
              </p>
            )}

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={async () => {
                  if (activeSeriesDetail.id.startsWith('mser-')) {
                    await patchMediaPodcastSeries(activeSeriesDetail.id, {
                      isFollowed: !activeSeriesDetail.isFollowed,
                    });
                  } else {
                    await togglePodcastSeriesFollow(activeSeriesDetail.id);
                  }
                  await onDataChanged();
                }}
                className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg border cursor-pointer ${
                  activeSeriesDetail.isFollowed
                    ? 'bg-[#09090B] text-white border-[#09090B]'
                    : 'bg-white text-[#09090B] border-zinc-200 hover:bg-zinc-50'
                }`}
              >
                <Heart
                  className="w-3.5 h-3.5"
                  fill={activeSeriesDetail.isFollowed ? 'currentColor' : 'none'}
                />
                <span>
                  {activeSeriesDetail.isFollowed ? 'Following' : 'Follow Podcast'}
                </span>
              </button>

              <a
                href={activeSeriesDetail.websiteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 hover:bg-zinc-50 text-zinc-700"
              >
                <span>Website</span>
                <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
              </a>

              <span className="text-xs font-mono tabular-nums text-zinc-500">
                {seriesEpisodes.length} episodes indexed
              </span>
            </div>
          </div>
        </div>

        <div className="relative max-w-md">
          <Search
            className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2"
            aria-hidden="true"
          />
          <input
            type="text"
            value={seriesSearch}
            onChange={(e) => setSeriesSearch(e.target.value)}
            placeholder="Search episodes in this show..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
          />
        </div>

        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100">
          {seriesEpisodes.map((ep) => {
            const isCurrent = currentEpisode?.id === ep.id;
            return (
              <div
                key={ep.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <button
                    type="button"
                    onClick={() =>
                      isCurrent
                        ? togglePlayPause()
                        : playEpisode(ep, seriesEpisodes)
                    }
                    aria-label={
                      isCurrent && isPlaying
                        ? `Pause ${ep.title}`
                        : `Play ${ep.title}`
                    }
                    className="w-9 h-9 rounded-full bg-[#09090B] text-white flex items-center justify-center hover:bg-zinc-800 shrink-0 cursor-pointer"
                  >
                    {isCurrent && isPlaying ? (
                      <Pause className="w-4 h-4" />
                    ) : (
                      <Play className="w-4 h-4 ml-0.5" />
                    )}
                  </button>

                  <div className="min-w-0 space-y-1">
                    <p className="text-sm font-semibold text-[#09090B]">
                      {ep.title}
                    </p>
                    <p className="text-xs text-zinc-500 flex items-center gap-2 flex-wrap font-mono tabular-nums">
                      <span>{formatTechDate(ep.publishedAt)}</span>
                      {ep.duration && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{ep.duration}</span>
                        </>
                      )}
                      {ep.playbackPosition > 0 && !ep.isPlayed && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-[#2563EB]">
                            Resume {Math.floor(ep.playbackPosition / 60)}m
                          </span>
                        </>
                      )}
                    </p>
                    {ep.description && (
                      <p className="text-xs text-zinc-600 line-clamp-2">
                        {ep.description}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={async () => {
                      if (ep.id.startsWith('mep-')) {
                        await patchMediaPodcastEpisode(ep.id, {
                          isPlayed: !ep.isPlayed,
                        });
                      } else {
                        await togglePodcastEpisodePlayed(ep.id);
                      }
                      await onDataChanged();
                    }}
                    aria-label="Toggle played"
                    className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                      ep.isPlayed ? 'text-emerald-600' : 'text-zinc-400'
                    }`}
                  >
                    {ep.isPlayed ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      if (ep.id.startsWith('mep-')) {
                        await patchMediaPodcastEpisode(ep.id, {
                          isFavorite: !ep.isFavorite,
                        });
                      } else {
                        await togglePodcastEpisodeFavorite(ep.id);
                      }
                      await onDataChanged();
                    }}
                    aria-label="Save episode"
                    className={`p-1.5 rounded hover:bg-zinc-100 cursor-pointer ${
                      ep.isFavorite ? 'text-amber-500' : 'text-zinc-400'
                    }`}
                  >
                    <Star
                      className="w-4 h-4"
                      fill={ep.isFavorite ? 'currentColor' : 'none'}
                    />
                  </button>
                  <a
                    href={ep.episodeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Open original episode"
                    className="p-1.5 rounded hover:bg-zinc-100 text-zinc-500 hover:text-[#2563EB]"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <FilterBar
        filter={filter}
        totalMatches={filteredItems.length}
        onChange={updateFilterAndUrl}
        onClearAll={handleClearAll}
        rightActions={
          <div className="flex items-center gap-1.5">
            {podcastSeries.length > 0 && (
              <button
                type="button"
                onClick={() => setShowPodcastDrawer((p) => !p)}
                aria-expanded={showPodcastDrawer}
                className={`inline-flex items-center gap-1.5 px-2.5 py-2 text-xs font-medium rounded-lg border cursor-pointer whitespace-nowrap ${
                  showPodcastDrawer
                    ? 'border-[#09090B] bg-[#09090B] text-white'
                    : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                }`}
              >
                <Headphones className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Shows ({podcastSeries.length})</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setShowAddDrawer((p) => !p)}
              aria-expanded={showAddDrawer}
              className="inline-flex items-center gap-1 px-2.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Add</span>
            </button>
          </div>
        }
      />

      {/* Contextual Podcast Shows & Continue Listening Drawer */}
      {showPodcastDrawer && (
        <section
          aria-label="Podcast shows and playback resume"
          className="rounded-xl bg-white border border-zinc-200 p-4 space-y-4"
        >
          <div className="flex items-center justify-between border-b border-zinc-100 pb-2.5">
            <h3 className="font-display text-sm font-semibold text-[#09090B]">
              Podcast Shows &amp; Continue Listening
            </h3>
            <button
              type="button"
              onClick={() => setShowPodcastDrawer(false)}
              aria-label="Close podcast shows panel"
              className="p-1 rounded hover:bg-zinc-100 text-zinc-500 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {continueListening.length > 0 && (
            <div className="space-y-2">
              <p className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider">
                Continue Listening
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {continueListening.map((ep) => {
                  const isCurr = currentEpisode?.id === ep.id;
                  return (
                    <div
                      key={ep.id}
                      className="flex items-center gap-3 p-2.5 rounded-lg border border-zinc-200"
                    >
                      <button
                        type="button"
                        onClick={() =>
                          isCurr
                            ? togglePlayPause()
                            : playEpisode(ep, continueListening)
                        }
                        aria-label={isCurr && isPlaying ? 'Pause' : 'Play'}
                        className="w-8 h-8 rounded-full bg-[#09090B] text-white flex items-center justify-center shrink-0 cursor-pointer"
                      >
                        {isCurr && isPlaying ? (
                          <Pause className="w-3.5 h-3.5" />
                        ) : (
                          <Play className="w-3.5 h-3.5 ml-0.5" />
                        )}
                      </button>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-[#09090B] truncate">
                          {ep.title}
                        </p>
                        <p className="text-[11px] text-zinc-500 font-mono tabular-nums truncate">
                          {ep.seriesTitle} · Resumes at{' '}
                          {Math.floor(ep.playbackPosition / 60)}m
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {podcastSeries.map((show) => (
              <div
                key={show.id}
                className="rounded-lg border border-zinc-200 p-3 flex items-center gap-3"
              >
                <button
                  type="button"
                  onClick={() => onSelectSeries(show.id)}
                  className="w-12 h-12 rounded-lg overflow-hidden border border-zinc-200 shrink-0 bg-zinc-100 cursor-pointer"
                >
                  <ResilientImage
                    src={show.artworkUrl || undefined}
                    alt={show.title}
                    fallbackTitle={show.title}
                  />
                </button>
                <div className="min-w-0 flex-1">
                  <button
                    type="button"
                    onClick={() => onSelectSeries(show.id)}
                    className="text-left text-xs font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-1 cursor-pointer"
                  >
                    {show.title}
                  </button>
                  <p className="text-[11px] text-zinc-500 truncate">
                    {show.category} · {show.episodeCount} episodes
                  </p>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    if (show.id.startsWith('mser-')) {
                      await patchMediaPodcastSeries(show.id, {
                        isFollowed: !show.isFollowed,
                      });
                    } else {
                      await togglePodcastSeriesFollow(show.id);
                    }
                    await onDataChanged();
                  }}
                  aria-label={show.isFollowed ? 'Unfollow show' : 'Follow show'}
                  className={`p-1.5 rounded-md border cursor-pointer shrink-0 ${
                    show.isFollowed
                      ? 'bg-[#09090B] text-white border-[#09090B]'
                      : 'border-zinc-200 text-zinc-600 hover:bg-zinc-50'
                  }`}
                >
                  <Heart
                    className="w-3.5 h-3.5"
                    fill={show.isFollowed ? 'currentColor' : 'none'}
                  />
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Contextual Manual Resource Drawer (Video / Course / Event) */}
      {showAddDrawer && (
        <form
          onSubmit={handleAddManualSubmit}
          className="rounded-xl bg-white border border-zinc-200 p-4 space-y-3"
        >
          <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
            <h3 className="font-display text-sm font-semibold text-[#09090B]">
              Add Manual Video, Course / Lab, or Conference Event
            </h3>
            <button
              type="button"
              onClick={() => setShowAddDrawer(false)}
              aria-label="Close manual entry drawer"
              className="p-1 rounded hover:bg-zinc-100 text-zinc-500 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <select
              aria-label="Resource kind"
              value={manualKind}
              onChange={(e) => {
                const next = e.target.value as ManualResourceKind;
                setManualKind(next);
                setMOrg(
                  next === 'video'
                    ? 'Red Hat TV'
                    : next === 'learning'
                      ? 'Red Hat Learning'
                      : 'Red Hat Summit'
                );
              }}
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
            >
              <option value="video">Video (e.g. Red Hat TV)</option>
              <option value="learning">Course / Lab / Docs</option>
              <option value="event">Conference / Event</option>
            </select>

            <input
              type="text"
              required
              value={mTitle}
              onChange={(e) => setMTitle(e.target.value)}
              placeholder="Title"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="text"
              value={mOrg}
              onChange={(e) => setMOrg(e.target.value)}
              placeholder="Channel / Platform / Organizer"
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />
            <input
              type="url"
              required
              value={mUrl}
              onChange={(e) => setMUrl(e.target.value)}
              placeholder="https://..."
              className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
            />

            {manualKind === 'learning' && (
              <select
                value={mLearningKind}
                onChange={(e) =>
                  setMLearningKind(e.target.value as LearningContentKind)
                }
                className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
              >
                <option value="lab">Lab</option>
                <option value="course">Course</option>
                <option value="tutorial">Tutorial</option>
                <option value="learning-path">Learning Path</option>
                <option value="documentation">Documentation</option>
              </select>
            )}

            {manualKind === 'event' ? (
              <>
                <select
                  value={mEventType}
                  onChange={(e) =>
                    setMEventType(e.target.value as TechEventType)
                  }
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200 bg-white"
                >
                  <option value="conference">Conference</option>
                  <option value="webinar">Webinar</option>
                  <option value="summit">Summit</option>
                  <option value="meetup">Meetup</option>
                </select>
                <input
                  type="date"
                  value={mStartDate}
                  onChange={(e) => setMStartDate(e.target.value)}
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
                />
                <input
                  type="text"
                  value={mLocation}
                  onChange={(e) => setMLocation(e.target.value)}
                  placeholder="Location (Virtual / City)"
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
                />
              </>
            ) : (
              <>
                <input
                  type="text"
                  value={mCategory}
                  onChange={(e) => setMCategory(e.target.value)}
                  placeholder="Technology / Category"
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
                />
                <input
                  type="text"
                  value={mDuration}
                  onChange={(e) => setMDuration(e.target.value)}
                  placeholder="Duration (optional, e.g. 25:00)"
                  className="px-3 py-2 text-xs rounded-lg border border-zinc-200"
                />
              </>
            )}
          </div>

          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddDrawer(false)}
              className="px-3 py-1.5 text-xs rounded-lg border border-zinc-200 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
            >
              Save Resource
            </button>
          </div>
        </form>
      )}

      <ContentFeed
        items={filteredItems}
        viewMode={filter.viewMode}
        page={filter.page}
        podcastQueue={podcastEpisodes}
        onPageChange={(nextPage) =>
          updateFilterAndUrl({ ...filter, page: nextPage })
        }
        onResetFilters={handleClearAll}
        onRetrySync={onRetrySync}
        onNavigate={onNavigate}
        onToggleFavorite={handleToggleFavorite}
        onToggleConsumed={handleToggleConsumed}
        onChangeLearningStatus={handleLearningStatusChange}
        onOpenPodcastSeries={onSelectSeries}
      />
    </div>
  );
};
