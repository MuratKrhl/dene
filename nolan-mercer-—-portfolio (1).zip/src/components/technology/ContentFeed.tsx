import React from 'react';
import { ChevronLeft, ChevronRight, Inbox, RefreshCw } from 'lucide-react';
import {
  DISCOVER_PAGE_SIZE,
  DiscoverViewMode,
  UnifiedFeedItem,
} from '../../services/technology/discoverFeed';
import { LearningProgressStatus, PodcastEpisode } from '../../types/technology';
import { ContentCard } from './ContentCard';

interface ContentFeedProps {
  items: UnifiedFeedItem[];
  viewMode: DiscoverViewMode;
  page: number;
  isLoading?: boolean;
  errorMessage?: string | null;
  podcastQueue?: PodcastEpisode[];
  onPageChange: (page: number) => void;
  onResetFilters: () => void;
  onRetrySync?: () => void;
  onNavigate: (path: string) => void;
  onToggleFavorite: (item: UnifiedFeedItem) => void | Promise<void>;
  onToggleConsumed?: (item: UnifiedFeedItem) => void | Promise<void>;
  onChangeLearningStatus?: (
    itemId: string,
    status: LearningProgressStatus
  ) => void | Promise<void>;
  onOpenPodcastSeries?: (seriesId: string) => void;
}

export const ContentFeed: React.FC<ContentFeedProps> = ({
  items,
  viewMode,
  page,
  isLoading = false,
  errorMessage = null,
  podcastQueue = [],
  onPageChange,
  onResetFilters,
  onRetrySync,
  onNavigate,
  onToggleFavorite,
  onToggleConsumed,
  onChangeLearningStatus,
  onOpenPodcastSeries,
}) => {
  if (isLoading) {
    return (
      <div
        aria-label="Loading technology content"
        className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100"
      >
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="p-5 space-y-2.5 animate-pulse">
            <div className="flex items-center gap-2">
              <div className="h-5 w-28 rounded bg-zinc-100" />
              <div className="h-4 w-16 rounded bg-zinc-100" />
            </div>
            <div className="h-4 w-3/4 rounded bg-zinc-100" />
            <div className="h-3 w-full rounded bg-zinc-100" />
          </div>
        ))}
      </div>
    );
  }

  if (errorMessage) {
    return (
      <div className="rounded-xl bg-white border border-zinc-200 p-8 text-center space-y-3">
        <p className="text-sm font-semibold text-[#09090B]">
          Unable to load feed items
        </p>
        <p className="text-xs text-zinc-500 max-w-md mx-auto">{errorMessage}</p>
        {onRetrySync && (
          <button
            type="button"
            onClick={onRetrySync}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Retry Sync</span>
          </button>
        )}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="rounded-xl bg-white border border-zinc-200 p-10 text-center space-y-3">
        <Inbox className="w-7 h-7 text-zinc-400 mx-auto" aria-hidden="true" />
        <h3 className="font-display text-sm font-semibold text-[#09090B]">
          No matching intelligence items
        </h3>
        <p className="text-xs text-zinc-500 max-w-md mx-auto">
          Try widening the date range, clearing one of the active filters, or syncing sources to populate more content.
        </p>
        <div className="flex items-center justify-center gap-2 pt-1">
          <button
            type="button"
            onClick={onResetFilters}
            className="px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 bg-white text-[#09090B] hover:bg-zinc-50 cursor-pointer"
          >
            Reset Filters
          </button>
          {onRetrySync && (
            <button
              type="button"
              onClick={onRetrySync}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#09090B] text-white hover:bg-zinc-800 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Sync Sources</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  const totalPages = Math.max(1, Math.ceil(items.length / DISCOVER_PAGE_SIZE));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const startIdx = (safePage - 1) * DISCOVER_PAGE_SIZE;
  const pageItems = items.slice(startIdx, startIdx + DISCOVER_PAGE_SIZE);

  return (
    <div className="space-y-4">
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {pageItems.map((item) => (
            <ContentCard
              key={item.id}
              item={item}
              viewMode="grid"
              podcastQueue={podcastQueue}
              onNavigate={onNavigate}
              onToggleFavorite={onToggleFavorite}
              onToggleConsumed={onToggleConsumed}
              onChangeLearningStatus={onChangeLearningStatus}
              onOpenPodcastSeries={onOpenPodcastSeries}
            />
          ))}
        </div>
      ) : (
        <div className="rounded-xl bg-white border border-zinc-200 divide-y divide-zinc-100 overflow-hidden">
          {pageItems.map((item) => (
            <ContentCard
              key={item.id}
              item={item}
              viewMode="list"
              podcastQueue={podcastQueue}
              onNavigate={onNavigate}
              onToggleFavorite={onToggleFavorite}
              onToggleConsumed={onToggleConsumed}
              onChangeLearningStatus={onChangeLearningStatus}
              onOpenPodcastSeries={onOpenPodcastSeries}
            />
          ))}
        </div>
      )}

      {/* Controlled Density Pagination (Max 10 items per screen) */}
      {totalPages > 1 && (
        <nav
          aria-label="Feed pagination"
          className="flex items-center justify-between gap-4 pt-1 text-xs"
        >
          <span className="font-mono tabular-nums text-zinc-500">
            Showing {startIdx + 1}–{Math.min(startIdx + DISCOVER_PAGE_SIZE, items.length)} of{' '}
            {items.length.toLocaleString()}
          </span>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              disabled={safePage <= 1}
              onClick={() => onPageChange(safePage - 1)}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Previous</span>
            </button>

            <span className="px-2.5 py-1 font-mono tabular-nums text-zinc-600">
              {safePage} / {totalPages}
            </span>

            <button
              type="button"
              disabled={safePage >= totalPages}
              onClick={() => onPageChange(safePage + 1)}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50 disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          </div>
        </nav>
      )}
    </div>
  );
};
