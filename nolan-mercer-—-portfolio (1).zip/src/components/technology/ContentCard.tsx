import React from 'react';
import {
  Check,
  CheckCircle2,
  ExternalLink,
  MapPin,
  Pause,
  Play,
  Star,
} from 'lucide-react';
import { usePodcastPlayer } from '../../context/PodcastPlayerContext';
import {
  DiscoverViewMode,
  UnifiedFeedItem,
} from '../../services/technology/discoverFeed';
import { formatTechDate } from '../../services/technology/retentionEngine';
import { LearningProgressStatus, PodcastEpisode } from '../../types/technology';
import { SourceBadge } from './SourceBadge';

interface ContentCardProps {
  item: UnifiedFeedItem;
  viewMode: DiscoverViewMode;
  podcastQueue?: PodcastEpisode[];
  onNavigate: (path: string) => void;
  onToggleFavorite: (item: UnifiedFeedItem) => void | Promise<void>;
  onToggleConsumed?: (item: UnifiedFeedItem) => void | Promise<void>;
  onChangeLearningStatus?: (
    itemId: string,
    status: LearningProgressStatus
  ) => void | Promise<void>;
  onOpenPodcastSeries?: (seriesId: string) => void;
}

export const ContentCard: React.FC<ContentCardProps> = ({
  item,
  viewMode,
  podcastQueue = [],
  onNavigate,
  onToggleFavorite,
  onToggleConsumed,
  onChangeLearningStatus,
  onOpenPodcastSeries,
}) => {
  const { currentEpisode, isPlaying, playEpisode, togglePlayPause } =
    usePodcastPlayer();

  const isCurrentPodcast =
    item.kind === 'podcast' && currentEpisode?.id === item.originalId;

  const handleOpenPrimary = () => {
    if (item.internalPath) {
      onNavigate(item.internalPath);
    } else if (item.kind === 'podcast' && item.podcastSeriesId && onOpenPodcastSeries) {
      onOpenPodcastSeries(item.podcastSeriesId);
    }
  };

  const renderPrimaryTitle = () => {
    if (
      item.internalPath ||
      (item.kind === 'podcast' && item.podcastSeriesId && onOpenPodcastSeries)
    ) {
      return (
        <button
          type="button"
          onClick={handleOpenPrimary}
          className="text-left font-display text-sm sm:text-[15px] font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-2 transition-colors cursor-pointer"
        >
          {item.title}
        </button>
      );
    }
    return (
      <a
        href={item.url}
        target="_blank"
        rel="noopener noreferrer"
        className="font-display text-sm sm:text-[15px] font-semibold text-[#09090B] hover:text-[#2563EB] line-clamp-2 transition-colors block"
      >
        {item.title}
      </a>
    );
  };

  const renderActions = () => (
    <div className="flex items-center gap-1 shrink-0">
      {item.kind === 'podcast' && item.podcastEpisode && (
        <button
          type="button"
          onClick={() =>
            isCurrentPodcast
              ? togglePlayPause()
              : playEpisode(
                  item.podcastEpisode!,
                  podcastQueue.length > 0 ? podcastQueue : [item.podcastEpisode!]
                )
          }
          aria-label={
            isCurrentPodcast && isPlaying
              ? `Pause ${item.title}`
              : `Play ${item.title}`
          }
          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#09090B] text-white text-[11px] font-medium hover:bg-zinc-800 cursor-pointer mr-1"
        >
          {isCurrentPodcast && isPlaying ? (
            <>
              <Pause className="w-3 h-3" aria-hidden="true" />
              <span>Pause</span>
            </>
          ) : (
            <>
              <Play className="w-3 h-3" aria-hidden="true" />
              <span>Listen</span>
            </>
          )}
        </button>
      )}

      {item.kind === 'learning' && onChangeLearningStatus && (
        <select
          aria-label={`Progress for ${item.title}`}
          value={item.learningStatus || 'not-started'}
          onChange={(e) =>
            onChangeLearningStatus(
              item.originalId,
              e.target.value as LearningProgressStatus
            )
          }
          className="px-2 py-1 text-[11px] font-medium rounded border border-zinc-200 bg-white text-zinc-700 cursor-pointer mr-1"
        >
          <option value="not-started">Not Started</option>
          <option value="in-progress">In Progress</option>
          <option value="completed">Completed</option>
        </select>
      )}

      {(item.kind === 'article' ||
        item.kind === 'video' ||
        item.kind === 'podcast' ||
        item.kind === 'security') &&
        onToggleConsumed && (
          <button
            type="button"
            onClick={() => onToggleConsumed(item)}
            aria-label={item.isConsumed ? 'Mark as unread' : 'Mark as completed'}
            title={item.isConsumed ? 'Completed' : 'Mark complete'}
            className={`p-1.5 rounded-md hover:bg-zinc-100 cursor-pointer ${
              item.isConsumed ? 'text-emerald-600' : 'text-zinc-400'
            }`}
          >
            {item.isConsumed ? (
              <CheckCircle2 className="w-4 h-4" />
            ) : (
              <Check className="w-4 h-4" />
            )}
          </button>
        )}

      <button
        type="button"
        onClick={() => onToggleFavorite(item)}
        aria-label={item.isFavorite ? 'Remove from saved' : 'Save item'}
        title={item.isFavorite ? 'Saved' : 'Save'}
        className={`p-1.5 rounded-md hover:bg-zinc-100 cursor-pointer ${
          item.isFavorite ? 'text-amber-500' : 'text-zinc-400 hover:text-amber-500'
        }`}
      >
        <Star
          className="w-4 h-4"
          fill={item.isFavorite ? 'currentColor' : 'none'}
        />
      </button>

      <a
        href={item.url}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={`Open ${item.title} in new tab`}
        className="p-1.5 rounded-md hover:bg-zinc-100 text-zinc-500 hover:text-[#2563EB]"
      >
        <ExternalLink className="w-4 h-4" />
      </a>
    </div>
  );

  const renderMetadataExtras = () => (
    <div className="flex flex-wrap items-center gap-1.5">
      {item.technologies.slice(0, 3).map((tech) => (
        <span
          key={tech}
          className="inline-flex items-center rounded border border-zinc-200 bg-zinc-50 px-1.5 py-0.5 text-[11px] font-medium text-zinc-700"
        >
          {tech}
        </span>
      ))}
      {typeof item.stars === 'number' && (
        <span className="inline-flex items-center gap-1 text-[11px] font-mono tabular-nums text-zinc-600 ml-1">
          <Star className="w-3 h-3 text-amber-500" aria-hidden="true" />
          {item.stars.toLocaleString()}
          {item.language ? ` · ${item.language}` : ''}
        </span>
      )}
      {item.severity && (
        <span
          className={`text-[11px] font-mono tabular-nums font-semibold ml-1 ${
            item.severity === 'CRITICAL' || item.severity === 'HIGH'
              ? 'text-red-600'
              : 'text-amber-700'
          }`}
        >
          {item.severity}
          {item.cvss !== null && item.cvss !== undefined
            ? ` (CVSS ${item.cvss})`
            : ''}
        </span>
      )}
      {item.duration && (
        <span className="text-[11px] font-mono tabular-nums text-zinc-500 ml-1">
          {item.duration}
        </span>
      )}
      {item.eventLocation && (
        <span className="inline-flex items-center gap-1 text-[11px] text-zinc-500 ml-1">
          <MapPin className="w-3 h-3" aria-hidden="true" />
          {item.eventLocation}
        </span>
      )}
    </div>
  );

  if (viewMode === 'grid') {
    return (
      <article className="rounded-xl bg-white border border-zinc-200 p-4 flex flex-col justify-between gap-3 hover:border-zinc-300 transition-colors">
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <SourceBadge
              sourceGroup={item.sourceGroup}
              sourceName={item.sourceName}
            />
            <span className="text-[11px] font-mono tabular-nums text-zinc-500 shrink-0">
              {formatTechDate(item.publishedAt || item.fetchedAt)}
            </span>
          </div>

          <div className="space-y-1">
            <p className="text-[11px] font-medium text-[#2563EB]">
              {item.contentType}
            </p>
            {renderPrimaryTitle()}
          </div>

          {item.description && (
            <p className="text-xs text-zinc-600 line-clamp-2 leading-relaxed">
              {item.description}
            </p>
          )}
        </div>

        <div className="space-y-2.5 pt-2.5 border-t border-zinc-100">
          {renderMetadataExtras()}
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] text-zinc-500 truncate">
              {item.authorOrOrg || item.sourceGroup}
            </span>
            {renderActions()}
          </div>
        </div>
      </article>
    );
  }

  return (
    <article className="px-5 py-4 bg-white hover:bg-zinc-50/70 transition-colors flex flex-col sm:flex-row sm:items-start justify-between gap-4">
      <div className="min-w-0 flex-1 space-y-1.5">
        <div className="flex items-center gap-2 flex-wrap">
          <SourceBadge
            sourceGroup={item.sourceGroup}
            sourceName={item.sourceName}
          />
          <span className="text-[11px] font-medium text-[#2563EB]">
            {item.contentType}
          </span>
          <span className="text-zinc-300" aria-hidden="true">
            ·
          </span>
          <span className="text-[11px] font-mono tabular-nums text-zinc-500">
            {formatTechDate(item.publishedAt || item.fetchedAt)}
          </span>
        </div>

        {renderPrimaryTitle()}

        {item.description && (
          <p className="text-xs text-zinc-600 line-clamp-2 leading-relaxed">
            {item.description}
          </p>
        )}

        <div className="pt-0.5">{renderMetadataExtras()}</div>
      </div>

      <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
        {renderActions()}
      </div>
    </article>
  );
};
