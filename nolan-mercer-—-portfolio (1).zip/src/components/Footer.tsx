import React, { useState } from 'react';
import { Check, Copy, LogOut, Moon, Sun, ArrowUpRight } from 'lucide-react';
import { STUDIO_PROFILE } from '../data/portfolioData';

interface FooterProps {
  theme: 'light' | 'dark';
  onToggleTheme: (next: 'light' | 'dark') => void;
  onNavigate: (path: string) => void;
  currentUser?: string | null;
  onLogout?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  theme,
  onToggleTheme,
  onNavigate,
  currentUser,
  onLogout,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(STUDIO_PROFILE.email);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  };

  const handleLink = (e: React.MouseEvent, path: string) => {
    e.preventDefault();
    onNavigate(path);
  };

  return (
    <footer className="border-t border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#0B0B0E]">
      <div className="max-w-[1200px] mx-auto px-6 py-14">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-zinc-200 dark:border-zinc-800">
          <div className="md:col-span-5 space-y-4">
            <a
              href="/"
              onClick={(e) => handleLink(e, '/')}
              className="inline-block font-display text-xl font-semibold tracking-tight text-[#09090B] dark:text-[#FAFAFA]"
            >
              Murat Krhl's
            </a>
            <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed max-w-sm">
              Work. Tools. Projects. Ideas. Building resilient software interfaces,
              design systems, and developer tools.
            </p>
            <div className="pt-1 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleCopyEmail}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-zinc-800 dark:text-zinc-200 hover:border-zinc-300 dark:hover:border-zinc-700 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#2563EB]"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#2563EB] dark:text-blue-400" />
                    <span>Copied {STUDIO_PROFILE.email}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-zinc-500" />
                    <span>{STUDIO_PROFILE.email}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="md:col-span-2 space-y-3">
            <h2 className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
              WorkSpace
            </h2>
            <ul className="space-y-2.5 text-sm">
              {[
                { label: 'Home', path: '/' },
                { label: 'Quick Access', path: '/quick-access' },
                { label: 'Environment', path: '/environment' },
                { label: 'Project Management', path: '/project-management' },
                { label: 'Tools', path: '/tools' },
                { label: 'Knowledge Hub', path: '/knowledge-hub' },
              ].map((link) => (
                <li key={link.path}>
                  <a
                    href={link.path}
                    onClick={(e) => handleLink(e, link.path)}
                    className="text-zinc-700 dark:text-zinc-300 hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-2 space-y-3">
            <h2 className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
              Profiles
            </h2>
            <ul className="space-y-2.5 text-sm">
              {[
                { label: 'GitHub', href: 'https://github.com/MuratKrhl' },
                { label: 'X', href: 'https://x.com/M_karahaliloglu' },
                {
                  label: 'LinkedIn',
                  href: 'https://www.linkedin.com/in/murat-karahalilo%C4%9Flu/',
                },
                { label: 'Gmail', href: 'https://mail.google.com/mail/u/0/#inbox' },
              ].map((social) => (
                <li key={social.label}>
                  <a
                    href={social.href}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-zinc-700 dark:text-zinc-300 hover:text-[#2563EB] dark:hover:text-blue-400 transition-colors"
                  >
                    <span>{social.label}</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-zinc-400" aria-hidden="true" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3 space-y-3">
            <h2 className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
              Appearance
            </h2>
            <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
              Switch between crisp daylight paper and low-glare studio dark mode.
            </p>
            <div
              role="group"
              aria-label="Color theme"
              className="inline-flex items-center p-1 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            >
              <button
                type="button"
                onClick={() => onToggleTheme('light')}
                aria-pressed={theme === 'light'}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  theme === 'light'
                    ? 'bg-white text-[#09090B] shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
                }`}
              >
                <Sun className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Light</span>
              </button>
              <button
                type="button"
                onClick={() => onToggleTheme('dark')}
                aria-pressed={theme === 'dark'}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  theme === 'dark'
                    ? 'bg-zinc-800 text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
                }`}
              >
                <Moon className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Dark</span>
              </button>
            </div>

            {onLogout && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={onLogout}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900 text-xs font-medium text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700 hover:text-[#09090B] dark:hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5 text-zinc-500" aria-hidden="true" />
                  <span>{currentUser ? `${currentUser} · Log out` : 'Log out'}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-zinc-500 dark:text-zinc-400">
          <p>© 2026 Murat Krhl's WorkSpace. All rights reserved.</p>
          <p className="tabular-nums">
            {STUDIO_PROFILE.location} · {STUDIO_PROFILE.timezone}
          </p>
        </div>
      </div>
    </footer>
  );
};
