import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  Clock,
  Folder,
  Search,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import {
  INITIAL_PM_FOLDERS,
  PmPriority,
  PmScheduleItem,
  PmStatus,
  PmTabConfig,
  PmTaskRow,
} from '../data/projectManagementData';
import {
  loadPmSchedule,
  loadPmTasks,
  savePmSchedule,
  savePmTasks,
} from '../services/projectManagementStore';

const STATUS_CYCLE: PmStatus[] = [
  'In Progress',
  'In Review',
  'Completed',
  'Overdue',
];

function getFolderAccentColor(accent: 'cobalt' | 'emerald' | 'slate'): string {
  if (accent === 'cobalt') return 'text-[#2563EB] dark:text-blue-400';
  if (accent === 'emerald') return 'text-emerald-600 dark:text-emerald-400';
  return 'text-zinc-600 dark:text-zinc-400';
}

function getFolderProgressBarColor(accent: 'cobalt' | 'emerald' | 'slate'): string {
  if (accent === 'cobalt') return 'bg-[#2563EB] dark:bg-blue-500';
  if (accent === 'emerald') return 'bg-emerald-600 dark:bg-emerald-500';
  return 'bg-zinc-700 dark:bg-zinc-400';
}

function getPriorityStyle(priority: PmPriority): {
  dot: string;
  text: string;
  wrap: string;
} {
  switch (priority) {
    case 'High':
      return {
        dot: 'bg-red-500',
        text: 'text-red-700 dark:text-red-300',
        wrap: 'bg-red-50 dark:bg-red-950/40 border-red-200/80 dark:border-red-900/50',
      };
    case 'Medium':
      return {
        dot: 'bg-amber-500',
        text: 'text-amber-700 dark:text-amber-300',
        wrap: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200/80 dark:border-amber-900/50',
      };
    case 'Low':
    default:
      return {
        dot: 'bg-zinc-400',
        text: 'text-zinc-700 dark:text-zinc-300',
        wrap: 'bg-zinc-100 dark:bg-zinc-800/80 border-zinc-200 dark:border-zinc-700',
      };
  }
}

function getStatusTextClass(status: PmStatus): string {
  switch (status) {
    case 'Completed':
      return 'text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/70 dark:bg-emerald-950/30';
    case 'In Review':
      return 'text-[#2563EB] dark:text-blue-400 border-[#2563EB]/25 dark:border-blue-500/30 bg-[#2563EB]/5 dark:bg-blue-500/10';
    case 'Overdue':
      return 'text-red-700 dark:text-red-400 border-red-200 dark:border-red-900/60 bg-red-50/70 dark:bg-red-950/30';
    case 'In Progress':
    default:
      return 'text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 bg-[#FAFAFA] dark:bg-zinc-900';
  }
}

interface ProjectManagementBoardProps {
  tabConfig: PmTabConfig;
}

export const ProjectManagementBoard: React.FC<ProjectManagementBoardProps> = ({
  tabConfig,
}) => {
  const [tasks, setTasks] = useState<PmTaskRow[]>(() => loadPmTasks());
  const [schedule, setSchedule] = useState<PmScheduleItem[]>(() =>
    loadPmSchedule()
  );

  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<'All' | PmStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const tabFolders = useMemo(
    () => INITIAL_PM_FOLDERS.filter((f) => f.tab === tabConfig.key),
    [tabConfig.key]
  );

  useEffect(() => {
    setSelectedFolderId(null);
    setStatusFilter('All');
    setSearchQuery('');
  }, [tabConfig.key]);

  const persistTasks = (next: PmTaskRow[]) => {
    setTasks(next);
    savePmTasks(next);
  };

  const persistSchedule = (next: PmScheduleItem[]) => {
    setSchedule(next);
    savePmSchedule(next);
  };

  const tabTasks = useMemo(
    () => tasks.filter((t) => t.tab === tabConfig.key),
    [tasks, tabConfig.key]
  );

  const tabSchedule = useMemo(
    () => schedule.filter((s) => s.tab === tabConfig.key),
    [schedule, tabConfig.key]
  );

  const kpiStats = useMemo(() => {
    const total = tabTasks.length;
    const inProgress = tabTasks.filter(
      (t) => t.status === 'In Progress' || t.status === 'In Review'
    ).length;
    const completed = tabTasks.filter((t) => t.status === 'Completed').length;
    const overdue = tabTasks.filter((t) => t.status === 'Overdue').length;
    return { total, inProgress, completed, overdue };
  }, [tabTasks]);

  const filteredTasks = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return tabTasks.filter((row) => {
      if (selectedFolderId && row.workstreamId !== selectedFolderId) return false;
      if (statusFilter !== 'All' && row.status !== statusFilter) return false;
      if (!q) return true;
      return (
        row.name.toLowerCase().includes(q) ||
        row.tag.toLowerCase().includes(q) ||
        row.dateRange.toLowerCase().includes(q) ||
        row.assignee.toLowerCase().includes(q)
      );
    });
  }, [tabTasks, selectedFolderId, statusFilter, searchQuery]);

  const handleCycleStatus = (id: string) => {
    persistTasks(
      tasks.map((t) => {
        if (t.id !== id) return t;
        const nextStatus =
          STATUS_CYCLE[(STATUS_CYCLE.indexOf(t.status) + 1) % STATUS_CYCLE.length];
        return { ...t, status: nextStatus };
      })
    );
  };

  const handleToggleScheduleDone = (id: string) => {
    persistSchedule(
      schedule.map((s) => (s.id === id ? { ...s, done: !s.done } : s))
    );
  };

  return (
    <div className="space-y-6">
      {/* Row 1: 4 Compact KPI Stat Cards (Dribbble Nexdo Layout) */}
      <section
        aria-label="Summary metrics"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        <div className="p-5 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
              Total Tasks
            </span>
            <span className="w-7 h-7 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-center text-zinc-500 dark:text-zinc-400">
              <ClipboardList className="w-3.5 h-3.5" aria-hidden="true" />
            </span>
          </div>
          <div className="flex items-end justify-between gap-2">
            <span className="font-display text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
              {kpiStats.total}
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-600 dark:text-emerald-400 tabular-nums">
              <TrendingUp className="w-3 h-3" aria-hidden="true" />
              <span>{tabConfig.trendTotal}</span>
            </span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
              In Progress
            </span>
            <span className="w-7 h-7 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-center text-[#2563EB] dark:text-blue-400">
              <Clock className="w-3.5 h-3.5" aria-hidden="true" />
            </span>
          </div>
          <div className="flex items-end justify-between gap-2">
            <span className="font-display text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
              {kpiStats.inProgress}
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-[#2563EB] dark:text-blue-400 tabular-nums">
              <TrendingUp className="w-3 h-3" aria-hidden="true" />
              <span>{tabConfig.trendProgress}</span>
            </span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
              Completed
            </span>
            <span className="w-7 h-7 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
            </span>
          </div>
          <div className="flex items-end justify-between gap-2">
            <span className="font-display text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
              {kpiStats.completed}
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-600 dark:text-emerald-400 tabular-nums">
              <TrendingUp className="w-3 h-3" aria-hidden="true" />
              <span>{tabConfig.trendCompleted}</span>
            </span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-zinc-600 dark:text-zinc-400">
              Overdue
            </span>
            <span className="w-7 h-7 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-center text-red-600 dark:text-red-400">
              <AlertCircle className="w-3.5 h-3.5" aria-hidden="true" />
            </span>
          </div>
          <div className="flex items-end justify-between gap-2">
            <span className="font-display text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
              {kpiStats.overdue}
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-red-600 dark:text-red-400 tabular-nums">
              <TrendingDown className="w-3 h-3" aria-hidden="true" />
              <span>{tabConfig.trendOverdue}</span>
            </span>
          </div>
        </div>
      </section>

      {/* Row 2: Project Overview Folder Cards (Left) + Upcoming Schedule Panel (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        <section
          aria-label="Workstream overview"
          className="lg:col-span-8 flex flex-col justify-between space-y-3"
        >
          <div className="flex items-center justify-between">
            <h2 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              Workstream Overview
            </h2>
            {selectedFolderId && (
              <button
                type="button"
                onClick={() => setSelectedFolderId(null)}
                className="text-xs font-medium text-[#2563EB] dark:text-blue-400 hover:underline cursor-pointer"
              >
                Show All Workstreams
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-1">
            {tabFolders.map((folder) => {
              const isSelected = selectedFolderId === folder.id;
              const liveTaskCount = tabTasks.filter(
                (t) => t.workstreamId === folder.id
              ).length;

              return (
                <button
                  key={folder.id}
                  type="button"
                  onClick={() =>
                    setSelectedFolderId((cur) =>
                      cur === folder.id ? null : folder.id
                    )
                  }
                  className={`text-left p-5 rounded-2xl bg-white dark:bg-[#111114] border transition-colors flex flex-col justify-between gap-4 cursor-pointer ${
                    isSelected
                      ? 'border-[#2563EB] dark:border-blue-500 ring-1 ring-[#2563EB]/20'
                      : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <Folder
                        className={`w-5 h-5 fill-current/15 ${getFolderAccentColor(
                          folder.accent
                        )}`}
                        aria-hidden="true"
                      />
                      <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                        {liveTaskCount || folder.taskCount} tasks
                      </span>
                    </div>

                    <h3 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA] leading-snug">
                      {folder.title}
                    </h3>

                    <div className="flex items-center -space-x-1.5">
                      {folder.owners.map((initials) => (
                        <span
                          key={initials}
                          className="w-6 h-6 rounded-full bg-zinc-100 dark:bg-zinc-800 border-2 border-white dark:border-[#111114] flex items-center justify-center font-mono text-[10px] font-semibold text-zinc-700 dark:text-zinc-200"
                        >
                          {initials}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-zinc-100 dark:border-zinc-800/80">
                    <div className="flex items-center justify-between text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                      <span>Deadline: {folder.deadline}</span>
                      <span className="font-mono font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                        {folder.progress}%
                      </span>
                    </div>

                    <div className="w-full h-1.5 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-200 ${getFolderProgressBarColor(
                          folder.accent
                        )}`}
                        style={{ width: `${folder.progress}%` }}
                      />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Right Side Panel: Sprint & Cutover Checkpoints */}
        <aside
          aria-label="Upcoming checkpoints"
          className="lg:col-span-4 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-5 flex flex-col justify-between gap-4"
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <CalendarDays
                className="w-4 h-4 text-[#2563EB] dark:text-blue-400"
                aria-hidden="true"
              />
              <h2 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                Upcoming Checkpoints
              </h2>
            </div>
            <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
              {tabSchedule.filter((s) => s.done).length}/{tabSchedule.length}
            </span>
          </div>

          <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
            {tabSchedule.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleToggleScheduleDone(item.id)}
                className="w-full py-2.5 first:pt-0 last:pb-0 flex items-start gap-3 text-left group cursor-pointer"
              >
                <span
                  aria-hidden="true"
                  className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors ${
                    item.done
                      ? 'bg-[#2563EB] border-[#2563EB] text-white'
                      : 'border-zinc-300 dark:border-zinc-700 group-hover:border-[#2563EB]'
                  }`}
                >
                  {item.done && <CheckCircle2 className="w-3 h-3" />}
                </span>
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div
                    className={`text-xs font-medium truncate ${
                      item.done
                        ? 'line-through text-zinc-400 dark:text-zinc-500'
                        : 'text-[#09090B] dark:text-[#FAFAFA]'
                    }`}
                  >
                    {item.title}
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                    <span className="font-mono">{item.dateLabel}</span>
                    <span aria-hidden="true">·</span>
                    <span>{item.owner}</span>
                    <span aria-hidden="true">·</span>
                    <span>{item.env}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </aside>
      </div>

      {/* Row 3: Tasks Overview Table (Dribbble Nexdo Table Structure) */}
      <section
        aria-label="Tasks overview"
        className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-hidden"
      >
        <div className="p-5 border-b border-zinc-200 dark:border-zinc-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="font-display text-base font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              Tasks Overview
            </h2>
            <span className="font-mono text-xs text-zinc-500 dark:text-zinc-400 tabular-nums">
              {filteredTasks.length} items
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1 p-0.5 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[11px]">
              {(['All', ...STATUS_CYCLE] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    statusFilter === st
                      ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-2xs'
                      : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-52">
              <Search
                className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tasks, tags..."
                aria-label="Search tasks"
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
              />
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#FAFAFA] dark:bg-zinc-900/60 border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                <th className="w-12 px-5 py-3">#</th>
                <th className="px-3 py-3">Name</th>
                <th className="px-3 py-3 whitespace-nowrap">Date</th>
                <th className="px-3 py-3 whitespace-nowrap">Priority</th>
                <th className="px-3 py-3 whitespace-nowrap">Tags</th>
                <th className="px-5 py-3 text-right whitespace-nowrap">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {filteredTasks.length === 0 ? (
                <tr>
                  <td
                    colSpan={6}
                    className="py-12 text-center text-zinc-500 dark:text-zinc-400"
                  >
                    No tasks found for the selected filter in {tabConfig.label}.
                  </td>
                </tr>
              ) : (
                filteredTasks.map((row, idx) => {
                  const prio = getPriorityStyle(row.priority);

                  return (
                    <tr
                      key={row.id}
                      className="hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40 transition-colors"
                    >
                      <td className="px-5 py-3.5 font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                        {String(idx + 1).padStart(2, '0')}
                      </td>

                      <td className="px-3 py-3.5 font-medium text-[#09090B] dark:text-[#FAFAFA]">
                        {row.name}
                      </td>

                      <td className="px-3 py-3.5 text-zinc-600 dark:text-zinc-400 tabular-nums whitespace-nowrap">
                        {row.dateRange}
                      </td>

                      <td className="px-3 py-3.5 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-[11px] font-medium ${prio.wrap} ${prio.text}`}
                        >
                          <span
                            aria-hidden="true"
                            className={`w-1.5 h-1.5 rounded-full ${prio.dot}`}
                          />
                          <span>{row.priority}</span>
                        </span>
                      </td>

                      <td className="px-3 py-3.5 whitespace-nowrap">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-zinc-100 dark:bg-zinc-800 text-[11px] font-medium text-zinc-700 dark:text-zinc-300">
                          {row.tag}
                        </span>
                      </td>

                      <td className="px-5 py-3.5 text-right whitespace-nowrap">
                        <div className="inline-flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => handleCycleStatus(row.id)}
                            title="Click to cycle status"
                            className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium transition-colors cursor-pointer ${getStatusTextClass(
                              row.status
                            )}`}
                          >
                            {row.status}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
