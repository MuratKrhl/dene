import React, { useMemo, useState } from 'react';
import {
  Calendar,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Columns3,
  Copy,
  Download,
  Edit3,
  Eye,
  EyeOff,
  Filter,
  KeyRound,
  LayoutGrid,
  List,
  Lock,
  Plus,
  RefreshCw,
  Search,
  Server,
  ShieldCheck,
  Table2,
  Trash2,
  User,
  X,
} from 'lucide-react';

export type CredentialEnv = 'Prod' | 'UAT' | 'Pre-Prod' | 'DR' | 'Internal';
export type CredentialStatus = 'Active' | 'Rotate Soon' | 'Inactive';

export interface UserCredentialEntry {
  id: string;
  service: string;
  endpointOrEmail: string;
  username: string;
  password: string;
  category: string;
  env: CredentialEnv;
  status: CredentialStatus;
  twoFactor: 'Enabled' | 'Disabled';
  updatedAt: string;
  notes?: string;
}

const STORAGE_KEY = 'mk-user-credentials-v1';

const INITIAL_CREDENTIALS: UserCredentialEntry[] = [
  {
    id: 'cred-1',
    service: 'JBoss EAP 8 Admin Console',
    endpointOrEmail: 'https://eap8-adm.corp.internal:9990',
    username: 'mkrhl_jboss_adm',
    password: 'Eap8#Prod!9241',
    category: 'Middleware',
    env: 'Prod',
    status: 'Active',
    twoFactor: 'Enabled',
    updatedAt: '16 Nov 2026, 14:20',
    notes: 'Elytron MgmtRealm admin console',
  },
  {
    id: 'cred-2',
    service: 'OpenShift Prod Cluster (ocp-eu1)',
    endpointOrEmail: 'api.ocp-prod-eu1.corp.internal:6443',
    username: 'murat.krhl@corp.internal',
    password: 'Ocp$Cluster8812',
    category: 'OpenShift',
    env: 'Prod',
    status: 'Active',
    twoFactor: 'Enabled',
    updatedAt: '15 Nov 2026, 09:45',
    notes: 'Cluster-admin OIDC + TOTP',
  },
  {
    id: 'cred-3',
    service: 'Edge Reverse Proxy (HAProxy Stats)',
    endpointOrEmail: 'https://edge-gw-prod-01.corp.internal:8404',
    username: 'haproxy_ops',
    password: 'Rpx!Edge4490',
    category: 'Reverse Proxy',
    env: 'Prod',
    status: 'Active',
    twoFactor: 'Enabled',
    updatedAt: '14 Nov 2026, 17:10',
  },
  {
    id: 'cred-4',
    service: 'Provenir 8.7 Decision Studio',
    endpointOrEmail: 'https://provenir-uat.corp.internal/studio',
    username: 'mkrhl_studio',
    password: 'Prv@Studio8732',
    category: 'Decisioning',
    env: 'UAT',
    status: 'Active',
    twoFactor: 'Enabled',
    updatedAt: '12 Nov 2026, 11:30',
  },
  {
    id: 'cred-5',
    service: 'PostgreSQL Credit DB (UAT)',
    endpointOrEmail: 'pg-credit-uat-01.corp.internal:5432',
    username: 'credit_ro_mkrhl',
    password: 'PgSql#Uat5521',
    category: 'Database',
    env: 'UAT',
    status: 'Rotate Soon',
    twoFactor: 'Disabled',
    updatedAt: '02 Oct 2026, 16:05',
    notes: '90-day password rotation approaching',
  },
  {
    id: 'cred-6',
    service: 'Red Hat Customer Portal',
    endpointOrEmail: 'murat.karahaliloglu@corp.internal',
    username: 'mkrhl-rhel-sub',
    password: 'Rhel!Portal7730',
    category: 'Cloud & Vendor',
    env: 'Internal',
    status: 'Active',
    twoFactor: 'Enabled',
    updatedAt: '08 Nov 2026, 10:15',
  },
  {
    id: 'cred-7',
    service: 'Evam CEP Engine Admin',
    endpointOrEmail: 'https://evam-preprod.corp.internal:8080',
    username: 'evam_deployer',
    password: 'Evam#Cep3109',
    category: 'Decisioning',
    env: 'Pre-Prod',
    status: 'Active',
    twoFactor: 'Enabled',
    updatedAt: '05 Nov 2026, 13:50',
  },
  {
    id: 'cred-8',
    service: 'PowerCurve Strategy Manager',
    endpointOrEmail: 'https://pc-dr.corp.internal:8443',
    username: 'pc_dr_operator',
    password: 'PcDr!7190Pass',
    category: 'Decisioning',
    env: 'DR',
    status: 'Inactive',
    twoFactor: 'Disabled',
    updatedAt: '19 Sep 2026, 08:30',
    notes: 'Enabled during DR switchover drills',
  },
];

const CATEGORIES = [
  'Middleware',
  'OpenShift',
  'Reverse Proxy',
  'Decisioning',
  'Database',
  'Cloud & Vendor',
  'Personal / Other',
];

const ENVIRONMENTS: CredentialEnv[] = ['Prod', 'UAT', 'Pre-Prod', 'DR', 'Internal'];

function generateStrongPassword(length = 16): string {
  const chars =
    'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*';
  const array = new Uint32Array(length);
  crypto.getRandomValues(array);
  return Array.from(array, (n) => chars[n % chars.length]).join('');
}

function formatNowLabel(): string {
  const d = new Date();
  const datePart = d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const timePart = d.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
  return `${datePart}, ${timePart}`;
}

export const KnowledgeUserManagementTab: React.FC = () => {
  const [entries, setEntries] = useState<UserCredentialEntry[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback to initial entries
    }
    return INITIAL_CREDENTIALS;
  });

  const [viewMode, setViewMode] = useState<'table' | 'board' | 'list'>('table');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFiltersBar, setShowFiltersBar] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [envFilter, setEnvFilter] = useState<string>('All');
  const [twoFactorFilter, setTwoFactorFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  const [showColumnMenu, setShowColumnMenu] = useState(false);
  const [visibleCols, setVisibleCols] = useState({
    endpoint: true,
    username: true,
    password: true,
    category: true,
    status: true,
    updated: true,
    twoFactor: true,
  });

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [revealedIds, setRevealedIds] = useState<Record<string, boolean>>({});
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const [rowsPerPage, setRowsPerPage] = useState(15);
  const [currentPage, setCurrentPage] = useState(1);

  // Add / Edit form state
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formService, setFormService] = useState('');
  const [formEndpoint, setFormEndpoint] = useState('');
  const [formUsername, setFormUsername] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formShowPw, setFormShowPw] = useState(false);
  const [formCategory, setFormCategory] = useState('Middleware');
  const [formEnv, setFormEnv] = useState<CredentialEnv>('Prod');
  const [formStatus, setFormStatus] = useState<CredentialStatus>('Active');
  const [formTwoFactor, setFormTwoFactor] = useState<'Enabled' | 'Disabled'>('Enabled');
  const [formNotes, setFormNotes] = useState('');

  const persistEntries = (next: UserCredentialEntry[]) => {
    setEntries(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // Ignore storage quota error
    }
  };

  const filteredEntries = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return entries.filter((item) => {
      if (categoryFilter !== 'All' && item.category !== categoryFilter) return false;
      if (envFilter !== 'All' && item.env !== envFilter) return false;
      if (twoFactorFilter !== 'All' && item.twoFactor !== twoFactorFilter) return false;
      if (statusFilter !== 'All' && item.status !== statusFilter) return false;
      if (!q) return true;
      return (
        item.service.toLowerCase().includes(q) ||
        item.username.toLowerCase().includes(q) ||
        item.endpointOrEmail.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.env.toLowerCase().includes(q)
      );
    });
  }, [entries, categoryFilter, envFilter, twoFactorFilter, statusFilter, searchQuery]);

  const totalPages = Math.max(1, Math.ceil(filteredEntries.length / rowsPerPage));
  const safePage = Math.min(currentPage, totalPages);
  const pagedEntries = useMemo(() => {
    const start = (safePage - 1) * rowsPerPage;
    return filteredEntries.slice(start, start + rowsPerPage);
  }, [filteredEntries, safePage, rowsPerPage]);

  const handleCopy = async (key: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedKey(key);
      window.setTimeout(() => setCopiedKey(null), 1600);
    } catch {
      setCopiedKey(null);
    }
  };

  const toggleReveal = (id: string) => {
    setRevealedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleSelectRow = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleSelectAllVisible = () => {
    const visIds = pagedEntries.map((e) => e.id);
    const allSelected = visIds.length > 0 && visIds.every((id) => selectedIds.includes(id));
    if (allSelected) {
      setSelectedIds((prev) => prev.filter((id) => !visIds.includes(id)));
    } else {
      setSelectedIds((prev) => Array.from(new Set([...prev, ...visIds])));
    }
  };

  const openAddForm = () => {
    setEditingId(null);
    setFormService('');
    setFormEndpoint('');
    setFormUsername('');
    setFormPassword('');
    setFormShowPw(false);
    setFormCategory('Middleware');
    setFormEnv('Prod');
    setFormStatus('Active');
    setFormTwoFactor('Enabled');
    setFormNotes('');
    setShowForm(true);
  };

  const openEditForm = (item: UserCredentialEntry) => {
    setEditingId(item.id);
    setFormService(item.service);
    setFormEndpoint(item.endpointOrEmail);
    setFormUsername(item.username);
    setFormPassword(item.password);
    setFormShowPw(false);
    setFormCategory(item.category);
    setFormEnv(item.env);
    setFormStatus(item.status);
    setFormTwoFactor(item.twoFactor);
    setFormNotes(item.notes || '');
    setShowForm(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formService.trim() || !formUsername.trim() || !formPassword) return;
    const nowLabel = formatNowLabel();

    if (editingId) {
      persistEntries(
        entries.map((item) =>
          item.id === editingId
            ? {
                ...item,
                service: formService.trim(),
                endpointOrEmail: formEndpoint.trim() || 'workspace.local',
                username: formUsername.trim(),
                password: formPassword,
                category: formCategory,
                env: formEnv,
                status: formStatus,
                twoFactor: formTwoFactor,
                updatedAt: nowLabel,
                notes: formNotes.trim() || undefined,
              }
            : item
        )
      );
    } else {
      const created: UserCredentialEntry = {
        id: `cred-${Date.now()}`,
        service: formService.trim(),
        endpointOrEmail: formEndpoint.trim() || 'workspace.local',
        username: formUsername.trim(),
        password: formPassword,
        category: formCategory,
        env: formEnv,
        status: formStatus,
        twoFactor: formTwoFactor,
        updatedAt: nowLabel,
        notes: formNotes.trim() || undefined,
      };
      persistEntries([created, ...entries]);
    }
    setShowForm(false);
    setEditingId(null);
  };

  const handleDelete = (id: string) => {
    persistEntries(entries.filter((item) => item.id !== id));
    setSelectedIds((prev) => prev.filter((x) => x !== id));
  };

  const handleExportCsv = () => {
    const target =
      selectedIds.length > 0
        ? filteredEntries.filter((e) => selectedIds.includes(e.id))
        : filteredEntries;
    const esc = (v: string) =>
      /[",\n\r]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
    const header = [
      'Service',
      'Endpoint / Email',
      'Username',
      'Category',
      'Environment',
      'Status',
      '2F Auth',
      'Updated',
    ].join(',');
    const rows = target.map((e) =>
      [
        e.service,
        e.endpointOrEmail,
        e.username,
        e.category,
        e.env,
        e.status,
        e.twoFactor,
        e.updatedAt,
      ]
        .map(esc)
        .join(',')
    );
    const csv = [header, ...rows].join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'workspace-credentials-inventory.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const resetFilters = () => {
    setCategoryFilter('All');
    setEnvFilter('All');
    setTwoFactorFilter('All');
    setStatusFilter('All');
    setSearchQuery('');
    setCurrentPage(1);
  };

  const hasActiveFilters =
    categoryFilter !== 'All' ||
    envFilter !== 'All' ||
    twoFactorFilter !== 'All' ||
    statusFilter !== 'All' ||
    searchQuery.trim() !== '';

  const renderStatusBadge = (status: CredentialStatus) => {
    if (status === 'Active') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" aria-hidden="true" />
          <span>Active</span>
        </span>
      );
    }
    if (status === 'Rotate Soon') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 dark:text-amber-400">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500" aria-hidden="true" />
          <span>Rotate Soon</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-700 dark:text-red-400">
        <span className="w-1.5 h-1.5 rounded-full bg-red-500" aria-hidden="true" />
        <span>Inactive</span>
      </span>
    );
  };

  return (
    <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-hidden shadow-xs">
      {/* Top Toolbar (Dribbble Reference Structure adapted to Astra Editorial) */}
      <div className="px-5 py-4 border-b border-zinc-200 dark:border-zinc-800 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        {/* Left: Table | Board | List View Switcher */}
        <div className="flex flex-wrap items-center gap-3">
          <div
            role="tablist"
            aria-label="Credentials view mode"
            className="inline-flex items-center gap-1 p-1 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
          >
            {(
              [
                ['table', 'Table', Table2],
                ['board', 'Board', LayoutGrid],
                ['list', 'List', List],
              ] as const
            ).map(([mode, label, Icon]) => {
              const active = viewMode === mode;
              return (
                <button
                  key={mode}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setViewMode(mode)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                    active
                      ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                      : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{label}</span>
                </button>
              );
            })}
          </div>

          <span className="inline-flex items-center gap-1.5 text-[11px] font-mono text-zinc-500 dark:text-zinc-400">
            <Lock className="w-3 h-3 text-[#2563EB] dark:text-blue-400" />
            <span>Personal Vault · Local Browser Storage</span>
          </span>
        </div>

        {/* Right: Search, Hide Filters, Customize Columns, Export, Add Credential */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-full sm:w-52">
            <Search
              className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search service, user..."
              aria-label="Search credentials"
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[#09090B] dark:text-[#FAFAFA] placeholder:text-zinc-400 focus:outline-none focus:border-[#2563EB]"
            />
          </div>

          <button
            type="button"
            onClick={() => setShowFiltersBar((v) => !v)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
              showFiltersBar
                ? 'border-zinc-300 dark:border-zinc-700 bg-zinc-100 dark:bg-zinc-800 text-[#09090B] dark:text-[#FAFAFA]'
                : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:border-zinc-300'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>{showFiltersBar ? 'Hide' : 'Filters'}</span>
          </button>

          {viewMode === 'table' && (
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowColumnMenu((v) => !v)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700 cursor-pointer whitespace-nowrap"
              >
                <Columns3 className="w-3.5 h-3.5" />
                <span>Customize</span>
              </button>
              {showColumnMenu && (
                <div className="absolute right-0 mt-1.5 w-48 p-2 rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 shadow-lg z-20 space-y-1 text-xs">
                  {(
                    [
                      ['endpoint', 'Endpoint / Email'],
                      ['username', 'Username'],
                      ['password', 'Password'],
                      ['category', 'Category / Env'],
                      ['status', 'Status'],
                      ['updated', 'Updated Date'],
                      ['twoFactor', '2F Auth'],
                    ] as const
                  ).map(([key, label]) => (
                    <label
                      key={key}
                      className="flex items-center gap-2 px-2 py-1 rounded hover:bg-zinc-100 dark:hover:bg-zinc-900 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={visibleCols[key]}
                        onChange={() =>
                          setVisibleCols((prev) => ({
                            ...prev,
                            [key]: !prev[key],
                          }))
                        }
                        className="accent-[#2563EB]"
                      />
                      <span>{label}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
          )}

          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export</span>
          </button>

          <button
            type="button"
            onClick={openAddForm}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add User</span>
            <ChevronDown className="w-3 h-3 opacity-80" />
          </button>
        </div>
      </div>

      {/* Filter Pills Bar (Role/Category, Environment, 2F Auth, Status) */}
      {showFiltersBar && (
        <div className="px-5 py-3 bg-[#FAFAFA] dark:bg-zinc-900/40 border-b border-zinc-200 dark:border-zinc-800 flex flex-wrap items-center gap-2 text-xs">
          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value);
              setCurrentPage(1);
            }}
            aria-label="Filter by category"
            className="px-3 py-1.5 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-700 dark:text-zinc-300 cursor-pointer"
          >
            <option value="All">Category: All</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            value={envFilter}
            onChange={(e) => {
              setEnvFilter(e.target.value);
              setCurrentPage(1);
            }}
            aria-label="Filter by environment"
            className="px-3 py-1.5 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-700 dark:text-zinc-300 cursor-pointer"
          >
            <option value="All">Environment: All</option>
            {ENVIRONMENTS.map((env) => (
              <option key={env} value={env}>
                {env}
              </option>
            ))}
          </select>

          <select
            value={twoFactorFilter}
            onChange={(e) => {
              setTwoFactorFilter(e.target.value);
              setCurrentPage(1);
            }}
            aria-label="Filter by 2F Auth"
            className="px-3 py-1.5 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-700 dark:text-zinc-300 cursor-pointer"
          >
            <option value="All">2F Auth: All</option>
            <option value="Enabled">Enabled</option>
            <option value="Disabled">Disabled</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            aria-label="Filter by status"
            className="px-3 py-1.5 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-700 dark:text-zinc-300 cursor-pointer"
          >
            <option value="All">Status: All</option>
            <option value="Active">Active</option>
            <option value="Rotate Soon">Rotate Soon</option>
            <option value="Inactive">Inactive</option>
          </select>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#2563EB] dark:text-blue-400 hover:underline cursor-pointer"
            >
              <X className="w-3 h-3" />
              <span>Clear filters</span>
            </button>
          )}
        </div>
      )}

      {/* Inline Add / Edit Credential Drawer */}
      {showForm && (
        <form
          onSubmit={handleSubmitForm}
          className="p-5 bg-[#FAFAFA] dark:bg-zinc-900/60 border-b border-zinc-200 dark:border-zinc-800 grid grid-cols-1 sm:grid-cols-12 gap-4 items-end"
        >
          <div className="sm:col-span-12 flex items-center justify-between">
            <h3 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              {editingId ? 'Edit Saved Credential' : 'Add Personal Credential'}
            </h3>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="p-1 text-zinc-400 hover:text-[#09090B] dark:hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <label className="sm:col-span-4 space-y-1 text-xs">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">
              System / Service Name *
            </span>
            <input
              type="text"
              required
              value={formService}
              onChange={(e) => setFormService(e.target.value)}
              placeholder="e.g. JBoss EAP 8 Admin Console"
              className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            />
          </label>

          <label className="sm:col-span-4 space-y-1 text-xs">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">
              Endpoint URL or Account Email
            </span>
            <input
              type="text"
              value={formEndpoint}
              onChange={(e) => setFormEndpoint(e.target.value)}
              placeholder="https://admin.corp.internal"
              className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
            />
          </label>

          <label className="sm:col-span-4 space-y-1 text-xs">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">
              Username *
            </span>
            <input
              type="text"
              required
              value={formUsername}
              onChange={(e) => setFormUsername(e.target.value)}
              placeholder="mkrhl_adm"
              className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
            />
          </label>

          <div className="sm:col-span-4 space-y-1 text-xs">
            <span className="block font-medium text-zinc-700 dark:text-zinc-300">
              Password *
            </span>
            <div className="flex items-center gap-1.5">
              <div className="relative flex-1">
                <input
                  type={formShowPw ? 'text' : 'password'}
                  required
                  value={formPassword}
                  onChange={(e) => setFormPassword(e.target.value)}
                  placeholder="Enter or generate password"
                  className="w-full pl-3 pr-8 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => setFormShowPw((v) => !v)}
                  aria-label={formShowPw ? 'Hide password' : 'Show password'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-700 cursor-pointer"
                >
                  {formShowPw ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
              <button
                type="button"
                onClick={() => {
                  setFormPassword(generateStrongPassword());
                  setFormShowPw(true);
                }}
                title="Generate strong password"
                className="p-2 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 hover:border-[#2563EB] cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <label className="sm:col-span-2 space-y-1 text-xs">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">Category</span>
            <select
              value={formCategory}
              onChange={(e) => setFormCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>

          <label className="sm:col-span-2 space-y-1 text-xs">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">Environment</span>
            <select
              value={formEnv}
              onChange={(e) => setFormEnv(e.target.value as CredentialEnv)}
              className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            >
              {ENVIRONMENTS.map((env) => (
                <option key={env} value={env}>
                  {env}
                </option>
              ))}
            </select>
          </label>

          <label className="sm:col-span-2 space-y-1 text-xs">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">Status</span>
            <select
              value={formStatus}
              onChange={(e) => setFormStatus(e.target.value as CredentialStatus)}
              className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            >
              <option value="Active">Active</option>
              <option value="Rotate Soon">Rotate Soon</option>
              <option value="Inactive">Inactive</option>
            </select>
          </label>

          <label className="sm:col-span-2 space-y-1 text-xs">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">2F Auth</span>
            <select
              value={formTwoFactor}
              onChange={(e) =>
                setFormTwoFactor(e.target.value as 'Enabled' | 'Disabled')
              }
              className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            >
              <option value="Enabled">Enabled</option>
              <option value="Disabled">Disabled</option>
            </select>
          </label>

          <label className="sm:col-span-9 space-y-1 text-xs">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">
              Notes (optional)
            </span>
            <input
              type="text"
              value={formNotes}
              onChange={(e) => setFormNotes(e.target.value)}
              placeholder="Realm, Bastion requirement, or rotation schedule..."
              className="w-full px-3 py-2 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            />
          </label>

          <div className="sm:col-span-3 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-4 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
            >
              {editingId ? 'Save Changes' : 'Save Credential'}
            </button>
          </div>
        </form>
      )}

      {/* VIEW 1: TABLE (Dribbble Reference High-Density Data Grid) */}
      {viewMode === 'table' && (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#FAFAFA] dark:bg-zinc-900/60 border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                <th className="w-10 px-4 py-3">
                  <input
                    type="checkbox"
                    checked={
                      pagedEntries.length > 0 &&
                      pagedEntries.every((e) => selectedIds.includes(e.id))
                    }
                    onChange={toggleSelectAllVisible}
                    aria-label="Select all visible rows"
                    className="accent-[#2563EB]"
                  />
                </th>
                <th className="px-3 py-3 whitespace-nowrap">
                  <span className="inline-flex items-center gap-1.5">
                    <Server className="w-3.5 h-3.5" />
                    <span>Service / System</span>
                  </span>
                </th>
                {visibleCols.endpoint && (
                  <th className="px-3 py-3 whitespace-nowrap">Endpoint / Email</th>
                )}
                {visibleCols.username && (
                  <th className="px-3 py-3 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5" />
                      <span>Username</span>
                    </span>
                  </th>
                )}
                {visibleCols.password && (
                  <th className="px-3 py-3 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5" />
                      <span>Password</span>
                    </span>
                  </th>
                )}
                {visibleCols.category && (
                  <th className="px-3 py-3 whitespace-nowrap">Role / Env</th>
                )}
                {visibleCols.status && (
                  <th className="px-3 py-3 whitespace-nowrap">Status</th>
                )}
                {visibleCols.updated && (
                  <th className="px-3 py-3 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Updated</span>
                    </span>
                  </th>
                )}
                {visibleCols.twoFactor && (
                  <th className="px-3 py-3 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>2F Auth</span>
                    </span>
                  </th>
                )}
                <th className="px-4 py-3 text-right whitespace-nowrap">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {pagedEntries.length === 0 ? (
                <tr>
                  <td
                    colSpan={10}
                    className="py-12 text-center text-zinc-500 dark:text-zinc-400"
                  >
                    No credentials match your filters.
                  </td>
                </tr>
              ) : (
                pagedEntries.map((item) => {
                  const isRevealed = Boolean(revealedIds[item.id]);
                  const initials = item.service
                    .split(/\s+/)
                    .slice(0, 2)
                    .map((w) => w[0]?.toUpperCase() || '')
                    .join('');

                  return (
                    <tr
                      key={item.id}
                      className="hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <input
                          type="checkbox"
                          checked={selectedIds.includes(item.id)}
                          onChange={() => toggleSelectRow(item.id)}
                          aria-label={`Select ${item.service}`}
                          className="accent-[#2563EB]"
                        />
                      </td>

                      <td className="px-3 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-2.5">
                          <span className="w-7 h-7 rounded-full bg-[#2563EB]/10 dark:bg-blue-500/15 text-[#2563EB] dark:text-blue-400 font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                            {initials}
                          </span>
                          <span className="font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                            {item.service}
                          </span>
                        </div>
                      </td>

                      {visibleCols.endpoint && (
                        <td className="px-3 py-3 font-mono text-[11px] text-zinc-500 dark:text-zinc-400 max-w-[200px] truncate">
                          {item.endpointOrEmail}
                        </td>
                      )}

                      {visibleCols.username && (
                        <td className="px-3 py-3 whitespace-nowrap">
                          <div className="inline-flex items-center gap-1.5 font-mono text-[11px] text-[#09090B] dark:text-zinc-200">
                            <span>{item.username}</span>
                            <button
                              type="button"
                              onClick={() => handleCopy(`u-${item.id}`, item.username)}
                              aria-label={`Copy username for ${item.service}`}
                              className="p-1 text-zinc-400 hover:text-[#2563EB] cursor-pointer"
                            >
                              {copiedKey === `u-${item.id}` ? (
                                <Check className="w-3 h-3 text-[#2563EB]" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </td>
                      )}

                      {visibleCols.password && (
                        <td className="px-3 py-3 whitespace-nowrap">
                          <div className="inline-flex items-center gap-1 font-mono text-[11px]">
                            <span className="min-w-[105px] text-zinc-700 dark:text-zinc-300">
                              {isRevealed ? item.password : '••••••••••••'}
                            </span>
                            <button
                              type="button"
                              onClick={() => toggleReveal(item.id)}
                              aria-label={isRevealed ? 'Hide password' : 'Reveal password'}
                              className="p-1 text-zinc-400 hover:text-[#09090B] dark:hover:text-white cursor-pointer"
                            >
                              {isRevealed ? (
                                <EyeOff className="w-3.5 h-3.5" />
                              ) : (
                                <Eye className="w-3.5 h-3.5" />
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleCopy(`p-${item.id}`, item.password)}
                              aria-label={`Copy password for ${item.service}`}
                              className="p-1 text-zinc-400 hover:text-[#2563EB] cursor-pointer"
                            >
                              {copiedKey === `p-${item.id}` ? (
                                <Check className="w-3.5 h-3.5 text-[#2563EB]" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        </td>
                      )}

                      {visibleCols.category && (
                        <td className="px-3 py-3 whitespace-nowrap text-zinc-600 dark:text-zinc-300">
                          {item.category} · {item.env}
                        </td>
                      )}

                      {visibleCols.status && (
                        <td className="px-3 py-3 whitespace-nowrap">
                          {renderStatusBadge(item.status)}
                        </td>
                      )}

                      {visibleCols.updated && (
                        <td className="px-3 py-3 whitespace-nowrap font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                          {item.updatedAt}
                        </td>
                      )}

                      {visibleCols.twoFactor && (
                        <td className="px-3 py-3 whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[11px] font-medium border ${
                              item.twoFactor === 'Enabled'
                                ? 'bg-emerald-50/70 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/60'
                                : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-700'
                            }`}
                          >
                            {item.twoFactor}
                          </span>
                        </td>
                      )}

                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => openEditForm(item)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-zinc-200 dark:border-zinc-700 bg-[#FAFAFA] dark:bg-zinc-900 hover:border-[#2563EB] text-[11px] font-medium cursor-pointer"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>Edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(item.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-zinc-200 dark:border-zinc-700 bg-[#FAFAFA] dark:bg-zinc-900 hover:border-red-500 hover:text-red-600 dark:hover:text-red-400 text-[11px] font-medium cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* VIEW 2: BOARD (Grouped by Environment) */}
      {viewMode === 'board' && (
        <div className="p-5 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredEntries.map((item) => {
            const isRevealed = Boolean(revealedIds[item.id]);
            return (
              <article
                key={item.id}
                className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-[11px] font-mono text-[#2563EB] dark:text-blue-400">
                      {item.env} · {item.category}
                    </div>
                    <h3 className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA] truncate">
                      {item.service}
                    </h3>
                    <div className="text-[11px] font-mono text-zinc-500 truncate">
                      {item.endpointOrEmail}
                    </div>
                  </div>
                  {renderStatusBadge(item.status)}
                </div>

                <div className="p-3 rounded-lg bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-1.5 text-xs font-mono">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-zinc-500">User:</span>
                    <button
                      type="button"
                      onClick={() => handleCopy(`bu-${item.id}`, item.username)}
                      className="inline-flex items-center gap-1 hover:text-[#2563EB] cursor-pointer"
                    >
                      <span>{item.username}</span>
                      {copiedKey === `bu-${item.id}` ? (
                        <Check className="w-3 h-3 text-[#2563EB]" />
                      ) : (
                        <Copy className="w-3 h-3 text-zinc-400" />
                      )}
                    </button>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-zinc-500">Pass:</span>
                    <div className="inline-flex items-center gap-1">
                      <span>{isRevealed ? item.password : '••••••••••••'}</span>
                      <button
                        type="button"
                        onClick={() => toggleReveal(item.id)}
                        className="p-0.5 text-zinc-400 hover:text-[#09090B] cursor-pointer"
                      >
                        {isRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleCopy(`bp-${item.id}`, item.password)}
                        className="p-0.5 text-zinc-400 hover:text-[#2563EB] cursor-pointer"
                      >
                        {copiedKey === `bp-${item.id}` ? (
                          <Check className="w-3 h-3 text-[#2563EB]" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 text-[11px] text-zinc-500">
                  <span>2FA: {item.twoFactor}</span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => openEditForm(item)}
                      className="hover:text-[#2563EB] cursor-pointer"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(item.id)}
                      className="hover:text-red-600 cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* VIEW 3: LIST */}
      {viewMode === 'list' && (
        <div className="divide-y divide-zinc-200 dark:divide-zinc-800">
          {pagedEntries.map((item) => {
            const isRevealed = Boolean(revealedIds[item.id]);
            return (
              <div
                key={item.id}
                className="px-5 py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-zinc-50/70 dark:hover:bg-zinc-900/40"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                      {item.service}
                    </span>
                    <span className="text-zinc-500">
                      · {item.category} ({item.env})
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-zinc-500">
                    {item.endpointOrEmail}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
                  <button
                    type="button"
                    onClick={() => handleCopy(`lu-${item.id}`, item.username)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-zinc-100 dark:bg-zinc-900 cursor-pointer"
                  >
                    <span>{item.username}</span>
                    {copiedKey === `lu-${item.id}` ? (
                      <Check className="w-3 h-3 text-[#2563EB]" />
                    ) : (
                      <Copy className="w-3 h-3 text-zinc-400" />
                    )}
                  </button>

                  <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-zinc-100 dark:bg-zinc-900">
                    <span>{isRevealed ? item.password : '••••••••'}</span>
                    <button
                      type="button"
                      onClick={() => toggleReveal(item.id)}
                      className="cursor-pointer text-zinc-400 hover:text-[#09090B]"
                    >
                      {isRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopy(`lp-${item.id}`, item.password)}
                      className="cursor-pointer text-zinc-400 hover:text-[#2563EB]"
                    >
                      {copiedKey === `lp-${item.id}` ? (
                        <Check className="w-3 h-3 text-[#2563EB]" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>

                  {renderStatusBadge(item.status)}

                  <button
                    type="button"
                    onClick={() => openEditForm(item)}
                    className="text-zinc-500 hover:text-[#2563EB] cursor-pointer font-sans"
                  >
                    Edit
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Bottom Pagination Footer (Matches Dribbble Reference) */}
      <div className="px-5 py-3.5 border-t border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-zinc-600 dark:text-zinc-400">
        <div className="flex items-center gap-3 tabular-nums">
          <span>Rows per page</span>
          <select
            value={rowsPerPage}
            onChange={(e) => {
              setRowsPerPage(Number(e.target.value));
              setCurrentPage(1);
            }}
            aria-label="Rows per page"
            className="px-2 py-1 rounded-md bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
          >
            <option value={10}>10</option>
            <option value={15}>15</option>
            <option value={25}>25</option>
          </select>
          <span className="font-mono text-[11px]">
            {filteredEntries.length === 0
              ? '0 rows'
              : `${(safePage - 1) * rowsPerPage + 1}-${Math.min(
                  safePage * rowsPerPage,
                  filteredEntries.length
                )} of ${filteredEntries.length} rows`}
          </span>
        </div>

        <div className="flex items-center gap-1 font-mono tabular-nums">
          <button
            type="button"
            disabled={safePage <= 1}
            onClick={() => setCurrentPage(1)}
            aria-label="First page"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 disabled:opacity-40 cursor-pointer"
          >
            <ChevronsLeft className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            disabled={safePage <= 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            aria-label="Previous page"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 disabled:opacity-40 cursor-pointer"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
            <button
              key={pageNum}
              type="button"
              onClick={() => setCurrentPage(pageNum)}
              className={`min-w-7 px-2 py-1 rounded-md text-xs cursor-pointer ${
                pageNum === safePage
                  ? 'bg-[#2563EB] text-white font-semibold'
                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
              }`}
            >
              {pageNum}
            </button>
          ))}

          <button
            type="button"
            disabled={safePage >= totalPages}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            aria-label="Next page"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 disabled:opacity-40 cursor-pointer"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            disabled={safePage >= totalPages}
            onClick={() => setCurrentPage(totalPages)}
            aria-label="Last page"
            className="p-1.5 rounded-md border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 disabled:opacity-40 cursor-pointer"
          >
            <ChevronsRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
