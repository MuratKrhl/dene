import React, { useEffect, useState } from 'react';
import {
  Bookmark,
  BookOpen,
  Code2,
  Compass,
  Database,
  FileCode2,
  Folder,
  Globe,
  Layers,
  Link2,
  Server,
  Terminal,
  Wrench,
} from 'lucide-react';
import { BookmarkIconKey } from '../data/portfolioData';

export const BOOKMARK_ICON_OPTIONS: Array<{
  key: BookmarkIconKey;
  label: string;
}> = [
  { key: 'auto', label: 'Auto Favicon (from URL)' },
  { key: 'globe', label: 'Web / Globe' },
  { key: 'code', label: 'Code / Engineering' },
  { key: 'layers', label: 'Design Systems' },
  { key: 'terminal', label: 'Terminal / CLI' },
  { key: 'server', label: 'Server / NFS' },
  { key: 'book', label: 'Docs / Reading' },
  { key: 'wrench', label: 'Tools / Utilities' },
  { key: 'database', label: 'Data / Storage' },
  { key: 'compass', label: 'Architecture' },
  { key: 'filecode', label: 'Specs / Handbook' },
  { key: 'folder', label: 'Collection' },
  { key: 'bookmark', label: 'Bookmark' },
];

function renderPresetSvg(key: BookmarkIconKey, className: string) {
  switch (key) {
    case 'github':
      return (
        <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
          <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
        </svg>
      );
    case 'code':
      return <Code2 className={className} aria-hidden="true" />;
    case 'layers':
      return <Layers className={className} aria-hidden="true" />;
    case 'terminal':
      return <Terminal className={className} aria-hidden="true" />;
    case 'server':
      return <Server className={className} aria-hidden="true" />;
    case 'book':
      return <BookOpen className={className} aria-hidden="true" />;
    case 'wrench':
      return <Wrench className={className} aria-hidden="true" />;
    case 'database':
      return <Database className={className} aria-hidden="true" />;
    case 'compass':
      return <Compass className={className} aria-hidden="true" />;
    case 'filecode':
      return <FileCode2 className={className} aria-hidden="true" />;
    case 'folder':
      return <Folder className={className} aria-hidden="true" />;
    case 'bookmark':
      return <Bookmark className={className} aria-hidden="true" />;
    case 'globe':
    case 'auto':
    default:
      return <Globe className={className} aria-hidden="true" />;
  }
}

function getToneAccent(tone: 'ink' | 'cobalt' | 'slate' | 'zinc'): string {
  switch (tone) {
    case 'cobalt':
      return 'bg-[#2563EB]/10 text-[#2563EB] border-[#2563EB]/20 dark:bg-blue-500/15 dark:text-blue-400 dark:border-blue-500/25';
    case 'ink':
      return 'bg-zinc-900 text-white border-zinc-800 dark:bg-zinc-100 dark:text-[#09090B] dark:border-zinc-200';
    case 'slate':
      return 'bg-zinc-100 text-zinc-800 border-zinc-200 dark:bg-zinc-800 dark:text-zinc-100 dark:border-zinc-700';
    case 'zinc':
    default:
      return 'bg-[#FAFAFA] text-zinc-700 border-zinc-200 dark:bg-zinc-900 dark:text-zinc-200 dark:border-zinc-800';
  }
}

interface BookmarkIconProps {
  title: string;
  domain: string;
  url: string;
  iconKey?: BookmarkIconKey;
  iconUrl?: string;
  tone?: 'ink' | 'cobalt' | 'slate' | 'zinc';
  size?: 'sm' | 'md';
}

export const BookmarkIcon: React.FC<BookmarkIconProps> = ({
  title,
  domain,
  url,
  iconKey = 'auto',
  iconUrl,
  tone = 'zinc',
  size = 'md',
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  const isExternal = !url.startsWith('/') && domain !== 'workspace.local';
  const resolvedFaviconUrl =
    iconUrl?.trim() ||
    (iconKey === 'auto' && isExternal
      ? `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=64`
      : '');

  useEffect(() => {
    setImgFailed(false);
  }, [resolvedFaviconUrl]);

  const boxSize = size === 'sm' ? 'w-8 h-8 rounded-lg' : 'w-11 h-11 rounded-xl';
  const iconDim = size === 'sm' ? 'w-4 h-4' : 'w-5 h-5';
  const imgDim = size === 'sm' ? 'w-4 h-4' : 'w-5 h-5';

  if (resolvedFaviconUrl && !imgFailed) {
    return (
      <div
        className={`${boxSize} bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-center shrink-0 overflow-hidden shadow-2xs`}
      >
        <img
          src={resolvedFaviconUrl}
          alt={`${title} icon`}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className={`${imgDim} object-contain rounded-sm`}
        />
      </div>
    );
  }

  return (
    <div
      aria-hidden="true"
      className={`${boxSize} border flex items-center justify-center shrink-0 ${getToneAccent(tone)}`}
    >
      {renderPresetSvg(iconKey, iconDim)}
    </div>
  );
};

export const BookmarkInlineFavicon: React.FC<{
  domain: string;
  url: string;
  iconKey?: BookmarkIconKey;
  iconUrl?: string;
}> = ({ domain, url, iconKey = 'auto', iconUrl }) => {
  const [failed, setFailed] = useState(false);
  const isExternal = !url.startsWith('/') && domain !== 'workspace.local';
  const src =
    iconUrl?.trim() ||
    (isExternal
      ? `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=32`
      : '');

  useEffect(() => {
    setFailed(false);
  }, [src]);

  if (src && !failed) {
    return (
      <img
        src={src}
        alt=""
        aria-hidden="true"
        referrerPolicy="no-referrer"
        onError={() => setFailed(true)}
        className="w-3.5 h-3.5 rounded-[3px] object-contain shrink-0"
      />
    );
  }

  if (iconKey && iconKey !== 'auto') {
    return renderPresetSvg(iconKey, 'w-3.5 h-3.5 text-zinc-400 shrink-0');
  }

  return <Link2 className="w-3.5 h-3.5 text-zinc-400 shrink-0" aria-hidden="true" />;
};
