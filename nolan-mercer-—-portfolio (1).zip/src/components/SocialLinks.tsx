import React from 'react';

interface SocialLinksProps {
  className?: string;
}

export const SocialLinks: React.FC<SocialLinksProps> = ({ className = '' }) => {
  return (
    <nav
      aria-label="Social and contact profiles"
      className={`flex items-center gap-3.5 ${className}`}
    >
      {/* GitHub */}
      <a
        href="https://github.com/MuratKrhl"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="GitHub"
        className="group relative inline-flex items-center justify-center w-10 h-10 text-zinc-500 dark:text-zinc-400 hover:text-[#181717] dark:hover:text-white focus-visible:text-[#181717] dark:focus-visible:text-white transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB] rounded-md"
      >
        <svg
          viewBox="0 0 24 24"
          className="w-[21px] h-[21px] fill-current transition-transform duration-200 group-hover:scale-105"
          aria-hidden="true"
        >
          <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
        </svg>
        <span
          role="tooltip"
          className="pointer-events-none absolute left-1/2 -translate-x-1/2 -bottom-7 px-2 py-0.5 rounded bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 text-[11px] font-medium whitespace-nowrap opacity-0 translate-y-0.5 group-hover:opacity-100 group-hover:translate-y-0 group-focus-visible:opacity-100 group-focus-visible:translate-y-0 transition-all duration-150"
        >
          GitHub
        </span>
      </a>

      {/* X (Twitter) */}
      <a
        href="https://x.com/M_karahaliloglu"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="X"
        className="group relative inline-flex items-center justify-center w-10 h-10 text-zinc-500 dark:text-zinc-400 hover:text-[#000000] dark:hover:text-white focus-visible:text-[#000000] dark:focus-visible:text-white transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB] rounded-md"
      >
        <svg
          viewBox="0 0 24 24"
          className="w-[20px] h-[20px] fill-current transition-transform duration-200 group-hover:scale-105"
          aria-hidden="true"
        >
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
        </svg>
        <span
          role="tooltip"
          className="pointer-events-none absolute left-1/2 -translate-x-1/2 -bottom-7 px-2 py-0.5 rounded bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 text-[11px] font-medium whitespace-nowrap opacity-0 translate-y-0.5 group-hover:opacity-100 group-hover:translate-y-0 group-focus-visible:opacity-100 group-focus-visible:translate-y-0 transition-all duration-150"
        >
          X
        </span>
      </a>

      {/* LinkedIn */}
      <a
        href="https://www.linkedin.com/in/murat-karahalilo%C4%9Flu/"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="LinkedIn"
        className="group relative inline-flex items-center justify-center w-10 h-10 text-zinc-500 dark:text-zinc-400 hover:text-[#0A66C2] dark:hover:text-[#0A66C2] focus-visible:text-[#0A66C2] transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB] rounded-md"
      >
        <svg
          viewBox="0 0 24 24"
          className="w-[21px] h-[21px] fill-current transition-transform duration-200 group-hover:scale-105"
          aria-hidden="true"
        >
          <path d="M6.94 5a2 2 0 1 1-4-.002 2 2 0 0 1 4 .002zM7 8.48H3V21h4V8.48zm6.32 0H9.34V21h3.94v-6.57c0-3.66 4.77-4 4.77 0V21H22v-7.93c0-6.17-7.06-5.94-8.72-2.91l.04-1.68z" />
        </svg>
        <span
          role="tooltip"
          className="pointer-events-none absolute left-1/2 -translate-x-1/2 -bottom-7 px-2 py-0.5 rounded bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 text-[11px] font-medium whitespace-nowrap opacity-0 translate-y-0.5 group-hover:opacity-100 group-hover:translate-y-0 group-focus-visible:opacity-100 group-focus-visible:translate-y-0 transition-all duration-150"
        >
          LinkedIn
        </span>
      </a>

      {/* Gmail */}
      <a
        href="https://mail.google.com/mail/u/0/#inbox"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Gmail"
        className="group relative inline-flex items-center justify-center w-10 h-10 text-zinc-500 dark:text-zinc-400 transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2563EB] rounded-md"
      >
        {/* Default neutral monochrome Gmail mark */}
        <svg
          viewBox="0 0 24 24"
          className="w-[22px] h-[22px] fill-current transition-opacity duration-200 group-hover:opacity-0 group-focus-visible:opacity-0"
          aria-hidden="true"
        >
          <path d="M24 5.457v13.909c0 .904-.732 1.636-1.636 1.636h-3.819V11.73L12 16.64l-6.545-4.91v9.273H1.636A1.636 1.636 0 0 1 0 19.366V5.457c0-2.023 2.309-3.178 3.927-1.964L5.455 4.64 12 9.548l6.545-4.91 1.528-1.145C21.69 2.28 24 3.434 24 5.457z" />
        </svg>

        {/* Original 4-color Gmail brand mark shown smoothly on hover / focus */}
        <svg
          viewBox="0 0 24 24"
          className="w-[22px] h-[22px] absolute inset-0 m-auto opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100 transition-all duration-200 group-hover:scale-105"
          aria-hidden="true"
        >
          <path
            fill="#4285F4"
            d="M1.636 21h3.819v-9.273L0 7.636V19.364C0 20.268.732 21 1.636 21z"
          />
          <path
            fill="#34A853"
            d="M18.545 21h3.819C23.268 21 24 20.268 24 19.364V7.636l-5.455 4.091V21z"
          />
          <path
            fill="#FBBC04"
            d="M18.545 4.636v7.091L24 7.636V5.455c0-2.023-2.309-3.178-3.927-1.964l-1.528 1.145z"
          />
          <path
            fill="#EA4335"
            d="M5.455 11.727V4.636L12 9.545l6.545-4.909v7.091L12 16.636l-6.545-4.909z"
          />
          <path
            fill="#C5221F"
            d="M0 5.455v2.181l5.455 4.091V4.636L3.927 3.491C2.309 2.277 0 3.432 0 5.455z"
          />
        </svg>

        <span
          role="tooltip"
          className="pointer-events-none absolute left-1/2 -translate-x-1/2 -bottom-7 px-2 py-0.5 rounded bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 text-[11px] font-medium whitespace-nowrap opacity-0 translate-y-0.5 group-hover:opacity-100 group-hover:translate-y-0 group-focus-visible:opacity-100 group-focus-visible:translate-y-0 transition-all duration-150"
        >
          Gmail
        </span>
      </a>
    </nav>
  );
};
