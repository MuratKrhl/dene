import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronDown,
  LogOut,
  Menu,
  ShieldCheck,
  User,
  X,
} from 'lucide-react';
import { EnvironmentTabKey } from '../data/environmentData';
import { ProjectManagementTabKey } from '../data/projectManagementData';
import { GitHubExplorerSubTab } from '../github/types';
import { TechSubTab } from '../types/technology';
import { KnowledgeHubTabKey } from '../pages/KnowledgeHubPage';
import { AdminTabKey } from '../pages/AdminPage';

export type AppRoute =
  | { page: 'home' }
  | { page: 'quick-access'; tab?: 'bookmarks' | 'nfs'; nfsSourceId?: string }
  | { page: 'nfs-viewer'; sourceId: string; fileId: string }
  | { page: 'project'; slug: string }
  | { page: 'environment'; tab?: EnvironmentTabKey }
  | { page: 'environment-detail'; tab: EnvironmentTabKey; slug: string }
  | { page: 'project-management'; tab?: ProjectManagementTabKey }
  | { page: 'article'; slug: string }
  | { page: 'tools' }
  | {
      page: 'knowledge-hub';
      tab?: KnowledgeHubTabKey;
      githubSubTab?: GitHubExplorerSubTab;
      technologySubTab?: TechSubTab;
      hubSection?: 'articles' | 'favorites' | 'archive' | 'sources' | 'history' | 'article';
      hubArticleId?: string;
      podcastSeriesId?: string;
      legacyTechPreset?: string;
      showTechSyncHistory?: boolean;
    }
  | { page: 'github-repo-detail'; owner: string; repo: string }
  | { page: 'onenote-page'; fileId?: string }
  | { page: 'admin'; tab?: AdminTabKey }
  | { page: 'contact' };

interface NavbarProps {
  currentRoute: AppRoute;
  onNavigate: (path: string) => void;
  currentUser: string;
  onLogout: () => void;
}

const NAV_LINKS = [
  { label: 'Home', path: '/', key: 'home' },
  { label: 'Quick Access', path: '/quick-access', key: 'quick-access' },
  { label: 'Environment', path: '/environment', key: 'environment' },
  { label: 'Project Management', path: '/project-management', key: 'project-management' },
  { label: 'Tools', path: '/tools', key: 'tools' },
  { label: 'Knowledge Hub', path: '/knowledge-hub', key: 'knowledge-hub' },
] as const;

export const Navbar: React.FC<NavbarProps> = ({
  currentRoute,
  onNavigate,
  currentUser,
  onLogout,
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  const isAdmin = currentUser === 'Admin';

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        userMenuRef.current &&
        !userMenuRef.current.contains(event.target as Node)
      ) {
        setUserMenuOpen(false);
      }
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const isLinkActive = (key: string) => {
    if (key === 'quick-access') {
      return (
        currentRoute.page === 'quick-access' ||
        currentRoute.page === 'nfs-viewer' ||
        currentRoute.page === 'project'
      );
    }
    if (key === 'environment') {
      return (
        currentRoute.page === 'environment' ||
        currentRoute.page === 'environment-detail'
      );
    }
    if (key === 'project-management') {
      return currentRoute.page === 'project-management';
    }
    if (key === 'knowledge-hub') {
      return (
        currentRoute.page === 'knowledge-hub' ||
        currentRoute.page === 'github-repo-detail' ||
        currentRoute.page === 'onenote-page' ||
        currentRoute.page === 'article'
      );
    }
    return currentRoute.page === key;
  };

  const handleLinkClick = (e: React.MouseEvent, path: string) => {
    e.preventDefault();
    setMobileOpen(false);
    setUserMenuOpen(false);
    onNavigate(path);
  };

  const handleUserAction = (path: string) => {
    setUserMenuOpen(false);
    setMobileOpen(false);
    onNavigate(path);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#FAFAFA]/90 backdrop-blur-md border-b border-zinc-200">
      <div className="max-w-[1200px] mx-auto px-6 h-16 flex items-center justify-between gap-6 lg:gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="/"
          onClick={(e) => handleLinkClick(e, '/')}
          className="font-display text-lg font-semibold tracking-tight text-[#09090B] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#2563EB] rounded-sm"
        >
          Murat Krhl's
        </a>

        {/* Zone 2: Concise single-line navigation links */}
        <nav
          aria-label="Primary navigation"
          className="hidden lg:flex items-center gap-5 xl:gap-6 text-sm font-medium"
        >
          {NAV_LINKS.map((item) => {
            const active = isLinkActive(item.key);
            return (
              <a
                key={item.key}
                href={item.path}
                onClick={(e) => handleLinkClick(e, item.path)}
                aria-current={active ? 'page' : undefined}
                className={`relative py-1 whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#2563EB] rounded-sm ${
                  active
                    ? 'text-[#09090B]'
                    : 'text-zinc-600 hover:text-[#09090B]'
                }`}
              >
                {item.label}
                <span
                  aria-hidden="true"
                  className={`absolute left-0 right-0 -bottom-0.5 h-[1.5px] bg-[#2563EB] transition-transform duration-150 origin-left ${
                    active ? 'scale-x-100' : 'scale-x-0'
                  }`}
                />
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Borderless inline logged-in user label + dropdown */}
        <div className="flex items-center gap-3 shrink-0">
          <div ref={userMenuRef} className="hidden lg:block relative">
            <button
              type="button"
              onClick={() => setUserMenuOpen((prev) => !prev)}
              aria-expanded={userMenuOpen}
              aria-haspopup="menu"
              className={`inline-flex items-center gap-1.5 py-1 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#2563EB] rounded-sm ${
                currentRoute.page === 'admin'
                  ? 'text-[#2563EB]'
                  : 'text-[#09090B] hover:text-[#2563EB]'
              }`}
            >
              <User className="w-4 h-4 text-zinc-500" aria-hidden="true" />
              <span>{currentUser}</span>
              <ChevronDown
                className={`w-3.5 h-3.5 text-zinc-400 transition-transform duration-150 ${
                  userMenuOpen ? 'rotate-180' : ''
                }`}
                aria-hidden="true"
              />
            </button>

            {userMenuOpen && (
              <div
                role="menu"
                aria-label="User account menu"
                className="absolute right-0 mt-2 w-48 rounded-xl bg-white border border-zinc-200 shadow-lg py-1.5 z-50"
              >
                <div className="px-3.5 py-2 border-b border-zinc-200">
                  <p className="text-xs font-semibold text-[#09090B] truncate">
                    {currentUser}
                  </p>
                  <p className="text-[11px] text-zinc-500 truncate">
                    {isAdmin ? 'Administrator' : 'Standard User'}
                  </p>
                </div>

                {isAdmin && (
                  <div className="py-1">
                    <button
                      type="button"
                      role="menuitem"
                      onClick={() => handleUserAction('/admin')}
                      className={`w-full px-3.5 py-2 text-left text-xs font-medium flex items-center gap-2.5 transition-colors cursor-pointer ${
                        currentRoute.page === 'admin'
                          ? 'bg-[#2563EB]/8 text-[#2563EB]'
                          : 'text-zinc-700 hover:bg-zinc-100'
                      }`}
                    >
                      <ShieldCheck
                        className="w-3.5 h-3.5 text-[#2563EB] shrink-0"
                        aria-hidden="true"
                      />
                      <span>Admin</span>
                    </button>
                  </div>
                )}

                <div className={isAdmin ? 'pt-1 border-t border-zinc-200' : 'pt-1'}>
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      setUserMenuOpen(false);
                      onLogout();
                    }}
                    className="w-full px-3.5 py-2 text-left text-xs font-medium text-red-600 hover:bg-red-50/70 flex items-center gap-2.5 transition-colors cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="lg:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg border border-zinc-200 text-zinc-700 hover:bg-zinc-100 transition-colors focus-visible:outline-2 focus-visible:outline-[#2563EB]"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile / Tablet navigation drawer */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-zinc-200 bg-[#FAFAFA] px-6 py-4">
          <nav aria-label="Mobile navigation" className="flex flex-col gap-1">
            {NAV_LINKS.map((item) => {
              const active = isLinkActive(item.key);
              return (
                <a
                  key={item.key}
                  href={item.path}
                  onClick={(e) => handleLinkClick(e, item.path)}
                  aria-current={active ? 'page' : undefined}
                  className={`py-3 px-3 rounded-lg text-sm font-medium transition-colors ${
                    active
                      ? 'bg-zinc-100 text-[#09090B]'
                      : 'text-zinc-600 hover:text-[#09090B]'
                  }`}
                >
                  {item.label}
                </a>
              );
            })}

            <div className="pt-3 mt-2 border-t border-zinc-200 space-y-1">
              <div className="px-3 py-2 flex items-center gap-2 text-xs text-zinc-600">
                <User className="w-3.5 h-3.5 text-zinc-500" aria-hidden="true" />
                <span className="font-semibold text-[#09090B]">{currentUser}</span>
              </div>

              {isAdmin && (
                <button
                  type="button"
                  onClick={() => handleUserAction('/admin')}
                  className="w-full py-2.5 px-3 rounded-lg text-left text-sm font-medium text-zinc-700 hover:bg-zinc-100 flex items-center gap-2.5 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-[#2563EB]" aria-hidden="true" />
                  <span>Admin</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onLogout();
                }}
                className="w-full py-2.5 px-3 rounded-lg text-left text-sm font-medium text-red-600 hover:bg-red-50/70 flex items-center gap-2.5 cursor-pointer"
              >
                <LogOut className="w-4 h-4" aria-hidden="true" />
                <span>Logout</span>
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
