export type ProjectCategory =
  | 'Product Design'
  | 'Design Systems'
  | 'Creative Engineering';

export interface ProjectMetric {
  value: string;
  label: string;
}

export interface ProjectItem {
  slug: string;
  title: string;
  client: string;
  category: ProjectCategory;
  year: string;
  role: string;
  timeline: string;
  summary: string;
  image?: string;
  imageAlt?: string;
  specimenType?: 'tokens' | 'grid';
  featured?: boolean;
  liveUrl: string;
  deliverables: string[];
  metrics: ProjectMetric[];
  challenge: string;
  approach: string;
  architecture: string;
}

export type ArticleCategory =
  | 'Systems'
  | 'Engineering'
  | 'Craft'
  | 'Architecture'
  | 'Infrastructure';

export interface ArticleBlock {
  type: 'paragraph' | 'heading' | 'quote' | 'code';
  content: string;
  language?: string;
}

export interface JournalArticle {
  slug: string;
  title: string;
  category: ArticleCategory;
  publishedAt: string;
  readTime: string;
  author?: string;
  authorAvatar?: string;
  excerpt: string;
  coverImage?: string;
  coverAlt?: string;
  featured?: boolean;
  blocks: ArticleBlock[];
}

export interface ExperienceItem {
  period: string;
  role: string;
  company: string;
  location: string;
  summary: string;
}

export interface CapabilityItem {
  index: string;
  title: string;
  description: string;
  deliverables: string[];
}

export interface TestimonialItem {
  quote: string;
  author: string;
  role: string;
  company: string;
  outcome: string;
}

export const STUDIO_PROFILE = {
  name: "Murat Krhl's",
  workspaceTitle: "Murat Krhl's WorkSpace",
  tagline: 'Work. Tools. Projects. Ideas. Everything I need, in one place.',
  role: 'Product Designer & Creative Frontend Engineer',
  location: 'Istanbul / Remote',
  timezone: 'TRT (UTC+3)',
  email: 'murat.karahaliloglu5@gmail.com',
  availability: 'Open for select product & engineering collaborations',
  careerMetrics: [
    { value: '8+ yrs', label: 'Production Shipping' },
    { value: '42', label: 'Products Launched' },
    { value: '14', label: 'Design Systems Built' },
    { value: '98%', label: 'Client Retention' },
  ],
};

export const PROJECTS: ProjectItem[] = [
  {
    slug: 'krono-treasury-platform',
    title: 'Krono Institutional Treasury',
    client: 'Krono Financial',
    category: 'Product Design',
    year: '2026',
    role: 'Lead Product Designer & Frontend Architect',
    timeline: '16 Weeks',
    featured: true,
    image: '/src/assets/images/project_nordic_fintech_1794861018196.jpg',
    imageAlt:
      'Krono Financial monochrome treasury analytics interface shown on a matte aluminum laptop resting on limestone',
    liveUrl: 'https://krono.example.com',
    summary:
      'Re-architecting multi-currency liquidity forecasting and cash-sweep workflows for Nordic corporate finance teams.',
    deliverables: [
      'Information Architecture',
      'React & TypeScript Ledger UI',
      'Keyboard-First Command Palette',
      'Multi-Entity Reporting System',
    ],
    metrics: [
      { value: '-42%', label: 'Reconciliation Time' },
      { value: '1.8s', label: 'Report Cold Load' },
      { value: '+34%', label: 'Daily Active Treasurers' },
    ],
    challenge:
      'Corporate treasurers were toggling across seven legacy banking portals and fragile spreadsheets to calculate daily net cash positions across 14 currencies. High visual clutter and inconsistent tabular alignment caused frequent manual entry errors.',
    approach:
      'We distilled the primary workspace down to a single unified liquidity ledger with strict tabular numerals, deterministic keyboard navigation, and progressive disclosure for multi-signature approvals.',
    architecture:
      'Built on a virtualized React table engine paired with Web Worker FX aggregation and strict WCAG AA contrast tokens across light and low-glare dark trading environments.',
  },
  {
    slug: 'solis-architectural-atelier',
    title: 'Solis Architectural Commerce',
    client: 'Solis Objects Copenhagen',
    category: 'Creative Engineering',
    year: '2026',
    role: 'Creative Director & Frontend Engineer',
    timeline: '12 Weeks',
    featured: true,
    image: '/src/assets/images/project_atelier_commerce_1794861018540.jpg',
    imageAlt:
      'Solis architectural furniture and lighting storefront displayed on a frameless studio monitor inside a concrete gallery',
    liveUrl: 'https://solisobjects.example.com',
    summary:
      'Editorial specification storefront and custom finish configurator for architectural lighting and solid timber furniture.',
    deliverables: [
      'Editorial Storefront UI',
      'Material & Finish Configurator',
      'CAD & Spec Sheet Downloads',
      'Edge-Cached Product Catalog',
    ],
    metrics: [
      { value: '+61%', label: 'Trade Spec Downloads' },
      { value: '99/100', label: 'Core Web Vitals' },
      { value: '+28%', label: 'Trade Account Inquiries' },
    ],
    challenge:
      'Architects specifying bespoke lighting fixtures struggled with slow PDF brochures and ambiguous material finish thumbnails that failed to communicate brushed brass versus raw travertine.',
    approach:
      'Designed an uncluttered gallery-grade catalog anchored by generous white space, crisp side-by-side material swatches, and instant spec-sheet generation directly from the selected configuration.',
    architecture:
      'Implemented optimistic variant switching with zero layout shift, responsive AVIF art direction, and URL-synchronized configuration state for direct sharing between interior architects and procurement teams.',
  },
  {
    slug: 'volt-8-spatial-synth',
    title: 'Volt-8 Browser Sound Engine',
    client: 'Kinetix Audio Labs',
    category: 'Creative Engineering',
    year: '2025',
    role: 'UI Systems & WebAudio Engineer',
    timeline: '10 Weeks',
    featured: true,
    image: '/src/assets/images/project_kinetix_audio_1794861018977.jpg',
    imageAlt:
      'Anodized aluminum Volt-8 synthesizer hardware controller beside a high-contrast dark waveform display',
    liveUrl: 'https://kinetixaudio.example.com',
    summary:
      'Hardware-paired WebMIDI patch editor and real-time FFT spectral visualizer with sub-12ms control latency.',
    deliverables: [
      'WebMIDI Hardware Bridge',
      'Canvas 2D Waveform Renderer',
      'High-Contrast Dark Studio UI',
      'Patch Bank Exchange Format',
    ],
    metrics: [
      { value: '<12ms', label: 'MIDI Round-Trip' },
      { value: '60 fps', label: 'Waveform Rendering' },
      { value: '18,400', label: 'Community Patches Shared' },
    ],
    challenge:
      'Musicians needed a zero-install companion editor that matched the tactile precision of physical rotary encoders without feeling like a sluggish desktop port.',
    approach:
      'Crafted a dark-first instrument surface with crisp amber and slate telemetry, rotary drag physics calibrated to shift-key fine tuning, and direct hardware knob bi-directional sync.',
    architecture:
      'Decoupled the 60fps Canvas spectral loop from React state reconciliation using mutable typed arrays and AudioWorklet parameter buffers.',
  },
  {
    slug: 'nordhavn-coastal-telemetry',
    title: 'Nordhavn Coastal Atlas',
    client: 'Baltic Marine Institute',
    category: 'Product Design',
    year: '2025',
    role: 'Principal Product Designer',
    timeline: '14 Weeks',
    featured: true,
    image: '/src/assets/images/project_veridian_climate_1794861019822.jpg',
    imageAlt:
      'Nordic workstation overlooking the coast with a monitor displaying oceanographic bathymetry contour maps and charts',
    liveUrl: 'https://nordhavnatlas.example.com',
    summary:
      'Interactive bathymetric survey explorer and sensor drift monitor for Nordic marine researchers and harbor planners.',
    deliverables: [
      'Geospatial Data Visualization',
      'Time-Series Comparison View',
      'Field Researcher Offline Mode',
      'Accessible Colorblind Palettes',
    ],
    metrics: [
      { value: '3.2x', label: 'Faster Anomaly Triage' },
      { value: '100%', label: 'WCAG AA Map Legends' },
      { value: '47', label: 'Coastal Stations Tracked' },
    ],
    challenge:
      'Oceanographic researchers were exporting raw CSV sensor dumps into desktop GIS tools just to inspect seasonal salinity and tidal anomalies across neighboring fjords.',
    approach:
      'Unified contour bathymetry with synchronized time-series scrubbers, allowing researchers to isolate depth bands and export publication-grade SVG figures in two clicks.',
    architecture:
      'Vector tile contour rendering combined with accessible perceptual color ramps and deterministic state permalinks for peer-reviewed citations.',
  },
  {
    slug: 'meridian-token-architecture',
    title: 'Meridian Cross-Platform System',
    client: 'Meridian Logistics',
    category: 'Design Systems',
    year: '2025',
    role: 'Design Systems Lead',
    timeline: '20 Weeks',
    featured: false,
    specimenType: 'tokens',
    liveUrl: 'https://meridian-system.example.com',
    summary:
      'Unified multi-brand design token pipeline and accessible React primitive library powering 11 warehouse and dispatch web apps.',
    deliverables: [
      'W3C Design Token Pipeline',
      '48 Accessible React Primitives',
      'Figma-to-GitHub Sync CLI',
      'Interactive Documentation Site',
    ],
    metrics: [
      { value: '-55%', label: 'UI Engineering Duplication' },
      { value: '11', label: 'Product Teams Adopted' },
      { value: '0', label: 'P1 Accessibility Regressions' },
    ],
    challenge:
      'Four acquired logistics startups maintained separate component libraries with conflicting spacing scales, inconsistent keyboard focus rings, and broken dark-mode contrast.',
    approach:
      'Established a strict semantic token taxonomy separating primitive palette scales from surface, border, and action tokens, backed by automated contrast gates in CI.',
    architecture:
      'Style Dictionary transforms generating typed CSS custom properties and Tailwind v4 theme presets alongside Playwright keyboard-navigation test suites.',
  },
  {
    slug: 'monolith-editorial-grid',
    title: 'Monolith Publishing Framework',
    client: 'Monolith Press Zurich',
    category: 'Design Systems',
    year: '2024',
    role: 'Systems Designer & Frontend Engineer',
    timeline: '8 Weeks',
    featured: false,
    specimenType: 'grid',
    liveUrl: 'https://monolithpress.example.com',
    summary:
      'Modular Swiss typographic grid engine and long-form monograph reader built for architectural essays and print-synchronized editions.',
    deliverables: [
      'Modular 12-Column Print/Web Grid',
      'Footnote & Margin-Note Engine',
      'Typography Scale System',
      'Static Edge Publishing Pipeline',
    ],
    metrics: [
      { value: '+48%', label: 'Avg. Essay Completion' },
      { value: '14ms', label: 'Median TTFB Worldwide' },
      { value: '24', label: 'Digital Monographs Live' },
    ],
    challenge:
      'Long-form architectural criticism lost its spatial clarity on the web when footnotes collapsed into bottom-of-page anchors and imagery drifted out of proportional rhythm.',
    approach:
      'Translated Swiss baseline grid discipline into fluid CSS Grid tracks with synchronized marginalia that tuck cleanly into inline disclosures on compact screens.',
    architecture:
      'Zero-runtime CSS typography tokens paired with semantic HTML article landmarks and print-ready `@media print` stylesheets.',
  },
];

export const CAPABILITIES: CapabilityItem[] = [
  {
    index: '01.',
    title: 'Product Architecture',
    description:
      'End-to-end interface design for complex B2B workflows, financial tools, and data-dense applications where clarity directly reduces operational errors.',
    deliverables: [
      'Workflow & Information Architecture',
      'Interactive Prototypes in Code',
      'Usability & Keyboard Audits',
    ],
  },
  {
    index: '02.',
    title: 'Design Systems',
    description:
      'Scalable component libraries, W3C semantic token pipelines, and light/dark contrast governance engineered to bridge Figma and production React.',
    deliverables: [
      'Semantic Color & Type Tokens',
      'WCAG AA Accessible Primitives',
      'Living Component Documentation',
    ],
  },
  {
    index: '03.',
    title: 'Creative Engineering',
    description:
      'Production frontend architecture built in TypeScript, React, and Tailwind CSS with compositor-only motion, instant load times, and lasting maintainability.',
    deliverables: [
      'TypeScript & React Frontends',
      'Core Web Vitals Optimization',
      'Custom Canvas & Data Visualizations',
    ],
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    quote:
      'Before working with Murat, our treasury team spent mornings reconciling cash positions across seven portals. Within four months of launching the new unified ledger, daily reconciliation time dropped by 42% and onboarding new analysts took days instead of weeks.',
    author: 'Henrik Lindholm',
    role: 'VP of Product',
    company: 'Krono Financial',
    outcome: '42% faster daily treasury reconciliation across 14 currencies',
  },
  {
    quote:
      'Murat bridges design intuition and frontend systems engineering better than anyone we have partnered with. He unified four fragmented component libraries into a single accessible token system that every squad adopted voluntarily.',
    author: 'Maren Solberg',
    role: 'Head of Engineering',
    company: 'Meridian Logistics',
    outcome: 'Adopted by 11 engineering squads with 55% less UI duplication',
  },
];

export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    slug: 'semantic-tokens-beyond-color-palettes',
    title: 'Semantic Tokens Beyond Color Palettes: Designing Resilient Surface Hierarchies',
    category: 'Systems',
    publishedAt: 'October 18, 2026',
    readTime: '6 min read',
    author: 'Murat Karahaliloğlu',
    authorAvatar: '/src/assets/images/hero_studio_portrait_1794861017948.jpg',
    featured: true,
    coverImage: '/src/assets/images/blog_featured_ai_systems_1795026057245.jpg',
    coverAlt:
      'Sunlit engineering studio interior with oak worktable, open technical notebook, and dark steel framing',
    excerpt:
      'Why pairing surface elevation, border hairlines, and optical text weights prevents contrast regressions across complex multi-screen developer tools.',
    blocks: [
      {
        type: 'paragraph',
        content:
          'Most surface-contrast bugs do not come from missing hex values—they come from treating elevations and borders as afterthoughts. Clean structural surfaces rely on predictable luminance steps and hairline dividers that guide the eye without visual noise.',
      },
      {
        type: 'heading',
        content: '1. Separate Primitive Scales from Structural Intent',
      },
      {
        type: 'paragraph',
        content:
          'A palette token such as zinc-900 describes what a color looks like, not where it is safe to use. Structural tokens—canvas, surface, surface-recessed, hairline, and ink-muted—encode contrast guarantees between adjacent layers.',
      },
      {
        type: 'code',
        language: 'css',
        content: `/* Pair every surface with an explicit ink and border step */
.panel-surface {
  background-color: #ffffff;
  border-color: #e4e4e7;
  color: #09090b;
}`,
      },
      {
        type: 'heading',
        content: '2. Optical Weight and Reading Rhythm',
      },
      {
        type: 'paragraph',
        content:
          'Restricting display headings to balanced line lengths and keeping long-form body copy between 65ch and 72ch keeps technical documentation calm across extended reading sessions.',
      },
      {
        type: 'quote',
        content:
          'A reliable design system never asks an engineer to guess whether a border will hold up under dense tables—the pairing is baked directly into the component contract.',
      },
    ],
  },
  {
    slug: 'tabular-discipline-in-financial-interfaces',
    title: 'Tabular Discipline: Why Numeric Alignment Makes or Breaks Analytical Tools',
    category: 'Craft',
    publishedAt: 'September 04, 2026',
    readTime: '5 min read',
    author: 'Murat Karahaliloğlu',
    authorAvatar: '/src/assets/images/hero_studio_portrait_1794861017948.jpg',
    coverImage: '/src/assets/images/blog_article_tabular_data_1795026053404.jpg',
    coverAlt:
      'Architectural specification sheet, precision metal scale, and drafting pen on an off-white desk',
    excerpt:
      'Small typographic decisions—proportional vs. tabular figures, right-aligned columns, and quiet unit markers—dramatically improve scanning speed.',
    blocks: [
      {
        type: 'paragraph',
        content:
          'When an analyst scans twenty rows of inventory or revenue figures, the human eye relies on vertical rhythm to detect outliers. Proportional numerals break that vertical spine whenever a "1" sits beneath an "8".',
      },
      {
        type: 'heading',
        content: 'Enforcing Vertical Rhythm',
      },
      {
        type: 'paragraph',
        content:
          'Applying font-variant-numeric: tabular-nums (or pairing metrics with a clean monospace face like JetBrains Mono) guarantees identical glyph advance widths across digits 0 through 9. Combine this with right-alignment for quantities and consistent decimal precision so decimal points stack in a clean plumb line.',
      },
      {
        type: 'quote',
        content:
          'Legibility in data-dense software is rarely achieved by adding color; it is achieved by removing jitter.',
      },
    ],
  },
  {
    slug: 'compositor-only-motion-for-snappy-webapps',
    title: 'Designing Sub-200ms Interfaces with Compositor-Only Transitions',
    category: 'Engineering',
    publishedAt: 'July 22, 2026',
    readTime: '7 min read',
    author: 'Murat Karahaliloğlu',
    authorAvatar: '/src/assets/images/hero_studio_portrait_1794861017948.jpg',
    coverImage: '/src/assets/images/blog_article_motion_craft_1795026054223.jpg',
    coverAlt:
      'Contemporary sunlit architectural room with oak flooring and floor-to-ceiling black steel windows',
    excerpt:
      'Practical guidelines for keeping interactive state transitions crisp, accessible under prefers-reduced-motion, and free of layout thrashing.',
    blocks: [
      {
        type: 'paragraph',
        content:
          'Heavy spring animations look playful in isolation, but in multi-page applications people use all day, slow choreography quickly turns into friction. Routine controls—tabs, filters, drawers, and hover indicators—should settle within 120ms to 200ms.',
      },
      {
        type: 'heading',
        content: 'Stick to Transform and Opacity',
      },
      {
        type: 'paragraph',
        content:
          'Animating width, height, top, or margin forces the browser to recalculate layout on every frame. Restricting transitions to transform and opacity keeps animations on the GPU compositor thread while preserving predictable spatial geometry.',
      },
      {
        type: 'code',
        language: 'css',
        content: `@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}`,
      },
    ],
  },
  {
    slug: 'architecture-of-zero-layout-shift-portfolios',
    title: 'Zero-Layout-Shift Art Direction for Editorial Case Studies',
    category: 'Architecture',
    publishedAt: 'May 11, 2026',
    readTime: '4 min read',
    author: 'Murat Karahaliloğlu',
    authorAvatar: '/src/assets/images/hero_studio_portrait_1794861017948.jpg',
    coverImage: '/src/assets/images/blog_article_cloud_infra_1795026054106.jpg',
    coverAlt:
      'Minimalist glass and concrete modern towers looking upward against a bright overcast sky',
    excerpt:
      'How explicit aspect-ratio containers, resilient fallbacks, and clean URL routing keep image-rich publications instantaneous on any connection.',
    blocks: [
      {
        type: 'paragraph',
        content:
          'Editorial sites routinely fail Core Web Vitals because high-resolution imagery arrives after text layout has already painted, pushing headings and navigation out from under the reader’s cursor.',
      },
      {
        type: 'heading',
        content: 'Reserve Geometry Before Pixels Arrive',
      },
      {
        type: 'paragraph',
        content:
          'Wrapping every media slot in an explicit aspect-[4/3] or aspect-[16/9] container with a subtle tonal placeholder prevents cumulative layout shift entirely and pairs cleanly with resilient fallback states.',
      },
    ],
  },
  {
    slug: 'hardening-nfsv4-and-jboss-eap-clusters',
    title: 'Hardening NFSv4 Mounts and JBoss EAP 8 Runbooks in Production',
    category: 'Infrastructure',
    publishedAt: 'April 02, 2026',
    readTime: '8 min read',
    author: 'Murat Karahaliloğlu',
    authorAvatar: '/src/assets/images/hero_studio_portrait_1794861017948.jpg',
    coverImage: '/src/assets/images/journal_typography_systems_1794861019195.jpg',
    coverAlt:
      'Swiss typographic grid specimen sheets, metal scale ruler, and drafting pen on cotton paper',
    excerpt:
      'Operational notes on tuning rsize/wsize buffers, failover timeouts, and repeatable enterprise middleware runbooks for zero-downtime maintenance.',
    blocks: [
      {
        type: 'paragraph',
        content:
          'Shared storage mounts and application server clusters demand boring, deterministic configuration. Ambiguous timeout settings or undocumented manual edits turn routine patching windows into high-stress incident responses.',
      },
      {
        type: 'heading',
        content: 'Standardize Mount Options and Health Probes',
      },
      {
        type: 'paragraph',
        content:
          'Pinning NFSv4.1 protocol versions, matching rsize/wsize to network MTU budgets, and documenting exact pre-flight CLI checks inside OneNote runbooks reduces recovery times when nodes recycle.',
      },
      {
        type: 'code',
        language: 'bash',
        content: `mount -t nfs4 -o rw,hard,timeo=600,retrans=2,rsize=1048576,wsize=1048576 \\
  nas-prod.internal:/exports/shared /mnt/workspace`,
      },
    ],
  },
];

export const EXPERIENCE_TIMELINE: ExperienceItem[] = [
  {
    period: '2023 — Present',
    role: 'Principal Product Designer & Creative Engineer',
    company: "Murat Krhl's WorkSpace",
    location: 'Istanbul / Remote',
    summary:
      'Partnering with product-led engineering teams across Europe and North America to ship B2B financial tools, multi-brand design systems, and architectural web platforms.',
  },
  {
    period: '2020 — 2023',
    role: 'Staff Design Systems Engineer',
    company: 'Vektor Cloud Systems',
    location: 'Remote',
    summary:
      'Led the unified React component architecture and design token pipeline serving 180+ engineers across observability, billing, and developer console surfaces.',
  },
  {
    period: '2018 — 2020',
    role: 'Senior Frontend Developer & UI Designer',
    company: 'Atelier Nord Digital',
    location: 'Remote',
    summary:
      'Crafted interactive editorial publications, bespoke e-commerce configurators, and accessible cultural archives for digital-first design houses.',
  },
];

export const CRAFT_STACK = [
  {
    group: 'Interface & Systems',
    items: [
      'Figma & Tokens Studio',
      'Information Architecture',
      'WCAG AA/AAA Auditing',
      'Editorial Typography',
      'Interactive Prototyping',
    ],
  },
  {
    group: 'Frontend Engineering',
    items: [
      'TypeScript & React 19',
      'Tailwind CSS v4',
      'Next.js & Vite',
      'HTML5 Canvas & WebAudio',
      'Accessible ARIA Primitives',
    ],
  },
  {
    group: 'Quality & Delivery',
    items: [
      'Design Token CI Pipelines',
      'Playwright & Vitest',
      'Core Web Vitals Tuning',
      'Semantic Documentation',
      'Technical Mentorship',
    ],
  },
];

export interface BookmarkCollectionGroup {
  id: string;
  label: string;
  children: { id: string; label: string }[];
}

export type BookmarkIconKey =
  | 'auto'
  | 'github'
  | 'code'
  | 'layers'
  | 'terminal'
  | 'server'
  | 'book'
  | 'wrench'
  | 'database'
  | 'compass'
  | 'filecode'
  | 'folder'
  | 'bookmark'
  | 'globe';

export interface RaindropBookmark {
  id: string;
  title: string;
  description: string;
  url: string;
  domain: string;
  date: string;
  collection: string;
  subCollection: string;
  monogram: string;
  tone: 'ink' | 'cobalt' | 'slate' | 'zinc';
  iconKey?: BookmarkIconKey;
  iconUrl?: string;
  favorite?: boolean;
  internalPath?: string;
}

export const BOOKMARK_COLLECTIONS: BookmarkCollectionGroup[] = [
  {
    id: 'engineering',
    label: 'Engineering',
    children: [
      { id: 'frontend', label: 'Frontend' },
      { id: 'architecture', label: 'Architecture' },
    ],
  },
  {
    id: 'design',
    label: 'Design',
    children: [
      { id: 'systems', label: 'Systems' },
      { id: 'inspiration', label: 'Inspiration' },
    ],
  },
  {
    id: 'infrastructure',
    label: 'Infrastructure',
    children: [
      { id: 'storage-nfs', label: 'Storage & NFS' },
      { id: 'tooling', label: 'Tooling' },
    ],
  },
  {
    id: 'reading',
    label: 'Reading & Docs',
    children: [
      { id: 'references', label: 'References' },
      { id: 'articles', label: 'Articles' },
    ],
  },
];

export const RAINDROP_BOOKMARKS: RaindropBookmark[] = [
  {
    id: 'bm-github-profile',
    title: 'MuratKrhl — GitHub Repositories',
    description:
      'Open-source TypeScript packages, UI primitives, and active workspace repositories.',
    url: 'https://github.com/MuratKrhl',
    domain: 'github.com',
    date: '16 Nov',
    collection: 'Engineering',
    subCollection: 'Frontend',
    monogram: 'GH',
    tone: 'ink',
    iconKey: 'github',
    favorite: true,
  },
  {
    id: 'bm-tailwind-v4',
    title: 'Tailwind CSS v4 Engine & Token Architecture',
    description:
      'CSS-first configuration, @custom-variant dark pairing, and zero-runtime utility generation.',
    url: 'https://tailwindcss.com/docs',
    domain: 'tailwindcss.com',
    date: '14 Nov',
    collection: 'Design',
    subCollection: 'Systems',
    monogram: 'TW',
    tone: 'cobalt',
    iconKey: 'auto',
    favorite: true,
  },
  {
    id: 'bm-react-docs',
    title: 'React 19 Reference & Concurrent Patterns',
    description:
      'Official documentation for hooks, transitions, compiler optimizations, and composition.',
    url: 'https://react.dev/reference/react',
    domain: 'react.dev',
    date: '12 Nov',
    collection: 'Engineering',
    subCollection: 'Frontend',
    monogram: 'R:',
    tone: 'slate',
    iconKey: 'auto',
  },
  {
    id: 'bm-knowledge-hub',
    title: 'Workspace Knowledge Hub',
    description:
      'Internal architecture playbooks, TypeScript route patterns, and copy-ready CSS snippets.',
    url: '/knowledge-hub',
    domain: 'workspace.local',
    date: '11 Nov',
    collection: 'Reading & Docs',
    subCollection: 'References',
    monogram: 'KH',
    tone: 'cobalt',
    iconKey: 'book',
    favorite: true,
    internalPath: '/knowledge-hub',
  },
  {
    id: 'bm-wcag-tools',
    title: 'Contrast Checker & Fluid Clamp Utilities',
    description:
      'Browser-native WCAG AA/AAA contrast verification and responsive CSS clamp() generator.',
    url: '/tools',
    domain: 'workspace.local',
    date: '09 Nov',
    collection: 'Design',
    subCollection: 'Systems',
    monogram: 'TL',
    tone: 'zinc',
    iconKey: 'wrench',
    internalPath: '/tools',
  },
  {
    id: 'bm-nfs-rfc',
    title: 'NFSv4.1 Protocol & Linux Mount Tuning',
    description:
      'Hard/intr mount options, rsize/wsize buffers, and export permissions for shared workspaces.',
    url: 'https://datatracker.ietf.org/doc/html/rfc8881',
    domain: 'ietf.org',
    date: '05 Nov',
    collection: 'Infrastructure',
    subCollection: 'Storage & NFS',
    monogram: 'NF',
    tone: 'ink',
    iconKey: 'server',
  },
  {
    id: 'bm-vite-guide',
    title: 'Vite 8 Bundler & Plugin Guide',
    description:
      'Rollup/Rolldown pipeline optimization, static asset handling, and SSR middleware patterns.',
    url: 'https://vite.dev/guide/',
    domain: 'vite.dev',
    date: '02 Nov',
    collection: 'Infrastructure',
    subCollection: 'Tooling',
    monogram: 'V8',
    tone: 'slate',
    iconKey: 'auto',
  },
  {
    id: 'bm-swiss-grid',
    title: 'Swiss Typographic Grid & Editorial Rhythm',
    description:
      'Proportional baseline math, optical dark-mode compensation, and multi-column reading measures.',
    url: '/journal/semantic-tokens-beyond-color-palettes',
    domain: 'workspace.local',
    date: '28 Oct',
    collection: 'Design',
    subCollection: 'Inspiration',
    monogram: 'SG',
    tone: 'zinc',
    iconKey: 'layers',
    internalPath: '/journal/semantic-tokens-beyond-color-palettes',
  },
  {
    id: 'bm-ts-handbook',
    title: 'TypeScript Handbook — Narrowing & Discriminated Unions',
    description:
      'Exhaustive type narrowing patterns for router state machines and API payload contracts.',
    url: 'https://www.typescriptlang.org/docs/handbook/2/narrowing.html',
    domain: 'typescriptlang.org',
    date: '21 Oct',
    collection: 'Engineering',
    subCollection: 'Architecture',
    monogram: 'TS',
    tone: 'cobalt',
    iconKey: 'auto',
  },
  {
    id: 'bm-project-board',
    title: 'Sprint Milestone & Delivery Board',
    description:
      'Track active engineering deliverables, review queues, and shipped release notes.',
    url: '/project-management',
    domain: 'workspace.local',
    date: '19 Oct',
    collection: 'Reading & Docs',
    subCollection: 'Articles',
    monogram: 'PM',
    tone: 'ink',
    iconKey: 'compass',
    internalPath: '/project-management',
  },
];

export interface EnvironmentSpec {
  category: string;
  items: { name: string; detail: string; note: string }[];
}

export const ENVIRONMENT_SPECS: EnvironmentSpec[] = [
  {
    category: 'Editor & Terminal',
    items: [
      { name: 'Neovim + VS Code', detail: 'Dual-editor setup', note: 'TypeScript LSP, ESLint, Tailwind IntelliSense' },
      { name: 'Ghostty + Zsh', detail: 'GPU terminal', note: 'Starship prompt, fzf, zoxide navigation' },
      { name: 'JetBrains Mono', detail: '13.5px / 1.55 line-height', note: 'Tabular numerals with ligatures disabled' },
    ],
  },
  {
    category: 'Frontend & Runtime',
    items: [
      { name: 'React 19 + TypeScript', detail: 'Strict compiler mode', note: 'Zero-any discipline and modular hooks' },
      { name: 'Vite 8 + Tailwind v4', detail: 'CSS-first tokens', note: 'Custom dark variant & sub-second builds' },
      { name: 'Node.js 22 LTS + pnpm', detail: 'Workspace monorepos', note: 'Playwright & Vitest verification suites' },
    ],
  },
  {
    category: 'Design & Prototyping',
    items: [
      { name: 'Figma + Tokens Studio', detail: 'Semantic token sync', note: 'Light & dark surface pairs exported as JSON' },
      { name: 'Contrast & A11y Audit', detail: 'WCAG AA baseline', note: 'Keyboard focus traps & reduced-motion checks' },
    ],
  },
];

export type TaskStatus = 'Active' | 'In Review' | 'Shipped';

export interface WorkspaceProjectTask {
  id: string;
  title: string;
  workstream: string;
  status: TaskStatus;
  priority: 'High' | 'Normal';
  dueDate: string;
  progress: number;
}

export const INITIAL_PROJECT_TASKS: WorkspaceProjectTask[] = [
  {
    id: 'PM-104',
    title: 'Token Contrast CI Gate & Dark Surface Audit',
    workstream: 'Meridian Design System',
    status: 'Active',
    priority: 'High',
    dueDate: 'Nov 24, 2026',
    progress: 75,
  },
  {
    id: 'PM-103',
    title: 'Virtualized FX Ledger Keyboard Navigation',
    workstream: 'Krono Treasury',
    status: 'In Review',
    priority: 'High',
    dueDate: 'Nov 19, 2026',
    progress: 92,
  },
  {
    id: 'PM-102',
    title: 'Knowledge Hub Markdown Indexing Pipeline',
    workstream: "Murat Krhl's WorkSpace",
    status: 'Active',
    priority: 'Normal',
    dueDate: 'Dec 02, 2026',
    progress: 60,
  },
  {
    id: 'PM-101',
    title: 'WebAudio Worklet Parameter Buffer Bridge',
    workstream: 'Volt-8 Sound Engine',
    status: 'Shipped',
    priority: 'Normal',
    dueDate: 'Oct 28, 2026',
    progress: 100,
  },
];

export interface KnowledgeNote {
  id: string;
  title: string;
  topic: 'Architecture' | 'CSS & UI' | 'TypeScript' | 'Workflow';
  updatedAt: string;
  summary: string;
  snippetLanguage: string;
  snippet: string;
  takeaways: string[];
}

export const KNOWLEDGE_HUB_NOTES: KnowledgeNote[] = [
  {
    id: 'kh-dark-variant',
    title: 'Tailwind v4 Explicit Dark Mode Variant Pattern',
    topic: 'CSS & UI',
    updatedAt: 'Nov 2026',
    summary:
      'Prevent split-brain light/dark mismatches by declaring @custom-variant dark right after @import "tailwindcss" and pairing surface/border tokens.',
    snippetLanguage: 'css',
    snippet: `@import "tailwindcss";
@custom-variant dark (&:where(.dark, .dark *));

/* Always pair surface + border + ink */
.card-shell {
  @apply bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800;
}`,
    takeaways: [
      'Avoid !important global inversion overrides.',
      'Keep dark surface steps within 8–12% luminance delta.',
      'Verify focus rings remain >= 3:1 against dark surfaces.',
    ],
  },
  {
    id: 'kh-discriminated-routes',
    title: 'Type-Safe Client Routing with Discriminated Unions',
    topic: 'TypeScript',
    updatedAt: 'Nov 2026',
    summary:
      'Model multipage application state as an explicit discriminated union so route parameters like slug are always narrowed by TypeScript.',
    snippetLanguage: 'ts',
    snippet: `export type AppRoute =
  | { page: 'home' }
  | { page: 'quick-access' }
  | { page: 'project'; slug: string }
  | { page: 'knowledge-hub' };`,
    takeaways: [
      'Zero runtime router overhead for focused portfolios.',
      'Guaranteed exhaustiveness checking in render switches.',
      'Synchronizes cleanly with History.pushState and popstate.',
    ],
  },
  {
    id: 'kh-compositor-motion',
    title: 'Sub-200ms Compositor-Only Interaction Budget',
    topic: 'Architecture',
    updatedAt: 'Oct 2026',
    summary:
      'Restrict interactive hover and tab transitions to transform and opacity to avoid main-thread layout recalculations on every frame.',
    snippetLanguage: 'css',
    snippet: `@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    transition-duration: 0.01ms !important;
    animation-duration: 0.01ms !important;
  }
}`,
    takeaways: [
      'Target 150–200ms ease-out for routine UI transitions.',
      'Never animate width, height, margin, or top on hover.',
      'Respect OS prefers-reduced-motion automatically.',
    ],
  },
  {
    id: 'kh-git-worktrees',
    title: 'Parallel Feature Verification with Git Worktrees',
    topic: 'Workflow',
    updatedAt: 'Oct 2026',
    summary:
      'Keep main clean for rapid hotfixes and visual checks while isolating experimental architecture refactors in parallel worktree directories.',
    snippetLanguage: 'bash',
    snippet: `git worktree add ../workspace-audit main
git worktree list
git worktree remove ../workspace-audit`,
    takeaways: [
      'Eliminates stash-and-pop mistakes during reviews.',
      'Shares the underlying Git object store with minimal disk cost.',
    ],
  },
];

