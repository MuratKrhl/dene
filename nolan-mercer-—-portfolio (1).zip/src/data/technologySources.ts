import { TechSettings, TechSource } from '../types/technology';

export const TECH_SCHEMA_VERSION = 1;

export const DEFAULT_TECH_SETTINGS: TechSettings = {
  schemaVersion: TECH_SCHEMA_VERSION,
  globalAutoSync: true,
  defaultSyncIntervalHours: 3,
  activeWindowDays: 30,
  requestTimeoutMs: 20_000,
  retryCount: 1,
  lastGlobalSyncAt: null,
  lastSuccessfulSyncAt: null,
};

const NOW_ISO = '2026-11-19T00:00:00.000Z';

function makeSource(
  partial: Omit<
    TechSource,
    | 'lastFetchedAt'
    | 'lastSuccessfulFetchAt'
    | 'nextFetchAt'
    | 'consecutiveFailures'
    | 'itemCount'
    | 'createdAt'
    | 'updatedAt'
  >
): TechSource {
  return {
    ...partial,
    lastFetchedAt: null,
    lastSuccessfulFetchAt: null,
    nextFetchAt: null,
    consecutiveFailures: 0,
    itemCount: 0,
    createdAt: NOW_ISO,
    updatedAt: NOW_ISO,
  };
}

export const INITIAL_TECH_SOURCES: TechSource[] = [
  // =========================================================================
  // 1. VIDEOS (YouTube channels via API/Atom + Red Hat TV honest unsupported)
  // =========================================================================
  makeSource({
    id: 'vid-redhat-youtube',
    name: 'Red Hat YouTube',
    description:
      'Official Red Hat engineering talks, OpenShift demos, Ansible automation, and enterprise Linux sessions.',
    websiteUrl: 'https://www.youtube.com/@RedHat',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UCp6NUFV9mSEK6RxUiEVymVg',
    channelId: 'UCp6NUFV9mSEK6RxUiEVymVg',
    sourceType: 'youtube-api',
    contentType: 'video',
    category: 'Red Hat',
    tags: ['red-hat', 'openshift', 'ansible', 'rhel', 'linux'],
    enabled: true,
    syncInterval: 360, // 6h quota-friendly interval for video channels
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'vid-redhat-tv',
    name: 'Red Hat TV',
    description:
      'Red Hat live engineering streams, developer shows, and summit replays on tv.redhat.com.',
    websiteUrl: 'https://tv.redhat.com/',
    feedUrl: '',
    sourceType: 'unsupported',
    contentType: 'video',
    category: 'Red Hat',
    tags: ['red-hat', 'openshift', 'streaming', 'portal'],
    enabled: false,
    syncInterval: 0,
    status: 'unsupported',
    errorMessage:
      'Red Hat TV (tv.redhat.com) does not expose a public RSS, Atom, or official API feed. Use the portal link or add videos manually.',
  }),
  makeSource({
    id: 'vid-cncf-youtube',
    name: 'CNCF YouTube',
    description:
      'Cloud Native Computing Foundation talks, KubeCon keynotes, and cloud-native project updates.',
    websiteUrl: 'https://www.youtube.com/@cncf',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UCvqbFHwN-nwalWPjPUKpvTA',
    channelId: 'UCvqbFHwN-nwalWPjPUKpvTA',
    sourceType: 'youtube-api',
    contentType: 'video',
    category: 'Kubernetes',
    tags: ['cncf', 'kubernetes', 'cloud-native', 'containers'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'vid-k8s-community',
    name: 'Kubernetes Community',
    description:
      'Official Kubernetes SIG meetings, contributor briefings, and release walkthroughs.',
    websiteUrl: 'https://www.youtube.com/@KubernetesCommunity',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UCZ2bu0qutTOM0tHYa_jkIwg',
    channelId: 'UCZ2bu0qutTOM0tHYa_jkIwg',
    sourceType: 'youtube-api',
    contentType: 'video',
    category: 'Kubernetes',
    tags: ['kubernetes', 'sig', 'community', 'orchestration'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'vid-aws-developers',
    name: 'AWS Developers',
    description:
      'AWS architecture deep dives, EKS/ECS container engineering, serverless patterns, and developer tooling.',
    websiteUrl: 'https://www.youtube.com/@AWSDevelopers',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UCT-nPlVzJI-ccQXlxjSvJmw',
    channelId: 'UCT-nPlVzJI-ccQXlxjSvJmw',
    sourceType: 'youtube-api',
    contentType: 'video',
    category: 'AWS',
    tags: ['aws', 'cloud', 'containers', 'devops'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'vid-gcp-tech',
    name: 'Google Cloud Tech',
    description:
      'Google Cloud architecture, GKE, Vertex AI, distributed systems, and platform engineering videos.',
    websiteUrl: 'https://www.youtube.com/@GoogleCloudTech',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UCJS9pqu9BzkAMNTmzNMNhvg',
    channelId: 'UCJS9pqu9BzkAMNTmzNMNhvg',
    sourceType: 'youtube-api',
    contentType: 'video',
    category: 'Google Cloud',
    tags: ['google-cloud', 'gke', 'kubernetes', 'ai'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'vid-github-youtube',
    name: 'GitHub YouTube',
    description:
      'GitHub Actions, Copilot engineering, security workflows, and open-source ecosystem briefings.',
    websiteUrl: 'https://www.youtube.com/@GitHub',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UC7c3Kb6jYCRj4JOHHZTxKsQ',
    channelId: 'UC7c3Kb6jYCRj4JOHHZTxKsQ',
    sourceType: 'youtube-api',
    contentType: 'video',
    category: 'Development',
    tags: ['github', 'devops', 'ci-cd', 'engineering'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'vid-cloudflare-youtube',
    name: 'Cloudflare YouTube',
    description:
      'Edge networking, Cloudflare Workers, Zero Trust security, and global infrastructure talks.',
    websiteUrl: 'https://www.youtube.com/@Cloudflare',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UCgv3xMy6kECn0boYP9d2o-g',
    channelId: 'UCgv3xMy6kECn0boYP9d2o-g',
    sourceType: 'youtube-api',
    contentType: 'video',
    category: 'Networking',
    tags: ['cloudflare', 'networking', 'security', 'edge'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'vid-openai-youtube',
    name: 'OpenAI YouTube',
    description:
      'OpenAI model releases, engineering demos, developer API updates, and research briefings.',
    websiteUrl: 'https://www.youtube.com/@OpenAI',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UCXZCJLdBC09xxGZ6gcdrc6A',
    channelId: 'UCXZCJLdBC09xxGZ6gcdrc6A',
    sourceType: 'youtube-api',
    contentType: 'video',
    category: 'AI',
    tags: ['openai', 'ai', 'llm', 'research'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'vid-anthropic-youtube',
    name: 'Anthropic YouTube',
    description:
      'Anthropic research talks, Claude engineering workflows, safety evaluations, and agent patterns.',
    websiteUrl: 'https://www.youtube.com/@anthropic-ai',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UCrDwWp7EBBv4NwvScIpBDOA',
    channelId: 'UCrDwWp7EBBv4NwvScIpBDOA',
    sourceType: 'youtube-api',
    contentType: 'video',
    category: 'AI',
    tags: ['anthropic', 'ai', 'safety', 'engineering'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),

  // =========================================================================
  // 2. PODCASTS (All live-verified RSS 2.0 + audio enclosure feeds)
  // =========================================================================
  makeSource({
    id: 'pod-kubernetes-podcast',
    name: 'Kubernetes Podcast from Google',
    description:
      'Weekly interviews and news from the Kubernetes and cloud-native open-source ecosystem.',
    websiteUrl: 'https://kubernetespodcast.com/',
    feedUrl: 'https://kubernetespodcast.com/feeds/audio.xml',
    sourceType: 'rss',
    contentType: 'podcast',
    category: 'Kubernetes',
    tags: ['kubernetes', 'cncf', 'containers', 'cloud-native'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'pod-aws-podcast',
    name: 'AWS Podcast',
    description:
      'The official AWS Podcast covering cloud architecture, containers, security, and AWS launches.',
    websiteUrl: 'https://aws.amazon.com/podcasts/aws-podcast/',
    feedUrl: 'https://d3gih7jbfe3jlq.cloudfront.net/aws-podcast.rss',
    sourceType: 'rss',
    contentType: 'podcast',
    category: 'AWS',
    tags: ['aws', 'cloud', 'infrastructure', 'devops'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'pod-changelog',
    name: 'The Changelog',
    description:
      'Conversations with the hackers, leaders, and innovators of open-source software.',
    websiteUrl: 'https://changelog.com/podcast',
    feedUrl: 'https://changelog.com/podcast/feed',
    sourceType: 'rss',
    contentType: 'podcast',
    category: 'Engineering',
    tags: ['open-source', 'engineering', 'software', 'architecture'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'pod-se-daily',
    name: 'Software Engineering Daily',
    description:
      'Technical interviews about software architecture, distributed systems, AI, and cloud platforms.',
    websiteUrl: 'https://softwareengineeringdaily.com/',
    feedUrl: 'https://softwareengineeringdaily.com/feed/podcast/',
    sourceType: 'rss',
    contentType: 'podcast',
    category: 'Architecture',
    tags: ['architecture', 'distributed-systems', 'engineering', 'ai'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'pod-redhat-compiler',
    name: 'Compiler (Red Hat)',
    description:
      'Red Hat podcast answering curious questions about software, open-source infrastructure, and engineering.',
    websiteUrl: 'https://www.redhat.com/en/compiler-podcast',
    feedUrl: 'https://feeds.simplecast.com/Ynq4lw9w',
    sourceType: 'rss',
    contentType: 'podcast',
    category: 'Red Hat',
    tags: ['red-hat', 'open-source', 'linux', 'engineering'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'pod-se-radio',
    name: 'Software Engineering Radio',
    description:
      'In-depth educational episodes for professional software engineers and architects.',
    websiteUrl: 'https://se-radio.net/',
    feedUrl: 'https://seradio.libsyn.com/rss',
    sourceType: 'rss',
    contentType: 'podcast',
    category: 'Systems',
    tags: ['systems', 'architecture', 'testing', 'distributed-systems'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),

  // =========================================================================
  // 3. LEARNING & LABS
  // =========================================================================
  makeSource({
    id: 'learn-freecodecamp',
    name: 'freeCodeCamp',
    description:
      'Long-form tutorials, courses, and developer handbooks covering Linux, DevOps, Java, TypeScript, and AI.',
    websiteUrl: 'https://www.freecodecamp.org/news/',
    feedUrl: 'https://www.freecodecamp.org/news/rss/',
    sourceType: 'rss',
    contentType: 'learning',
    category: 'Tutorials',
    tags: ['tutorials', 'courses', 'development', 'devops'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'learn-kodekloud',
    name: 'KodeKloud',
    description:
      'Kubernetes, Terraform, Docker, DevOps, and cloud certification guides and hands-on tutorials.',
    websiteUrl: 'https://kodekloud.com/blog/',
    feedUrl: 'https://kodekloud.com/blog/rss/',
    sourceType: 'rss',
    contentType: 'learning',
    category: 'Kubernetes & DevOps',
    tags: ['kubernetes', 'devops', 'labs', 'certification'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'learn-techworld-nana',
    name: 'TechWorld with Nana',
    description:
      'Structured DevOps, Kubernetes, CI/CD, Docker, and cloud engineering courses and walkthroughs.',
    websiteUrl: 'https://www.youtube.com/@TechWorldwithNana',
    feedUrl:
      'https://www.youtube.com/feeds/videos.xml?channel_id=UCdngmbVKX1Tgre699-XLlUA',
    channelId: 'UCdngmbVKX1Tgre699-XLlUA',
    sourceType: 'atom',
    contentType: 'learning',
    category: 'Courses',
    tags: ['devops', 'kubernetes', 'courses', 'docker'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'learn-redhat-training',
    name: 'Red Hat Learning',
    description:
      'Official Red Hat Enterprise Linux, OpenShift, JBoss EAP, and Ansible training paths & certifications.',
    websiteUrl: 'https://www.redhat.com/en/services/training-and-certification',
    feedUrl: '',
    sourceType: 'unsupported',
    contentType: 'learning',
    category: 'Red Hat',
    tags: ['red-hat', 'learning-path', 'certification', 'openshift'],
    enabled: false,
    syncInterval: 0,
    status: 'unsupported',
    errorMessage:
      'Red Hat Learning does not publish a public RSS/API catalog endpoint. Open the portal link or add courses manually.',
  }),
  makeSource({
    id: 'learn-killercoda',
    name: 'Killercoda',
    description:
      'Interactive browser-based Kubernetes, Linux, and CKA/CKAD hands-on lab environments.',
    websiteUrl: 'https://killercoda.com/',
    feedUrl: '',
    sourceType: 'unsupported',
    contentType: 'learning',
    category: 'Labs',
    tags: ['labs', 'kubernetes', 'linux', 'interactive'],
    enabled: false,
    syncInterval: 0,
    status: 'unsupported',
    errorMessage:
      'Killercoda does not publish a public RSS or scenario API. Launch labs via the portal link or log labs manually.',
  }),

  // =========================================================================
  // 4. SECURITY INTELLIGENCE (Official APIs + Feeds)
  // =========================================================================
  makeSource({
    id: 'sec-nvd-cve',
    name: 'NVD CVE API 2.0',
    description:
      'Official NIST National Vulnerability Database structured CVE records with CVSS scores and CPEs.',
    websiteUrl: 'https://nvd.nist.gov/',
    feedUrl:
      'https://services.nvd.nist.gov/rest/json/cves/2.0?resultsPerPage=20',
    sourceType: 'official-api',
    contentType: 'security',
    category: 'CVE',
    tags: ['cve', 'nvd', 'cvss', 'vulnerability'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'sec-cisa-kev',
    name: 'CISA Known Exploited Vulnerabilities',
    description:
      'Official CISA KEV catalog of actively exploited CVEs and remediation due dates.',
    websiteUrl: 'https://www.cisa.gov/known-exploited-vulnerabilities-catalog',
    feedUrl:
      'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json',
    sourceType: 'official-api',
    contentType: 'security',
    category: 'Exploit',
    tags: ['cisa', 'kev', 'exploit', 'cve'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'sec-cisa-advisories',
    name: 'CISA Cybersecurity Advisories',
    description:
      'Official CISA ICS advisories, alerts, and critical infrastructure mitigation guidance.',
    websiteUrl: 'https://www.cisa.gov/news-events/cybersecurity-advisories',
    feedUrl: 'https://www.cisa.gov/cybersecurity-advisories/all.xml',
    sourceType: 'rss',
    contentType: 'security',
    category: 'Security Advisory',
    tags: ['cisa', 'advisory', 'mitigation', 'critical-infrastructure'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'sec-redhat-security-api',
    name: 'Red Hat Security Advisories & CVEs',
    description:
      'Official Red Hat Security Data API tracking Enterprise Linux, OpenShift, and JBoss CVEs.',
    websiteUrl: 'https://access.redhat.com/security/security-updates/cve',
    feedUrl: 'https://access.redhat.com/hydra/rest/securitydata/cve.json?per_page=20',
    sourceType: 'official-api',
    contentType: 'security',
    category: 'Red Hat Security',
    tags: ['red-hat', 'cve', 'advisory', 'rhel'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'sec-the-hacker-news',
    name: 'The Hacker News',
    description:
      'Daily vulnerability disclosures, zero-day research, malware campaigns, and threat intelligence.',
    websiteUrl: 'https://thehackernews.com/',
    feedUrl: 'https://feeds.feedburner.com/TheHackersNews',
    sourceType: 'rss',
    contentType: 'security',
    category: 'Vulnerability News',
    tags: ['vulnerability', 'malware', 'threat-intel', 'zero-day'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'sec-bleepingcomputer',
    name: 'BleepingComputer',
    description:
      'Breaking security patches, ransomware analysis, enterprise software flaws, and CVEs.',
    websiteUrl: 'https://www.bleepingcomputer.com/',
    feedUrl: 'https://www.bleepingcomputer.com/feed/',
    sourceType: 'rss',
    contentType: 'security',
    category: 'Malware & Patches',
    tags: ['ransomware', 'patches', 'security', 'malware'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'sec-securityweek',
    name: 'SecurityWeek',
    description:
      'Enterprise vulnerability advisories, cloud security architecture, and ICS security reporting.',
    websiteUrl: 'https://www.securityweek.com/',
    feedUrl: 'https://www.securityweek.com/feed/',
    sourceType: 'rss',
    contentType: 'security',
    category: 'Security Research',
    tags: ['enterprise-security', 'ics', 'research', 'advisory'],
    enabled: true,
    syncInterval: 180,
    status: 'idle',
    errorMessage: null,
  }),

  // =========================================================================
  // 5. EVENTS (Official RSS feeds + Manual/Unsupported Portals — Zero Fake Dates)
  // =========================================================================
  makeSource({
    id: 'evt-linux-foundation',
    name: 'Linux Foundation Events',
    description:
      'Official Linux Foundation technical summits, open-source conferences, and webinar announcements.',
    websiteUrl: 'https://events.linuxfoundation.org/',
    feedUrl: 'https://events.linuxfoundation.org/feed/',
    sourceType: 'rss',
    contentType: 'event',
    category: 'Conferences',
    tags: ['linux-foundation', 'conference', 'open-source', 'summit'],
    enabled: true,
    syncInterval: 360,
    status: 'idle',
    errorMessage: null,
  }),
  makeSource({
    id: 'evt-kubecon',
    name: 'KubeCon + CloudNativeCon',
    description:
      'Official KubeCon + CloudNativeCon portal for CNCF flagship cloud-native conferences. Add verified sessions manually or browse the portal.',
    websiteUrl: 'https://events.linuxfoundation.org/kubecon-cloudnativecon-europe/',
    feedUrl: '',
    sourceType: 'manual',
    contentType: 'event',
    category: 'Conferences',
    tags: ['kubecon', 'cncf', 'kubernetes', 'conference'],
    enabled: false,
    syncInterval: 0,
    status: 'unsupported',
    errorMessage:
      'KubeCon page feed only exposes empty WordPress comments RSS. Open the official portal or add verified conference dates manually.',
  }),
  makeSource({
    id: 'evt-redhat-summit',
    name: 'Red Hat Summit',
    description:
      'Official Red Hat Summit conference portal. Official /en/rss/events feed currently returns 0 items; track manually or via portal.',
    websiteUrl: 'https://www.redhat.com/en/summit',
    feedUrl: '',
    sourceType: 'manual',
    contentType: 'event',
    category: 'Summits',
    tags: ['red-hat', 'summit', 'openshift', 'enterprise'],
    enabled: false,
    syncInterval: 0,
    status: 'unsupported',
    errorMessage:
      'Red Hat Summit does not publish active upcoming dates via RSS (/en/rss/events is empty). Add verified events manually or visit the portal.',
  }),
  makeSource({
    id: 'evt-aws-reinvent',
    name: 'AWS re:Invent',
    description:
      'Official AWS re:Invent cloud conference portal. Add verified dates and session registrations manually.',
    websiteUrl: 'https://reinvent.awsevents.com/',
    feedUrl: '',
    sourceType: 'manual',
    contentType: 'event',
    category: 'Conferences',
    tags: ['aws', 'reinvent', 'cloud', 'conference'],
    enabled: false,
    syncInterval: 0,
    status: 'unsupported',
    errorMessage:
      'AWS re:Invent portal does not expose a structured RSS/ICS event feed. Visit portal or add verified dates manually.',
  }),
  makeSource({
    id: 'evt-google-cloud-next',
    name: 'Google Cloud Next',
    description:
      'Official Google Cloud Next flagship event portal. Add verified dates and webinar sessions manually.',
    websiteUrl: 'https://cloud.withgoogle.com/next',
    feedUrl: '',
    sourceType: 'manual',
    contentType: 'event',
    category: 'Conferences',
    tags: ['google-cloud', 'next', 'cloud', 'ai'],
    enabled: false,
    syncInterval: 0,
    status: 'unsupported',
    errorMessage:
      'Google Cloud Next does not expose a public RSS/API schedule feed. Visit portal or add verified dates manually.',
  }),
];
