export type ProjectManagementTabKey =
  | 'bulgu-takip'
  | 'jboss-8-migration'
  | 'provenir-migration';

export type PmPriority = 'High' | 'Medium' | 'Low';
export type PmStatus = 'In Progress' | 'In Review' | 'Completed' | 'Overdue';

export interface PmTabConfig {
  key: ProjectManagementTabKey;
  label: string;
  description: string;
  trendTotal: string;
  trendProgress: string;
  trendCompleted: string;
  trendOverdue: string;
}

export interface PmWorkstreamFolder {
  id: string;
  tab: ProjectManagementTabKey;
  title: string;
  accent: 'cobalt' | 'emerald' | 'slate';
  owners: string[];
  deadline: string;
  taskCount: number;
  progress: number;
}

export interface PmScheduleItem {
  id: string;
  tab: ProjectManagementTabKey;
  dateLabel: string;
  title: string;
  owner: string;
  env: string;
  done: boolean;
}

export interface PmTaskRow {
  id: string;
  tab: ProjectManagementTabKey;
  workstreamId: string;
  name: string;
  dateRange: string;
  priority: PmPriority;
  tag: string;
  status: PmStatus;
  assignee: string;
}

export const PM_TABS: PmTabConfig[] = [
  {
    key: 'bulgu-takip',
    label: 'Bulgu Takip',
    description:
      'Audit findings, security remediation actions, SLA due dates, and closure verification across enterprise systems.',
    trendTotal: '+6% vs last month',
    trendProgress: '+4% vs last month',
    trendCompleted: '+11% vs last month',
    trendOverdue: '-2% vs last month',
  },
  {
    key: 'jboss-8-migration',
    label: 'JBOSS 8 Migration',
    description:
      'JBoss EAP 7.4 to EAP 8 (Jakarta EE 10) namespace migration, Elytron security realms, and OpenShift rollout tracking.',
    trendTotal: '+9% vs last month',
    trendProgress: '+5% vs last month',
    trendCompleted: '+14% vs last month',
    trendOverdue: '-3% vs last month',
  },
  {
    key: 'provenir-migration',
    label: 'Provenir Migration',
    description:
      'Provenir 8.7 runtime upgrade, credit scoring ruleflow validation, KKB/Findeks adapter parity, and UAT shadow runs.',
    trendTotal: '+5% vs last month',
    trendProgress: '+3% vs last month',
    trendCompleted: '+8% vs last month',
    trendOverdue: '-1% vs last month',
  },
];

export const INITIAL_PM_FOLDERS: PmWorkstreamFolder[] = [
  // Bulgu Takip
  {
    id: 'ws-bt-1',
    tab: 'bulgu-takip',
    title: 'BDDK & İç Denetim Bulguları',
    accent: 'cobalt',
    owners: ['MK', 'EA', 'SK'],
    deadline: '12 Dec, 2026',
    taskCount: 8,
    progress: 68,
  },
  {
    id: 'ws-bt-2',
    tab: 'bulgu-takip',
    title: 'Pentest & WAF Zafiyet Kapama',
    accent: 'emerald',
    owners: ['MK', 'NS'],
    deadline: '28 Nov, 2026',
    taskCount: 6,
    progress: 54,
  },
  {
    id: 'ws-bt-3',
    tab: 'bulgu-takip',
    title: 'Middleware TLS & Erişim Bulguları',
    accent: 'slate',
    owners: ['MK', 'DO'],
    deadline: '20 Dec, 2026',
    taskCount: 5,
    progress: 40,
  },

  // JBOSS 8 Migration
  {
    id: 'ws-jb-1',
    tab: 'jboss-8-migration',
    title: 'Jakarta EE 10 Namespace Dönüşümü',
    accent: 'cobalt',
    owners: ['MK', 'AT'],
    deadline: '18 Dec, 2026',
    taskCount: 9,
    progress: 72,
  },
  {
    id: 'ws-jb-2',
    tab: 'jboss-8-migration',
    title: 'EAP 8 Elytron & Datasource Config',
    accent: 'emerald',
    owners: ['MK', 'BK'],
    deadline: '05 Jan, 2027',
    taskCount: 7,
    progress: 48,
  },
  {
    id: 'ws-jb-3',
    tab: 'jboss-8-migration',
    title: 'OpenShift EAP 8 Container Rollout',
    accent: 'slate',
    owners: ['MK', 'SR'],
    deadline: '22 Jan, 2027',
    taskCount: 6,
    progress: 25,
  },

  // Provenir Migration
  {
    id: 'ws-pv-1',
    tab: 'provenir-migration',
    title: 'Provenir 8.7 Engine Upgrade',
    accent: 'cobalt',
    owners: ['MK', 'CR'],
    deadline: '15 Dec, 2026',
    taskCount: 7,
    progress: 64,
  },
  {
    id: 'ws-pv-2',
    tab: 'provenir-migration',
    title: 'Bureau Adapter & SOAP/REST Parity',
    accent: 'emerald',
    owners: ['MK', 'RA'],
    deadline: '08 Jan, 2027',
    taskCount: 6,
    progress: 45,
  },
  {
    id: 'ws-pv-3',
    tab: 'provenir-migration',
    title: 'UAT Regression & Shadow Traffic',
    accent: 'slate',
    owners: ['MK', 'QA'],
    deadline: '25 Jan, 2027',
    taskCount: 5,
    progress: 30,
  },
];

export const INITIAL_PM_SCHEDULE: PmScheduleItem[] = [
  // Bulgu Takip
  {
    id: 'sch-bt-1',
    tab: 'bulgu-takip',
    dateLabel: '18 Nov',
    title: 'mTLS CA Intermediate Yenileme Kanıtı',
    owner: 'Network Security',
    env: 'Prod',
    done: false,
  },
  {
    id: 'sch-bt-2',
    tab: 'bulgu-takip',
    dateLabel: '24 Nov',
    title: 'RHEL 9.3 Kernel Patch & Denetim Kapanışı',
    owner: 'DBA Core',
    env: 'Prod',
    done: false,
  },
  {
    id: 'sch-bt-3',
    tab: 'bulgu-takip',
    dateLabel: '28 Nov',
    title: 'WAF Rate-Limit & Header Hardening Onayı',
    owner: 'AppSec',
    env: 'DMZ',
    done: true,
  },
  {
    id: 'sch-bt-4',
    tab: 'bulgu-takip',
    dateLabel: '12 Dec',
    title: 'Q4 BDDK Bulgu Kapanış Raporu Sunumu',
    owner: 'Murat Krhl',
    env: 'Audit',
    done: false,
  },

  // JBOSS 8 Migration
  {
    id: 'sch-jb-1',
    tab: 'jboss-8-migration',
    dateLabel: '21 Nov',
    title: 'javax.* -> jakarta.* Bytecode Tarama Raporu',
    owner: 'Core Java',
    env: 'UAT',
    done: true,
  },
  {
    id: 'sch-jb-2',
    tab: 'jboss-8-migration',
    dateLabel: '30 Nov',
    title: 'Elytron LDAP/Kerberos Credential Store Testi',
    owner: 'Middleware Ops',
    env: 'UAT',
    done: false,
  },
  {
    id: 'sch-jb-3',
    tab: 'jboss-8-migration',
    dateLabel: '14 Dec',
    title: 'OpenShift EAP 8 Helm Chart Load Test',
    owner: 'Platform SRE',
    env: 'Pre-Prod',
    done: false,
  },
  {
    id: 'sch-jb-4',
    tab: 'jboss-8-migration',
    dateLabel: '05 Jan',
    title: 'Credit Gateway Canary Cutover Window',
    owner: 'Murat Krhl',
    env: 'Prod',
    done: false,
  },

  // Provenir Migration
  {
    id: 'sch-pv-1',
    tab: 'provenir-migration',
    dateLabel: '25 Nov',
    title: 'KKB & Findeks mTLS Cert Rotation',
    owner: 'Credit Tech',
    env: 'Prod',
    done: false,
  },
  {
    id: 'sch-pv-2',
    tab: 'provenir-migration',
    dateLabel: '03 Dec',
    title: 'Provenir 8.7 UAT Studio Ruleflow Import',
    owner: 'Decisioning Ops',
    env: 'UAT',
    done: true,
  },
  {
    id: 'sch-pv-3',
    tab: 'provenir-migration',
    dateLabel: '15 Dec',
    title: 'Shadow Replay 100k Application Diff Check',
    owner: 'Risk Analytics',
    env: 'Pre-Prod',
    done: false,
  },
  {
    id: 'sch-pv-4',
    tab: 'provenir-migration',
    dateLabel: '12 Jan',
    title: 'Production Blue/Green Switchover Dry Run',
    owner: 'Murat Krhl',
    env: 'Prod',
    done: false,
  },
];

export const INITIAL_PM_TASKS: PmTaskRow[] = [
  // Bulgu Takip
  {
    id: 'bt-01',
    tab: 'bulgu-takip',
    workstreamId: 'ws-bt-3',
    name: 'mtls-partner-gateway CA bundle ara sertifika yenilemesi',
    dateRange: '05 Nov - 18 Nov',
    priority: 'High',
    tag: 'TLS / Security',
    status: 'Overdue',
    assignee: 'MK',
  },
  {
    id: 'bt-02',
    tab: 'bulgu-takip',
    workstreamId: 'ws-bt-1',
    name: 'Kredi karar servisi log maskeleme (TCKN/IBAN) doğrulaması',
    dateRange: '08 Nov - 24 Nov',
    priority: 'High',
    tag: 'BDDK Audit',
    status: 'In Progress',
    assignee: 'EA',
  },
  {
    id: 'bt-03',
    tab: 'bulgu-takip',
    workstreamId: 'ws-bt-2',
    name: 'Edge gateway CSP & HSTS header eksikliği giderimi',
    dateRange: '10 Nov - 22 Nov',
    priority: 'Medium',
    tag: 'WAF / AppSec',
    status: 'In Review',
    assignee: 'NS',
  },
  {
    id: 'bt-04',
    tab: 'bulgu-takip',
    workstreamId: 'ws-bt-1',
    name: 'Ayrıcalıklı SSH & Bastion MFA oturum kayıt denetimi',
    dateRange: '02 Nov - 15 Nov',
    priority: 'High',
    tag: 'IAM / PAM',
    status: 'Completed',
    assignee: 'SK',
  },
  {
    id: 'bt-05',
    tab: 'bulgu-takip',
    workstreamId: 'ws-bt-2',
    name: 'OpenShift Ingress TLS 1.1 legacy cipher kapatma aksiyonu',
    dateRange: '12 Nov - 29 Nov',
    priority: 'Medium',
    tag: 'Network Sec',
    status: 'Completed',
    assignee: 'MK',
  },
  {
    id: 'bt-06',
    tab: 'bulgu-takip',
    workstreamId: 'ws-bt-3',
    name: 'DR gateway RHEL 9.2 minor sürüm ve kernel güncellemesi',
    dateRange: '14 Nov - 02 Dec',
    priority: 'Low',
    tag: 'Patch Mgmt',
    status: 'In Progress',
    assignee: 'DO',
  },

  // JBOSS 8 Migration
  {
    id: 'jb-01',
    tab: 'jboss-8-migration',
    workstreamId: 'ws-jb-1',
    name: 'Credit Decision Gateway javax.persistence -> jakarta.persistence refactoring',
    dateRange: '04 Nov - 22 Nov',
    priority: 'High',
    tag: 'Jakarta EE 10',
    status: 'In Progress',
    assignee: 'MK',
  },
  {
    id: 'jb-02',
    tab: 'jboss-8-migration',
    workstreamId: 'ws-jb-2',
    name: 'WildFly Elytron security-domain ve vault credential migration',
    dateRange: '07 Nov - 27 Nov',
    priority: 'High',
    tag: 'Elytron',
    status: 'In Review',
    assignee: 'BK',
  },
  {
    id: 'jb-03',
    tab: 'jboss-8-migration',
    workstreamId: 'ws-jb-1',
    name: 'JBoss EAP 8 Server Migration Tool XML standalone-full.xml dönüşümü',
    dateRange: '01 Nov - 14 Nov',
    priority: 'Medium',
    tag: 'Config CLI',
    status: 'Completed',
    assignee: 'AT',
  },
  {
    id: 'jb-04',
    tab: 'jboss-8-migration',
    workstreamId: 'ws-jb-2',
    name: 'PostgreSQL JDBC XA Datasource & Hikari pool tuning (Java 21)',
    dateRange: '11 Nov - 03 Dec',
    priority: 'Medium',
    tag: 'Datasource',
    status: 'In Progress',
    assignee: 'MK',
  },
  {
    id: 'jb-05',
    tab: 'jboss-8-migration',
    workstreamId: 'ws-jb-3',
    name: 'EAP 8 OpenShift S2I base image & readiness probe güncellemesi',
    dateRange: '15 Nov - 12 Dec',
    priority: 'High',
    tag: 'OpenShift',
    status: 'In Progress',
    assignee: 'SR',
  },
  {
    id: 'jb-06',
    tab: 'jboss-8-migration',
    workstreamId: 'ws-jb-1',
    name: 'Legacy EJB 2.x remote lookup bağımlılıklarının REST adaptöre alınması',
    dateRange: '03 Nov - 17 Nov',
    priority: 'High',
    tag: 'Legacy EJB',
    status: 'Overdue',
    assignee: 'AT',
  },

  // Provenir Migration
  {
    id: 'pv-01',
    tab: 'provenir-migration',
    workstreamId: 'ws-pv-1',
    name: 'Provenir Runtime 8.6.4 -> 8.7.0 UAT node kurulumu ve lisans aktivasyonu',
    dateRange: '03 Nov - 18 Nov',
    priority: 'High',
    tag: 'Engine 8.7',
    status: 'Completed',
    assignee: 'MK',
  },
  {
    id: 'pv-02',
    tab: 'provenir-migration',
    workstreamId: 'ws-pv-2',
    name: 'KKB / Findeks SOAP & REST adapter şema uyumluluk testi',
    dateRange: '09 Nov - 26 Nov',
    priority: 'High',
    tag: 'Bureau Adapter',
    status: 'In Progress',
    assignee: 'RA',
  },
  {
    id: 'pv-03',
    tab: 'provenir-migration',
    workstreamId: 'ws-pv-1',
    name: 'Retail & SME kredi karar ağacı ruleflow paketlerinin import edilmesi',
    dateRange: '10 Nov - 29 Nov',
    priority: 'Medium',
    tag: 'Ruleflow',
    status: 'In Review',
    assignee: 'CR',
  },
  {
    id: 'pv-04',
    tab: 'provenir-migration',
    workstreamId: 'ws-pv-3',
    name: '90 günlük anonim başvuru verisiyle shadow karar karşılaştırma (diff < %0.01)',
    dateRange: '16 Nov - 10 Dec',
    priority: 'High',
    tag: 'Shadow UAT',
    status: 'In Progress',
    assignee: 'QA',
  },
  {
    id: 'pv-05',
    tab: 'provenir-migration',
    workstreamId: 'ws-pv-2',
    name: 'JVM GC ve 320+ TPS yük altında P95 latency benchmark testi',
    dateRange: '18 Nov - 14 Dec',
    priority: 'Low',
    tag: 'Performance',
    status: 'In Progress',
    assignee: 'MK',
  },
];
