export type ToolCategoryIconKey =
  | 'network'
  | 'openshift'
  | 'middleware'
  | 'decision'
  | 'security'
  | 'data';

export interface ToolSlotItem {
  id: string;
  name: string;
  scope: string;
  description: string;
  ioSpec: string;
}

export interface ToolCategoryConfig {
  id: string;
  label: string;
  description: string;
  icon: ToolCategoryIconKey;
  tools: ToolSlotItem[];
}

export const TOOL_CATEGORIES: ToolCategoryConfig[] = [
  {
    id: 'reverse-proxy-network',
    label: 'Reverse Proxy & Network',
    description:
      'Edge routing rules, TLS/mTLS certificate validation, upstream health policies, and HTTP header diagnostics.',
    icon: 'network',
    tools: [
      {
        id: 'tls-chain-inspector',
        name: 'TLS & mTLS Chain Inspector',
        scope: 'Edge Gateway',
        description:
          'Inspect X.509 leaf/intermediate chains, SAN entries, cipher suites, and certificate expiry windows.',
        ioSpec: 'PEM / Host -> Chain Report',
      },
      {
        id: 'upstream-config-validator',
        name: 'Nginx & HAProxy Config Validator',
        scope: 'Routing',
        description:
          'Validate upstream pool weights, sticky session directives, timeout budgets, and health check paths.',
        ioSpec: 'Conf Snippet -> Lint & Diff',
      },
      {
        id: 'http-header-analyzer',
        name: 'HTTP Security Header & CORS Checker',
        scope: 'DMZ / WAF',
        description:
          'Verify HSTS, CSP, X-Forwarded-* headers, and partner gateway CORS policies before Prod cutover.',
        ioSpec: 'Headers -> Compliance Audit',
      },
    ],
  },
  {
    id: 'openshift-containers',
    label: 'OpenShift & Containers',
    description:
      'OCP route manifests, pod resource quotas, probe templates, and cluster namespace capacity utilities.',
    icon: 'openshift',
    tools: [
      {
        id: 'ocp-route-builder',
        name: 'OpenShift Route & Ingress Builder',
        scope: 'OCP 4.x',
        description:
          'Generate edge, reencrypt, and passthrough Route YAML manifests with HAProxy timeout annotations.',
        ioSpec: 'Form Inputs -> Route YAML',
      },
      {
        id: 'pod-quota-calculator',
        name: 'Pod Resource & LimitRange Calculator',
        scope: 'Capacity',
        description:
          'Calculate CPU/Memory requests, burst ratios, and namespace quota allocation across worker nodes.',
        ioSpec: 'Replicas & Profile -> Quota Spec',
      },
      {
        id: 'probe-config-generator',
        name: 'Readiness & Liveness Probe Generator',
        scope: 'Workload Health',
        description:
          'Tune initialDelaySeconds, periodSeconds, and failureThreshold for JVM and Spring Boot services.',
        ioSpec: 'Boot Profile -> Probe YAML',
      },
    ],
  },
  {
    id: 'jboss-middleware',
    label: 'JBoss & Middleware',
    description:
      'JBoss EAP 8 migration helpers, Elytron security realm configs, Jakarta EE checks, and datasource pool tuning.',
    icon: 'middleware',
    tools: [
      {
        id: 'elytron-credential-helper',
        name: 'EAP 8 Elytron CLI & Credential Helper',
        scope: 'JBoss EAP 8',
        description:
          'Build jboss-cli batch commands for credential-store aliases, LDAP realms, and TLS key-managers.',
        ioSpec: 'Realm Params -> CLI Script',
      },
      {
        id: 'jakarta-namespace-checker',
        name: 'Jakarta EE 10 Namespace Mapper',
        scope: 'Migration',
        description:
          'Map legacy javax.* imports, deployment descriptors, and pom dependencies to Jakarta EE 10 targets.',
        ioSpec: 'Import / XML -> Jakarta Map',
      },
      {
        id: 'datasource-pool-tuner',
        name: 'JDBC & XA Datasource Pool Tuner',
        scope: 'Database Pool',
        description:
          'Model min/max-pool-size, prepared-statement cache, and validation timeouts for Oracle & PostgreSQL.',
        ioSpec: 'Concurrency -> Pool XML',
      },
    ],
  },
  {
    id: 'decision-engines',
    label: 'Decision Engines',
    description:
      'Provenir, Evam, and PowerCurve payload testers, ruleflow schema validators, and bureau adapter utilities.',
    icon: 'decision',
    tools: [
      {
        id: 'provenir-payload-tester',
        name: 'Provenir Ruleflow Payload Validator',
        scope: 'Provenir 8.7',
        description:
          'Validate credit decisioning request/response schemas and compare UAT vs Prod shadow replay diffs.',
        ioSpec: 'JSON / XML -> Schema Diff',
      },
      {
        id: 'evam-event-validator',
        name: 'Evam Event Stream Schema Tester',
        scope: 'Evam CEP',
        description:
          'Verify real-time scenario trigger payloads, Kafka topic keys, and customer event field mappings.',
        ioSpec: 'Event Payload -> CEP Check',
      },
      {
        id: 'powercurve-response-inspector',
        name: 'PowerCurve Strategy Trace Inspector',
        scope: 'Experian PC',
        description:
          'Parse scorecard decision reasons, bureau call latency segments, and strategy branch execution traces.',
        ioSpec: 'Trace XML -> Decision Tree',
      },
    ],
  },
  {
    id: 'security-audit',
    label: 'Security & Audit',
    description:
      'Token decoding, certificate format conversion, PII masking checks, and BDDK audit SLA tracking helpers.',
    icon: 'security',
    tools: [
      {
        id: 'jwt-oidc-decoder',
        name: 'JWT & OIDC Claims Inspector',
        scope: 'IAM / SSO',
        description:
          'Decode JWT headers, payload claims, role scopes, and expiration timestamps completely offline.',
        ioSpec: 'Bearer Token -> Claims JSON',
      },
      {
        id: 'pem-base64-converter',
        name: 'PEM / Base64 & Keystore Converter',
        scope: 'PKI',
        description:
          'Convert certificate blocks, inspect Base64-encoded Kubernetes secrets, and verify fingerprint hashes.',
        ioSpec: 'Base64 / PEM -> Decoded Key',
      },
      {
        id: 'log-pii-mask-tester',
        name: 'Log Masking & Regex Audit Tester',
        scope: 'BDDK Compliance',
        description:
          'Test log redaction patterns against sample TCKN, IBAN, and card PAN strings before deployment.',
        ioSpec: 'Log Sample -> Redacted Output',
      },
    ],
  },
  {
    id: 'data-encoding',
    label: 'Data & Encoding',
    description:
      'Configuration formatting, structural diff comparisons, and maintenance window cron schedule calculators.',
    icon: 'data',
    tools: [
      {
        id: 'config-schema-formatter',
        name: 'JSON / YAML / XML Formatter',
        scope: 'Config Files',
        description:
          'Format, validate, and convert between structured JSON, YAML, and standalone XML configuration blocks.',
        ioSpec: 'Raw Config -> Formatted Spec',
      },
      {
        id: 'env-config-diff',
        name: 'Environment Config Diff Viewer',
        scope: 'UAT / Prod',
        description:
          'Compare environment variables, JVM flags, and properties across UAT, Pre-Prod, and Prod clusters.',
        ioSpec: 'Env A + Env B -> Key Diff',
      },
      {
        id: 'cron-window-planner',
        name: 'Cron & Cutover Window Planner',
        scope: 'Batch / SRE',
        description:
          'Preview next execution timestamps and validate batch job cron expressions in Europe/Istanbul time.',
        ioSpec: 'Cron Expr -> Next Runs',
      },
    ],
  },
];
