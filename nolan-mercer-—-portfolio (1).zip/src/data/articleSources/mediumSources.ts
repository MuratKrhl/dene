import { INITIAL_MEDIUM_SOURCES } from '../mediumSources';
import { ArticleSource } from '../../types/articleSource';

export const MEDIUM_AGGREGATOR_SOURCES: ArticleSource[] =
  INITIAL_MEDIUM_SOURCES.map((src) => ({
    id: src.id,
    name: `Medium · ${src.name}`,
    description: `Medium RSS tag feed for #${src.tag} (max 10 latest articles per feed).`,
    websiteUrl: `https://medium.com/tag/${src.tag}`,
    feedUrl: src.rssUrl,
    sourceType: 'rss',
    sourceGroup: 'Medium',
    category: src.name,
    tags: [src.tag.toLowerCase(), src.name.toLowerCase(), 'medium'],
    defaultContentType: 'article',
    enabled: src.enabled,
    fetchInterval: 180,
    maxArticlesPerFetch: 10,
    lastFetchedAt: src.lastFetchedAt,
    lastSuccessfulFetchAt: src.lastSuccessfulFetchAt,
    status: src.status,
    errorMessage: src.errorMessage,
    lastArticleCount: src.lastArticleCount ?? 0,
  }));
