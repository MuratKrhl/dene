import {
  AggregationSyncConfig,
  ArticleSource,
  ArticleSourceGroup,
} from '../../types/articleSource';
import { AI_ARTICLE_SOURCES } from './aiSources';
import { MEDIUM_AGGREGATOR_SOURCES } from './mediumSources';
import { OFFICIAL_ARTICLE_SOURCES } from './officialSources';
import { SECURITY_ARTICLE_SOURCES } from './securitySources';

export const ARTICLE_SYNC_CONFIG_VERSION = 1;

export const DEFAULT_AGGREGATION_SYNC_CONFIG: AggregationSyncConfig = {
  configVersion: ARTICLE_SYNC_CONFIG_VERSION,
  autoSyncEnabled: true,
  autoSyncIntervalHours: 3,
  requestTimeoutMs: 20_000,
};

export const INITIAL_ARTICLE_SOURCES: ArticleSource[] = [
  ...MEDIUM_AGGREGATOR_SOURCES,
  ...OFFICIAL_ARTICLE_SOURCES,
  ...SECURITY_ARTICLE_SOURCES,
  ...AI_ARTICLE_SOURCES,
];

export const ARTICLE_SOURCE_FILTER_GROUPS: ArticleSourceGroup[] = [
  'Medium',
  'Red Hat',
  'Kubernetes',
  'AWS',
  'Cloudflare',
  'GitHub',
  'Security',
  'AI',
  'Java',
];

export {
  AI_ARTICLE_SOURCES,
  MEDIUM_AGGREGATOR_SOURCES,
  OFFICIAL_ARTICLE_SOURCES,
  SECURITY_ARTICLE_SOURCES,
};
