export type EnvironmentTabKey =
  | 'sunucu'
  | 'uygulama'
  | 'openshift'
  | 'reverse-proxy'
  | 'provenir'
  | 'evam'
  | 'powercurve';

export interface EnvironmentTabConfig {
  key: EnvironmentTabKey;
  label: string;
  description: string;
  capacitySummaryUnit: string;
  usageSublabel: string;
  expiryLabel: string;
  codePlaceholder: string;
}

export interface EnvironmentEntry {
  id: string;
  tab: EnvironmentTabKey;
  name: string;
  subtitle: string;
  code: string;
  env: 'Prod' | 'UAT' | 'Pre-Prod' | 'DR' | 'Test';
  status: 'Online' | 'Healthy' | 'Active' | 'Degraded' | 'Maintenance' | 'Standby';
  endpoint: string;
  capacity: string;
  capacityValue: number;
  usageOrLoad: string;
  version: string;
  expiryDate: string;
  alertLevel?: 'none' | 'warning' | 'critical';
  alertNote?: string;
  updatedAt: string;
  owner: string;
  regionOrCluster: string;
  notes?: string;
  isCustom?: boolean;
}

export const ENVIRONMENT_TABS: EnvironmentTabConfig[] = [
  {
    key: 'sunucu',
    label: 'Sunucu',
    description: 'Linux VM, bare-metal, and database hosts across Prod, UAT, and DR zones.',
    capacitySummaryUnit: 'vCPU',
    usageSublabel: '30d Avg CPU',
    expiryLabel: 'Patch / SLA',
    codePlaceholder: 'SRV-PRD-01',
  },
  {
    key: 'uygulama',
    label: 'Uygulama',
    description: 'Core banking microservices, batch workers, and integration APIs.',
    capacitySummaryUnit: 'Instances',
    usageSublabel: '24h Avg RPS',
    expiryLabel: 'Cert / SLA',
    codePlaceholder: 'APP-CRD-01',
  },
  {
    key: 'openshift',
    label: 'Openshift',
    description: 'Red Hat OpenShift clusters, namespaces, pod quotas, and ingress routes.',
    capacitySummaryUnit: 'Pods',
    usageSublabel: '30d Mem Load',
    expiryLabel: 'Token / Cert',
    codePlaceholder: 'OCP-PRD-01',
  },
  {
    key: 'reverse-proxy',
    label: 'Reverse Proxy',
    description: 'Edge Nginx, HAProxy, mTLS gateways, and upstream routing policies.',
    capacitySummaryUnit: 'Upstreams',
    usageSublabel: '24h Req/s',
    expiryLabel: 'TLS Expiry',
    codePlaceholder: 'RPX-EDG-01',
  },
  {
    key: 'provenir',
    label: 'Provenir',
    description: 'Provenir risk decisioning runtime nodes, rule flows, and bureau adapters.',
    capacitySummaryUnit: 'Workers',
    usageSublabel: '30d Peak TPS',
    expiryLabel: 'License / Rule',
    codePlaceholder: 'PRV-ENG-01',
  },
  {
    key: 'evam',
    label: 'Evam',
    description: 'Evam CEP real-time event streaming engines, Kafka bridges, and scenarios.',
    capacitySummaryUnit: 'Partitions',
    usageSublabel: '24h Evt/s',
    expiryLabel: 'License / Sync',
    codePlaceholder: 'EVM-CEP-01',
  },
  {
    key: 'powercurve',
    label: 'PowerCurve',
    description: 'Experian PowerCurve Strategy Manager, Originations, and scoring agents.',
    capacitySummaryUnit: 'Threads',
    usageSublabel: '30d Calls/m',
    expiryLabel: 'Rulepack / Cert',
    codePlaceholder: 'PWC-STR-01',
  },
];

export const INITIAL_ENVIRONMENT_ENTRIES: EnvironmentEntry[] = [
  // 1. SUNUCU
  {
    id: 'srv-01',
    tab: 'sunucu',
    name: 'prod-core-app01',
    subtitle: 'Primary middleware application host',
    code: 'SRV-PRD-01',
    env: 'Prod',
    status: 'Online',
    endpoint: '10.42.10.11:22',
    capacity: '32 vCPU / 128 GB',
    capacityValue: 32,
    usageOrLoad: '41%',
    version: 'RHEL 9.4',
    expiryDate: 'Dec 18, 2026',
    alertLevel: 'none',
    updatedAt: 'Nov 16, 2026',
    owner: 'Platform Infra',
    regionOrCluster: 'DC-IST-01 · VLAN 42',
    notes: 'Bonded 25GbE NICs, SELinux enforcing, node_exporter active.',
  },
  {
    id: 'srv-02',
    tab: 'sunucu',
    name: 'prod-core-app02',
    subtitle: 'Secondary middleware application host',
    code: 'SRV-PRD-02',
    env: 'Prod',
    status: 'Online',
    endpoint: '10.42.10.12:22',
    capacity: '32 vCPU / 128 GB',
    capacityValue: 32,
    usageOrLoad: '38%',
    version: 'RHEL 9.4',
    expiryDate: 'Dec 18, 2026',
    alertLevel: 'none',
    updatedAt: 'Nov 16, 2026',
    owner: 'Platform Infra',
    regionOrCluster: 'DC-IST-01 · VLAN 42',
    notes: 'Active-active pair with prod-core-app01.',
  },
  {
    id: 'srv-03',
    tab: 'sunucu',
    name: 'prod-db-replica01',
    subtitle: 'PostgreSQL synchronous read replica',
    code: 'SRV-PRD-03',
    env: 'Prod',
    status: 'Online',
    endpoint: '10.42.14.20:5432',
    capacity: '64 vCPU / 256 GB',
    capacityValue: 64,
    usageOrLoad: '67%',
    version: 'RHEL 9.3',
    expiryDate: 'Nov 24, 2026',
    alertLevel: 'warning',
    alertNote: 'Kernel security patch window scheduled Nov 24',
    updatedAt: 'Nov 15, 2026',
    owner: 'DBA Core',
    regionOrCluster: 'DC-IST-01 · VLAN 44',
    notes: 'NVMe RAID-10 storage pool, WAL archiving to S3 vault.',
  },
  {
    id: 'srv-04',
    tab: 'sunucu',
    name: 'uat-middleware-01',
    subtitle: 'UAT integration & regression host',
    code: 'SRV-UAT-01',
    env: 'UAT',
    status: 'Online',
    endpoint: '10.64.10.15:22',
    capacity: '16 vCPU / 64 GB',
    capacityValue: 16,
    usageOrLoad: '29%',
    version: 'RHEL 9.4',
    expiryDate: 'Jan 12, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 14, 2026',
    owner: 'QA Middleware',
    regionOrCluster: 'DC-IST-UAT · VLAN 64',
    notes: 'Shared host for release candidate smoke runs.',
  },
  {
    id: 'srv-05',
    tab: 'sunucu',
    name: 'dr-gateway-01',
    subtitle: 'Disaster recovery failover gateway',
    code: 'SRV-DR-01',
    env: 'DR',
    status: 'Standby',
    endpoint: '10.82.4.10:22',
    capacity: '16 vCPU / 64 GB',
    capacityValue: 16,
    usageOrLoad: '12%',
    version: 'RHEL 9.2',
    expiryDate: 'Nov 19, 2026',
    alertLevel: 'critical',
    alertNote: 'OS minor release upgrade overdue',
    updatedAt: 'Nov 12, 2026',
    owner: 'BCP & DR Ops',
    regionOrCluster: 'DC-ANK-02 · VLAN 82',
    notes: 'Synced every 15 minutes via Ansible state verification.',
  },
  {
    id: 'srv-06',
    tab: 'sunucu',
    name: 'preprod-batch-01',
    subtitle: 'Pre-production nightly batch runner',
    code: 'SRV-PRP-01',
    env: 'Pre-Prod',
    status: 'Maintenance',
    endpoint: '10.52.8.31:22',
    capacity: '24 vCPU / 96 GB',
    capacityValue: 24,
    usageOrLoad: '18%',
    version: 'RHEL 9.4',
    expiryDate: 'Dec 04, 2026',
    alertLevel: 'warning',
    alertNote: 'Disk expansion maintenance window open',
    updatedAt: 'Nov 16, 2026',
    owner: 'Platform Infra',
    regionOrCluster: 'DC-IST-01 · VLAN 52',
    notes: 'Mounted to /exports/workspace NFSv4 share.',
  },

  // 2. UYGULAMA
  {
    id: 'app-01',
    tab: 'uygulama',
    name: 'Credit Decision Gateway',
    subtitle: 'com.corp.credit.gateway',
    code: 'APP-CRD-01',
    env: 'Prod',
    status: 'Active',
    endpoint: 'https://credit-gw.internal:8443',
    capacity: '8 Instances · 4 GB',
    capacityValue: 8,
    usageOrLoad: '420 rps',
    version: 'Java 21 · v3.14.2',
    expiryDate: 'Jan 30, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 16, 2026',
    owner: 'Credit Tech',
    regionOrCluster: 'ocp-prod-eu01 / credit-core',
    notes: 'Primary orchestration API bridging mobile onboarding and Provenir.',
  },
  {
    id: 'app-02',
    tab: 'uygulama',
    name: 'Customer Onboarding API',
    subtitle: 'com.corp.onboarding.service',
    code: 'APP-ONB-02',
    env: 'Prod',
    status: 'Active',
    endpoint: 'https://onboard-api.internal:8443',
    capacity: '6 Instances · 2 GB',
    capacityValue: 6,
    usageOrLoad: '285 rps',
    version: '.NET 8 · v2.9.0',
    expiryDate: 'Dec 02, 2026',
    alertLevel: 'warning',
    alertNote: 'mTLS client secret rotates Dec 02',
    updatedAt: 'Nov 15, 2026',
    owner: 'Digital Channels',
    regionOrCluster: 'ocp-prod-eu01 / channels',
    notes: 'Handles KYC payload verification and document upload tokens.',
  },
  {
    id: 'app-03',
    tab: 'uygulama',
    name: 'Document Ingestion Service',
    subtitle: 'com.corp.docs.ingestion',
    code: 'APP-DOC-03',
    env: 'Prod',
    status: 'Active',
    endpoint: 'https://doc-ingest.internal:9443',
    capacity: '4 Instances · 4 GB',
    capacityValue: 4,
    usageOrLoad: '112 rps',
    version: 'Node 22 · v1.18.4',
    expiryDate: 'Feb 14, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 14, 2026',
    owner: 'Workspace Core',
    regionOrCluster: 'ocp-prod-eu01 / docs',
    notes: 'Streams PDF/DOCX/XLSX payloads to NFS and object vault.',
  },
  {
    id: 'app-04',
    tab: 'uygulama',
    name: 'Batch Settlement Worker',
    subtitle: 'com.corp.settlement.batch',
    code: 'APP-BAT-04',
    env: 'Prod',
    status: 'Degraded',
    endpoint: 'tcp://batch-worker.internal:7070',
    capacity: '4 Instances · 8 GB',
    capacityValue: 4,
    usageOrLoad: '94 rps',
    version: 'Java 17 · v4.2.1',
    expiryDate: 'Nov 20, 2026',
    alertLevel: 'critical',
    alertNote: 'High GC pause ratio detected in shard-2',
    updatedAt: 'Nov 16, 2026',
    owner: 'Core Ledger',
    regionOrCluster: 'prod-core-app01 / systemd',
    notes: 'Nightly EOD ledger reconciliation job.',
  },
  {
    id: 'app-05',
    tab: 'uygulama',
    name: 'Notification Dispatch Hub',
    subtitle: 'com.corp.notify.dispatcher',
    code: 'APP-NTF-05',
    env: 'UAT',
    status: 'Active',
    endpoint: 'https://notify-uat.internal:8443',
    capacity: '2 Instances · 1 GB',
    capacityValue: 2,
    usageOrLoad: '48 rps',
    version: 'Go 1.23 · v1.6.0',
    expiryDate: 'Mar 05, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 13, 2026',
    owner: 'Messaging SRE',
    regionOrCluster: 'ocp-uat-01 / messaging',
    notes: 'Dispatches SMS, push, and SMTP alerts via Evam trigger webhooks.',
  },

  // 3. OPENSHIFT
  {
    id: 'ocp-01',
    tab: 'openshift',
    name: 'ocp-prod-eu01 / credit-core',
    subtitle: 'Primary production decisioning namespace',
    code: 'OCP-PRD-01',
    env: 'Prod',
    status: 'Healthy',
    endpoint: 'api.ocp-prod-eu01.internal:6443',
    capacity: '48 Pods · 64 CPU',
    capacityValue: 48,
    usageOrLoad: '62%',
    version: 'OCP 4.14.18',
    expiryDate: 'Jan 22, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 16, 2026',
    owner: 'Platform SRE',
    regionOrCluster: 'Istanbul DC-1 · Bare Metal',
    notes: 'HPA enabled (min 24, max 64 pods), Istio service mesh enabled.',
  },
  {
    id: 'ocp-02',
    tab: 'openshift',
    name: 'ocp-prod-eu01 / decision-mesh',
    subtitle: 'Provenir & PowerCurve container bridge',
    code: 'OCP-PRD-02',
    env: 'Prod',
    status: 'Healthy',
    endpoint: 'mesh.apps.ocp-prod-eu01.internal',
    capacity: '32 Pods · 48 CPU',
    capacityValue: 32,
    usageOrLoad: '54%',
    version: 'OCP 4.14.18',
    expiryDate: 'Nov 28, 2026',
    alertLevel: 'warning',
    alertNote: 'Ingress wildcard TLS cert renews Nov 28',
    updatedAt: 'Nov 15, 2026',
    owner: 'Decisioning SRE',
    regionOrCluster: 'Istanbul DC-1 · Worker Pool B',
    notes: 'Dedicated mTLS egress gateway to external credit bureaus.',
  },
  {
    id: 'ocp-03',
    tab: 'openshift',
    name: 'ocp-prod-eu02 / gateway-ingress',
    subtitle: 'Active-active secondary ingress cluster',
    code: 'OCP-PRD-03',
    env: 'Prod',
    status: 'Healthy',
    endpoint: 'api.ocp-prod-eu02.internal:6443',
    capacity: '36 Pods · 48 CPU',
    capacityValue: 36,
    usageOrLoad: '49%',
    version: 'OCP 4.14.18',
    expiryDate: 'Feb 09, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 15, 2026',
    owner: 'Platform SRE',
    regionOrCluster: 'Istanbul DC-2 · Bare Metal',
    notes: 'BGP Anycast VIP routed via F5 Big-IP.',
  },
  {
    id: 'ocp-04',
    tab: 'openshift',
    name: 'ocp-uat-01 / integration-bus',
    subtitle: 'UAT test pipelines and mock bureau pods',
    code: 'OCP-UAT-01',
    env: 'UAT',
    status: 'Healthy',
    endpoint: 'api.ocp-uat-01.internal:6443',
    capacity: '22 Pods · 24 CPU',
    capacityValue: 22,
    usageOrLoad: '35%',
    version: 'OCP 4.15.4',
    expiryDate: 'Mar 11, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 14, 2026',
    owner: 'QA Middleware',
    regionOrCluster: 'UAT Lab Cluster',
    notes: 'ArgoCD GitOps auto-sync enabled on release/* branches.',
  },
  {
    id: 'ocp-05',
    tab: 'openshift',
    name: 'ocp-dr-01 / standby-core',
    subtitle: 'Cold/warm standby DR namespace',
    code: 'OCP-DR-01',
    env: 'DR',
    status: 'Standby',
    endpoint: 'api.ocp-dr-01.internal:6443',
    capacity: '12 Pods · 32 CPU',
    capacityValue: 12,
    usageOrLoad: '14%',
    version: 'OCP 4.14.12',
    expiryDate: 'Nov 21, 2026',
    alertLevel: 'critical',
    alertNote: 'ServiceAccount pull token expires Nov 21',
    updatedAt: 'Nov 11, 2026',
    owner: 'BCP & DR Ops',
    regionOrCluster: 'Ankara DC-2 · DR Zone',
    notes: 'Velero daily snapshot restore tested every Sunday.',
  },

  // 4. REVERSE PROXY
  {
    id: 'rpx-01',
    tab: 'reverse-proxy',
    name: 'edge-gw-prod-01',
    subtitle: 'External partner HTTPS & WAF edge',
    code: 'RPX-EDG-01',
    env: 'Prod',
    status: 'Active',
    endpoint: '10.40.1.10:443',
    capacity: '18 Upstreams',
    capacityValue: 18,
    usageOrLoad: '1,840 req/s',
    version: 'Nginx Plus R31',
    expiryDate: 'Nov 27, 2026',
    alertLevel: 'warning',
    alertNote: 'Partner *.gw.corp.internal cert expires in 11 days',
    updatedAt: 'Nov 16, 2026',
    owner: 'Network Security',
    regionOrCluster: 'DMZ-IST-01 · Active',
    notes: 'TLS 1.3 enforced, OCSP stapling enabled, rate limit 500r/s/IP.',
  },
  {
    id: 'rpx-02',
    tab: 'reverse-proxy',
    name: 'internal-api-proxy',
    subtitle: 'East-West L7 internal service router',
    code: 'RPX-INT-02',
    env: 'Prod',
    status: 'Active',
    endpoint: '10.42.2.50:8443',
    capacity: '26 Upstreams',
    capacityValue: 26,
    usageOrLoad: '2,410 req/s',
    version: 'HAProxy 2.9',
    expiryDate: 'Feb 19, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 16, 2026',
    owner: 'Middleware Ops',
    regionOrCluster: 'Core LAN · Keepalived VIP',
    notes: 'Routes Provenir, Evam, and PowerCurve internal traffic with health checks.',
  },
  {
    id: 'rpx-03',
    tab: 'reverse-proxy',
    name: 'mtls-partner-gateway',
    subtitle: 'Two-way mTLS bureau & OpenBanking proxy',
    code: 'RPX-MTL-03',
    env: 'Prod',
    status: 'Active',
    endpoint: '10.40.3.22:9443',
    capacity: '9 Upstreams',
    capacityValue: 9,
    usageOrLoad: '620 req/s',
    version: 'Nginx Plus R31',
    expiryDate: 'Nov 18, 2026',
    alertLevel: 'critical',
    alertNote: 'Bureau CA bundle intermediate renewal due Nov 18',
    updatedAt: 'Nov 16, 2026',
    owner: 'Network Security',
    regionOrCluster: 'DMZ-IST-01 · Pair A/B',
    notes: 'Strict client CN allowlist + CRL verification.',
  },
  {
    id: 'rpx-04',
    tab: 'reverse-proxy',
    name: 'uat-reverse-proxy',
    subtitle: 'UAT consolidated frontend & API ingress',
    code: 'RPX-UAT-04',
    env: 'UAT',
    status: 'Active',
    endpoint: '10.64.2.12:443',
    capacity: '14 Upstreams',
    capacityValue: 14,
    usageOrLoad: '145 req/s',
    version: 'Nginx 1.26.1',
    expiryDate: 'Apr 01, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 13, 2026',
    owner: 'QA Middleware',
    regionOrCluster: 'UAT Zone · Single Node',
    notes: 'Self-signed internal PKI wildcard certificate.',
  },
  {
    id: 'rpx-05',
    tab: 'reverse-proxy',
    name: 'legacy-soap-bridge',
    subtitle: 'REST-to-SOAP XML transformation proxy',
    code: 'RPX-BRG-05',
    env: 'Pre-Prod',
    status: 'Maintenance',
    endpoint: '10.52.4.19:8080',
    capacity: '6 Upstreams',
    capacityValue: 6,
    usageOrLoad: '42 req/s',
    version: 'Envoy 1.30',
    expiryDate: 'Dec 15, 2026',
    alertLevel: 'none',
    updatedAt: 'Nov 14, 2026',
    owner: 'Integration Team',
    regionOrCluster: 'Pre-Prod Zone',
    notes: 'Migrating legacy XML endpoints to JSON gateway.',
  },

  // 5. PROVENIR
  {
    id: 'prv-01',
    tab: 'provenir',
    name: 'Provenir Runtime Node 01',
    subtitle: 'Retail Credit Decision Engine (Active)',
    code: 'PRV-PRD-01',
    env: 'Prod',
    status: 'Online',
    endpoint: '10.48.20.14:8080',
    capacity: '32 Workers · 16 GB',
    capacityValue: 32,
    usageOrLoad: '310 TPS',
    version: 'Provenir 8.6.4',
    expiryDate: 'Mar 31, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 16, 2026',
    owner: 'Decisioning Ops',
    regionOrCluster: 'Provenir Prod Cluster',
    notes: 'Executes retail scoring, affordability, and policy rules.',
  },
  {
    id: 'prv-02',
    tab: 'provenir',
    name: 'Provenir Runtime Node 02',
    subtitle: 'Retail Credit Decision Engine (Active)',
    code: 'PRV-PRD-02',
    env: 'Prod',
    status: 'Online',
    endpoint: '10.48.20.15:8080',
    capacity: '32 Workers · 16 GB',
    capacityValue: 32,
    usageOrLoad: '295 TPS',
    version: 'Provenir 8.6.4',
    expiryDate: 'Mar 31, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 16, 2026',
    owner: 'Decisioning Ops',
    regionOrCluster: 'Provenir Prod Cluster',
    notes: 'Load-balanced behind internal-api-proxy.',
  },
  {
    id: 'prv-03',
    tab: 'provenir',
    name: 'KYC & Bureau Connector Hub',
    subtitle: 'KKB / Findeks / Mernis SOAP & REST adapters',
    code: 'PRV-ADP-03',
    env: 'Prod',
    status: 'Online',
    endpoint: '10.48.21.10:8443',
    capacity: '16 Workers · 8 GB',
    capacityValue: 16,
    usageOrLoad: '148 TPS',
    version: 'Provenir Adapter 8.6',
    expiryDate: 'Nov 25, 2026',
    alertLevel: 'warning',
    alertNote: 'KKB client certificate rotation due Nov 25',
    updatedAt: 'Nov 15, 2026',
    owner: 'Credit Risk Tech',
    regionOrCluster: 'Provenir Prod Cluster',
    notes: 'Timeout threshold 1800ms with circuit breaker fallback.',
  },
  {
    id: 'prv-04',
    tab: 'provenir',
    name: 'Provenir Studio & Design UAT',
    subtitle: 'Rule authoring & workflow simulation',
    code: 'PRV-UAT-04',
    env: 'UAT',
    status: 'Online',
    endpoint: '10.64.20.11:8080',
    capacity: '8 Workers · 8 GB',
    capacityValue: 8,
    usageOrLoad: '24 TPS',
    version: 'Provenir 8.7.0-RC1',
    expiryDate: 'Jan 15, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 14, 2026',
    owner: 'Credit Risk Tech',
    regionOrCluster: 'UAT Decisioning Lab',
    notes: 'Validating v8.7 ruleflow deployment package.',
  },
  {
    id: 'prv-05',
    tab: 'provenir',
    name: 'Batch Simulation Engine',
    subtitle: 'Champion/Challenger backtesting runner',
    code: 'PRV-PRP-05',
    env: 'Pre-Prod',
    status: 'Standby',
    endpoint: '10.52.20.19:8080',
    capacity: '16 Workers · 12 GB',
    capacityValue: 16,
    usageOrLoad: '85 TPS',
    version: 'Provenir 8.6.4',
    expiryDate: 'Dec 20, 2026',
    alertLevel: 'none',
    updatedAt: 'Nov 12, 2026',
    owner: 'Risk Analytics',
    regionOrCluster: 'Pre-Prod Decisioning',
    notes: 'Replays anonymized 90-day application datasets.',
  },

  // 6. EVAM
  {
    id: 'evm-01',
    tab: 'evam',
    name: 'Evam CEP Core Engine',
    subtitle: 'Real-time customer event correlation engine',
    code: 'EVM-PRD-01',
    env: 'Prod',
    status: 'Active',
    endpoint: '10.49.12.22:8080',
    capacity: '24 Partitions',
    capacityValue: 24,
    usageOrLoad: '14.2k evt/s',
    version: 'Evam 5.4.2',
    expiryDate: 'Feb 28, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 16, 2026',
    owner: 'Streaming & CEP',
    regionOrCluster: 'Evam Prod Cluster A',
    notes: 'Processes card authorization, login, and balance threshold events.',
  },
  {
    id: 'evm-02',
    tab: 'evam',
    name: 'Kafka Event Ingestion Bridge',
    subtitle: 'Confluent Kafka -> Evam Actor consumer',
    code: 'EVM-KFK-02',
    env: 'Prod',
    status: 'Active',
    endpoint: '10.49.12.30:9092',
    capacity: '36 Partitions',
    capacityValue: 36,
    usageOrLoad: '18.9k evt/s',
    version: 'Evam Kafka 5.4',
    expiryDate: 'Nov 26, 2026',
    alertLevel: 'warning',
    alertNote: 'Consumer lag spike observed during 09:00 peak',
    updatedAt: 'Nov 16, 2026',
    owner: 'Streaming & CEP',
    regionOrCluster: 'Kafka Prod Mesh',
    notes: 'SASL_SSL authentication, 6 consumer group threads.',
  },
  {
    id: 'evm-03',
    tab: 'evam',
    name: 'Fraud & Limit Alert Scenario',
    subtitle: 'High-velocity anomaly notification scenario',
    code: 'EVM-SCN-03',
    env: 'Prod',
    status: 'Active',
    endpoint: '10.49.14.11:8081',
    capacity: '12 Partitions',
    capacityValue: 12,
    usageOrLoad: '3.4k evt/s',
    version: 'Scenario v14.8',
    expiryDate: 'Jan 19, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 15, 2026',
    owner: 'Fraud Ops Tech',
    regionOrCluster: 'Evam Prod Cluster A',
    notes: 'Triggers push + SMS alerts within 120ms SLA.',
  },
  {
    id: 'evm-04',
    tab: 'evam',
    name: 'Evam Designer & UAT Node',
    subtitle: 'Scenario studio and campaign QA runtime',
    code: 'EVM-UAT-04',
    env: 'UAT',
    status: 'Active',
    endpoint: '10.64.12.22:8080',
    capacity: '8 Partitions',
    capacityValue: 8,
    usageOrLoad: '620 evt/s',
    version: 'Evam 5.4.2',
    expiryDate: 'Apr 10, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 14, 2026',
    owner: 'Campaign Tech',
    regionOrCluster: 'UAT Streaming Zone',
    notes: 'Used for UAT campaign sign-off before Prod promotion.',
  },

  // 7. POWERCURVE
  {
    id: 'pwc-01',
    tab: 'powercurve',
    name: 'PowerCurve Strategy Engine',
    subtitle: 'Experian Strategy Manager runtime',
    code: 'PWC-PRD-01',
    env: 'Prod',
    status: 'Online',
    endpoint: '10.50.8.30:8443',
    capacity: '120 Threads',
    capacityValue: 120,
    usageOrLoad: '4,820 /min',
    version: 'PowerCurve 11.2',
    expiryDate: 'May 01, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 16, 2026',
    owner: 'Decisioning Ops',
    regionOrCluster: 'PowerCurve Prod Pool',
    notes: 'Primary consumer & SME credit decision tree execution engine.',
  },
  {
    id: 'pwc-02',
    tab: 'powercurve',
    name: 'Retail Loan Origination Flow',
    subtitle: 'PowerCurve Originations workflow node',
    code: 'PWC-ORG-02',
    env: 'Prod',
    status: 'Online',
    endpoint: '10.50.8.31:8443',
    capacity: '80 Threads',
    capacityValue: 80,
    usageOrLoad: '2,150 /min',
    version: 'PWC Orig 11.2.1',
    expiryDate: 'Nov 23, 2026',
    alertLevel: 'warning',
    alertNote: 'Quarterly scoring scorecard rulepack update Nov 23',
    updatedAt: 'Nov 15, 2026',
    owner: 'Credit Risk Tech',
    regionOrCluster: 'PowerCurve Prod Pool',
    notes: 'Integrates with internal customer profile and collateral service.',
  },
  {
    id: 'pwc-03',
    tab: 'powercurve',
    name: 'Corporate Scoring Agent',
    subtitle: 'Commercial underwriting decision agent',
    code: 'PWC-CRP-03',
    env: 'Prod',
    status: 'Online',
    endpoint: '10.50.9.14:8443',
    capacity: '40 Threads',
    capacityValue: 40,
    usageOrLoad: '640 /min',
    version: 'PowerCurve 11.2',
    expiryDate: 'Feb 11, 2027',
    alertLevel: 'none',
    updatedAt: 'Nov 14, 2026',
    owner: 'Corporate Credit Tech',
    regionOrCluster: 'PowerCurve Prod Pool',
    notes: 'Financial statement ratio scoring + limit matrix.',
  },
  {
    id: 'pwc-04',
    tab: 'powercurve',
    name: 'PowerCurve UAT Sandbox',
    subtitle: 'Strategy studio & challenger validation',
    code: 'PWC-UAT-04',
    env: 'UAT',
    status: 'Online',
    endpoint: '10.64.8.30:8443',
    capacity: '24 Threads',
    capacityValue: 24,
    usageOrLoad: '185 /min',
    version: 'PowerCurve 11.3-Beta',
    expiryDate: 'Nov 18, 2026',
    alertLevel: 'critical',
    alertNote: 'Trial evaluation key expires Nov 18',
    updatedAt: 'Nov 16, 2026',
    owner: 'Credit Risk Tech',
    regionOrCluster: 'UAT Decisioning Lab',
    notes: 'Sandbox for PowerCurve 11.3 strategy regression suite.',
  },
];

export const ENV_STORAGE_KEY = 'mk-environment-inventory-v1';

export function toEntrySlug(entry: Pick<EnvironmentEntry, 'id' | 'name'>): string {
  const clean = entry.name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return clean || entry.id;
}

export function loadEnvironmentEntries(): EnvironmentEntry[] {
  try {
    const saved = localStorage.getItem(ENV_STORAGE_KEY);
    if (saved !== null) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // Fallback to defaults
  }
  return INITIAL_ENVIRONMENT_ENTRIES;
}

export function saveEnvironmentEntries(entries: EnvironmentEntry[]): void {
  try {
    localStorage.setItem(ENV_STORAGE_KEY, JSON.stringify(entries));
  } catch {
    // Ignore storage failures
  }
}

export function findEnvironmentEntryByRoute(
  tab: EnvironmentTabKey,
  slug: string
): EnvironmentEntry | null {
  const entries = loadEnvironmentEntries();
  const normalized = decodeURIComponent(slug).toLowerCase();
  return (
    entries.find(
      (e) =>
        e.tab === tab &&
        (toEntrySlug(e) === normalized ||
          e.id.toLowerCase() === normalized ||
          e.code.toLowerCase() === normalized)
    ) || null
  );
}

export interface UpstreamServiceItem {
  id: string;
  service: string;
  endpoint: string;
  health: 'Healthy' | 'Degraded' | 'Unhealthy';
  traffic: string;
  latencyMs: number;
  weight: number;
  activeConns: number;
}

export interface TlsCertificateSpec {
  commonName: string;
  issuer: string;
  serialNumber: string;
  validFrom: string;
  validTo: string;
  daysRemaining: number;
  tlsVersions: string;
  cipherSuite: string;
  mtlsMode: string;
  ocspStapling: string;
  hsts: string;
  sans: string[];
}

export interface ActivityEventItem {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  severity: 'info' | 'warning' | 'critical' | 'ok';
}

export interface TrafficPoint {
  hour: string;
  rps: number;
  p95Ms: number;
}

export interface EnvironmentDetailProfile {
  protocol: string;
  zoneLabel: string;
  createdAt: string;
  availability: string;
  avgLatencyMs: number;
  p95LatencyMs: number;
  requestRate: string;
  trafficDelta: string;
  upstreamCount: number;
  unhealthyCount: number;
  tlsSummaryValue: string;
  tlsSummaryNote: string;
  trafficSeries: TrafficPoint[];
  upstreams: UpstreamServiceItem[];
  tls: TlsCertificateSpec;
  configSnippet: string;
  configFilename: string;
  activities: ActivityEventItem[];
}

export function buildEnvironmentDetailProfile(
  entry: EnvironmentEntry
): EnvironmentDetailProfile {
  const isEdgeProxy = entry.id === 'rpx-01' || entry.name === 'edge-gw-prod-01';
  const isWarning = entry.alertLevel === 'warning';
  const isCritical = entry.alertLevel === 'critical';

  const baseRps = isEdgeProxy
    ? 1840
    : entry.id === 'rpx-02'
    ? 2410
    : entry.id === 'rpx-03'
    ? 620
    : entry.env === 'Prod'
    ? 920
    : 145;

  const trafficMultipliers = [
    0.42, 0.34, 0.28, 0.25, 0.31, 0.45, 0.68, 0.89, 1.08, 1.18, 1.14, 1.09,
    1.04, 1.12, 1.21, 1.19, 1.07, 0.96, 0.88, 0.79, 0.71, 0.63, 0.54, 0.48,
  ];
  const trafficSeries: TrafficPoint[] = trafficMultipliers.map((mult, idx) => ({
    hour: `${String(idx).padStart(2, '0')}:00`,
    rps: Math.round(baseRps * mult),
    p95Ms: Math.round((isEdgeProxy ? 96 : 78) + mult * 24),
  }));

  const upstreams: UpstreamServiceItem[] = isEdgeProxy
    ? [
        {
          id: 'up-1',
          service: 'partner-api-prod',
          endpoint: '10.40.12.18:8443',
          health: 'Healthy',
          traffic: '680 req/s',
          latencyMs: 36,
          weight: 50,
          activeConns: 142,
        },
        {
          id: 'up-2',
          service: 'openbanking-auth-v2',
          endpoint: '10.40.12.24:8443',
          health: 'Healthy',
          traffic: '490 req/s',
          latencyMs: 41,
          weight: 30,
          activeConns: 98,
        },
        {
          id: 'up-3',
          service: 'kyc-webhook-gw',
          endpoint: '10.40.14.11:8080',
          health: 'Degraded',
          traffic: '245 req/s',
          latencyMs: 94,
          weight: 10,
          activeConns: 64,
        },
        {
          id: 'up-4',
          service: 'credit-callback-svc',
          endpoint: '10.40.15.09:8443',
          health: 'Healthy',
          traffic: '295 req/s',
          latencyMs: 38,
          weight: 40,
          activeConns: 71,
        },
        {
          id: 'up-5',
          service: 'waf-inspection-pool',
          endpoint: '10.40.16.04:9000',
          health: 'Healthy',
          traffic: '130 req/s',
          latencyMs: 19,
          weight: 25,
          activeConns: 33,
        },
        {
          id: 'up-6',
          service: 'legacy-partner-bridge',
          endpoint: '10.40.18.30:8080',
          health: 'Unhealthy',
          traffic: '0 req/s',
          latencyMs: 0,
          weight: 0,
          activeConns: 0,
        },
      ]
    : [
        {
          id: 'up-a',
          service: `${entry.name}-primary`,
          endpoint: entry.endpoint,
          health: entry.status === 'Degraded' ? 'Degraded' : 'Healthy',
          traffic: entry.usageOrLoad,
          latencyMs: entry.env === 'Prod' ? 34 : 52,
          weight: 70,
          activeConns: 84,
        },
        {
          id: 'up-b',
          service: `${entry.name}-secondary`,
          endpoint: entry.endpoint.replace(/:\d+$/, ':8444'),
          health: 'Healthy',
          traffic: entry.env === 'Prod' ? '410 req/s' : '45 req/s',
          latencyMs: 39,
          weight: 30,
          activeConns: 46,
        },
        {
          id: 'up-c',
          service: `${entry.name}-metrics-exporter`,
          endpoint: entry.endpoint.replace(/:\d+$/, ':9113'),
          health: entry.status === 'Maintenance' ? 'Unhealthy' : 'Healthy',
          traffic: '12 req/s',
          latencyMs: 11,
          weight: 10,
          activeConns: 6,
        },
      ];

  const unhealthyCount = isEdgeProxy
    ? 2
    : upstreams.filter((u) => u.health !== 'Healthy').length;

  const tls: TlsCertificateSpec = {
    commonName: isEdgeProxy ? '*.gw.corp.internal' : `${entry.name}.internal`,
    issuer: 'Corp Enterprise Issuing CA G3',
    serialNumber: isEdgeProxy
      ? '4A:91:F0:33:C8:19:7E:02'
      : '3C:18:A2:74:09:B1:4D:88',
    validFrom: 'Nov 27, 2025',
    validTo: entry.expiryDate,
    daysRemaining: isCritical ? 2 : isWarning ? 10 : 94,
    tlsVersions: 'TLS 1.3, TLS 1.2',
    cipherSuite: 'TLS_AES_256_GCM_SHA384',
    mtlsMode:
      entry.id === 'rpx-03'
        ? 'Strict Client CN Allowlist'
        : isEdgeProxy
        ? 'Optional Partner mTLS'
        : 'Internal PKI Verified',
    ocspStapling: 'Enabled (Cached 60m)',
    hsts: 'max-age=31536000; includeSubDomains',
    sans: isEdgeProxy
      ? [
          'gw.corp.internal',
          '*.gw.corp.internal',
          'partner-edge.corp.internal',
          'openbanking-gw.corp.internal',
        ]
      : [`${entry.name}.internal`, `${entry.code.toLowerCase()}.corp.internal`],
  };

  const configFilename =
    entry.tab === 'reverse-proxy'
      ? `${entry.name}.conf`
      : entry.tab === 'openshift'
      ? `${entry.code.toLowerCase()}-ingress.yaml`
      : `${entry.code.toLowerCase()}-runtime.conf`;

  const configSnippet =
    entry.tab === 'reverse-proxy'
      ? `# Managed by Workspace Environment Registry (${entry.code})
# Engine: ${entry.version} | Zone: ${entry.regionOrCluster}

upstream ${entry.name.replace(/[^a-z0-9]/gi, '_')}_pool {
    least_conn;
    keepalive 128;
${upstreams
  .map(
    (u) =>
      `    server ${u.endpoint} weight=${u.weight || 1} max_fails=3 fail_timeout=15s;${
        u.health === 'Unhealthy' ? ' # drained' : ''
      }`
  )
  .join('\n')}
}

server {
    listen ${entry.endpoint.split(':')[1] || '443'} ssl http2;
    server_name ${tls.commonName};

    ssl_certificate     /etc/pki/tls/certs/${entry.name}.crt;
    ssl_certificate_key /etc/pki/tls/private/${entry.name}.key;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_stapling        on;

    add_header Strict-Transport-Security "${tls.hsts}" always;

    location / {
        proxy_pass https://${entry.name.replace(/[^a-z0-9]/gi, '_')}_pool;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_connect_timeout 5s;
        proxy_read_timeout 30s;
    }
}`
      : `# Managed Runtime Descriptor (${entry.code})
service: ${entry.name}
environment: ${entry.env}
status: ${entry.status}
endpoint: ${entry.endpoint}
version: ${entry.version}
capacity: ${entry.capacity}
cluster_zone: ${entry.regionOrCluster}
owner: ${entry.owner}

tls:
  common_name: ${tls.commonName}
  versions: ${tls.tlsVersions}
  mtls: ${tls.mtlsMode}
  expires: ${entry.expiryDate}

upstreams:
${upstreams
  .map(
    (u) =>
      `  - name: ${u.service}
    endpoint: ${u.endpoint}
    weight: ${u.weight}
    health: ${u.health}`
  )
  .join('\n')}`;

  const activities: ActivityEventItem[] = [
    {
      id: 'act-1',
      timestamp: `${entry.updatedAt} · 14:22`,
      actor: entry.owner,
      action: 'Health Probe Completed',
      target: `${entry.endpoint} (${entry.status})`,
      severity: isCritical ? 'critical' : isWarning ? 'warning' : 'ok',
    },
    ...(entry.alertNote
      ? [
          {
            id: 'act-2',
            timestamp: `${entry.updatedAt} · 09:15`,
            actor: 'CertWatch Daemon',
            action: isCritical ? 'Critical Expiry Alert' : 'Renewal Warning Raised',
            target: entry.alertNote,
            severity: (isCritical ? 'critical' : 'warning') as 'critical' | 'warning',
          },
        ]
      : []),
    {
      id: 'act-3',
      timestamp: 'Nov 14, 2026 · 18:40',
      actor: 'murat.krhl',
      action: 'Verified Upstream Weights',
      target: `${upstreams[0]?.service || entry.name} (weight=${upstreams[0]?.weight || 50})`,
      severity: 'info',
    },
    {
      id: 'act-4',
      timestamp: 'Nov 10, 2026 · 07:05',
      actor: 'Ansible GitOps',
      action: 'Applied Baseline Config',
      target: `${configFilename} (${entry.version})`,
      severity: 'ok',
    },
  ];

  return {
    protocol: entry.endpoint.startsWith('http://') || entry.endpoint.endsWith(':8080')
      ? 'HTTP / REST'
      : entry.endpoint.endsWith(':22')
      ? 'SSH / TCP'
      : entry.endpoint.endsWith(':9092')
      ? 'Kafka SASL_SSL'
      : 'HTTPS',
    zoneLabel: entry.regionOrCluster,
    createdAt: 'Oct 04, 2024',
    availability: entry.status === 'Degraded' ? '99.41%' : entry.status === 'Maintenance' ? '99.72%' : '99.98%',
    avgLatencyMs: isEdgeProxy ? 42 : entry.env === 'Prod' ? 36 : 54,
    p95LatencyMs: isEdgeProxy ? 118 : entry.env === 'Prod' ? 98 : 132,
    requestRate: isEdgeProxy ? '1,840 req/s' : entry.usageOrLoad,
    trafficDelta: entry.status === 'Degraded' ? '-2.1%' : '+4.8%',
    upstreamCount: isEdgeProxy ? 18 : upstreams.length,
    unhealthyCount,
    tlsSummaryValue: isCritical
      ? 'Expires in 2 days'
      : isWarning
      ? 'Expires in 10 days'
      : entry.expiryDate,
    tlsSummaryNote: isCritical
      ? 'Immediate renewal required'
      : isWarning
      ? 'Certificate renewal warning'
      : 'Valid certificate chain',
    trafficSeries,
    upstreams,
    tls,
    configSnippet,
    configFilename,
    activities,
  };
}

