export type GitHubExplorerSubTab =
  | 'discover'
  | 'recently-added'
  | 'trending'
  | 'saved'
  | 'categories'
  | 'settings'
  | 'sync-history';

export type RefreshIntervalMinutes = 0 | 30 | 60 | 180 | 360 | 720 | 1440;

export type SyncStatus = 'idle' | 'syncing' | 'success' | 'partial' | 'rate_limited' | 'error';

export interface GitHubOwner {
  login: string;
  avatarUrl: string;
  htmlUrl: string;
}

export interface GitHubRepository {
  id: number;
  nodeId: string;
  name: string;
  fullName: string;
  owner: GitHubOwner;
  htmlUrl: string;
  description: string | null;
  language: string | null;
  stargazersCount: number;
  watchersCount: number;
  forksCount: number;
  openIssuesCount: number;
  createdAt: string;
  updatedAt: string;
  pushedAt: string | null;
  defaultBranch: string;
  topics: string[];
  license: string | null;
  archived: boolean;
  fork: boolean;
  visibility: string;
  discoveredAt: string;
  lastRefreshedAt: string;
}

export interface GitHubCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  color: string;
  enabled: boolean;
  searchQueries: string[];
  excludedKeywords: string[];
  minimumStars: number;
  maximumResults: number;
  createdWithinDays: number | null;
  updatedWithinDays: number | null;
  languages: string[];
  refreshIntervalMinutes: RefreshIntervalMinutes;
  lastSyncedAt: string | null;
  lastSyncStatus: SyncStatus;
  lastSyncError: string | null;
  repositoryCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface CategoryAssociation {
  repoId: number;
  categoryIds: string[];
  manualAddedCategoryIds: string[];
  manualExcludedCategoryIds: string[];
  matchedQueries: string[];
  updatedAt: string;
}

export interface GitHubSettings {
  autoRefreshEnabled: boolean;
  defaultRefreshIntervalMinutes: RefreshIntervalMinutes;
  defaultCreatedWithinDays: number | null;
  defaultUpdatedWithinDays: number | null;
  defaultMinimumStars: number;
  defaultMaximumResults: number;
  defaultSort: 'stars' | 'updated' | 'created' | 'name';
  defaultView: 'grid' | 'table';
}

export interface SyncHistoryEntry {
  id: string;
  categoryId: string;
  categoryName: string;
  query: string;
  startedAt: string;
  endedAt: string;
  durationMs: number;
  retrievedCount: number;
  newCount: number;
  updatedCount: number;
  duplicatesRemoved: number;
  errorCount: number;
  status: 'success' | 'partial' | 'rate_limited' | 'error';
  errorMessage: string | null;
}

export interface StarSnapshot {
  repoId: number;
  stars: number;
  capturedAt: string;
}

export interface RateLimitBucket {
  resource: 'search' | 'core';
  limit: number | null;
  remaining: number | null;
  resetAt: number | null; // epoch ms
  retryAfterSeconds: number | null;
  updatedAt: string | null;
}

export interface RateLimitState {
  search: RateLimitBucket;
  core: RateLimitBucket;
}

export interface SyncProgressState {
  isRunning: boolean;
  currentCategoryName: string | null;
  currentQuery: string | null;
  completedCategories: number;
  totalCategories: number;
  lastGlobalSyncAt: string | null;
  message: string | null;
}

export interface GitHubReleaseItem {
  id: number;
  tagName: string;
  name: string | null;
  publishedAt: string | null;
  prerelease: boolean;
  htmlUrl: string;
  body: string | null;
}

export interface GitHubContributorItem {
  id: number;
  login: string;
  avatarUrl: string;
  htmlUrl: string;
  contributions: number;
}

export interface GitHubExplorerViewState {
  subTab: GitHubExplorerSubTab;
  viewMode: 'grid' | 'table';
  searchQuery: string;
  selectedCategoryIds: string[];
  sortBy: 'stars' | 'updated' | 'created' | 'name';
  sortOrder: 'asc' | 'desc';
  languageFilter: string;
  recentWindow: '24h' | '7d' | '30d' | '90d' | 'custom';
  customDateFrom: string;
  customDateTo: string;
  minStarsFilter: number;
  page: number;
}

export interface GitHubRepositoryProvider {
  getRepositories(): GitHubRepository[];
  getCategories(): GitHubCategory[];
  getAssociations(): Record<number, CategoryAssociation>;
  getSavedRepoIds(): number[];
  getSettings(): GitHubSettings;
  getSyncHistory(): SyncHistoryEntry[];
  getStarSnapshots(): Record<number, StarSnapshot[]>;
  getRateLimits(): RateLimitState;
  syncCategory(categoryId: string): Promise<{
    status: SyncStatus;
    added: number;
    updated: number;
    error: string | null;
  }>;
  syncDueCategories(forceAll?: boolean): Promise<{
    syncedCategories: number;
    rateLimited: boolean;
    error: string | null;
  }>;
  fetchRepositoryDetails(owner: string, repo: string): Promise<GitHubRepository>;
  fetchRepositoryReadme(owner: string, repo: string): Promise<string | null>;
  fetchRepositoryReleases(owner: string, repo: string): Promise<GitHubReleaseItem[]>;
  fetchRepositoryContributors(owner: string, repo: string): Promise<GitHubContributorItem[]>;
  fetchRepositoryLanguages(owner: string, repo: string): Promise<Record<string, number>>;
}
