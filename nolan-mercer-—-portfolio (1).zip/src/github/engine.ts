import {
  fetchGitHubRepo,
  fetchGitHubRepoContributors,
  fetchGitHubRepoLanguages,
  fetchGitHubRepoReadme,
  fetchGitHubRepoReleases,
  GitHubApiError,
  searchGitHubRepositories,
} from './api';
import { validateGitHubQuery } from './categories';
import {
  appendSyncHistory,
  loadAssociations,
  loadCategories,
  loadRateLimits,
  loadRepositories,
  loadSavedRepoIds,
  loadSettings,
  loadStarSnapshots,
  loadSyncHistory,
  recordStarSnapshots,
  saveAssociations,
  saveCategories,
  saveRepositories,
  saveSavedRepoIds,
  saveSettings,
} from './storage';
import {
  CategoryAssociation,
  GitHubCategory,
  GitHubContributorItem,
  GitHubReleaseItem,
  GitHubRepository,
  GitHubRepositoryProvider,
  GitHubSettings,
  RateLimitState,
  StarSnapshot,
  SyncHistoryEntry,
  SyncProgressState,
  SyncStatus,
} from './types';

function isoDaysAgo(days: number): string {
  const d = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  return d.toISOString().slice(0, 10);
}

export function buildEffectiveSearchQuery(
  rawQuery: string,
  category: GitHubCategory
): string {
  const parts: string[] = [rawQuery.trim()];
  if (category.minimumStars > 0 && !/\bstars:/i.test(rawQuery)) {
    parts.push(`stars:>=${category.minimumStars}`);
  }
  if (category.createdWithinDays && category.createdWithinDays > 0 && !/\bcreated:/i.test(rawQuery)) {
    parts.push(`created:>=${isoDaysAgo(category.createdWithinDays)}`);
  }
  if (category.updatedWithinDays && category.updatedWithinDays > 0 && !/\bpushed:/i.test(rawQuery)) {
    parts.push(`pushed:>=${isoDaysAgo(category.updatedWithinDays)}`);
  }
  if (category.languages.length === 1 && !/\blanguage:/i.test(rawQuery)) {
    parts.push(`language:${category.languages[0]}`);
  }
  return parts.join(' ').trim();
}

export function passesCategoryRelevance(
  repo: GitHubRepository,
  category: GitHubCategory
): boolean {
  if (repo.stargazersCount < category.minimumStars) {
    return false;
  }
  if (category.languages.length > 0) {
    const repoLang = (repo.language || '').toLowerCase();
    const matchesLang = category.languages.some((l) => l.toLowerCase() === repoLang);
    if (!matchesLang) return false;
  }

  const haystack = [
    repo.name,
    repo.fullName,
    repo.description || '',
    ...(repo.topics || []),
  ]
    .join(' ')
    .toLowerCase();

  // Excluded keywords check
  if (category.excludedKeywords.length > 0) {
    const hitExcluded = category.excludedKeywords.some((kw) => {
      const clean = kw.trim().toLowerCase();
      return clean.length > 0 && haystack.includes(clean);
    });
    if (hitExcluded) return false;
  }

  // Category-specific precision rules (keep JBoss, Apache, HTTPD, Red Hat Apache distinct)
  if (category.id === 'red-hat-apache') {
    const hasRedHatSignal =
      haystack.includes('redhat') ||
      haystack.includes('red-hat') ||
      haystack.includes('red hat') ||
      haystack.includes('rhel') ||
      haystack.includes('rpm') ||
      haystack.includes('rhscl');
    const hasHttpdSignal =
      haystack.includes('httpd') || haystack.includes('apache');
    return hasRedHatSignal && hasHttpdSignal;
  }

  if (category.id === 'httpd') {
    return (
      haystack.includes('httpd') ||
      haystack.includes('apache-http') ||
      haystack.includes('apache http') ||
      haystack.includes('mod_http2') ||
      haystack.includes('mod-http2')
    );
  }

  return true;
}

export function isCategoryDueForRefresh(category: GitHubCategory): boolean {
  if (!category.enabled) return false;
  if (category.refreshIntervalMinutes === 0) return false;
  if (!category.lastSyncedAt) return true;
  const elapsedMs = Date.now() - new Date(category.lastSyncedAt).getTime();
  return elapsedMs >= category.refreshIntervalMinutes * 60 * 1000;
}

export function getNextScheduledSyncMs(
  categories: GitHubCategory[],
  settings: GitHubSettings
): number | null {
  if (!settings.autoRefreshEnabled) return null;
  const enabled = categories.filter(
    (c) => c.enabled && c.refreshIntervalMinutes > 0
  );
  if (enabled.length === 0) return null;

  let earliest: number | null = null;
  enabled.forEach((cat) => {
    const base = cat.lastSyncedAt ? new Date(cat.lastSyncedAt).getTime() : 0;
    const nextAt = base + cat.refreshIntervalMinutes * 60 * 1000;
    if (earliest === null || nextAt < earliest) {
      earliest = nextAt;
    }
  });
  return earliest;
}

export function recalculateCategoryCounts(
  categories: GitHubCategory[],
  associations: Record<number, CategoryAssociation>
): GitHubCategory[] {
  const counts = new Map<string, number>();
  Object.values(associations).forEach((assoc) => {
    assoc.categoryIds.forEach((cid) => {
      counts.set(cid, (counts.get(cid) || 0) + 1);
    });
  });

  return categories.map((cat) => ({
    ...cat,
    repositoryCount: counts.get(cat.id) || 0,
  }));
}

export function getLanguageColor(language: string | null): string {
  if (!language) return '#71717A';
  const map: Record<string, string> = {
    TypeScript: '#3178C6',
    JavaScript: '#F1E05A',
    Python: '#3572A5',
    Java: '#B07219',
    Go: '#00ADD8',
    Shell: '#89E051',
    Dockerfile: '#384D54',
    Rust: '#DEA584',
    C: '#555555',
    'C++': '#F34B7D',
    Ruby: '#701516',
    PHP: '#4F5D95',
    YAML: '#CB171E',
    HCL: '#844FBA',
    Kotlin: '#A97BFF',
  };
  return map[language] || '#2563EB';
}

export class BrowserGitHubRepositoryProvider implements GitHubRepositoryProvider {
  private isSyncLocked = false;
  private progressListeners = new Set<(state: SyncProgressState) => void>();
  private progressState: SyncProgressState = {
    isRunning: false,
    currentCategoryName: null,
    currentQuery: null,
    completedCategories: 0,
    totalCategories: 0,
    lastGlobalSyncAt: null,
    message: null,
  };

  subscribeProgress(listener: (state: SyncProgressState) => void): () => void {
    this.progressListeners.add(listener);
    listener(this.progressState);
    return () => {
      this.progressListeners.delete(listener);
    };
  }

  private emitProgress(patch: Partial<SyncProgressState>) {
    this.progressState = { ...this.progressState, ...patch };
    this.progressListeners.forEach((fn) => fn(this.progressState));
  }

  getIsSyncRunning(): boolean {
    return this.isSyncLocked;
  }

  getRepositories(): GitHubRepository[] {
    return loadRepositories();
  }

  getCategories(): GitHubCategory[] {
    return loadCategories();
  }

  getAssociations(): Record<number, CategoryAssociation> {
    return loadAssociations();
  }

  getSavedRepoIds(): number[] {
    return loadSavedRepoIds();
  }

  getSettings(): GitHubSettings {
    return loadSettings();
  }

  getSyncHistory(): SyncHistoryEntry[] {
    return loadSyncHistory();
  }

  getStarSnapshots(): Record<number, StarSnapshot[]> {
    return loadStarSnapshots();
  }

  getRateLimits(): RateLimitState {
    return loadRateLimits();
  }

  toggleSaveRepo(repoId: number): number[] {
    const current = loadSavedRepoIds();
    const exists = current.includes(repoId);
    const next = exists ? current.filter((id) => id !== repoId) : [repoId, ...current];
    saveSavedRepoIds(next);
    return next;
  }

  saveCategoriesList(categories: GitHubCategory[]): GitHubCategory[] {
    const assoc = loadAssociations();
    const recounted = recalculateCategoryCounts(categories, assoc);
    saveCategories(recounted);
    return recounted;
  }

  updateCategoryAssociationManual(
    repoId: number,
    categoryId: string,
    include: boolean
  ): {
    associations: Record<number, CategoryAssociation>;
    categories: GitHubCategory[];
  } {
    const associations = loadAssociations();
    const existing: CategoryAssociation = associations[repoId] || {
      repoId,
      categoryIds: [],
      manualAddedCategoryIds: [],
      manualExcludedCategoryIds: [],
      matchedQueries: [],
      updatedAt: new Date().toISOString(),
    };

    const nextCats = new Set(existing.categoryIds);
    const nextAdded = new Set(existing.manualAddedCategoryIds);
    const nextExcluded = new Set(existing.manualExcludedCategoryIds);

    if (include) {
      nextCats.add(categoryId);
      nextAdded.add(categoryId);
      nextExcluded.delete(categoryId);
    } else {
      nextCats.delete(categoryId);
      nextAdded.delete(categoryId);
      nextExcluded.add(categoryId);
    }

    associations[repoId] = {
      ...existing,
      categoryIds: Array.from(nextCats),
      manualAddedCategoryIds: Array.from(nextAdded),
      manualExcludedCategoryIds: Array.from(nextExcluded),
      updatedAt: new Date().toISOString(),
    };

    saveAssociations(associations);
    const categories = recalculateCategoryCounts(loadCategories(), associations);
    saveCategories(categories);
    return { associations, categories };
  }

  updateSettings(next: GitHubSettings): GitHubSettings {
    saveSettings(next);
    return next;
  }

  private mergeSearchResults(
    category: GitHubCategory,
    query: string,
    fetched: GitHubRepository[],
    repoMap: Map<number, GitHubRepository>,
    associations: Record<number, CategoryAssociation>
  ): { added: number; updated: number; duplicatesRemoved: number } {
    let added = 0;
    let updated = 0;
    let duplicatesRemoved = 0;
    const seenInQuery = new Set<number>();

    fetched.forEach((incoming) => {
      if (seenInQuery.has(incoming.id)) {
        duplicatesRemoved += 1;
        return;
      }
      seenInQuery.add(incoming.id);

      if (!passesCategoryRelevance(incoming, category)) {
        return;
      }

      const prev = repoMap.get(incoming.id);
      if (!prev) {
        repoMap.set(incoming.id, incoming);
        added += 1;
      } else {
        // Deduplicate: update canonical record while keeping original discoveredAt
        repoMap.set(incoming.id, {
          ...incoming,
          discoveredAt: prev.discoveredAt,
        });
        updated += 1;
      }

      const prevAssoc = associations[incoming.id] || {
        repoId: incoming.id,
        categoryIds: [],
        manualAddedCategoryIds: [],
        manualExcludedCategoryIds: [],
        matchedQueries: [],
        updatedAt: new Date().toISOString(),
      };

      const isManuallyExcluded = prevAssoc.manualExcludedCategoryIds.includes(
        category.id
      );
      const nextCatIds = new Set(prevAssoc.categoryIds);
      if (!isManuallyExcluded) {
        nextCatIds.add(category.id);
      }
      prevAssoc.manualAddedCategoryIds.forEach((cid) => nextCatIds.add(cid));

      const nextQueries = Array.from(
        new Set([...prevAssoc.matchedQueries, query])
      ).slice(0, 12);

      associations[incoming.id] = {
        ...prevAssoc,
        categoryIds: Array.from(nextCatIds),
        matchedQueries: nextQueries,
        updatedAt: new Date().toISOString(),
      };
    });

    return { added, updated, duplicatesRemoved };
  }

  private async runCategoryQueries(
    category: GitHubCategory,
    repoMap: Map<number, GitHubRepository>,
    associations: Record<number, CategoryAssociation>,
    maxQueriesForBatch?: number
  ): Promise<{
    status: SyncStatus;
    added: number;
    updated: number;
    error: string | null;
    historyEntries: SyncHistoryEntry[];
    newlyTouchedRepos: GitHubRepository[];
  }> {
    const validQueries = category.searchQueries.filter(
      (q) => validateGitHubQuery(q).valid
    );
    const queriesToRun = maxQueriesForBatch
      ? validQueries.slice(0, maxQueriesForBatch)
      : validQueries;

    let totalAdded = 0;
    let totalUpdated = 0;
    let errorCount = 0;
    let rateLimited = false;
    let lastError: string | null = null;
    const historyEntries: SyncHistoryEntry[] = [];
    const touchedIds = new Set<number>();

    if (queriesToRun.length === 0) {
      return {
        status: 'error',
        added: 0,
        updated: 0,
        error: 'No valid search queries configured for this category.',
        historyEntries: [],
        newlyTouchedRepos: [],
      };
    }

    for (const rawQuery of queriesToRun) {
      this.emitProgress({
        currentCategoryName: category.name,
        currentQuery: rawQuery,
      });

      const startedMs = Date.now();
      const startedAt = new Date(startedMs).toISOString();
      const effectiveQuery = buildEffectiveSearchQuery(rawQuery, category);

      try {
        const res = await searchGitHubRepositories({
          q: effectiveQuery,
          sort: 'stars',
          order: 'desc',
          perPage: Math.min(100, Math.max(5, category.maximumResults)),
          page: 1,
        });

        const merged = this.mergeSearchResults(
          category,
          rawQuery,
          res.items,
          repoMap,
          associations
        );

        res.items.forEach((r) => {
          if (repoMap.has(r.id)) touchedIds.add(r.id);
        });

        totalAdded += merged.added;
        totalUpdated += merged.updated;

        const endedMs = Date.now();
        historyEntries.push({
          id: `sync-${startedMs}-${Math.random().toString(36).slice(2, 7)}`,
          categoryId: category.id,
          categoryName: category.name,
          query: effectiveQuery,
          startedAt,
          endedAt: new Date(endedMs).toISOString(),
          durationMs: endedMs - startedMs,
          retrievedCount: res.items.length,
          newCount: merged.added,
          updatedCount: merged.updated,
          duplicatesRemoved: merged.duplicatesRemoved,
          errorCount: 0,
          status: 'success',
          errorMessage: null,
        });
      } catch (err) {
        errorCount += 1;
        const msg = err instanceof Error ? err.message : 'GitHub request failed';
        lastError = msg;
        const isRl = err instanceof GitHubApiError && err.isRateLimited;
        if (isRl) rateLimited = true;

        const endedMs = Date.now();
        historyEntries.push({
          id: `sync-${startedMs}-${Math.random().toString(36).slice(2, 7)}`,
          categoryId: category.id,
          categoryName: category.name,
          query: effectiveQuery,
          startedAt,
          endedAt: new Date(endedMs).toISOString(),
          durationMs: endedMs - startedMs,
          retrievedCount: 0,
          newCount: 0,
          updatedCount: 0,
          duplicatesRemoved: 0,
          errorCount: 1,
          status: isRl ? 'rate_limited' : 'error',
          errorMessage: msg,
        });

        if (isRl) {
          // Stop immediately when rate limited — preserve partial progress
          break;
        }
      }
    }

    const status: SyncStatus = rateLimited
      ? 'rate_limited'
      : errorCount === queriesToRun.length
        ? 'error'
        : errorCount > 0
          ? 'partial'
          : 'success';

    const newlyTouchedRepos = Array.from(touchedIds)
      .map((id) => repoMap.get(id))
      .filter((r): r is GitHubRepository => Boolean(r));

    return {
      status,
      added: totalAdded,
      updated: totalUpdated,
      error: lastError,
      historyEntries,
      newlyTouchedRepos,
    };
  }

  async syncCategory(categoryId: string): Promise<{
    status: SyncStatus;
    added: number;
    updated: number;
    error: string | null;
  }> {
    if (this.isSyncLocked) {
      return {
        status: 'partial',
        added: 0,
        updated: 0,
        error: 'A synchronization job is already running.',
      };
    }

    const categories = loadCategories();
    const target = categories.find((c) => c.id === categoryId);
    if (!target) {
      return {
        status: 'error',
        added: 0,
        updated: 0,
        error: 'Category not found.',
      };
    }

    this.isSyncLocked = true;
    this.emitProgress({
      isRunning: true,
      currentCategoryName: target.name,
      currentQuery: null,
      completedCategories: 0,
      totalCategories: 1,
      message: `Synchronizing ${target.name}...`,
    });

    try {
      const repoMap = new Map<number, GitHubRepository>(
        loadRepositories().map((r) => [r.id, r])
      );
      const associations = loadAssociations();

      const res = await this.runCategoryQueries(target, repoMap, associations);

      const allRepos = Array.from(repoMap.values());
      saveRepositories(allRepos);
      saveAssociations(associations);
      if (res.newlyTouchedRepos.length > 0) {
        recordStarSnapshots(res.newlyTouchedRepos);
      }
      if (res.historyEntries.length > 0) {
        appendSyncHistory(res.historyEntries);
      }

      const now = new Date().toISOString();
      const updatedCategories = recalculateCategoryCounts(
        categories.map((cat) =>
          cat.id === categoryId
            ? {
                ...cat,
                lastSyncedAt: res.status === 'success' || res.added > 0 || res.updated > 0 ? now : cat.lastSyncedAt,
                lastSyncStatus: res.status,
                lastSyncError: res.error,
                updatedAt: now,
              }
            : cat
        ),
        associations
      );
      saveCategories(updatedCategories);

      this.emitProgress({
        isRunning: false,
        currentCategoryName: null,
        currentQuery: null,
        completedCategories: 1,
        totalCategories: 1,
        lastGlobalSyncAt: now,
        message:
          res.status === 'rate_limited'
            ? res.error
            : `Synced ${target.name}: +${res.added} new, ${res.updated} updated.`,
      });

      return {
        status: res.status,
        added: res.added,
        updated: res.updated,
        error: res.error,
      };
    } finally {
      this.isSyncLocked = false;
    }
  }

  async syncDueCategories(forceAll = false): Promise<{
    syncedCategories: number;
    rateLimited: boolean;
    error: string | null;
  }> {
    if (this.isSyncLocked) {
      return {
        syncedCategories: 0,
        rateLimited: false,
        error: 'Synchronization already in progress.',
      };
    }

    const categories = loadCategories();
    const queue = categories.filter((cat) =>
      forceAll ? cat.enabled : isCategoryDueForRefresh(cat)
    );

    if (queue.length === 0) {
      return { syncedCategories: 0, rateLimited: false, error: null };
    }

    this.isSyncLocked = true;
    this.emitProgress({
      isRunning: true,
      currentCategoryName: queue[0].name,
      currentQuery: null,
      completedCategories: 0,
      totalCategories: queue.length,
      message: `Starting synchronization for ${queue.length} categories...`,
    });

    let syncedCount = 0;
    let rateLimited = false;
    let lastError: string | null = null;

    try {
      const repoMap = new Map<number, GitHubRepository>(
        loadRepositories().map((r) => [r.id, r])
      );
      const associations = loadAssociations();
      const updatedMap = new Map(categories.map((c) => [c.id, c]));

      // In multi-category batch sync, run top 1 focused query per category when >3 categories queued
      // so unauthenticated 10 req/min Search quota covers up to ~9-10 categories cleanly before reset.
      const queriesPerCategory = queue.length > 3 ? 1 : undefined;

      for (let i = 0; i < queue.length; i += 1) {
        const cat = queue[i];
        const res = await this.runCategoryQueries(
          cat,
          repoMap,
          associations,
          queriesPerCategory
        );

        if (res.newlyTouchedRepos.length > 0) {
          recordStarSnapshots(res.newlyTouchedRepos);
        }
        if (res.historyEntries.length > 0) {
          appendSyncHistory(res.historyEntries);
        }

        const now = new Date().toISOString();
        updatedMap.set(cat.id, {
          ...cat,
          lastSyncedAt:
            res.status === 'success' || res.added > 0 || res.updated > 0
              ? now
              : cat.lastSyncedAt,
          lastSyncStatus: res.status,
          lastSyncError: res.error,
          updatedAt: now,
        });

        syncedCount += 1;
        this.emitProgress({
          completedCategories: syncedCount,
          totalCategories: queue.length,
        });

        // Persist incrementally after each category so cached data is never lost
        saveRepositories(Array.from(repoMap.values()));
        saveAssociations(associations);
        saveCategories(
          recalculateCategoryCounts(Array.from(updatedMap.values()), associations)
        );

        if (res.status === 'rate_limited') {
          rateLimited = true;
          lastError = res.error;
          break;
        }
        if (res.error) lastError = res.error;
      }

      const finishedAt = new Date().toISOString();
      this.emitProgress({
        isRunning: false,
        currentCategoryName: null,
        currentQuery: null,
        lastGlobalSyncAt: finishedAt,
        message: rateLimited
          ? `Paused by GitHub Search API rate limit after ${syncedCount} categories. Cached data preserved.`
          : `Completed sync for ${syncedCount} categories.`,
      });

      return { syncedCategories: syncedCount, rateLimited, error: lastError };
    } finally {
      this.isSyncLocked = false;
    }
  }

  async fetchRepositoryDetails(
    owner: string,
    repo: string
  ): Promise<GitHubRepository> {
    const fresh = await fetchGitHubRepo(owner, repo);
    const existingList = loadRepositories();
    const idx = existingList.findIndex(
      (r) => r.id === fresh.id || r.fullName.toLowerCase() === fresh.fullName.toLowerCase()
    );
    if (idx >= 0) {
      const merged: GitHubRepository = {
        ...fresh,
        discoveredAt: existingList[idx].discoveredAt,
      };
      existingList[idx] = merged;
      saveRepositories(existingList);
      recordStarSnapshots([merged]);
      return merged;
    }
    return fresh;
  }

  async fetchRepositoryReadme(owner: string, repo: string): Promise<string | null> {
    return fetchGitHubRepoReadme(owner, repo);
  }

  async fetchRepositoryReleases(
    owner: string,
    repo: string
  ): Promise<GitHubReleaseItem[]> {
    return fetchGitHubRepoReleases(owner, repo);
  }

  async fetchRepositoryContributors(
    owner: string,
    repo: string
  ): Promise<GitHubContributorItem[]> {
    return fetchGitHubRepoContributors(owner, repo);
  }

  async fetchRepositoryLanguages(
    owner: string,
    repo: string
  ): Promise<Record<string, number>> {
    return fetchGitHubRepoLanguages(owner, repo);
  }
}

export const githubProvider = new BrowserGitHubRepositoryProvider();
