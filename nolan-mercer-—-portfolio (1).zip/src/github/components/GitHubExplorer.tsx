import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Bookmark,
  CheckSquare,
  Columns3,
  Download,
  ExternalLink,
  GitFork,
  LayoutGrid,
  RefreshCw,
  Search,
  Settings,
  Star,
  Table2,
  X,
} from 'lucide-react';
import {
  getLanguageColor,
  getNextScheduledSyncMs,
  githubProvider,
  isCategoryDueForRefresh,
} from '../engine';
import { exportRepositoriesToCsv } from '../exportUtils';
import {
  loadExplorerViewState,
  saveExplorerViewState,
} from '../storage';
import {
  CategoryAssociation,
  GitHubCategory,
  GitHubExplorerSubTab,
  GitHubExplorerViewState,
  GitHubRepository,
  GitHubSettings,
  RateLimitState,
  StarSnapshot,
  SyncHistoryEntry,
  SyncProgressState,
} from '../types';
import { CategoryManagementView } from './CategoryManagementView';
import {
  DiscoverySettingsView,
  SyncHistoryView,
} from './SettingsAndHistoryView';

interface GitHubExplorerProps {
  onNavigate: (path: string) => void;
  initialSubTab?: GitHubExplorerSubTab;
}

const PAGE_SIZE = 12;

export const GitHubExplorer: React.FC<GitHubExplorerProps> = ({
  onNavigate,
  initialSubTab,
}) => {
  const [viewState, setViewState] = useState<GitHubExplorerViewState>(() => {
    const saved = loadExplorerViewState();
    return initialSubTab ? { ...saved, subTab: initialSubTab } : saved;
  });

  useEffect(() => {
    if (initialSubTab && initialSubTab !== viewState.subTab) {
      setViewState((prev) => ({ ...prev, subTab: initialSubTab, page: 1 }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialSubTab]);

  useEffect(() => {
    saveExplorerViewState(viewState);
  }, [viewState]);

  const [repositories, setRepositories] = useState<GitHubRepository[]>(() =>
    githubProvider.getRepositories()
  );
  const [categories, setCategories] = useState<GitHubCategory[]>(() =>
    githubProvider.getCategories()
  );
  const [associations, setAssociations] = useState<
    Record<number, CategoryAssociation>
  >(() => githubProvider.getAssociations());
  const [savedIds, setSavedIds] = useState<number[]>(() =>
    githubProvider.getSavedRepoIds()
  );
  const [settings, setSettings] = useState<GitHubSettings>(() =>
    githubProvider.getSettings()
  );
  const [syncHistory, setSyncHistory] = useState<SyncHistoryEntry[]>(() =>
    githubProvider.getSyncHistory()
  );
  const [starSnapshots, setStarSnapshots] = useState<
    Record<number, StarSnapshot[]>
  >(() => githubProvider.getStarSnapshots());
  const [rateLimits, setRateLimits] = useState<RateLimitState>(() =>
    githubProvider.getRateLimits()
  );
  const [progress, setProgress] = useState<SyncProgressState>({
    isRunning: false,
    currentCategoryName: null,
    currentQuery: null,
    completedCategories: 0,
    totalCategories: 0,
    lastGlobalSyncAt: null,
    message: null,
  });

  const [selectedRowIds, setSelectedRowIds] = useState<number[]>([]);
  const [showColumnMenu, setShowColumnMenu] = useState(false);
  const [visibleCols, setVisibleCols] = useState({
    category: true,
    language: true,
    stars: true,
    forks: true,
    issues: true,
    created: true,
    updated: true,
  });

  const reloadAllFromStorage = useCallback(() => {
    setRepositories(githubProvider.getRepositories());
    setCategories(githubProvider.getCategories());
    setAssociations(githubProvider.getAssociations());
    setSavedIds(githubProvider.getSavedRepoIds());
    setSettings(githubProvider.getSettings());
    setSyncHistory(githubProvider.getSyncHistory());
    setStarSnapshots(githubProvider.getStarSnapshots());
    setRateLimits(githubProvider.getRateLimits());
  }, []);

  useEffect(() => {
    return githubProvider.subscribeProgress((state) => {
      setProgress(state);
      if (!state.isRunning) {
        reloadAllFromStorage();
      }
    });
  }, [reloadAllFromStorage]);

  // Automatic synchronization (visibility-aware, checks due intervals without fake timers)
  useEffect(() => {
    const checkAndSyncDue = () => {
      if (document.visibilityState === 'hidden') return;
      const currentSettings = githubProvider.getSettings();
      if (!currentSettings.autoRefreshEnabled) return;
      if (githubProvider.getIsSyncRunning()) return;

      const cats = githubProvider.getCategories();
      const anyDue = cats.some((c) => isCategoryDueForRefresh(c));
      if (anyDue) {
        void githubProvider.syncDueCategories(false).then(reloadAllFromStorage);
      }
    };

    // Run on initial mount if any enabled category is due (e.g. first visit)
    checkAndSyncDue();

    const intervalId = window.setInterval(checkAndSyncDue, 5 * 60 * 1000);
    const onVisChange = () => {
      if (document.visibilityState === 'visible') {
        checkAndSyncDue();
      }
    };
    document.addEventListener('visibilitychange', onVisChange);

    return () => {
      window.clearInterval(intervalId);
      document.removeEventListener('visibilitychange', onVisChange);
    };
  }, [reloadAllFromStorage]);

  const handleSubTabChange = (subTab: GitHubExplorerSubTab) => {
    setViewState((prev) => ({ ...prev, subTab, page: 1 }));
    const path =
      subTab === 'discover'
        ? '/knowledge-hub/github'
        : `/knowledge-hub/github/${subTab}`;
    onNavigate(path);
  };

  const handleManualRefresh = async () => {
    if (viewState.selectedCategoryIds.length === 1) {
      await githubProvider.syncCategory(viewState.selectedCategoryIds[0]);
    } else {
      await githubProvider.syncDueCategories(true);
    }
    reloadAllFromStorage();
  };

  const handleSyncSingleCategory = async (categoryId: string) => {
    await githubProvider.syncCategory(categoryId);
    reloadAllFromStorage();
  };

  const handleToggleCategoryFilter = (catId: string) => {
    setViewState((prev) => {
      const exists = prev.selectedCategoryIds.includes(catId);
      const next = exists
        ? prev.selectedCategoryIds.filter((id) => id !== catId)
        : [...prev.selectedCategoryIds, catId];
      return { ...prev, selectedCategoryIds: next, page: 1 };
    });
  };

  const categoryNameById = useMemo(
    () => new Map(categories.map((c) => [c.id, c.name])),
    [categories]
  );

  const enabledCategories = useMemo(
    () => categories.filter((c) => c.enabled),
    [categories]
  );

  const availableLanguages = useMemo(() => {
    const set = new Set<string>();
    repositories.forEach((r) => {
      if (r.language) set.add(r.language);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [repositories]);

  const lastSuccessfulSync = useMemo(() => {
    const times = categories
      .map((c) => c.lastSyncedAt)
      .filter((t): t is string => Boolean(t))
      .sort()
      .reverse();
    return times[0] || null;
  }, [categories]);

  const nextScheduledMs = useMemo(
    () => getNextScheduledSyncMs(categories, settings),
    [categories, settings]
  );

  // Derived real overview metrics
  const overviewMetrics = useMemo(() => {
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
    const recentCreatedCount = repositories.filter(
      (r) => new Date(r.createdAt).getTime() >= thirtyDaysAgo
    ).length;
    const popularCount = repositories.filter(
      (r) => r.stargazersCount >= 100
    ).length;

    return {
      totalDiscovered: repositories.length,
      recentCreatedCount,
      popularCount,
      savedCount: savedIds.length,
      activeCategories: enabledCategories.length,
    };
  }, [repositories, savedIds.length, enabledCategories.length]);

  const getRepoStarDelta = useCallback(
    (repoId: number): { delta: number; prevTime: string } | null => {
      const snaps = starSnapshots[repoId];
      if (!snaps || snaps.length < 2) return null;
      const prev = snaps[snaps.length - 2];
      const latest = snaps[snaps.length - 1];
      return {
        delta: latest.stars - prev.stars,
        prevTime: prev.capturedAt,
      };
    },
    [starSnapshots]
  );

  // Filtered & sorted repositories for Discover / Recently Added / Trending / Saved
  const filteredRepositories = useMemo(() => {
    const q = viewState.searchQuery.trim().toLowerCase();
    const now = Date.now();

    const filtered = repositories.filter((repo) => {
      // Saved filter
      if (viewState.subTab === 'saved' && !savedIds.includes(repo.id)) {
        return false;
      }

      // Multi-select category filter
      if (viewState.selectedCategoryIds.length > 0) {
        const assocCats = associations[repo.id]?.categoryIds || [];
        const matchesCat = viewState.selectedCategoryIds.some((cid) =>
          assocCats.includes(cid)
        );
        if (!matchesCat) return false;
      }

      // Language filter
      if (
        viewState.languageFilter !== 'all' &&
        (repo.language || '') !== viewState.languageFilter
      ) {
        return false;
      }

      // Minimum stars filter (used in Trending / Discover)
      if (viewState.minStarsFilter > 0 && repo.stargazersCount < viewState.minStarsFilter) {
        return false;
      }

      // Recently Added creation window
      if (viewState.subTab === 'recently-added') {
        const createdMs = new Date(repo.createdAt).getTime();
        if (viewState.recentWindow === '24h' && now - createdMs > 24 * 3600 * 1000) {
          return false;
        }
        if (viewState.recentWindow === '7d' && now - createdMs > 7 * 24 * 3600 * 1000) {
          return false;
        }
        if (viewState.recentWindow === '30d' && now - createdMs > 30 * 24 * 3600 * 1000) {
          return false;
        }
        if (viewState.recentWindow === '90d' && now - createdMs > 90 * 24 * 3600 * 1000) {
          return false;
        }
        if (viewState.recentWindow === 'custom') {
          if (viewState.customDateFrom) {
            const fromMs = new Date(viewState.customDateFrom).getTime();
            if (createdMs < fromMs) return false;
          }
          if (viewState.customDateTo) {
            const toMs = new Date(viewState.customDateTo).getTime() + 86400000;
            if (createdMs > toMs) return false;
          }
        }
      }

      if (!q) return true;
      return (
        repo.fullName.toLowerCase().includes(q) ||
        (repo.description || '').toLowerCase().includes(q) ||
        (repo.language || '').toLowerCase().includes(q) ||
        repo.topics.some((t) => t.toLowerCase().includes(q))
      );
    });

    const sortKey =
      viewState.subTab === 'recently-added' ? 'created' : viewState.sortBy;
    const dir = viewState.sortOrder === 'asc' ? 1 : -1;

    return [...filtered].sort((a, b) => {
      if (sortKey === 'stars') return (a.stargazersCount - b.stargazersCount) * dir;
      if (sortKey === 'updated') {
        return (
          (new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime()) *
          dir
        );
      }
      if (sortKey === 'created') {
        return (
          (new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()) *
          dir
        );
      }
      return a.fullName.localeCompare(b.fullName) * dir;
    });
  }, [
    repositories,
    savedIds,
    associations,
    viewState,
  ]);

  const totalPages = Math.max(
    1,
    Math.ceil(filteredRepositories.length / PAGE_SIZE)
  );
  const currentPage = Math.min(viewState.page, totalPages);
  const pagedRepositories = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredRepositories.slice(start, start + PAGE_SIZE);
  }, [filteredRepositories, currentPage]);

  const handleOpenRepoDetail = (repo: GitHubRepository) => {
    const [owner, name] = repo.fullName.split('/');
    if (owner && name) {
      onNavigate(
        `/knowledge-hub/github/repositories/${encodeURIComponent(
          owner
        )}/${encodeURIComponent(name)}`
      );
    }
  };

  const handleToggleRowSelect = (repoId: number) => {
    setSelectedRowIds((prev) =>
      prev.includes(repoId)
        ? prev.filter((id) => id !== repoId)
        : [...prev, repoId]
    );
  };

  const isRepoListView =
    viewState.subTab === 'discover' ||
    viewState.subTab === 'recently-added' ||
    viewState.subTab === 'trending' ||
    viewState.subTab === 'saved';

  return (
    <div className="space-y-6">
      {/* Explorer Header + Sub-Navigation */}
      <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-5 sm:p-6 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display text-2xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA]">
              GitHub Explorer
            </h2>
            <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400">
              Discover repositories, explore emerging technologies and track projects worth following.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={progress.isRunning}
              onClick={() => void handleManualRefresh()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 disabled:opacity-50 text-white transition-colors cursor-pointer whitespace-nowrap"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${progress.isRunning ? 'animate-spin' : ''}`}
              />
              <span>
                {viewState.selectedCategoryIds.length === 1
                  ? 'Sync Selected Category'
                  : 'Refresh Repositories'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => handleSubTabChange('settings')}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] cursor-pointer"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Settings</span>
            </button>

            {isRepoListView && (
              <div className="inline-flex items-center p-0.5 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
                <button
                  type="button"
                  onClick={() =>
                    setViewState((p) => ({ ...p, viewMode: 'grid' }))
                  }
                  aria-label="Grid View"
                  className={`p-1.5 rounded-md cursor-pointer ${
                    viewState.viewMode === 'grid'
                      ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                      : 'text-zinc-500'
                  }`}
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setViewState((p) => ({ ...p, viewMode: 'table' }))
                  }
                  aria-label="Table View"
                  className={`p-1.5 rounded-md cursor-pointer ${
                    viewState.viewMode === 'table'
                      ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                      : 'text-zinc-500'
                  }`}
                >
                  <Table2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Sub-Tabs Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-zinc-200 dark:border-zinc-800">
          <div className="inline-flex flex-wrap items-center gap-1 p-1 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
            {(
              [
                ['discover', 'Discover'],
                ['recently-added', 'Recently Added'],
                ['trending', 'Trending'],
                ['saved', `Saved (${savedIds.length})`],
                ['categories', `Categories (${categories.length})`],
                ['settings', 'Settings'],
                ['sync-history', 'Sync History'],
              ] as Array<[GitHubExplorerSubTab, string]>
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => handleSubTabChange(key)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  viewState.subTab === key
                    ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Sync Status & Rate-Limit Strip */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] font-mono text-zinc-500 dark:text-zinc-400 tabular-nums">
            <span>
              Last sync:{' '}
              {lastSuccessfulSync
                ? new Date(lastSuccessfulSync).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })
                : 'Not yet synced'}
            </span>
            <span>
              Next:{' '}
              {nextScheduledMs
                ? new Date(nextScheduledMs).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })
                : 'Manual'}
            </span>
            <span>
              Search Quota: {rateLimits.search.remaining ?? '—'}/
              {rateLimits.search.limit ?? 10}
            </span>
          </div>
        </div>

        {/* Live Progress or Rate-Limit Banner */}
        {(progress.isRunning || progress.message) && (
          <div className="px-4 py-2.5 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              {progress.isRunning ? (
                <RefreshCw className="w-3.5 h-3.5 text-[#2563EB] animate-spin shrink-0" />
              ) : (
                <AlertTriangle className="w-3.5 h-3.5 text-[#2563EB] shrink-0" />
              )}
              <span className="truncate text-[#09090B] dark:text-[#FAFAFA]">
                {progress.isRunning
                  ? `Syncing ${progress.currentCategoryName || ''} (${progress.completedCategories}/${progress.totalCategories}) — ${progress.currentQuery || ''}`
                  : progress.message}
              </span>
            </div>
            {progress.isRunning && progress.totalCategories > 0 && (
              <span className="font-mono text-[11px] text-zinc-500 tabular-nums">
                {Math.round(
                  (progress.completedCategories / progress.totalCategories) * 100
                )}
                %
              </span>
            )}
          </div>
        )}
      </div>

      {/* Overview Metrics Row (6 Live Stored Metrics) */}
      {isRepoListView && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            ['Total Discovered', String(overviewMetrics.totalDiscovered)],
            ['Created (30d)', String(overviewMetrics.recentCreatedCount)],
            ['Popular (100+ ★)', String(overviewMetrics.popularCount)],
            ['Saved Repos', String(overviewMetrics.savedCount)],
            ['Active Categories', String(overviewMetrics.activeCategories)],
            [
              'Last Successful Sync',
              lastSuccessfulSync
                ? new Date(lastSuccessfulSync).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })
                : 'Never',
            ],
          ].map(([label, val]) => (
            <div
              key={label}
              className="p-4 rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-1"
            >
              <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                {label}
              </div>
              <div className="font-display text-xl font-bold text-[#09090B] dark:text-[#FAFAFA] tabular-nums">
                {val}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Sub-Views Routing */}
      {viewState.subTab === 'categories' ? (
        <CategoryManagementView
          categories={categories}
          syncHistory={syncHistory}
          isSyncRunning={progress.isRunning}
          onCategoriesChange={(next) => setCategories(next)}
          onSyncCategory={handleSyncSingleCategory}
          onViewCategoryResults={(catId) =>
            setViewState((p) => ({
              ...p,
              subTab: 'discover',
              selectedCategoryIds: [catId],
              page: 1,
            }))
          }
        />
      ) : viewState.subTab === 'settings' ? (
        <DiscoverySettingsView
          settings={settings}
          rateLimits={rateLimits}
          progress={progress}
          repositories={repositories}
          categories={categories}
          associations={associations}
          onUpdateSettings={(next) => setSettings(githubProvider.updateSettings(next))}
          onReplaceCategories={(next) =>
            setCategories(githubProvider.saveCategoriesList(next))
          }
          onClearCacheComplete={reloadAllFromStorage}
          onClearHistoryComplete={reloadAllFromStorage}
          onManualSyncAll={handleManualRefresh}
        />
      ) : viewState.subTab === 'sync-history' ? (
        <SyncHistoryView history={syncHistory} categories={categories} />
      ) : (
        /* Repository Discovery / Recently Added / Trending / Saved Views */
        <div className="space-y-5">
          {/* Multi-Select Category Filter + Search + View Controls */}
          <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-4 sm:p-5 space-y-4">
            {/* Multi-select 13+ Category Bar */}
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() =>
                  setViewState((p) => ({
                    ...p,
                    selectedCategoryIds: [],
                    page: 1,
                  }))
                }
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                  viewState.selectedCategoryIds.length === 0
                    ? 'bg-[#2563EB] border-[#2563EB] text-white'
                    : 'bg-[#FAFAFA] dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300'
                }`}
              >
                All Categories ({repositories.length})
              </button>

              {enabledCategories.map((cat) => {
                const active = viewState.selectedCategoryIds.includes(cat.id);
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => handleToggleCategoryFilter(cat.id)}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs rounded-lg border transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#2563EB]/10 border-[#2563EB] text-[#2563EB] dark:text-blue-400 font-medium'
                        : 'bg-[#FAFAFA] dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:border-zinc-300 dark:hover:border-zinc-700'
                    }`}
                  >
                    <span
                      className="w-2 h-2 rounded-full shrink-0"
                      style={{ backgroundColor: cat.color }}
                    />
                    <span>{cat.name}</span>
                    <span className="font-mono text-[11px] opacity-75 tabular-nums">
                      ({cat.repositoryCount})
                    </span>
                  </button>
                );
              })}

              {viewState.selectedCategoryIds.length > 0 && (
                <button
                  type="button"
                  onClick={() =>
                    setViewState((p) => ({
                      ...p,
                      selectedCategoryIds: [],
                      page: 1,
                    }))
                  }
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs text-zinc-500 hover:text-[#09090B] dark:hover:text-white cursor-pointer"
                >
                  <X className="w-3 h-3" />
                  <span>Clear filters</span>
                </button>
              )}
            </div>

            {/* Search, Sort, Language, Date Window, Export Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-zinc-100 dark:border-zinc-800">
              <div className="flex flex-wrap items-center gap-2.5 flex-1">
                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="search"
                    value={viewState.searchQuery}
                    onChange={(e) =>
                      setViewState((p) => ({
                        ...p,
                        searchQuery: e.target.value,
                        page: 1,
                      }))
                    }
                    placeholder="Search repositories, topics..."
                    className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
                  />
                </div>

                <select
                  value={viewState.languageFilter}
                  onChange={(e) =>
                    setViewState((p) => ({
                      ...p,
                      languageFilter: e.target.value,
                      page: 1,
                    }))
                  }
                  aria-label="Filter by programming language"
                  className="px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
                >
                  <option value="all">All Languages</option>
                  {availableLanguages.map((lang) => (
                    <option key={lang} value={lang}>
                      {lang}
                    </option>
                  ))}
                </select>

                {viewState.subTab === 'recently-added' && (
                  <>
                    <select
                      value={viewState.recentWindow}
                      onChange={(e) =>
                        setViewState((p) => ({
                          ...p,
                          recentWindow: e.target
                            .value as GitHubExplorerViewState['recentWindow'],
                          page: 1,
                        }))
                      }
                      aria-label="Creation date window"
                      className="px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
                    >
                      <option value="24h">Created: Last 24h</option>
                      <option value="7d">Created: Last 7 days</option>
                      <option value="30d">Created: Last 30 days</option>
                      <option value="90d">Created: Last 90 days</option>
                      <option value="custom">Custom Date Range</option>
                    </select>

                    {viewState.recentWindow === 'custom' && (
                      <div className="flex items-center gap-1.5 text-xs">
                        <input
                          type="date"
                          value={viewState.customDateFrom}
                          onChange={(e) =>
                            setViewState((p) => ({
                              ...p,
                              customDateFrom: e.target.value,
                            }))
                          }
                          className="px-2 py-1 rounded border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900"
                        />
                        <span>to</span>
                        <input
                          type="date"
                          value={viewState.customDateTo}
                          onChange={(e) =>
                            setViewState((p) => ({
                              ...p,
                              customDateTo: e.target.value,
                            }))
                          }
                          className="px-2 py-1 rounded border border-zinc-200 dark:border-zinc-800 bg-[#FAFAFA] dark:bg-zinc-900"
                        />
                      </div>
                    )}
                  </>
                )}

                {viewState.subTab === 'trending' && (
                  <label className="inline-flex items-center gap-1.5 text-xs">
                    <span className="text-zinc-500">Min ★:</span>
                    <input
                      type="number"
                      min={0}
                      value={viewState.minStarsFilter}
                      onChange={(e) =>
                        setViewState((p) => ({
                          ...p,
                          minStarsFilter: Math.max(0, Number(e.target.value) || 0),
                          page: 1,
                        }))
                      }
                      className="w-20 px-2 py-1.5 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs tabular-nums"
                    />
                  </label>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={viewState.sortBy}
                  onChange={(e) =>
                    setViewState((p) => ({
                      ...p,
                      sortBy: e.target.value as GitHubExplorerViewState['sortBy'],
                    }))
                  }
                  aria-label="Sort repositories"
                  className="px-3 py-1.5 text-xs rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
                >
                  <option value="stars">Sort: Most Stars</option>
                  <option value="updated">Sort: Recently Updated</option>
                  <option value="created">Sort: Recently Created</option>
                  <option value="name">Sort: Name</option>
                </select>

                {viewState.viewMode === 'table' && (
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setShowColumnMenu((v) => !v)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 cursor-pointer"
                    >
                      <Columns3 className="w-3.5 h-3.5" />
                      <span>Columns</span>
                    </button>
                    {showColumnMenu && (
                      <div className="absolute right-0 mt-1 w-44 p-2 rounded-xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 shadow-lg z-20 space-y-1 text-xs">
                        {Object.entries(visibleCols).map(([col, val]) => (
                          <label
                            key={col}
                            className="flex items-center gap-2 px-2 py-1 rounded hover:bg-zinc-100 dark:hover:bg-zinc-900 cursor-pointer capitalize"
                          >
                            <input
                              type="checkbox"
                              checked={val}
                              onChange={() =>
                                setVisibleCols((prev) => ({
                                  ...prev,
                                  [col]: !val,
                                }))
                              }
                              className="accent-[#2563EB]"
                            />
                            <span>{col}</span>
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <button
                  type="button"
                  disabled={filteredRepositories.length === 0}
                  onClick={() => {
                    const target =
                      selectedRowIds.length > 0
                        ? filteredRepositories.filter((r) =>
                            selectedRowIds.includes(r.id)
                          )
                        : filteredRepositories;
                    exportRepositoriesToCsv(
                      target,
                      categories,
                      associations,
                      `github-${viewState.subTab}.csv`
                    );
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] disabled:opacity-40 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>
                    {selectedRowIds.length > 0
                      ? `Export Selected (${selectedRowIds.length})`
                      : 'Export CSV'}
                  </span>
                </button>
              </div>
            </div>
          </div>

          {/* Empty / Results State */}
          {filteredRepositories.length === 0 ? (
            <div className="py-16 text-center rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 space-y-3 px-6">
              <p className="text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                {repositories.length === 0
                  ? 'No repositories synchronized yet'
                  : 'No repositories match the current filters'}
              </p>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-md mx-auto">
                {repositories.length === 0
                  ? 'Click Refresh Repositories above to discover live public projects from GitHub across your 13 configured categories.'
                  : 'Try clearing category filters, widening the creation date window, or switching back to Discover.'}
              </p>
              <div className="flex justify-center gap-2 pt-1">
                {repositories.length === 0 ? (
                  <button
                    type="button"
                    disabled={progress.isRunning}
                    onClick={() => void handleManualRefresh()}
                    className="px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] text-white cursor-pointer"
                  >
                    Run Initial GitHub Discovery
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() =>
                      setViewState((p) => ({
                        ...p,
                        selectedCategoryIds: [],
                        searchQuery: '',
                        languageFilter: 'all',
                        minStarsFilter: 0,
                        recentWindow: '90d',
                      }))
                    }
                    className="px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] text-white cursor-pointer"
                  >
                    Reset Filters
                  </button>
                )}
              </div>
            </div>
          ) : viewState.viewMode === 'grid' ? (
            /* GRID VIEW */
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {pagedRepositories.map((repo) => {
                const isSaved = savedIds.includes(repo.id);
                const repoCats = (associations[repo.id]?.categoryIds || [])
                  .map((id) => categoryNameById.get(id))
                  .filter((n): n is string => Boolean(n));
                const starDelta = getRepoStarDelta(repo.id);
                const isNewlyDiscovered =
                  Date.now() - new Date(repo.discoveredAt).getTime() <
                  24 * 3600 * 1000;

                return (
                  <article
                    key={repo.id}
                    className="p-5 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 hover:border-[#2563EB]/60 transition-colors flex flex-col justify-between gap-4"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-2.5 min-w-0">
                          {repo.owner.avatarUrl ? (
                            <img
                              src={repo.owner.avatarUrl}
                              alt={repo.owner.login}
                              referrerPolicy="no-referrer"
                              className="w-8 h-8 rounded-lg border border-zinc-200 dark:border-zinc-700 shrink-0"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-lg bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center font-mono text-xs shrink-0">
                              {repo.owner.login.slice(0, 2).toUpperCase()}
                            </div>
                          )}
                          <div className="min-w-0">
                            <button
                              type="button"
                              onClick={() => handleOpenRepoDetail(repo)}
                              className="font-display text-sm font-semibold text-[#09090B] dark:text-[#FAFAFA] hover:text-[#2563EB] dark:hover:text-blue-400 truncate block text-left cursor-pointer"
                            >
                              {repo.name}
                            </button>
                            <div className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                              {repo.owner.login}
                              {isNewlyDiscovered && viewState.subTab === 'recently-added'
                                ? ' · NEW discovery'
                                : ''}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() =>
                              setSavedIds(githubProvider.toggleSaveRepo(repo.id))
                            }
                            aria-label={isSaved ? 'Remove bookmark' : 'Bookmark repo'}
                            className={`p-1.5 rounded-md cursor-pointer ${
                              isSaved
                                ? 'text-[#2563EB] dark:text-blue-400'
                                : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
                            }`}
                          >
                            <Bookmark
                              className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`}
                            />
                          </button>
                          <a
                            href={repo.htmlUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            aria-label={`Open ${repo.fullName} on GitHub`}
                            className="p-1.5 rounded-md text-zinc-400 hover:text-[#2563EB] dark:hover:text-blue-400"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        </div>
                      </div>

                      <p className="text-xs text-zinc-600 dark:text-zinc-400 line-clamp-2 leading-relaxed">
                        {repo.description || 'No description provided.'}
                      </p>

                      {repoCats.length > 0 && (
                        <div className="text-[11px] font-medium text-[#2563EB] dark:text-blue-400 truncate">
                          {repoCats.join(' · ')}
                        </div>
                      )}

                      {repo.topics.length > 0 && (
                        <div className="text-[11px] font-mono text-zinc-500 dark:text-zinc-400 truncate">
                          {repo.topics.slice(0, 4).map((t) => `#${t}`).join(' ')}
                        </div>
                      )}
                    </div>

                    <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800/80 space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono tabular-nums text-zinc-600 dark:text-zinc-300">
                        <div className="flex items-center gap-3">
                          {repo.language && (
                            <span className="inline-flex items-center gap-1.5 font-sans">
                              <span
                                className="w-2 h-2 rounded-full"
                                style={{
                                  backgroundColor: getLanguageColor(repo.language),
                                }}
                              />
                              <span>{repo.language}</span>
                            </span>
                          )}
                          <span className="inline-flex items-center gap-1">
                            <Star className="w-3.5 h-3.5 text-amber-500" />
                            <span>{repo.stargazersCount.toLocaleString()}</span>
                          </span>
                          <span className="inline-flex items-center gap-1">
                            <GitFork className="w-3.5 h-3.5 text-zinc-400" />
                            <span>{repo.forksCount.toLocaleString()}</span>
                          </span>
                        </div>

                        {viewState.subTab === 'trending' && (
                          <span className="text-[11px] text-[#2563EB] dark:text-blue-400">
                            {starDelta
                              ? `${starDelta.delta >= 0 ? '+' : ''}${starDelta.delta} ★ since last snapshot`
                              : 'Popular'}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                        <span>
                          Created {new Date(repo.createdAt).toLocaleDateString()} · Updated{' '}
                          {new Date(repo.updatedAt).toLocaleDateString()}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleOpenRepoDetail(repo)}
                          className="font-medium text-[#2563EB] dark:text-blue-400 hover:underline cursor-pointer"
                        >
                          Details
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            /* TABLE VIEW */
            <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-[#FAFAFA] dark:bg-zinc-900/60 border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                      <th className="w-10 px-4 py-3">
                        <CheckSquare className="w-3.5 h-3.5 text-zinc-400" />
                      </th>
                      <th className="px-3 py-3">Repository</th>
                      {visibleCols.category && <th className="px-3 py-3">Category</th>}
                      {visibleCols.language && <th className="px-3 py-3">Language</th>}
                      {visibleCols.stars && (
                        <th className="px-3 py-3 text-right">Stars</th>
                      )}
                      {visibleCols.forks && (
                        <th className="px-3 py-3 text-right">Forks</th>
                      )}
                      {visibleCols.issues && (
                        <th className="px-3 py-3 text-right">Open Issues</th>
                      )}
                      {visibleCols.created && <th className="px-3 py-3">Created</th>}
                      {visibleCols.updated && (
                        <th className="px-3 py-3">Last Updated</th>
                      )}
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                    {pagedRepositories.map((repo) => {
                      const isSaved = savedIds.includes(repo.id);
                      const repoCats = (associations[repo.id]?.categoryIds || [])
                        .map((id) => categoryNameById.get(id))
                        .filter((n): n is string => Boolean(n));

                      return (
                        <tr
                          key={repo.id}
                          className="hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40"
                        >
                          <td className="px-4 py-3">
                            <input
                              type="checkbox"
                              checked={selectedRowIds.includes(repo.id)}
                              onChange={() => handleToggleRowSelect(repo.id)}
                              aria-label={`Select ${repo.fullName}`}
                              className="accent-[#2563EB]"
                            />
                          </td>
                          <td className="px-3 py-3 max-w-xs">
                            <button
                              type="button"
                              onClick={() => handleOpenRepoDetail(repo)}
                              className="font-semibold text-[#09090B] dark:text-[#FAFAFA] hover:text-[#2563EB] dark:hover:text-blue-400 text-left cursor-pointer block truncate"
                            >
                              {repo.fullName}
                            </button>
                            <span className="text-[11px] text-zinc-500 truncate block">
                              {repo.description || '—'}
                            </span>
                          </td>
                          {visibleCols.category && (
                            <td className="px-3 py-3 text-[11px] text-[#2563EB] dark:text-blue-400">
                              {repoCats.join(', ') || '—'}
                            </td>
                          )}
                          {visibleCols.language && (
                            <td className="px-3 py-3 whitespace-nowrap">
                              {repo.language || '—'}
                            </td>
                          )}
                          {visibleCols.stars && (
                            <td className="px-3 py-3 text-right font-mono tabular-nums">
                              {repo.stargazersCount.toLocaleString()}
                            </td>
                          )}
                          {visibleCols.forks && (
                            <td className="px-3 py-3 text-right font-mono tabular-nums text-zinc-500">
                              {repo.forksCount.toLocaleString()}
                            </td>
                          )}
                          {visibleCols.issues && (
                            <td className="px-3 py-3 text-right font-mono tabular-nums text-zinc-500">
                              {repo.openIssuesCount.toLocaleString()}
                            </td>
                          )}
                          {visibleCols.created && (
                            <td className="px-3 py-3 font-mono text-[11px] text-zinc-500 tabular-nums whitespace-nowrap">
                              {new Date(repo.createdAt).toLocaleDateString()}
                            </td>
                          )}
                          {visibleCols.updated && (
                            <td className="px-3 py-3 font-mono text-[11px] text-zinc-500 tabular-nums whitespace-nowrap">
                              {new Date(repo.updatedAt).toLocaleDateString()}
                            </td>
                          )}
                          <td className="px-4 py-3 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() =>
                                  setSavedIds(githubProvider.toggleSaveRepo(repo.id))
                                }
                                aria-label="Bookmark"
                                className={`p-1 rounded cursor-pointer ${
                                  isSaved ? 'text-[#2563EB]' : 'text-zinc-400'
                                }`}
                              >
                                <Bookmark
                                  className={`w-3.5 h-3.5 ${
                                    isSaved ? 'fill-current' : ''
                                  }`}
                                />
                              </button>
                              <a
                                href={repo.htmlUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-1 rounded text-zinc-400 hover:text-[#2563EB]"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Pagination */}
          {filteredRepositories.length > PAGE_SIZE && (
            <div className="flex items-center justify-between text-xs text-zinc-600 dark:text-zinc-400">
              <span className="font-mono tabular-nums">
                Showing {(currentPage - 1) * PAGE_SIZE + 1}–
                {Math.min(currentPage * PAGE_SIZE, filteredRepositories.length)} of{' '}
                {filteredRepositories.length}
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={currentPage <= 1}
                  onClick={() =>
                    setViewState((p) => ({
                      ...p,
                      page: Math.max(1, currentPage - 1),
                    }))
                  }
                  className="px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 disabled:opacity-40 cursor-pointer"
                >
                  Previous
                </button>
                <span className="px-2 font-mono tabular-nums">
                  {currentPage} / {totalPages}
                </span>
                <button
                  type="button"
                  disabled={currentPage >= totalPages}
                  onClick={() =>
                    setViewState((p) => ({
                      ...p,
                      page: Math.min(totalPages, currentPage + 1),
                    }))
                  }
                  className="px-3 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 disabled:opacity-40 cursor-pointer"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
