import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Edit3,
  Plus,
  RefreshCw,
  Trash2,
  X,
} from 'lucide-react';
import { validateGitHubQuery } from '../categories';
import { githubProvider } from '../engine';
import {
  GitHubCategory,
  RefreshIntervalMinutes,
  SyncHistoryEntry,
} from '../types';

interface CategoryManagementViewProps {
  categories: GitHubCategory[];
  syncHistory: SyncHistoryEntry[];
  isSyncRunning: boolean;
  onCategoriesChange: (next: GitHubCategory[]) => void;
  onSyncCategory: (categoryId: string) => Promise<void>;
  onViewCategoryResults: (categoryId: string) => void;
}

const INTERVAL_OPTIONS: Array<{ value: RefreshIntervalMinutes; label: string }> = [
  { value: 0, label: 'Manual only' },
  { value: 30, label: '30 minutes' },
  { value: 60, label: '1 hour' },
  { value: 180, label: '3 hours (Default)' },
  { value: 360, label: '6 hours' },
  { value: 720, label: '12 hours' },
  { value: 1440, label: '24 hours' },
];

const COLOR_SWATCHES = [
  '#2563EB',
  '#DC2626',
  '#059669',
  '#0284C7',
  '#D97706',
  '#4F46E5',
  '#0D9488',
  '#EA580C',
];

function slugify(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || `cat-${Date.now()}`;
}

export const CategoryManagementView: React.FC<CategoryManagementViewProps> = ({
  categories,
  syncHistory,
  isSyncRunning,
  onCategoriesChange,
  onSyncCategory,
  onViewCategoryResults,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  // Editor form state
  const [formName, setFormName] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formColor, setFormColor] = useState('#2563EB');
  const [formIcon, setFormIcon] = useState('folder');
  const [formEnabled, setFormEnabled] = useState(true);
  const [formQueries, setFormQueries] = useState<string[]>([]);
  const [newQueryInput, setNewQueryInput] = useState('');
  const [queryError, setQueryError] = useState<string | null>(null);
  const [formExcluded, setFormExcluded] = useState('');
  const [formMinStars, setFormMinStars] = useState(0);
  const [formMaxResults, setFormMaxResults] = useState(30);
  const [formCreatedDays, setFormCreatedDays] = useState<string>('');
  const [formUpdatedDays, setFormUpdatedDays] = useState<string>('365');
  const [formLanguages, setFormLanguages] = useState('');
  const [formInterval, setFormInterval] = useState<RefreshIntervalMinutes>(180);

  const editingCategory = useMemo(
    () => categories.find((c) => c.id === editingId) || null,
    [categories, editingId]
  );

  const categoryHistory = useMemo(() => {
    if (!editingId) return [];
    return syncHistory.filter((h) => h.categoryId === editingId).slice(0, 12);
  }, [syncHistory, editingId]);

  const startEdit = (cat: GitHubCategory) => {
    setIsCreating(false);
    setEditingId(cat.id);
    setFormName(cat.name);
    setFormDesc(cat.description);
    setFormColor(cat.color);
    setFormIcon(cat.icon);
    setFormEnabled(cat.enabled);
    setFormQueries([...cat.searchQueries]);
    setNewQueryInput('');
    setQueryError(null);
    setFormExcluded(cat.excludedKeywords.join(', '));
    setFormMinStars(cat.minimumStars);
    setFormMaxResults(cat.maximumResults);
    setFormCreatedDays(cat.createdWithinDays ? String(cat.createdWithinDays) : '');
    setFormUpdatedDays(cat.updatedWithinDays ? String(cat.updatedWithinDays) : '');
    setFormLanguages(cat.languages.join(', '));
    setFormInterval(cat.refreshIntervalMinutes);
  };

  const startCreate = () => {
    setEditingId(null);
    setIsCreating(true);
    setFormName('');
    setFormDesc('');
    setFormColor('#2563EB');
    setFormIcon('folder');
    setFormEnabled(true);
    setFormQueries([]);
    setNewQueryInput('');
    setQueryError(null);
    setFormExcluded('');
    setFormMinStars(5);
    setFormMaxResults(30);
    setFormCreatedDays('');
    setFormUpdatedDays('180');
    setFormLanguages('');
    setFormInterval(180);
  };

  const closeEditor = () => {
    setEditingId(null);
    setIsCreating(false);
    setQueryError(null);
  };

  const handleAddQuery = () => {
    const check = validateGitHubQuery(newQueryInput);
    if (!check.valid) {
      setQueryError(check.error);
      return;
    }
    const clean = newQueryInput.trim();
    if (formQueries.includes(clean)) {
      setQueryError('This query already exists in this category.');
      return;
    }
    setFormQueries((prev) => [...prev, clean]);
    setNewQueryInput('');
    setQueryError(null);
  };

  const handleUpdateQueryAt = (idx: number, val: string) => {
    setFormQueries((prev) => prev.map((q, i) => (i === idx ? val : q)));
  };

  const handleRemoveQueryAt = (idx: number) => {
    setFormQueries((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    const name = formName.trim();
    if (!name) return;

    if (formQueries.length === 0) {
      setQueryError('Add at least one valid GitHub search query.');
      return;
    }
    for (const q of formQueries) {
      const check = validateGitHubQuery(q);
      if (!check.valid) {
        setQueryError(`Invalid query "${q}": ${check.error}`);
        return;
      }
    }

    const excluded = formExcluded
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    const langs = formLanguages
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    const createdDays = Number(formCreatedDays) > 0 ? Number(formCreatedDays) : null;
    const updatedDays = Number(formUpdatedDays) > 0 ? Number(formUpdatedDays) : null;
    const now = new Date().toISOString();

    if (isCreating) {
      const baseSlug = slugify(name);
      const uniqueId = categories.some((c) => c.id === baseSlug)
        ? `${baseSlug}-${Date.now().toString(36)}`
        : baseSlug;

      const created: GitHubCategory = {
        id: uniqueId,
        name,
        slug: uniqueId,
        description: formDesc.trim() || `${name} GitHub repositories.`,
        icon: formIcon || 'folder',
        color: formColor,
        enabled: formEnabled,
        searchQueries: formQueries,
        excludedKeywords: excluded,
        minimumStars: Math.max(0, formMinStars),
        maximumResults: Math.min(100, Math.max(5, formMaxResults)),
        createdWithinDays: createdDays,
        updatedWithinDays: updatedDays,
        languages: langs,
        refreshIntervalMinutes: formInterval,
        lastSyncedAt: null,
        lastSyncStatus: 'idle',
        lastSyncError: null,
        repositoryCount: 0,
        createdAt: now,
        updatedAt: now,
      };
      const saved = githubProvider.saveCategoriesList([...categories, created]);
      onCategoriesChange(saved);
      closeEditor();
      return;
    }

    if (editingId) {
      const next = categories.map((cat) =>
        cat.id === editingId
          ? {
              ...cat,
              name,
              description: formDesc.trim() || cat.description,
              icon: formIcon || cat.icon,
              color: formColor,
              enabled: formEnabled,
              searchQueries: formQueries,
              excludedKeywords: excluded,
              minimumStars: Math.max(0, formMinStars),
              maximumResults: Math.min(100, Math.max(5, formMaxResults)),
              createdWithinDays: createdDays,
              updatedWithinDays: updatedDays,
              languages: langs,
              refreshIntervalMinutes: formInterval,
              updatedAt: now,
            }
          : cat
      );
      const saved = githubProvider.saveCategoriesList(next);
      onCategoriesChange(saved);
      closeEditor();
    }
  };

  const handleToggleEnabled = (catId: string) => {
    // Disabling stops future sync ONLY — never deletes stored repositories
    const next = categories.map((cat) =>
      cat.id === catId
        ? { ...cat, enabled: !cat.enabled, updatedAt: new Date().toISOString() }
        : cat
    );
    const saved = githubProvider.saveCategoriesList(next);
    onCategoriesChange(saved);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-bold text-[#09090B] dark:text-[#FAFAFA]">
            Category Management ({categories.length})
          </h2>
          <p className="text-xs text-zinc-600 dark:text-zinc-400">
            Configure independent search queries, excluded keywords, star thresholds,
            and refresh schedules per technology category.
          </p>
        </div>
        <button
          type="button"
          onClick={startCreate}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 self-start"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Category</span>
        </button>
      </div>

      {/* Category Create / Detail Edit Panel */}
      {(isCreating || editingCategory) && (
        <form
          onSubmit={handleSaveCategory}
          className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-6 space-y-6"
        >
          <div className="flex items-center justify-between gap-3 pb-4 border-b border-zinc-200 dark:border-zinc-800">
            <div>
              <h3 className="font-display text-lg font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                {isCreating ? 'New Discovery Category' : `Edit Category: ${editingCategory?.name}`}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Changes apply immediately to future discovery queries and relevance checks.
              </p>
            </div>
            <button
              type="button"
              onClick={closeEditor}
              aria-label="Close category editor"
              className="p-2 rounded-lg text-zinc-400 hover:text-[#09090B] dark:hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <label className="md:col-span-4 space-y-1 text-xs">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">Category Name *</span>
              <input
                type="text"
                required
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                placeholder="e.g. Keycloak"
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
              />
            </label>

            <label className="md:col-span-5 space-y-1 text-xs">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">Description</span>
              <input
                type="text"
                value={formDesc}
                onChange={(e) => setFormDesc(e.target.value)}
                placeholder="Scope & purpose of this category..."
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
              />
            </label>

            <div className="md:col-span-3 space-y-1 text-xs">
              <span className="block font-medium text-zinc-700 dark:text-zinc-300">Accent Color &amp; State</span>
              <div className="flex items-center justify-between gap-2 pt-1">
                <div className="flex items-center gap-1.5">
                  {COLOR_SWATCHES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setFormColor(c)}
                      aria-label={`Select color ${c}`}
                      className={`w-5 h-5 rounded-full cursor-pointer ${
                        formColor === c ? 'ring-2 ring-offset-2 ring-[#2563EB]' : ''
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
                <label className="inline-flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formEnabled}
                    onChange={(e) => setFormEnabled(e.target.checked)}
                    className="accent-[#2563EB]"
                  />
                  <span>Enabled</span>
                </label>
              </div>
            </div>

            <label className="md:col-span-2 space-y-1 text-xs">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">Min Stars</span>
              <input
                type="number"
                min={0}
                value={formMinStars}
                onChange={(e) => setFormMinStars(Math.max(0, Number(e.target.value) || 0))}
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs tabular-nums"
              />
            </label>

            <label className="md:col-span-2 space-y-1 text-xs">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">Max Results / Query</span>
              <input
                type="number"
                min={5}
                max={100}
                value={formMaxResults}
                onChange={(e) => setFormMaxResults(Math.min(100, Math.max(5, Number(e.target.value) || 30)))}
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs tabular-nums"
              />
            </label>

            <label className="md:col-span-2 space-y-1 text-xs">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">Created Within (days)</span>
              <input
                type="number"
                min={0}
                placeholder="Any"
                value={formCreatedDays}
                onChange={(e) => setFormCreatedDays(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs tabular-nums"
              />
            </label>

            <label className="md:col-span-2 space-y-1 text-xs">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">Updated Within (days)</span>
              <input
                type="number"
                min={0}
                placeholder="Any"
                value={formUpdatedDays}
                onChange={(e) => setFormUpdatedDays(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs tabular-nums"
              />
            </label>

            <label className="md:col-span-4 space-y-1 text-xs">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">Refresh Interval</span>
              <select
                value={formInterval}
                onChange={(e) => setFormInterval(Number(e.target.value) as RefreshIntervalMinutes)}
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
              >
                {INTERVAL_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </label>

            <label className="md:col-span-6 space-y-1 text-xs">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">
                Excluded Keywords (comma separated)
              </span>
              <input
                type="text"
                value={formExcluded}
                onChange={(e) => setFormExcluded(e.target.value)}
                placeholder="minecraft, tutorial, boilerplate"
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
              />
            </label>

            <label className="md:col-span-6 space-y-1 text-xs">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">
                Languages Filter (comma separated, blank = all)
              </span>
              <input
                type="text"
                value={formLanguages}
                onChange={(e) => setFormLanguages(e.target.value)}
                placeholder="Java, Go, TypeScript, Shell"
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs"
              />
            </label>
          </div>

          {/* Search Queries Manager */}
          <div className="space-y-3 pt-2 border-t border-zinc-100 dark:border-zinc-800">
            <div className="text-xs font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              GitHub Search Queries ({formQueries.length})
            </div>
            <div className="flex flex-wrap gap-2">
              <input
                type="text"
                value={newQueryInput}
                onChange={(e) => setNewQueryInput(e.target.value)}
                placeholder="e.g. jboss-eap in:name,description,readme"
                className="flex-1 min-w-[240px] px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
              />
              <button
                type="button"
                onClick={handleAddQuery}
                className="px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] cursor-pointer"
              >
                Add Query
              </button>
            </div>
            {queryError && (
              <p className="text-xs text-red-600 dark:text-red-400 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>{queryError}</span>
              </p>
            )}
            <div className="space-y-2">
              {formQueries.map((q, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={q}
                    onChange={(e) => handleUpdateQueryAt(idx, e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveQueryAt(idx)}
                    aria-label="Remove query"
                    className="p-1.5 text-zinc-400 hover:text-red-600 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Category Sync History Preview when editing */}
          {editingCategory && categoryHistory.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-zinc-100 dark:border-zinc-800">
              <div className="text-xs font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                Recent Synchronization Logs ({editingCategory.name})
              </div>
              <div className="divide-y divide-zinc-100 dark:divide-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-800 text-[11px] font-mono">
                {categoryHistory.map((h) => (
                  <div
                    key={h.id}
                    className="px-3 py-2 flex flex-wrap items-center justify-between gap-2"
                  >
                    <span className="truncate max-w-md text-zinc-700 dark:text-zinc-300">
                      {h.query}
                    </span>
                    <span className="text-zinc-500 tabular-nums">
                      {h.retrievedCount} fetched · +{h.newCount} new · {h.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-zinc-200 dark:border-zinc-800">
            {editingCategory ? (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={isSyncRunning}
                  onClick={() => onSyncCategory(editingCategory.id)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncRunning ? 'animate-spin' : ''}`} />
                  <span>Sync Category Now</span>
                </button>
                <button
                  type="button"
                  onClick={() => onViewCategoryResults(editingCategory.id)}
                  className="px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] cursor-pointer"
                >
                  View Discovered Repos ({editingCategory.repositoryCount})
                </button>
              </div>
            ) : (
              <span />
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={closeEditor}
                className="px-4 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 text-white cursor-pointer"
              >
                Save Category
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Categories Registry Table */}
      <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#FAFAFA] dark:bg-zinc-900/60 border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                <th className="px-4 py-3">Category</th>
                <th className="px-3 py-3 whitespace-nowrap">State</th>
                <th className="px-3 py-3 text-right whitespace-nowrap">Queries</th>
                <th className="px-3 py-3 text-right whitespace-nowrap">Repos</th>
                <th className="px-3 py-3 whitespace-nowrap">Interval</th>
                <th className="px-3 py-3 whitespace-nowrap">Last Sync</th>
                <th className="px-3 py-3 whitespace-nowrap">Status</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {categories.map((cat) => (
                <tr
                  key={cat.id}
                  className="hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40 transition-colors"
                >
                  <td className="px-4 py-3.5 max-w-xs">
                    <div className="flex items-center gap-2.5">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: cat.color }}
                        aria-hidden="true"
                      />
                      <div className="min-w-0">
                        <div className="font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                          {cat.name}
                        </div>
                        <div className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate">
                          {cat.description}
                        </div>
                      </div>
                    </div>
                  </td>

                  <td className="px-3 py-3.5 whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => handleToggleEnabled(cat.id)}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-medium border cursor-pointer ${
                        cat.enabled
                          ? 'bg-emerald-50/70 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/60'
                          : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 border-zinc-200 dark:border-zinc-700'
                      }`}
                    >
                      {cat.enabled ? 'Enabled' : 'Disabled'}
                    </button>
                  </td>

                  <td className="px-3 py-3.5 text-right font-mono tabular-nums text-zinc-600 dark:text-zinc-300">
                    {cat.searchQueries.length}
                  </td>

                  <td className="px-3 py-3.5 text-right font-mono tabular-nums font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                    <button
                      type="button"
                      onClick={() => onViewCategoryResults(cat.id)}
                      className="hover:text-[#2563EB] dark:hover:text-blue-400 hover:underline cursor-pointer"
                    >
                      {cat.repositoryCount}
                    </button>
                  </td>

                  <td className="px-3 py-3.5 whitespace-nowrap text-zinc-600 dark:text-zinc-400 tabular-nums">
                    {INTERVAL_OPTIONS.find((o) => o.value === cat.refreshIntervalMinutes)?.label ||
                      `${cat.refreshIntervalMinutes}m`}
                  </td>

                  <td className="px-3 py-3.5 whitespace-nowrap font-mono text-[11px] text-zinc-500 dark:text-zinc-400 tabular-nums">
                    {cat.lastSyncedAt
                      ? new Date(cat.lastSyncedAt).toLocaleString([], {
                          month: 'short',
                          day: '2-digit',
                          hour: '2-digit',
                          minute: '2-digit',
                        })
                      : 'Never'}
                  </td>

                  <td className="px-3 py-3.5 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center gap-1 text-[11px] font-medium ${
                        cat.lastSyncStatus === 'success'
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : cat.lastSyncStatus === 'rate_limited'
                            ? 'text-amber-600 dark:text-amber-400'
                            : cat.lastSyncStatus === 'error'
                              ? 'text-red-600 dark:text-red-400'
                              : 'text-zinc-500 dark:text-zinc-400'
                      }`}
                    >
                      {cat.lastSyncStatus === 'success' && (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      <span>{cat.lastSyncStatus}</span>
                    </span>
                  </td>

                  <td className="px-4 py-3.5 text-right whitespace-nowrap">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => startEdit(cat)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] text-[11px] font-medium cursor-pointer"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>Edit</span>
                      </button>
                      <button
                        type="button"
                        disabled={isSyncRunning || !cat.enabled}
                        onClick={() => onSyncCategory(cat.id)}
                        title={
                          cat.enabled
                            ? `Sync ${cat.name} now`
                            : 'Enable category before syncing'
                        }
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#2563EB] hover:bg-blue-700 disabled:opacity-40 text-white text-[11px] font-medium cursor-pointer"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>Sync</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
