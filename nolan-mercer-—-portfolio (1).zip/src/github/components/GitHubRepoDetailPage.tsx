import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Bookmark,
  Check,
  Copy,
  ExternalLink,
  GitFork,
  RefreshCw,
  Star,
} from 'lucide-react';
import { SafeMarkdown } from '../../components/SafeMarkdown';
import { githubProvider } from '../engine';
import {
  GitHubContributorItem,
  GitHubReleaseItem,
  GitHubRepository,
} from '../types';

type RepoDetailTab =
  | 'overview'
  | 'readme'
  | 'releases'
  | 'contributors'
  | 'languages'
  | 'activity';

interface GitHubRepoDetailPageProps {
  owner: string;
  repoName: string;
  onNavigate: (path: string) => void;
}

export const GitHubRepoDetailPage: React.FC<GitHubRepoDetailPageProps> = ({
  owner,
  repoName,
  onNavigate,
}) => {
  const fullNameTarget = `${owner}/${repoName}`.toLowerCase();

  const [repo, setRepo] = useState<GitHubRepository | null>(() => {
    const cached = githubProvider.getRepositories();
    return (
      cached.find((r) => r.fullName.toLowerCase() === fullNameTarget) || null
    );
  });
  const [loadingRepo, setLoadingRepo] = useState(!repo);
  const [repoError, setRepoError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<RepoDetailTab>('overview');
  const [savedIds, setSavedIds] = useState<number[]>(() =>
    githubProvider.getSavedRepoIds()
  );
  const [categories, setCategories] = useState(() =>
    githubProvider.getCategories()
  );
  const [associations, setAssociations] = useState(() =>
    githubProvider.getAssociations()
  );
  const [copiedUrl, setCopiedUrl] = useState(false);

  // Lazy-loaded detail tabs
  const [readme, setReadme] = useState<string | null | undefined>(undefined);
  const [releases, setReleases] = useState<GitHubReleaseItem[] | undefined>(
    undefined
  );
  const [contributors, setContributors] = useState<
    GitHubContributorItem[] | undefined
  >(undefined);
  const [languages, setLanguages] = useState<Record<string, number> | undefined>(
    undefined
  );
  const [tabLoading, setTabLoading] = useState(false);
  const [tabError, setTabError] = useState<string | null>(null);

  const loadLiveRepo = async () => {
    setLoadingRepo(true);
    setRepoError(null);
    try {
      const fresh = await githubProvider.fetchRepositoryDetails(owner, repoName);
      setRepo(fresh);
    } catch (err) {
      setRepoError(
        err instanceof Error ? err.message : 'Unable to fetch repository details.'
      );
    } finally {
      setLoadingRepo(false);
    }
  };

  useEffect(() => {
    if (!repo) {
      void loadLiveRepo();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [owner, repoName]);

  // Lazy-load secondary GitHub endpoints ONLY when user opens the corresponding tab
  useEffect(() => {
    let cancelled = false;

    const loadTab = async () => {
      setTabError(null);
      if (activeTab === 'readme' && readme === undefined) {
        setTabLoading(true);
        try {
          const md = await githubProvider.fetchRepositoryReadme(owner, repoName);
          if (!cancelled) setReadme(md);
        } catch (err) {
          if (!cancelled)
            setTabError(err instanceof Error ? err.message : 'Failed to load README.');
        } finally {
          if (!cancelled) setTabLoading(false);
        }
      } else if (activeTab === 'releases' && releases === undefined) {
        setTabLoading(true);
        try {
          const list = await githubProvider.fetchRepositoryReleases(owner, repoName);
          if (!cancelled) setReleases(list);
        } catch (err) {
          if (!cancelled)
            setTabError(err instanceof Error ? err.message : 'Failed to load releases.');
        } finally {
          if (!cancelled) setTabLoading(false);
        }
      } else if (activeTab === 'contributors' && contributors === undefined) {
        setTabLoading(true);
        try {
          const list = await githubProvider.fetchRepositoryContributors(
            owner,
            repoName
          );
          if (!cancelled) setContributors(list);
        } catch (err) {
          if (!cancelled)
            setTabError(
              err instanceof Error ? err.message : 'Failed to load contributors.'
            );
        } finally {
          if (!cancelled) setTabLoading(false);
        }
      } else if (activeTab === 'languages' && languages === undefined) {
        setTabLoading(true);
        try {
          const langs = await githubProvider.fetchRepositoryLanguages(
            owner,
            repoName
          );
          if (!cancelled) setLanguages(langs);
        } catch (err) {
          if (!cancelled)
            setTabError(
              err instanceof Error ? err.message : 'Failed to load languages.'
            );
        } finally {
          if (!cancelled) setTabLoading(false);
        }
      }
    };

    void loadTab();
    return () => {
      cancelled = true;
    };
  }, [activeTab, owner, repoName, readme, releases, contributors, languages]);

  const repoCategoryIds = useMemo(() => {
    if (!repo) return [];
    return associations[repo.id]?.categoryIds || [];
  }, [repo, associations]);

  const snapshots = useMemo(() => {
    if (!repo) return [];
    return githubProvider.getStarSnapshots()[repo.id] || [];
  }, [repo]);

  const isSaved = repo ? savedIds.includes(repo.id) : false;

  const handleToggleSave = () => {
    if (!repo) return;
    setSavedIds(githubProvider.toggleSaveRepo(repo.id));
  };

  const handleCopyUrl = async () => {
    if (!repo) return;
    try {
      await navigator.clipboard.writeText(repo.htmlUrl);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 1600);
    } catch {
      setCopiedUrl(false);
    }
  };

  const handleToggleCategoryAssociation = (catId: string) => {
    if (!repo) return;
    const include = !repoCategoryIds.includes(catId);
    const updated = githubProvider.updateCategoryAssociationManual(
      repo.id,
      catId,
      include
    );
    setAssociations({ ...updated.associations });
    setCategories([...updated.categories]);
  };

  const handleBack = () => {
    onNavigate('/knowledge-hub/github');
  };

  const totalLangBytes = useMemo(() => {
    if (!languages) return 0;
    return Object.values(languages).reduce((sum, n) => sum + n, 0);
  }, [languages]);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Breadcrumb & Back */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
          <button
            type="button"
            onClick={handleBack}
            className="inline-flex items-center gap-1.5 font-medium text-[#2563EB] dark:text-blue-400 hover:underline cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to GitHub Explorer</span>
          </button>
          <span aria-hidden="true">/</span>
          <span>Knowledge Hub</span>
          <span aria-hidden="true">/</span>
          <span>GitHub</span>
          <span aria-hidden="true">/</span>
          <span className="font-mono text-[#09090B] dark:text-[#FAFAFA]">
            {owner}/{repoName}
          </span>
        </div>
      </div>

      {loadingRepo && !repo ? (
        <div className="p-12 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 text-center text-sm text-zinc-500">
          Loading repository metadata from GitHub API...
        </div>
      ) : repoError && !repo ? (
        <div className="p-8 rounded-2xl bg-white dark:bg-[#111114] border border-red-200 dark:border-red-900/60 space-y-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-red-600 dark:text-red-400">
            <AlertTriangle className="w-4 h-4" />
            <span>Could not load {owner}/{repoName}</span>
          </div>
          <p className="text-xs text-zinc-600 dark:text-zinc-400">{repoError}</p>
          <button
            type="button"
            onClick={() => void loadLiveRepo()}
            className="px-4 py-2 text-xs font-medium rounded-lg bg-[#2563EB] text-white cursor-pointer"
          >
            Retry
          </button>
        </div>
      ) : repo ? (
        <>
          {/* Repository Header */}
          <header className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-6 space-y-5">
            <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-5">
              <div className="flex items-start gap-4 min-w-0">
                {repo.owner.avatarUrl ? (
                  <img
                    src={repo.owner.avatarUrl}
                    alt={repo.owner.login}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-xl border border-zinc-200 dark:border-zinc-700 shrink-0"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center font-mono font-bold text-sm shrink-0">
                    {repo.owner.login.slice(0, 2).toUpperCase()}
                  </div>
                )}

                <div className="space-y-1.5 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                    <a
                      href={repo.owner.htmlUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:underline"
                    >
                      {repo.owner.login}
                    </a>
                    <span>·</span>
                    <span>{repo.visibility}</span>
                    {repo.license && (
                      <>
                        <span>·</span>
                        <span>{repo.license}</span>
                      </>
                    )}
                    {repo.archived && (
                      <>
                        <span>·</span>
                        <span className="text-amber-600 dark:text-amber-400 font-medium">
                          Archived
                        </span>
                      </>
                    )}
                  </div>

                  <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#09090B] dark:text-[#FAFAFA] break-words">
                    {repo.fullName}
                  </h1>

                  <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed max-w-3xl">
                    {repo.description || 'No description provided on GitHub.'}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleToggleSave}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                    isSaved
                      ? 'bg-[#2563EB] border-[#2563EB] text-white'
                      : 'border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB]'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-current' : ''}`} />
                  <span>{isSaved ? 'Saved' : 'Save'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] cursor-pointer"
                >
                  {copiedUrl ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#2563EB]" />
                      <span>Copied URL</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy URL</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  disabled={loadingRepo}
                  onClick={() => void loadLiveRepo()}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingRepo ? 'animate-spin' : ''}`} />
                  <span>Refresh</span>
                </button>

                <a
                  href={repo.htmlUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#09090B] dark:bg-zinc-800 text-white hover:opacity-90"
                >
                  <span>Open on GitHub</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Compact Metrics Row */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 pt-4 border-t border-zinc-200 dark:border-zinc-800 text-xs">
              <div>
                <div className="text-zinc-500 dark:text-zinc-400">Stars</div>
                <div className="font-mono font-semibold text-base tabular-nums flex items-center gap-1.5 mt-0.5">
                  <Star className="w-3.5 h-3.5 text-amber-500" />
                  <span>{repo.stargazersCount.toLocaleString()}</span>
                </div>
              </div>
              <div>
                <div className="text-zinc-500 dark:text-zinc-400">Forks</div>
                <div className="font-mono font-semibold text-base tabular-nums flex items-center gap-1.5 mt-0.5">
                  <GitFork className="w-3.5 h-3.5 text-zinc-400" />
                  <span>{repo.forksCount.toLocaleString()}</span>
                </div>
              </div>
              <div>
                <div className="text-zinc-500 dark:text-zinc-400">Open Issues</div>
                <div className="font-mono font-semibold text-base tabular-nums mt-0.5">
                  {repo.openIssuesCount.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-zinc-500 dark:text-zinc-400">Primary Language</div>
                <div className="font-semibold text-sm mt-0.5">
                  {repo.language || 'Not specified'}
                </div>
              </div>
              <div>
                <div className="text-zinc-500 dark:text-zinc-400">Created</div>
                <div className="font-mono text-xs tabular-nums mt-1">
                  {new Date(repo.createdAt).toLocaleDateString()}
                </div>
              </div>
              <div>
                <div className="text-zinc-500 dark:text-zinc-400">Last Updated</div>
                <div className="font-mono text-xs tabular-nums mt-1">
                  {new Date(repo.updatedAt).toLocaleDateString()}
                </div>
              </div>
            </div>
          </header>

          {/* 6 Repository Detail Tabs */}
          <div className="flex flex-wrap items-center gap-1 p-1 rounded-lg bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 self-start w-fit">
            {(
              [
                ['overview', 'Overview'],
                ['readme', 'README'],
                ['releases', 'Releases'],
                ['contributors', 'Contributors'],
                ['languages', 'Languages'],
                ['activity', 'Activity'],
              ] as Array<[RepoDetailTab, string]>
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setActiveTab(key)}
                className={`px-4 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  activeTab === key
                    ? 'bg-white dark:bg-zinc-800 text-[#09090B] dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-[#09090B] dark:hover:text-zinc-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Tab Panels */}
          <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-6">
            {tabLoading ? (
              <div className="py-12 text-center text-xs text-zinc-500">
                Fetching {activeTab} from GitHub API...
              </div>
            ) : tabError ? (
              <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/60 text-xs text-red-700 dark:text-red-300">
                {tabError}
              </div>
            ) : activeTab === 'overview' ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div className="lg:col-span-7 space-y-5">
                  <div className="space-y-1.5">
                    <h2 className="font-display text-base font-semibold">
                      Repository Summary
                    </h2>
                    <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed">
                      {repo.description || 'No description provided on GitHub.'}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                      GitHub Topics
                    </h3>
                    {repo.topics.length === 0 ? (
                      <p className="text-xs text-zinc-500">No topics listed.</p>
                    ) : (
                      <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs font-mono text-[#2563EB] dark:text-blue-400">
                        {repo.topics.map((topic) => (
                          <span key={topic}>#{topic}</span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 pt-2 border-t border-zinc-200 dark:border-zinc-800">
                    <h3 className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                      Workspace Category Associations (Click to adjust manually)
                    </h3>
                    <div className="flex flex-wrap gap-1.5">
                      {categories.map((cat) => {
                        const active = repoCategoryIds.includes(cat.id);
                        return (
                          <button
                            key={cat.id}
                            type="button"
                            onClick={() => handleToggleCategoryAssociation(cat.id)}
                            className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-colors cursor-pointer ${
                              active
                                ? 'bg-[#2563EB]/10 border-[#2563EB] text-[#2563EB] dark:text-blue-400'
                                : 'bg-[#FAFAFA] dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                            }`}
                          >
                            {cat.name}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-5 space-y-3 text-xs border-t lg:border-t-0 lg:border-l border-zinc-200 dark:border-zinc-800 pt-5 lg:pt-0 lg:pl-8">
                  <h3 className="font-display text-base font-semibold">Metadata</h3>
                  <dl className="divide-y divide-zinc-100 dark:divide-zinc-800">
                    {[
                      ['Repository ID', String(repo.id)],
                      ['Default Branch', repo.defaultBranch],
                      ['License', repo.license || 'Unavailable'],
                      ['Visibility', repo.visibility],
                      ['Fork', repo.fork ? 'Yes' : 'No'],
                      ['Last Push', repo.pushedAt ? new Date(repo.pushedAt).toLocaleString() : 'Unavailable'],
                      ['Workspace Discovered', new Date(repo.discoveredAt).toLocaleString()],
                    ].map(([k, v]) => (
                      <div key={k} className="py-2.5 flex items-center justify-between gap-3">
                        <dt className="text-zinc-500 dark:text-zinc-400">{k}</dt>
                        <dd className="font-mono text-[#09090B] dark:text-[#FAFAFA] text-right">
                          {v}
                        </dd>
                      </div>
                    ))}
                  </dl>
                </div>
              </div>
            ) : activeTab === 'readme' ? (
              readme ? (
                <SafeMarkdown markdown={readme} />
              ) : (
                <p className="text-xs text-zinc-500">
                  No README.md file is available for this repository.
                </p>
              )
            ) : activeTab === 'releases' ? (
              !releases || releases.length === 0 ? (
                <p className="text-xs text-zinc-500">
                  No published GitHub releases found for {repo.fullName}.
                </p>
              ) : (
                <div className="divide-y divide-zinc-200 dark:divide-zinc-800">
                  {releases.map((rel) => (
                    <div
                      key={rel.id}
                      className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-xs">
                          <span className="font-mono font-semibold text-[#2563EB] dark:text-blue-400">
                            {rel.tagName}
                          </span>
                          {rel.prerelease && (
                            <span className="text-amber-600 dark:text-amber-400">
                              · Pre-release
                            </span>
                          )}
                          {rel.publishedAt && (
                            <span className="text-zinc-500 tabular-nums">
                              · {new Date(rel.publishedAt).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                        <div className="text-sm font-medium text-[#09090B] dark:text-[#FAFAFA]">
                          {rel.name || rel.tagName}
                        </div>
                      </div>
                      <a
                        href={rel.htmlUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#2563EB] dark:text-blue-400 hover:underline shrink-0"
                      >
                        <span>View Release</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  ))}
                </div>
              )
            ) : activeTab === 'contributors' ? (
              !contributors || contributors.length === 0 ? (
                <p className="text-xs text-zinc-500">
                  Contributor information is unavailable for this repository.
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {contributors.map((c) => (
                    <a
                      key={c.id}
                      href={c.htmlUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3.5 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 hover:border-[#2563EB] flex items-center gap-3"
                    >
                      <img
                        src={c.avatarUrl}
                        alt={c.login}
                        referrerPolicy="no-referrer"
                        className="w-9 h-9 rounded-full border border-zinc-200 dark:border-zinc-700"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-semibold truncate">{c.login}</div>
                        <div className="text-[11px] font-mono text-zinc-500 tabular-nums">
                          {c.contributions} commits
                        </div>
                      </div>
                    </a>
                  ))}
                </div>
              )
            ) : activeTab === 'languages' ? (
              !languages || totalLangBytes === 0 ? (
                <p className="text-xs text-zinc-500">
                  No language breakdown returned by GitHub.
                </p>
              ) : (
                <div className="space-y-4 max-w-2xl">
                  {Object.entries(languages).map(([lang, bytes]) => {
                    const pct = ((bytes / totalLangBytes) * 100).toFixed(1);
                    return (
                      <div key={lang} className="space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{lang}</span>
                          <span className="font-mono text-zinc-500 tabular-nums">
                            {pct}% ({bytes.toLocaleString()} B)
                          </span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden">
                          <div
                            className="h-full bg-[#2563EB] dark:bg-blue-500 rounded-full"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )
            ) : (
              <div className="space-y-5 text-xs">
                <p className="text-zinc-600 dark:text-zinc-400">
                  Timestamps reflect actual GitHub metadata and Workspace star snapshots
                  recorded across sync cycles.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
                    <div className="text-zinc-500">Created At</div>
                    <div className="font-mono mt-1">
                      {new Date(repo.createdAt).toLocaleString()}
                    </div>
                  </div>
                  <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
                    <div className="text-zinc-500">Last Pushed</div>
                    <div className="font-mono mt-1">
                      {repo.pushedAt ? new Date(repo.pushedAt).toLocaleString() : 'Unavailable'}
                    </div>
                  </div>
                  <div className="p-4 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
                    <div className="text-zinc-500">Last Workspace Sync</div>
                    <div className="font-mono mt-1">
                      {new Date(repo.lastRefreshedAt).toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold text-[#09090B] dark:text-[#FAFAFA]">
                    Recorded Star Snapshots ({snapshots.length})
                  </h3>
                  {snapshots.length === 0 ? (
                    <p className="text-zinc-500">No historical snapshots recorded yet.</p>
                  ) : (
                    <div className="divide-y divide-zinc-200 dark:divide-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-800">
                      {snapshots.map((snap, idx) => (
                        <div
                          key={idx}
                          className="px-4 py-2.5 flex items-center justify-between font-mono tabular-nums"
                        >
                          <span>{new Date(snap.capturedAt).toLocaleString()}</span>
                          <span className="font-semibold">{snap.stars.toLocaleString()} ★</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </>
      ) : null}
    </div>
  );
};
