import React, { useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  RefreshCw,
  Search,
  Trash2,
  Upload,
} from 'lucide-react';
import {
  exportCategoriesToJson,
  exportRepositoriesToCsv,
  parseImportedCategoriesJson,
} from '../exportUtils';
import {
  clearRepositoryCacheStorage,
  clearSyncHistoryStorage,
  resetCategoriesToDefault,
} from '../storage';
import {
  CategoryAssociation,
  GitHubCategory,
  GitHubRepository,
  GitHubSettings,
  RateLimitState,
  RefreshIntervalMinutes,
  SyncHistoryEntry,
  SyncProgressState,
} from '../types';

interface DiscoverySettingsViewProps {
  settings: GitHubSettings;
  rateLimits: RateLimitState;
  progress: SyncProgressState;
  repositories: GitHubRepository[];
  categories: GitHubCategory[];
  associations: Record<number, CategoryAssociation>;
  onUpdateSettings: (next: GitHubSettings) => void;
  onReplaceCategories: (next: GitHubCategory[]) => void;
  onClearCacheComplete: () => void;
  onClearHistoryComplete: () => void;
  onManualSyncAll: () => Promise<void>;
}

export const DiscoverySettingsView: React.FC<DiscoverySettingsViewProps> = ({
  settings,
  rateLimits,
  progress,
  repositories,
  categories,
  associations,
  onUpdateSettings,
  onReplaceCategories,
  onClearCacheComplete,
  onClearHistoryComplete,
  onManualSyncAll,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [confirmAction, setConfirmAction] = useState<
    null | 'clear-cache' | 'clear-history' | 'reset-categories'
  >(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = parseImportedCategoriesJson(text);
      if (parsed.error || !parsed.categories) {
        setStatusMessage(`Import failed: ${parsed.error}`);
      } else {
        onReplaceCategories(parsed.categories);
        setStatusMessage(
          `Imported ${parsed.categories.length} categories cleanly.`
        );
      }
    } catch {
      setStatusMessage('Unable to read uploaded JSON file.');
    } finally {
      e.target.value = '';
    }
  };

  const executeConfirmedAction = () => {
    if (confirmAction === 'clear-cache') {
      clearRepositoryCacheStorage();
      onClearCacheComplete();
      setStatusMessage(
        'Repository cache cleared. Saved repository IDs were preserved.'
      );
    } else if (confirmAction === 'clear-history') {
      clearSyncHistoryStorage();
      onClearHistoryComplete();
      setStatusMessage('Synchronization history cleared.');
    } else if (confirmAction === 'reset-categories') {
      const defaults = resetCategoriesToDefault();
      onReplaceCategories(defaults);
      setStatusMessage('Categories reset to the 13 default configurations.');
    }
    setConfirmAction(null);
  };

  const formatReset = (resetMs: number | null) => {
    if (!resetMs) return 'Unknown';
    return new Date(resetMs).toLocaleTimeString();
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-xl font-bold text-[#09090B] dark:text-[#FAFAFA]">
          Discovery Settings
        </h2>
        <p className="text-xs text-zinc-600 dark:text-zinc-400">
          Configure automatic refresh defaults, monitor GitHub Search &amp; Core API quotas,
          and manage cached data exports.
        </p>
      </div>

      {statusMessage && (
        <div className="p-3.5 rounded-xl bg-[#2563EB]/10 dark:bg-blue-500/15 border border-[#2563EB]/30 text-xs text-[#2563EB] dark:text-blue-300 flex items-center justify-between gap-2">
          <span>{statusMessage}</span>
          <button
            type="button"
            onClick={() => setStatusMessage(null)}
            className="text-[11px] font-medium underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* General Settings */}
        <section className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-6 space-y-5">
          <h3 className="font-display text-base font-semibold text-[#09090B] dark:text-[#FAFAFA]">
            General Defaults
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <label className="sm:col-span-2 flex items-center justify-between p-3.5 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 cursor-pointer">
              <div>
                <div className="font-medium text-[#09090B] dark:text-[#FAFAFA]">
                  Automatic Background Refresh (While Tab Active)
                </div>
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400">
                  Checks elapsed category intervals when visible or when returning to Workspace.
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.autoRefreshEnabled}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    autoRefreshEnabled: e.target.checked,
                  })
                }
                className="w-4 h-4 accent-[#2563EB]"
              />
            </label>

            <label className="space-y-1">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">
                Default Refresh Interval
              </span>
              <select
                value={settings.defaultRefreshIntervalMinutes}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    defaultRefreshIntervalMinutes: Number(
                      e.target.value
                    ) as RefreshIntervalMinutes,
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
              >
                <option value={30}>30 minutes</option>
                <option value={60}>1 hour</option>
                <option value={180}>3 hours</option>
                <option value={360}>6 hours</option>
                <option value={720}>12 hours</option>
                <option value={1440}>24 hours</option>
                <option value={0}>Manual only</option>
              </select>
            </label>

            <label className="space-y-1">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">
                Default View Mode
              </span>
              <select
                value={settings.defaultView}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    defaultView: e.target.value as 'grid' | 'table',
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
              >
                <option value="grid">Grid Cards</option>
                <option value="table">Table View</option>
              </select>
            </label>

            <label className="space-y-1">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">
                Default Minimum Stars
              </span>
              <input
                type="number"
                min={0}
                value={settings.defaultMinimumStars}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    defaultMinimumStars: Math.max(0, Number(e.target.value) || 0),
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono tabular-nums"
              />
            </label>

            <label className="space-y-1">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">
                Default Max Results / Query
              </span>
              <input
                type="number"
                min={5}
                max={100}
                value={settings.defaultMaximumResults}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    defaultMaximumResults: Math.min(
                      100,
                      Math.max(5, Number(e.target.value) || 30)
                    ),
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono tabular-nums"
              />
            </label>

            <label className="space-y-1">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">
                Default Created Window (days)
              </span>
              <input
                type="number"
                min={1}
                value={settings.defaultCreatedWithinDays ?? 30}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    defaultCreatedWithinDays: Math.max(1, Number(e.target.value) || 30),
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono tabular-nums"
              />
            </label>

            <label className="space-y-1">
              <span className="font-medium text-zinc-700 dark:text-zinc-300">
                Default Sort Order
              </span>
              <select
                value={settings.defaultSort}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    defaultSort: e.target.value as GitHubSettings['defaultSort'],
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
              >
                <option value="stars">Most Stars</option>
                <option value="updated">Recently Updated</option>
                <option value="created">Recently Created</option>
                <option value="name">Repository Name</option>
              </select>
            </label>
          </div>
        </section>

        {/* API & Sync Status */}
        <section className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-6 space-y-5">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-display text-base font-semibold text-[#09090B] dark:text-[#FAFAFA]">
              API &amp; Quota Status
            </h3>
            <button
              type="button"
              disabled={progress.isRunning}
              onClick={onManualSyncAll}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#2563EB] hover:bg-blue-700 disabled:opacity-50 text-white cursor-pointer"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${progress.isRunning ? 'animate-spin' : ''}`}
              />
              <span>Sync Due</span>
            </button>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3.5 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-medium text-zinc-700 dark:text-zinc-300">
                  Search API Quota
                </span>
                <span className="font-mono tabular-nums text-[#09090B] dark:text-[#FAFAFA]">
                  {rateLimits.search.remaining ?? '—'} / {rateLimits.search.limit ?? '10'}
                </span>
              </div>
              <div className="text-[11px] font-mono text-zinc-500">
                Reset: {formatReset(rateLimits.search.resetAt)}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-medium text-zinc-700 dark:text-zinc-300">
                  Core REST API Quota
                </span>
                <span className="font-mono tabular-nums text-[#09090B] dark:text-[#FAFAFA]">
                  {rateLimits.core.remaining ?? '—'} / {rateLimits.core.limit ?? '60'}
                </span>
              </div>
              <div className="text-[11px] font-mono text-zinc-500">
                Reset: {formatReset(rateLimits.core.resetAt)}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#FAFAFA] dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
              <span className="text-zinc-600 dark:text-zinc-400">Cached Repositories</span>
              <span className="font-mono font-semibold tabular-nums">
                {repositories.length}
              </span>
            </div>

            <p className="text-[11px] text-zinc-500 dark:text-zinc-400 leading-relaxed">
              Note: Frontend-only synchronization runs while this browser tab is active.
              Provider interfaces are backend-ready for scheduled cron workers.
            </p>
          </div>
        </section>
      </div>

      {/* Data Management & Export */}
      <section className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 p-6 space-y-4">
        <h3 className="font-display text-base font-semibold text-[#09090B] dark:text-[#FAFAFA]">
          Data Management, Export &amp; Import
        </h3>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={repositories.length === 0}
            onClick={() =>
              exportRepositoriesToCsv(repositories, categories, associations)
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] disabled:opacity-40 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export All Repositories (CSV)</span>
          </button>

          <button
            type="button"
            onClick={() => exportCategoriesToJson(categories)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Categories (JSON)</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 hover:border-[#2563EB] cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import Categories (JSON)</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/json,.json"
            onChange={handleImportFile}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => setConfirmAction('clear-cache')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Repository Cache</span>
          </button>

          <button
            type="button"
            onClick={() => setConfirmAction('clear-history')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-900 cursor-pointer"
          >
            <span>Clear Sync History</span>
          </button>

          <button
            type="button"
            onClick={() => setConfirmAction('reset-categories')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-amber-200 dark:border-amber-900/60 text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/30 cursor-pointer"
          >
            <span>Reset 13 Default Categories</span>
          </button>
        </div>

        {confirmAction && (
          <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>
                Confirm destructive action:{' '}
                <strong>
                  {confirmAction === 'clear-cache'
                    ? 'Clear all cached repositories (saved bookmarks are kept)'
                    : confirmAction === 'clear-history'
                      ? 'Clear all synchronization logs'
                      : 'Reset all categories back to initial 13 defaults'}
                </strong>
                ?
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setConfirmAction(null)}
                className="px-3 py-1.5 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executeConfirmedAction}
                className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium cursor-pointer"
              >
                Confirm
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};

interface SyncHistoryViewProps {
  history: SyncHistoryEntry[];
  categories: GitHubCategory[];
}

export const SyncHistoryView: React.FC<SyncHistoryViewProps> = ({
  history,
  categories,
}) => {
  const [catFilter, setCatFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [queryFilter, setQueryFilter] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = queryFilter.trim().toLowerCase();
    return history.filter((item) => {
      if (catFilter !== 'all' && item.categoryId !== catFilter) return false;
      if (statusFilter !== 'all' && item.status !== statusFilter) return false;
      if (!q) return true;
      return (
        item.query.toLowerCase().includes(q) ||
        item.categoryName.toLowerCase().includes(q) ||
        (item.errorMessage || '').toLowerCase().includes(q)
      );
    });
  }, [history, catFilter, statusFilter, queryFilter]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-bold text-[#09090B] dark:text-[#FAFAFA]">
            Synchronization History
          </h2>
          <p className="text-xs text-zinc-600 dark:text-zinc-400">
            Audit trail of GitHub Search API executions, deduplication counts, and errors.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={catFilter}
            onChange={(e) => setCatFilter(e.target.value)}
            aria-label="Filter sync history by category"
            className="px-3 py-2 text-xs rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            aria-label="Filter sync history by status"
            className="px-3 py-2 text-xs rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
          >
            <option value="all">All Statuses</option>
            <option value="success">Success</option>
            <option value="partial">Partial</option>
            <option value="rate_limited">Rate Limited</option>
            <option value="error">Error</option>
          </select>

          <div className="relative w-52">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={queryFilter}
              onChange={(e) => setQueryFilter(e.target.value)}
              placeholder="Filter query..."
              className="w-full pl-8 pr-3 py-2 text-xs rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800"
            />
          </div>
        </div>
      </div>

      <div className="rounded-2xl bg-white dark:bg-[#111114] border border-zinc-200 dark:border-zinc-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#FAFAFA] dark:bg-zinc-900/60 border-b border-zinc-200 dark:border-zinc-800 text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                <th className="px-4 py-3">Category</th>
                <th className="px-3 py-3">Query</th>
                <th className="px-3 py-3 whitespace-nowrap">Started</th>
                <th className="px-3 py-3 text-right whitespace-nowrap">Duration</th>
                <th className="px-3 py-3 text-right whitespace-nowrap">Retrieved</th>
                <th className="px-3 py-3 text-right whitespace-nowrap">New / Upd</th>
                <th className="px-3 py-3 text-right whitespace-nowrap">Dupes</th>
                <th className="px-4 py-3 text-right whitespace-nowrap">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-zinc-500 dark:text-zinc-400">
                    No synchronization records yet. Run Sync to execute GitHub discovery queries.
                  </td>
                </tr>
              ) : (
                filtered.map((row) => (
                  <React.Fragment key={row.id}>
                    <tr
                      onClick={() =>
                        row.errorMessage &&
                        setExpandedId((cur) => (cur === row.id ? null : row.id))
                      }
                      className={`${
                        row.errorMessage ? 'cursor-pointer' : ''
                      } hover:bg-zinc-50/80 dark:hover:bg-zinc-900/40`}
                    >
                      <td className="px-4 py-3 font-medium text-[#09090B] dark:text-[#FAFAFA] whitespace-nowrap">
                        {row.categoryName}
                      </td>
                      <td className="px-3 py-3 font-mono text-[11px] text-zinc-600 dark:text-zinc-300 max-w-xs truncate">
                        {row.query}
                      </td>
                      <td className="px-3 py-3 font-mono text-[11px] text-zinc-500 tabular-nums whitespace-nowrap">
                        {new Date(row.startedAt).toLocaleString([], {
                          month: 'short',
                          day: '2-digit',
                          hour: '2-digit',
                          minute: '2-digit',
                          second: '2-digit',
                        })}
                      </td>
                      <td className="px-3 py-3 text-right font-mono text-[11px] tabular-nums text-zinc-500">
                        {row.durationMs}ms
                      </td>
                      <td className="px-3 py-3 text-right font-mono tabular-nums">
                        {row.retrievedCount}
                      </td>
                      <td className="px-3 py-3 text-right font-mono tabular-nums text-zinc-600 dark:text-zinc-300">
                        +{row.newCount} / {row.updatedCount}
                      </td>
                      <td className="px-3 py-3 text-right font-mono tabular-nums text-zinc-500">
                        {row.duplicatesRemoved}
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 text-[11px] font-medium ${
                            row.status === 'success'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : row.status === 'rate_limited'
                                ? 'text-amber-600 dark:text-amber-400'
                                : 'text-red-600 dark:text-red-400'
                          }`}
                        >
                          {row.status === 'success' && <CheckCircle2 className="w-3 h-3" />}
                          <span>{row.status}</span>
                        </span>
                      </td>
                    </tr>
                    {expandedId === row.id && row.errorMessage && (
                      <tr>
                        <td
                          colSpan={8}
                          className="px-4 py-3 bg-red-50/70 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300 font-mono"
                        >
                          Error Detail ({row.id}): {row.errorMessage}
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
