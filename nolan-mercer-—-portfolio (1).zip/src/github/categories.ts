import { GitHubCategory } from './types';

export interface QueryValidationResult {
  valid: boolean;
  error: string | null;
}

export function validateGitHubQuery(query: string): QueryValidationResult {
  const trimmed = query.trim();
  if (!trimmed) {
    return { valid: false, error: 'Query cannot be empty.' };
  }
  if (trimmed.length > 256) {
    return { valid: false, error: 'GitHub search query must be 256 characters or fewer.' };
  }
  const unsupportedQualifiers = ['regex:', 'not:', 'site:', 'filetype:'];
  const lower = trimmed.toLowerCase();
  const foundUnsupported = unsupportedQualifiers.find((q) => lower.includes(q));
  if (foundUnsupported) {
    return {
      valid: false,
      error: `Unsupported GitHub search qualifier "${foundUnsupported}".`,
    };
  }
  const operatorCount = (trimmed.match(/\b(AND|OR|NOT)\b/g) || []).length;
  if (operatorCount > 5) {
    return {
      valid: false,
      error: 'GitHub Search API allows at most 5 boolean operators per query.',
    };
  }
  return { valid: true, error: null };
}

export function createInitialCategories(): GitHubCategory[] {
  const now = new Date().toISOString();

  const specs: Array<
    Pick<
      GitHubCategory,
      | 'id'
      | 'name'
      | 'slug'
      | 'description'
      | 'icon'
      | 'color'
      | 'searchQueries'
      | 'excludedKeywords'
      | 'minimumStars'
      | 'languages'
    >
  > = [
    {
      id: 'jboss',
      name: 'JBoss',
      slug: 'jboss',
      description: 'JBoss EAP, WildFly runtime modules, Jakarta EE migrations, and CLI tooling.',
      icon: 'server',
      color: '#2563EB',
      searchQueries: [
        'jboss in:name,description,readme',
        'wildfly in:name,description,readme',
        'jboss-eap in:name,description,readme',
        'jboss-eap-configuration in:name,description,readme',
        'jboss-migration in:name,description,readme',
      ],
      excludedKeywords: ['minecraft', 'roblox'],
      minimumStars: 2,
      languages: [],
    },
    {
      id: 'openshift',
      name: 'OpenShift',
      slug: 'openshift',
      description: 'Red Hat OpenShift, OKD operators, GitOps manifests, and deployment automation.',
      icon: 'layers',
      color: '#DC2626',
      searchQueries: [
        'openshift in:name,description,readme',
        'okd in:name,description,readme',
        'openshift-operator in:name,description,readme',
        'openshift-gitops in:name,description,readme',
        'openshift-deployment in:name,description,readme',
      ],
      excludedKeywords: [],
      minimumStars: 3,
      languages: [],
    },
    {
      id: 'nginx',
      name: 'Nginx',
      slug: 'nginx',
      description: 'Nginx core server, ingress controllers, dynamic modules, and proxy configurations.',
      icon: 'globe',
      color: '#059669',
      searchQueries: [
        'nginx in:name,description,readme',
        'nginx-ingress in:name,description,readme',
        'nginx-configuration in:name,description,readme',
        'nginx-module in:name,description,readme',
      ],
      excludedKeywords: [],
      minimumStars: 5,
      languages: [],
    },
    {
      id: 'reverse-proxy',
      name: 'Reverse Proxy',
      slug: 'reverse-proxy',
      description: 'Edge reverse proxies, HAProxy, Traefik, Envoy, Caddy, and gateway load balancers.',
      icon: 'shield',
      color: '#0284C7',
      searchQueries: [
        'reverse-proxy in:name,description,readme',
        'haproxy in:name,description,readme',
        'traefik in:name,description,readme',
        'envoy-proxy in:name,description,readme',
        'caddy-server in:name,description,readme',
      ],
      excludedKeywords: [],
      minimumStars: 5,
      languages: [],
    },
    {
      id: 'apache',
      name: 'Apache',
      slug: 'apache',
      description: 'Apache Software Foundation ecosystem projects, governance tools, and core libraries.',
      icon: 'feather',
      color: '#D97706',
      searchQueries: [
        'apache in:name,description,readme',
        'apache-software-foundation in:name,description,readme',
        'apache-project in:name,description,readme',
      ],
      excludedKeywords: ['httpd-rpm', 'rhel-httpd', 'apache-native-game'],
      minimumStars: 10,
      languages: [],
    },
    {
      id: 'httpd',
      name: 'HTTPD',
      slug: 'httpd',
      description: 'Apache HTTP Server (httpd), mod_http2, MPM tuning, and virtual host modules.',
      icon: 'network',
      color: '#B45309',
      searchQueries: [
        'httpd in:name,description,readme',
        'apache-http-server in:name,description,readme',
        'apache-httpd in:name,description,readme',
        'mod-http2 in:name,description,readme',
      ],
      excludedKeywords: ['nginx'],
      minimumStars: 2,
      languages: [],
    },
    {
      id: 'red-hat-apache',
      name: 'Red Hat Apache',
      slug: 'red-hat-apache',
      description: 'Red Hat / RHEL RPM packaging, security patches, and enterprise httpd configs.',
      icon: 'package',
      color: '#B91C1C',
      searchQueries: [
        'redhat-httpd in:name,description,readme',
        'rhel-httpd in:name,description,readme',
        'red-hat-httpd in:name,description,readme',
        'redhat-apache in:name,description,readme',
        'httpd-rpm in:name,description,readme',
      ],
      excludedKeywords: ['ubuntu-only', 'windows-xampp'],
      minimumStars: 0,
      languages: [],
    },
    {
      id: 'kubernetes',
      name: 'Kubernetes',
      slug: 'kubernetes',
      description: 'Kubernetes cluster controllers, kubectl plugins, Helm charts, Kustomize, and operators.',
      icon: 'boxes',
      color: '#1D4ED8',
      searchQueries: [
        'kubernetes in:name,description,readme',
        'kubectl in:name,description,readme',
        'helm in:name,description,readme',
        'kustomize in:name,description,readme',
        'kubernetes-operator in:name,description,readme',
      ],
      excludedKeywords: [],
      minimumStars: 10,
      languages: [],
    },
    {
      id: 'ai',
      name: 'AI',
      slug: 'ai',
      description: 'LLM frameworks, AI agents, RAG pipelines, agentic workflows, and automation systems.',
      icon: 'cpu',
      color: '#4F46E5',
      searchQueries: [
        'llm in:name,description,readme',
        'ai-agent in:name,description,readme',
        'rag in:name,description,readme',
        'agentic-ai in:name,description,readme',
        'ai-automation in:name,description,readme',
      ],
      excludedKeywords: [],
      minimumStars: 10,
      languages: [],
    },
    {
      id: 'claude-code',
      name: 'Claude Code',
      slug: 'claude-code',
      description: 'Claude Code skills, plugins, MCP integrations, hooks, and developer workflows.',
      icon: 'terminal',
      color: '#EA580C',
      searchQueries: [
        'claude-code in:name,description,readme',
        'claude-code-skill in:name,description,readme',
        'claude-code-plugin in:name,description,readme',
        'claude-code-mcp in:name,description,readme',
        'claude-code-workflow in:name,description,readme',
      ],
      excludedKeywords: [],
      minimumStars: 0,
      languages: [],
    },
    {
      id: 'chatgpt',
      name: 'ChatGPT',
      slug: 'chatgpt',
      description: 'ChatGPT & OpenAI API integrations, agent SDKs, MCP bridges, and automation tools.',
      icon: 'message',
      color: '#0D9488',
      searchQueries: [
        'chatgpt in:name,description,readme',
        'openai-api in:name,description,readme',
        'gpt-integration in:name,description,readme',
        'openai-agents in:name,description,readme',
        'openai-mcp in:name,description,readme',
      ],
      excludedKeywords: [],
      minimumStars: 5,
      languages: [],
    },
    {
      id: 'gemini',
      name: 'Gemini',
      slug: 'gemini',
      description: 'Google Gemini SDK integrations, Gemini CLI tooling, and multimodal workflow apps.',
      icon: 'sparkles',
      color: '#2563EB',
      searchQueries: [
        'google-gemini in:name,description,readme',
        'gemini-api in:name,description,readme',
        'gemini-cli in:name,description,readme',
        'gemini-integration in:name,description,readme',
      ],
      excludedKeywords: ['crypto-exchange', 'gemini-protocol-gopher'],
      minimumStars: 2,
      languages: [],
    },
    {
      id: 'deepseek',
      name: 'DeepSeek',
      slug: 'deepseek',
      description: 'DeepSeek R1/Coder integrations, local inference bridges, and API wrappers.',
      icon: 'radar',
      color: '#0369A1',
      searchQueries: [
        'deepseek in:name,description,readme',
        'deepseek-api in:name,description,readme',
        'deepseek-r1 in:name,description,readme',
        'deepseek-coder in:name,description,readme',
        'deepseek-integration in:name,description,readme',
      ],
      excludedKeywords: [],
      minimumStars: 2,
      languages: [],
    },
  ];

  return specs.map((spec) => ({
    ...spec,
    enabled: true,
    maximumResults: 30,
    createdWithinDays: null,
    updatedWithinDays: 365,
    refreshIntervalMinutes: 180,
    lastSyncedAt: null,
    lastSyncStatus: 'idle',
    lastSyncError: null,
    repositoryCount: 0,
    createdAt: now,
    updatedAt: now,
  }));
}
