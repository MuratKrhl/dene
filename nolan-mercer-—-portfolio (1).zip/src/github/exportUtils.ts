import { CategoryAssociation, GitHubCategory, GitHubRepository } from './types';

function escapeCsvCell(value: string | number | null | undefined): string {
  const str = value === null || value === undefined ? '' : String(value);
  if (/[",\n\r]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function exportRepositoriesToCsv(
  repos: GitHubRepository[],
  categories: GitHubCategory[],
  associations: Record<number, CategoryAssociation>,
  filename = 'workspace-github-repositories.csv'
): void {
  const categoryNameById = new Map(categories.map((c) => [c.id, c.name]));

  const headers = [
    'Repository Name',
    'Full Name',
    'GitHub URL',
    'Description',
    'Categories',
    'Language',
    'Stars',
    'Forks',
    'Open Issues',
    'Created Date',
    'Updated Date',
    'Pushed Date',
    'License',
  ];

  const rows = repos.map((repo) => {
    const assoc = associations[repo.id];
    const catNames = (assoc?.categoryIds || [])
      .map((id) => categoryNameById.get(id) || id)
      .join(' | ');

    return [
      repo.name,
      repo.fullName,
      repo.htmlUrl,
      repo.description || '',
      catNames,
      repo.language || '',
      repo.stargazersCount,
      repo.forksCount,
      repo.openIssuesCount,
      repo.createdAt,
      repo.updatedAt,
      repo.pushedAt || '',
      repo.license || '',
    ]
      .map(escapeCsvCell)
      .join(',');
  });

  const csvContent = [headers.map(escapeCsvCell).join(','), ...rows].join('\r\n');
  triggerDownload(csvContent, filename, 'text/csv;charset=utf-8;');
}

export function exportCategoriesToJson(
  categories: GitHubCategory[],
  filename = 'workspace-github-categories.json'
): void {
  const payload = {
    exportedAt: new Date().toISOString(),
    schemaVersion: 1,
    categories,
  };
  triggerDownload(
    JSON.stringify(payload, null, 2),
    filename,
    'application/json;charset=utf-8;'
  );
}

export function parseImportedCategoriesJson(rawText: string): {
  categories: GitHubCategory[] | null;
  error: string | null;
} {
  try {
    const parsed = JSON.parse(rawText);
    const list = Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed?.categories)
        ? parsed.categories
        : null;

    if (!list || list.length === 0) {
      return {
        categories: null,
        error: 'JSON must contain a non-empty categories array.',
      };
    }

    const valid = list.every(
      (c: unknown) =>
        typeof c === 'object' &&
        c !== null &&
        typeof (c as GitHubCategory).id === 'string' &&
        typeof (c as GitHubCategory).name === 'string' &&
        Array.isArray((c as GitHubCategory).searchQueries)
    );

    if (!valid) {
      return {
        categories: null,
        error: 'One or more category items are missing required fields (id, name, searchQueries).',
      };
    }

    return { categories: list as GitHubCategory[], error: null };
  } catch (err) {
    return {
      categories: null,
      error: err instanceof Error ? err.message : 'Invalid JSON file.',
    };
  }
}

function triggerDownload(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
