import { loadRateLimits, saveRateLimits } from './storage';
import {
  GitHubContributorItem,
  GitHubReleaseItem,
  GitHubRepository,
  RateLimitBucket,
} from './types';

const GITHUB_API_BASE = 'https://api.github.com';
const GITHUB_API_VERSION = '2022-11-28';

export class GitHubApiError extends Error {
  status: number;
  isRateLimited: boolean;
  isValidationFailed: boolean;
  retryAfterSeconds: number | null;
  resetAt: number | null;

  constructor(
    message: string,
    opts: {
      status: number;
      isRateLimited?: boolean;
      isValidationFailed?: boolean;
      retryAfterSeconds?: number | null;
      resetAt?: number | null;
    }
  ) {
    super(message);
    this.name = 'GitHubApiError';
    this.status = opts.status;
    this.isRateLimited = Boolean(opts.isRateLimited);
    this.isValidationFailed = Boolean(opts.isValidationFailed);
    this.retryAfterSeconds = opts.retryAfterSeconds ?? null;
    this.resetAt = opts.resetAt ?? null;
  }
}

interface RawGitHubRepo {
  id: number;
  node_id: string;
  name: string;
  full_name: string;
  owner?: {
    login?: string;
    avatar_url?: string;
    html_url?: string;
  };
  html_url: string;
  description: string | null;
  language: string | null;
  stargazers_count?: number;
  watchers_count?: number;
  forks_count?: number;
  open_issues_count?: number;
  created_at: string;
  updated_at: string;
  pushed_at: string | null;
  default_branch?: string;
  topics?: string[];
  license?: { spdx_id?: string | null; name?: string | null } | null;
  archived?: boolean;
  fork?: boolean;
  visibility?: string;
}

export function normalizeGitHubRepo(
  raw: RawGitHubRepo,
  existing?: GitHubRepository
): GitHubRepository {
  const now = new Date().toISOString();
  const licenseName =
    raw.license?.spdx_id && raw.license.spdx_id !== 'NOASSERTION'
      ? raw.license.spdx_id
      : raw.license?.name || null;

  return {
    id: raw.id,
    nodeId: raw.node_id || existing?.nodeId || String(raw.id),
    name: raw.name,
    fullName: raw.full_name,
    owner: {
      login: raw.owner?.login || raw.full_name.split('/')[0] || 'unknown',
      avatarUrl: raw.owner?.avatar_url || existing?.owner.avatarUrl || '',
      htmlUrl: raw.owner?.html_url || existing?.owner.htmlUrl || '',
    },
    htmlUrl: raw.html_url,
    description: raw.description ?? null,
    language: raw.language ?? null,
    stargazersCount: raw.stargazers_count ?? 0,
    watchersCount: raw.watchers_count ?? 0,
    forksCount: raw.forks_count ?? 0,
    openIssuesCount: raw.open_issues_count ?? 0,
    createdAt: raw.created_at,
    updatedAt: raw.updated_at,
    pushedAt: raw.pushed_at ?? null,
    defaultBranch: raw.default_branch || 'main',
    topics: Array.isArray(raw.topics) ? raw.topics : [],
    license: licenseName,
    archived: Boolean(raw.archived),
    fork: Boolean(raw.fork),
    visibility: raw.visibility || 'public',
    discoveredAt: existing?.discoveredAt || now,
    lastRefreshedAt: now,
  };
}

function updateRateLimitFromHeaders(
  resource: 'search' | 'core',
  headers: Headers
): RateLimitBucket {
  const limitHeader = headers.get('X-RateLimit-Limit');
  const remainingHeader = headers.get('X-RateLimit-Remaining');
  const resetHeader = headers.get('X-RateLimit-Reset');
  const retryAfterHeader = headers.get('Retry-After');

  const current = loadRateLimits();
  const prev = current[resource];

  const bucket: RateLimitBucket = {
    resource,
    limit: limitHeader !== null ? Number(limitHeader) : prev.limit,
    remaining: remainingHeader !== null ? Number(remainingHeader) : prev.remaining,
    resetAt: resetHeader !== null ? Number(resetHeader) * 1000 : prev.resetAt,
    retryAfterSeconds: retryAfterHeader !== null ? Number(retryAfterHeader) : null,
    updatedAt: new Date().toISOString(),
  };

  saveRateLimits({
    ...current,
    [resource]: bucket,
  });

  return bucket;
}

function isBucketBlocked(resource: 'search' | 'core'): {
  blocked: boolean;
  resetAt: number | null;
} {
  const limits = loadRateLimits();
  const bucket = limits[resource];
  if (
    bucket.remaining !== null &&
    bucket.remaining <= 0 &&
    bucket.resetAt !== null &&
    Date.now() < bucket.resetAt
  ) {
    return { blocked: true, resetAt: bucket.resetAt };
  }
  return { blocked: false, resetAt: null };
}

async function githubFetchJson<T>(
  path: string,
  resource: 'search' | 'core',
  attempt = 0
): Promise<T> {
  const blockCheck = isBucketBlocked(resource);
  if (blockCheck.blocked) {
    const secs = blockCheck.resetAt
      ? Math.max(1, Math.ceil((blockCheck.resetAt - Date.now()) / 1000))
      : 60;
    throw new GitHubApiError(
      `GitHub ${resource} rate limit reached. Retry in ${secs}s.`,
      {
        status: 429,
        isRateLimited: true,
        retryAfterSeconds: secs,
        resetAt: blockCheck.resetAt,
      }
    );
  }

  const response = await fetch(`${GITHUB_API_BASE}${path}`, {
    method: 'GET',
    headers: {
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': GITHUB_API_VERSION,
    },
  });

  const bucket = updateRateLimitFromHeaders(resource, response.headers);

  if (response.ok) {
    return (await response.json()) as T;
  }

  let apiMessage = `GitHub API returned HTTP ${response.status}`;
  try {
    const errBody = (await response.json()) as { message?: string };
    if (errBody?.message) apiMessage = errBody.message;
  } catch {
    // Ignore non-JSON error body
  }

  // Handle rate limits (403 with remaining=0 or Retry-After, or 429) — NEVER retry aggressively
  if (
    response.status === 429 ||
    (response.status === 403 &&
      (bucket.remaining === 0 ||
        bucket.retryAfterSeconds !== null ||
        apiMessage.toLowerCase().includes('rate limit')))
  ) {
    throw new GitHubApiError(apiMessage, {
      status: response.status,
      isRateLimited: true,
      retryAfterSeconds: bucket.retryAfterSeconds,
      resetAt: bucket.resetAt,
    });
  }

  // Invalid query / validation failure (422) — NEVER retry invalid query
  if (response.status === 422) {
    throw new GitHubApiError(`Validation failed: ${apiMessage}`, {
      status: 422,
      isValidationFailed: true,
    });
  }

  // Not found (404) or forbidden (403)
  if (response.status === 404 || response.status === 403) {
    throw new GitHubApiError(apiMessage, { status: response.status });
  }

  // Transient 500 / 502 / 503 with bounded exponential backoff (max 2 retries)
  if (response.status >= 500 && attempt < 2) {
    const delayMs = 600 * Math.pow(2, attempt);
    await new Promise((r) => window.setTimeout(r, delayMs));
    return githubFetchJson<T>(path, resource, attempt + 1);
  }

  throw new GitHubApiError(apiMessage, { status: response.status });
}

export async function searchGitHubRepositories(params: {
  q: string;
  sort?: 'stars' | 'updated' | 'forks';
  order?: 'asc' | 'desc';
  perPage?: number;
  page?: number;
}): Promise<{
  items: GitHubRepository[];
  totalCount: number;
  incompleteResults: boolean;
}> {
  const qs = new URLSearchParams({
    q: params.q,
    sort: params.sort || 'stars',
    order: params.order || 'desc',
    per_page: String(Math.min(100, Math.max(1, params.perPage || 30))),
    page: String(Math.max(1, params.page || 1)),
  });

  const data = await githubFetchJson<{
    total_count: number;
    incomplete_results: boolean;
    items: RawGitHubRepo[];
  }>(`/search/repositories?${qs.toString()}`, 'search');

  return {
    items: (data.items || []).map((item) => normalizeGitHubRepo(item)),
    totalCount: data.total_count || 0,
    incompleteResults: Boolean(data.incomplete_results),
  };
}

export async function fetchGitHubRepo(
  owner: string,
  repo: string
): Promise<GitHubRepository> {
  const raw = await githubFetchJson<RawGitHubRepo>(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`,
    'core'
  );
  return normalizeGitHubRepo(raw);
}

export async function fetchGitHubRepoLanguages(
  owner: string,
  repo: string
): Promise<Record<string, number>> {
  return githubFetchJson<Record<string, number>>(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/languages`,
    'core'
  );
}

export async function fetchGitHubRepoReleases(
  owner: string,
  repo: string
): Promise<GitHubReleaseItem[]> {
  const raw = await githubFetchJson<
    Array<{
      id: number;
      tag_name: string;
      name: string | null;
      published_at: string | null;
      prerelease: boolean;
      html_url: string;
      body: string | null;
    }>
  >(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/releases?per_page=15`,
    'core'
  );

  return (raw || []).map((r) => ({
    id: r.id,
    tagName: r.tag_name,
    name: r.name,
    publishedAt: r.published_at,
    prerelease: Boolean(r.prerelease),
    htmlUrl: r.html_url,
    body: r.body,
  }));
}

export async function fetchGitHubRepoContributors(
  owner: string,
  repo: string
): Promise<GitHubContributorItem[]> {
  const raw = await githubFetchJson<
    Array<{
      id: number;
      login: string;
      avatar_url: string;
      html_url: string;
      contributions: number;
    }>
  >(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contributors?per_page=18`,
    'core'
  );

  return (raw || []).map((c) => ({
    id: c.id,
    login: c.login,
    avatarUrl: c.avatar_url,
    htmlUrl: c.html_url,
    contributions: c.contributions,
  }));
}

export async function fetchGitHubRepoReadme(
  owner: string,
  repo: string
): Promise<string | null> {
  try {
    const raw = await githubFetchJson<{ content?: string; encoding?: string }>(
      `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/readme`,
      'core'
    );
    if (!raw.content) return null;
    if (raw.encoding === 'base64') {
      const cleaned = raw.content.replace(/\s+/g, '');
      const binary = atob(cleaned);
      const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
      return new TextDecoder('utf-8').decode(bytes);
    }
    return raw.content;
  } catch (err) {
    if (err instanceof GitHubApiError && err.status === 404) {
      return null;
    }
    throw err;
  }
}
