import { createInitialCategories } from './categories';
import {
  CategoryAssociation,
  GitHubCategory,
  GitHubExplorerViewState,
  GitHubRepository,
  GitHubSettings,
  RateLimitState,
  StarSnapshot,
  SyncHistoryEntry,
} from './types';

export const GITHUB_STORAGE_KEYS = {
  SCHEMA_VERSION: 'workspace_github_schema_version',
  REPOSITORIES: 'workspace_github_repositories',
  CATEGORIES: 'workspace_github_categories',
  SAVED: 'workspace_github_saved',
  SETTINGS: 'workspace_github_settings',
  SYNC_HISTORY: 'workspace_github_sync_history',
  STAR_SNAPSHOTS: 'workspace_github_star_snapshots',
  ASSOCIATIONS: 'workspace_github_category_associations',
  RATE_LIMITS: 'workspace_github_rate_limits',
  VIEW_STATE: 'workspace_github_view_state',
} as const;

const CURRENT_SCHEMA_VERSION = 1;
const MAX_HISTORY_ITEMS = 120;
const MAX_SNAPSHOTS_PER_REPO = 10;

export function getDefaultSettings(): GitHubSettings {
  return {
    autoRefreshEnabled: true,
    defaultRefreshIntervalMinutes: 180,
    defaultCreatedWithinDays: 30,
    defaultUpdatedWithinDays: 30,
    defaultMinimumStars: 0,
    defaultMaximumResults: 30,
    defaultSort: 'stars',
    defaultView: 'grid',
  };
}

export function getDefaultRateLimits(): RateLimitState {
  return {
    search: {
      resource: 'search',
      limit: null,
      remaining: null,
      resetAt: null,
      retryAfterSeconds: null,
      updatedAt: null,
    },
    core: {
      resource: 'core',
      limit: null,
      remaining: null,
      resetAt: null,
      retryAfterSeconds: null,
      updatedAt: null,
    },
  };
}

export function getDefaultViewState(): GitHubExplorerViewState {
  return {
    subTab: 'discover',
    viewMode: 'grid',
    searchQuery: '',
    selectedCategoryIds: [],
    sortBy: 'stars',
    sortOrder: 'desc',
    languageFilter: 'all',
    recentWindow: '30d',
    customDateFrom: '',
    customDateTo: '',
    minStarsFilter: 0,
    page: 1,
  };
}

function safeReadJson<T>(key: string, fallback: T, validate?: (v: unknown) => v is T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed: unknown = JSON.parse(raw);
    if (validate && !validate(parsed)) return fallback;
    return parsed as T;
  } catch {
    return fallback;
  }
}

function safeWriteJson(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Handle quota exceeded cleanly: trim sync history first and retry
    try {
      const history = safeReadJson<SyncHistoryEntry[]>(
        GITHUB_STORAGE_KEYS.SYNC_HISTORY,
        [],
        Array.isArray
      );
      if (history.length > 30) {
        localStorage.setItem(
          GITHUB_STORAGE_KEYS.SYNC_HISTORY,
          JSON.stringify(history.slice(0, 30))
        );
      }
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Ignore unrecoverable storage quota errors
    }
  }
}

export function ensureGitHubStorageSchema(): void {
  try {
    const verRaw = localStorage.getItem(GITHUB_STORAGE_KEYS.SCHEMA_VERSION);
    const ver = verRaw ? Number(verRaw) : 0;
    if (!ver || ver < CURRENT_SCHEMA_VERSION) {
      localStorage.setItem(
        GITHUB_STORAGE_KEYS.SCHEMA_VERSION,
        String(CURRENT_SCHEMA_VERSION)
      );
    }
  } catch {
    // Ignore storage failure
  }
}

export function loadRepositories(): GitHubRepository[] {
  ensureGitHubStorageSchema();
  return safeReadJson<GitHubRepository[]>(
    GITHUB_STORAGE_KEYS.REPOSITORIES,
    [],
    (v): v is GitHubRepository[] => Array.isArray(v)
  );
}

export function saveRepositories(repos: GitHubRepository[]): void {
  safeWriteJson(GITHUB_STORAGE_KEYS.REPOSITORIES, repos);
}

export function loadCategories(): GitHubCategory[] {
  ensureGitHubStorageSchema();
  const stored = safeReadJson<GitHubCategory[]>(
    GITHUB_STORAGE_KEYS.CATEGORIES,
    [],
    (v): v is GitHubCategory[] => Array.isArray(v) && v.length > 0
  );
  if (stored.length === 0) {
    const initial = createInitialCategories();
    saveCategories(initial);
    return initial;
  }
  return stored;
}

export function saveCategories(categories: GitHubCategory[]): void {
  safeWriteJson(GITHUB_STORAGE_KEYS.CATEGORIES, categories);
}

export function loadAssociations(): Record<number, CategoryAssociation> {
  return safeReadJson<Record<number, CategoryAssociation>>(
    GITHUB_STORAGE_KEYS.ASSOCIATIONS,
    {},
    (v): v is Record<number, CategoryAssociation> =>
      typeof v === 'object' && v !== null && !Array.isArray(v)
  );
}

export function saveAssociations(assoc: Record<number, CategoryAssociation>): void {
  safeWriteJson(GITHUB_STORAGE_KEYS.ASSOCIATIONS, assoc);
}

export function loadSavedRepoIds(): number[] {
  return safeReadJson<number[]>(
    GITHUB_STORAGE_KEYS.SAVED,
    [],
    (v): v is number[] => Array.isArray(v)
  );
}

export function saveSavedRepoIds(ids: number[]): void {
  safeWriteJson(GITHUB_STORAGE_KEYS.SAVED, Array.from(new Set(ids)));
}

export function loadSettings(): GitHubSettings {
  const defaults = getDefaultSettings();
  const stored = safeReadJson<Partial<GitHubSettings>>(
    GITHUB_STORAGE_KEYS.SETTINGS,
    defaults,
    (v): v is Partial<GitHubSettings> =>
      typeof v === 'object' && v !== null && !Array.isArray(v)
  );
  return { ...defaults, ...stored };
}

export function saveSettings(settings: GitHubSettings): void {
  safeWriteJson(GITHUB_STORAGE_KEYS.SETTINGS, settings);
}

export function loadSyncHistory(): SyncHistoryEntry[] {
  return safeReadJson<SyncHistoryEntry[]>(
    GITHUB_STORAGE_KEYS.SYNC_HISTORY,
    [],
    (v): v is SyncHistoryEntry[] => Array.isArray(v)
  );
}

export function appendSyncHistory(entries: SyncHistoryEntry[]): void {
  const existing = loadSyncHistory();
  const merged = [...entries, ...existing].slice(0, MAX_HISTORY_ITEMS);
  safeWriteJson(GITHUB_STORAGE_KEYS.SYNC_HISTORY, merged);
}

export function clearSyncHistoryStorage(): void {
  safeWriteJson(GITHUB_STORAGE_KEYS.SYNC_HISTORY, []);
}

export function loadStarSnapshots(): Record<number, StarSnapshot[]> {
  return safeReadJson<Record<number, StarSnapshot[]>>(
    GITHUB_STORAGE_KEYS.STAR_SNAPSHOTS,
    {},
    (v): v is Record<number, StarSnapshot[]> =>
      typeof v === 'object' && v !== null && !Array.isArray(v)
  );
}

export function recordStarSnapshots(repos: GitHubRepository[]): void {
  if (repos.length === 0) return;
  const snapshots = loadStarSnapshots();
  const now = new Date().toISOString();

  repos.forEach((repo) => {
    const list = snapshots[repo.id] || [];
    const last = list[list.length - 1];
    // Record if no prior snapshot or stars changed or > 30 mins elapsed
    const elapsedMs = last ? Date.now() - new Date(last.capturedAt).getTime() : Infinity;
    if (!last || last.stars !== repo.stargazersCount || elapsedMs > 30 * 60 * 1000) {
      const next = [
        ...list,
        { repoId: repo.id, stars: repo.stargazersCount, capturedAt: now },
      ].slice(-MAX_SNAPSHOTS_PER_REPO);
      snapshots[repo.id] = next;
    }
  });

  safeWriteJson(GITHUB_STORAGE_KEYS.STAR_SNAPSHOTS, snapshots);
}

export function loadRateLimits(): RateLimitState {
  const defaults = getDefaultRateLimits();
  const stored = safeReadJson<Partial<RateLimitState>>(
    GITHUB_STORAGE_KEYS.RATE_LIMITS,
    defaults,
    (v): v is Partial<RateLimitState> =>
      typeof v === 'object' && v !== null && !Array.isArray(v)
  );
  return {
    search: { ...defaults.search, ...(stored.search || {}) },
    core: { ...defaults.core, ...(stored.core || {}) },
  };
}

export function saveRateLimits(rateLimits: RateLimitState): void {
  safeWriteJson(GITHUB_STORAGE_KEYS.RATE_LIMITS, rateLimits);
}

export function loadExplorerViewState(): GitHubExplorerViewState {
  try {
    const raw = sessionStorage.getItem(GITHUB_STORAGE_KEYS.VIEW_STATE);
    if (!raw) return getDefaultViewState();
    const parsed = JSON.parse(raw);
    return { ...getDefaultViewState(), ...parsed };
  } catch {
    return getDefaultViewState();
  }
}

export function saveExplorerViewState(state: GitHubExplorerViewState): void {
  try {
    sessionStorage.setItem(GITHUB_STORAGE_KEYS.VIEW_STATE, JSON.stringify(state));
  } catch {
    // Ignore sessionStorage errors
  }
}

export function clearRepositoryCacheStorage(): void {
  safeWriteJson(GITHUB_STORAGE_KEYS.REPOSITORIES, []);
  safeWriteJson(GITHUB_STORAGE_KEYS.ASSOCIATIONS, {});
  safeWriteJson(GITHUB_STORAGE_KEYS.STAR_SNAPSHOTS, {});
  const categories = loadCategories().map((cat) => ({
    ...cat,
    lastSyncedAt: null,
    lastSyncStatus: 'idle' as const,
    lastSyncError: null,
    repositoryCount: 0,
  }));
  saveCategories(categories);
}

export function resetCategoriesToDefault(): GitHubCategory[] {
  const initial = createInitialCategories();
  saveCategories(initial);
  return initial;
}
