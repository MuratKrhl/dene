import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { PodcastEpisode } from '../types/technology';
import { techStorage } from '../services/technology/techStorage';
import { updateEpisodePlaybackPosition } from '../services/technology/syncEngine';
import {
  fetchMediaPodcasts,
  patchMediaPodcastEpisode,
} from '../services/techMediaApi';

async function persistEpisodePosition(
  episodeId: string,
  positionSeconds: number,
  markPlayed: boolean
): Promise<void> {
  if (episodeId.startsWith('mep-')) {
    await patchMediaPodcastEpisode(episodeId, {
      playbackPosition: Math.floor(positionSeconds),
      ...(markPlayed ? { isPlayed: true } : {}),
    }).catch(() => undefined);
    return;
  }
  await updateEpisodePlaybackPosition(episodeId, positionSeconds, markPlayed);
}

interface PodcastPlayerContextValue {
  currentEpisode: PodcastEpisode | null;
  queue: PodcastEpisode[];
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  playbackRate: number;
  audioError: string | null;
  playEpisode: (episode: PodcastEpisode, queueEpisodes?: PodcastEpisode[]) => void;
  togglePlayPause: () => void;
  seekTo: (seconds: number) => void;
  setVolume: (volume: number) => void;
  setPlaybackRate: (rate: number) => void;
  playNext: () => void;
  playPrevious: () => void;
  closePlayer: () => void;
}

const PodcastPlayerContext = createContext<PodcastPlayerContextValue | null>(
  null
);

export const PodcastPlayerProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const lastSavedPosRef = useRef<number>(0);

  const [currentEpisode, setCurrentEpisode] = useState<PodcastEpisode | null>(
    null
  );
  const [queue, setQueue] = useState<PodcastEpisode[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(0.9);
  const [playbackRate, setPlaybackRateState] = useState(1);
  const [audioError, setAudioError] = useState<string | null>(null);

  // Restore last active podcast episode & position on Workspace open
  useEffect(() => {
    let active = true;
    techStorage.init().then(async () => {
      if (!active) return;
      const playerState = techStorage.getPlayerState();
      setVolumeState(playerState.volume ?? 0.9);
      setPlaybackRateState(playerState.playbackRate ?? 1);
      if (playerState.currentEpisodeId) {
        let episodes = techStorage.getPodcastEpisodes();
        let found = episodes.find(
          (e) => e.id === playerState.currentEpisodeId
        );
        if (!found && playerState.currentEpisodeId.startsWith('mep-')) {
          try {
            const media = await fetchMediaPodcasts();
            episodes = media.episodes;
            found = episodes.find(
              (e) => e.id === playerState.currentEpisodeId
            );
          } catch {
            // ignore backend lookup errors during startup
          }
        }
        if (found && active) {
          setCurrentEpisode(found);
          setCurrentTime(found.playbackPosition || 0);
          setDuration(found.durationSeconds || 0);
          setQueue(episodes.filter((e) => e.seriesId === found!.seriesId));
        }
      }
    });
    return () => {
      active = false;
    };
  }, []);

  // Create persistent HTMLAudioElement once
  useEffect(() => {
    const audio = new Audio();
    audio.preload = 'metadata';
    audioRef.current = audio;

    return () => {
      audio.pause();
      audio.src = '';
    };
  }, []);

  // Bind audio element listeners to currentEpisode state
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      const pos = audio.currentTime || 0;
      setCurrentTime(pos);
      if (currentEpisode && Math.abs(pos - lastSavedPosRef.current) >= 4) {
        lastSavedPosRef.current = pos;
        void persistEpisodePosition(currentEpisode.id, pos, false);
      }
    };

    const handleLoadedMetadata = () => {
      if (Number.isFinite(audio.duration) && audio.duration > 0) {
        setDuration(audio.duration);
      }
      if (currentEpisode?.playbackPosition && currentEpisode.playbackPosition > 2) {
        const target =
          Number.isFinite(audio.duration) &&
          currentEpisode.playbackPosition < audio.duration - 2
            ? currentEpisode.playbackPosition
            : 0;
        if (target > 0) {
          audio.currentTime = target;
          setCurrentTime(target);
        }
      }
    };

    const handleEnded = () => {
      setIsPlaying(false);
      if (currentEpisode) {
        void persistEpisodePosition(
          currentEpisode.id,
          audio.duration || currentTime,
          true
        );
      }
    };

    const handleError = () => {
      setIsPlaying(false);
      setAudioError(
        'Direct audio playback was blocked by the podcast host or browser codec policy. Open the original episode page to listen.'
      );
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [currentEpisode, currentTime]);

  const playEpisode = useCallback(
    (episode: PodcastEpisode, queueEpisodes?: PodcastEpisode[]) => {
      const audio = audioRef.current;
      setAudioError(null);
      setCurrentEpisode(episode);
      if (queueEpisodes && queueEpisodes.length > 0) {
        setQueue(queueEpisodes);
      } else {
        setQueue((prev) =>
          prev.some((e) => e.id === episode.id) ? prev : [episode, ...prev]
        );
      }

      void techStorage.savePlayerState({
        currentEpisodeId: episode.id,
        currentSeriesId: episode.seriesId,
        volume,
        playbackRate,
        lastUpdatedAt: new Date().toISOString(),
      });

      if (!episode.audioUrl) {
        if (audio) audio.pause();
        setIsPlaying(false);
        setAudioError(
          'This episode RSS entry does not expose a direct audio enclosure URL. Open the original episode page.'
        );
        return;
      }

      if (!audio) return;
      if (audio.src !== episode.audioUrl) {
        audio.src = episode.audioUrl;
        audio.load();
      }
      audio.volume = volume;
      audio.playbackRate = playbackRate;
      lastSavedPosRef.current = episode.playbackPosition || 0;
      setCurrentTime(episode.playbackPosition || 0);
      setDuration(episode.durationSeconds || 0);

      audio
        .play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch(() => {
          setIsPlaying(false);
          setAudioError(
            'Unable to stream audio directly in this browser context. Open the original episode link below.'
          );
        });
    },
    [playbackRate, volume]
  );

  const togglePlayPause = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || !currentEpisode) return;
    if (!currentEpisode.audioUrl) {
      setAudioError(
        'No direct audio enclosure URL available. Use Open Original Episode.'
      );
      return;
    }
    if (audio.src !== currentEpisode.audioUrl) {
      playEpisode(currentEpisode);
      return;
    }
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
      void persistEpisodePosition(
        currentEpisode.id,
        audio.currentTime || currentTime,
        false
      );
    } else {
      setAudioError(null);
      audio.volume = volume;
      audio.playbackRate = playbackRate;
      audio
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => {
          setIsPlaying(false);
          setAudioError(
            'Playback blocked or unavailable from host. Open original episode page to listen.'
          );
        });
    }
  }, [currentEpisode, currentTime, isPlaying, playEpisode, playbackRate, volume]);

  const seekTo = useCallback(
    (seconds: number) => {
      const audio = audioRef.current;
      const clamped = Math.max(0, Math.min(seconds, duration || seconds));
      setCurrentTime(clamped);
      if (audio && Number.isFinite(clamped)) {
        audio.currentTime = clamped;
      }
      if (currentEpisode) {
        lastSavedPosRef.current = clamped;
        void persistEpisodePosition(currentEpisode.id, clamped, false);
      }
    },
    [currentEpisode, duration]
  );

  const setVolume = useCallback(
    (nextVol: number) => {
      const clamped = Math.max(0, Math.min(1, nextVol));
      setVolumeState(clamped);
      if (audioRef.current) audioRef.current.volume = clamped;
      void techStorage.savePlayerState({
        currentEpisodeId: currentEpisode?.id || null,
        currentSeriesId: currentEpisode?.seriesId || null,
        volume: clamped,
        playbackRate,
        lastUpdatedAt: new Date().toISOString(),
      });
    },
    [currentEpisode, playbackRate]
  );

  const setPlaybackRate = useCallback(
    (rate: number) => {
      setPlaybackRateState(rate);
      if (audioRef.current) audioRef.current.playbackRate = rate;
      void techStorage.savePlayerState({
        currentEpisodeId: currentEpisode?.id || null,
        currentSeriesId: currentEpisode?.seriesId || null,
        volume,
        playbackRate: rate,
        lastUpdatedAt: new Date().toISOString(),
      });
    },
    [currentEpisode, volume]
  );

  const playNext = useCallback(() => {
    if (!currentEpisode || queue.length === 0) return;
    const idx = queue.findIndex((e) => e.id === currentEpisode.id);
    if (idx >= 0 && idx + 1 < queue.length) {
      playEpisode(queue[idx + 1], queue);
    }
  }, [currentEpisode, playEpisode, queue]);

  const playPrevious = useCallback(() => {
    if (!currentEpisode || queue.length === 0) return;
    const idx = queue.findIndex((e) => e.id === currentEpisode.id);
    if (idx > 0) {
      playEpisode(queue[idx - 1], queue);
    }
  }, [currentEpisode, playEpisode, queue]);

  const closePlayer = useCallback(() => {
    const audio = audioRef.current;
    if (audio) {
      if (currentEpisode) {
        void persistEpisodePosition(
          currentEpisode.id,
          audio.currentTime || currentTime,
          false
        );
      }
      audio.pause();
    }
    setIsPlaying(false);
    setCurrentEpisode(null);
    setAudioError(null);
    void techStorage.savePlayerState({
      currentEpisodeId: null,
      currentSeriesId: null,
      volume,
      playbackRate,
      lastUpdatedAt: new Date().toISOString(),
    });
  }, [currentEpisode, currentTime, playbackRate, volume]);

  const value = useMemo<PodcastPlayerContextValue>(
    () => ({
      currentEpisode,
      queue,
      isPlaying,
      currentTime,
      duration,
      volume,
      playbackRate,
      audioError,
      playEpisode,
      togglePlayPause,
      seekTo,
      setVolume,
      setPlaybackRate,
      playNext,
      playPrevious,
      closePlayer,
    }),
    [
      audioError,
      closePlayer,
      currentEpisode,
      currentTime,
      duration,
      isPlaying,
      playEpisode,
      playNext,
      playPrevious,
      playbackRate,
      queue,
      seekTo,
      setPlaybackRate,
      setVolume,
      togglePlayPause,
      volume,
    ]
  );

  return (
    <PodcastPlayerContext.Provider value={value}>
      {children}
    </PodcastPlayerContext.Provider>
  );
};

export function usePodcastPlayer(): PodcastPlayerContextValue {
  const ctx = useContext(PodcastPlayerContext);
  if (!ctx) {
    throw new Error('usePodcastPlayer must be used within PodcastPlayerProvider');
  }
  return ctx;
}
